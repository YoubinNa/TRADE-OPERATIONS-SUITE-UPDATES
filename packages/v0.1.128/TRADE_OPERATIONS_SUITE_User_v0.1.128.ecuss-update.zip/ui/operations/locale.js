const localeTags={ko:'ko-KR',en:'en-US',vi:'vi-VN'};
const languageNames={ko:'한국어',en:'English',vi:'Tiếng Việt'};
const terms=new Map();
function addTerms(lines) {
  for(const row of lines.trim().split('\n')){
    const [ko,en,vi]=row.split('|');
    if(!ko||!en||!vi)throw new Error('Incomplete language entry: '+ko);
    terms.set(ko,{ko,en,vi});
  }
}
for(const m of DATA.mods){
  if(m.names)terms.set(m.title,m.names);
  if(m.descriptions)terms.set(m.description,m.descriptions);
}
addTerms(`
홈 화면|Home|Trang chủ
홈|Home|Trang chủ
현황판|Dashboards|Bảng theo dõi
업무 도구|Work tools|Công cụ
업무 카테고리|Work categories|Nhóm nghiệp vụ
업무 현황판|Operations overview|Tổng quan nghiệp vụ
무역 업무 통합 프로그램|Trade operations suite|Bộ công cụ nghiệp vụ
본문으로 이동|Skip to content|Đến nội dung chính
업무 탐색|Workspace navigation|Điều hướng nghiệp vụ
업무 탐색 닫기|Close navigation|Đóng điều hướng
업무 탐색 열기|Open navigation|Mở điều hướng
메인 화면으로|Go to home|Về trang chủ
홈으로 돌아가기|Back to home|Về trang chủ
메인 메뉴|Main navigation|Điều hướng chính
표시 언어|Display language|Ngôn ngữ hiển thị
화면 테마|Color theme|Giao diện
배율|Zoom|Thu phóng
축소|Zoom out|Thu nhỏ
확대|Zoom in|Phóng to
100% 복원|Reset to 100%|Đặt lại 100%
텍스트 크기|Text size|Cỡ chữ
기본|Standard|Chuẩn
크게|Large|Lớn
메뉴와 모듈 목록의 텍스트 크기|Text size of menus and module lists|Cỡ chữ của menu và danh sách mô-đun
메뉴, 모듈 목록과 검증 현황의 텍스트 크기|Text size of menus, module lists and verification status|Cỡ chữ của menu, danh sách mô-đun và tình trạng kiểm tra
다크|Dark|Tối
라이트|Light|Sáng
설정 · 검토 정보|Settings & review notes|Cài đặt và thông tin
개인 작업 공간|Personal workspace|Không gian cá nhân
검토 사용자 전환|Switch review profile|Chuyển hồ sơ xem thử
업무 또는 자료 검색|Search tools or data|Tìm công cụ hoặc dữ liệu
즐겨찾기|Favorites|Yêu thích
예제 자료의 출처와 기준|Sample data sources and methods|Nguồn và cách tính dữ liệu mẫu
예제 자료|Sample data|Dữ liệu mẫu
업무 요약|Operations summary|Tóm tắt nghiệp vụ
두 법인의 수출입·물류비·재고와 검증 현황|Trade, logistics costs, inventory and checks across both companies|Xuất nhập khẩu, chi phí logistics, tồn kho và kiểm tra của hai công ty
현황판 편집|Edit overview|Chỉnh tổng quan
표시할 요약을 선택하세요.|Choose which summaries to display.|Chọn nội dung tóm tắt để hiển thị.
조회할 모듈을 선택하세요.|Select a module to explore its data.|Chọn mô-đun để xem dữ liệu.
검토·계산·변환에 사용하는 도구|Tools for review, calculation and conversion|Công cụ kiểm tra, tính toán và chuyển đổi
검증, 재고 취합과 월간 보고 업무|Validation, inventory consolidation and monthly reporting|Kiểm tra, tổng hợp tồn kho và báo cáo tháng
전체 업무|All categories|Tất cả
Balance Sheet 검증|Balance sheet checks|Kiểm tra Balance Sheet
재고 취합|Inventory consolidation|Tổng hợp tồn kho
업무 카테고리 선택|Filter work categories|Lọc nhóm nghiệp vụ
현황판 모듈|Dashboard modules|Các mô-đun theo dõi
검증 현황|Verification status|Tình trạng kiểm tra
외부 현황판|External dashboards|Bảng theo dõi bên ngoài
베트남 도착 화물 정보|Vietnam cargo arrivals|Hàng hóa đến Việt Nam
베트남 법인 임가공비 현황|Vietnam processing fees|Phí gia công tại Việt Nam
법인별 일일 밸런스 시트 검증 수행 여부를 확인합니다.|Check whether each company completed its daily balance sheet validation.|Xem từng công ty đã hoàn tất kiểm tra Balance Sheet hằng ngày hay chưa.
주간·월간 세관 자료 확인 요청 메일의 발송 여부를 확인합니다.|See whether weekly and monthly customs data verification emails were sent.|Xem tình trạng gửi email yêu cầu xác nhận dữ liệu hải quan theo tuần và tháng.
베트남 도착 화물 조회 페이지를 엽니다.|Look up shipments arriving in Vietnam.|Tra cứu các lô hàng đến Việt Nam.
베트남 법인의 임가공비 현황을 새 창에서 조회합니다.|View processing fees for the Vietnam companies in a new window.|Xem phí gia công của các công ty tại Việt Nam trong cửa sổ mới.
새 창에서 열기|Open in a new window|Mở trong cửa sổ mới
순서 편집|Edit order|Sắp xếp
같은 분류 안에서 항목을 끌거나 화살표로 옮기세요.|Drag items or use the arrows to reorder them within each group.|Kéo mục hoặc dùng mũi tên để đổi thứ tự trong từng nhóm.
위로 이동|Move up|Di chuyển lên
아래로 이동|Move down|Di chuyển xuống
끌어서 이동|Drag to move|Kéo để di chuyển
기본 순서|Default order|Thứ tự mặc định
순서 저장|Save order|Lưu thứ tự
모듈 순서를 저장했습니다.|Module order saved.|Đã lưu thứ tự mô-đun.
이 창에서 모듈 순서를 유지합니다.|Module order will be kept in this window.|Thứ tự mô-đun được giữ trong cửa sổ này.
이 창에서 선택한 설정을 유지합니다.|Your preferences will be kept in this window.|Cài đặt của bạn được giữ trong cửa sổ này.
즐겨찾는 업무를 추가하세요|Add your favorite tools|Thêm công cụ yêu thích
목록에서 별표를 누르면 여기에 모입니다.|Select the star next to a tool to keep it here.|Chọn dấu sao cạnh công cụ để lưu vào đây.
업무 도구로|Browse tools|Xem công cụ
이 창에서 즐겨찾기를 유지합니다.|Favorites will be kept in this window.|Mục yêu thích được giữ trong cửa sổ này.
닫기|Close|Đóng
취소|Cancel|Hủy
수출입 실적|Import & export performance|Kết quả xuất nhập khẩu
법인·거래 방향·기간별 실적과 ITEM별 금액, 인보이스 상세를 조회합니다.|View trade by company, direction and period, with item values and invoice details.|Xem kết quả theo công ty, chiều giao dịch và kỳ, cùng giá trị từng mặt hàng và chi tiết hóa đơn.
월별 물류비 현황|Monthly logistics costs|Chi phí logistics hằng tháng
과부족 현황|Stock surplus & shortage|Tồn kho thừa và thiếu
밸런스 시트 검증 현황|Balance sheet verification|Kiểm tra Balance Sheet
세관 자료 검증 현황|Customs data verification|Kiểm tra dữ liệu hải quan
세관 자료 대조|Customs reconciliation|Đối chiếu dữ liệu hải quan
컨테이너 적입 결과|Container loading results|Kết quả xếp container
출하 가능 수량|Shipment capacity|Số lượng có thể xuất
세관 검수비용 비교|Inspection cost comparison|So sánh chi phí kiểm tra
통관·보고 산출물|Customs & reporting outputs|Kết quả khai quan và báo cáo
월별 비교 그래프|Monthly comparison|Biểu đồ so sánh theo tháng
비용 추이 그래프|Cost trend|Biểu đồ xu hướng chi phí
법인별 과잉·부족 금액|Surplus and shortage by company|Giá trị thừa thiếu theo công ty
법인별 일일 검증 수행|Daily checks by company|Kiểm tra hằng ngày theo công ty
주간·월간 확인 요청 메일 발송|Weekly and monthly verification emails|Email yêu cầu xác nhận theo tuần và tháng
검증 상태 도넛|Reconciliation chart|Biểu đồ trạng thái đối chiếu
적입 수량 인포그래픽|Loading quantities|Số lượng xếp hàng
자재 소요량 인포그래픽|Materials required|Nhu cầu nguyên liệu
비용 비교 그래프|Cost comparison|Biểu đồ so sánh chi phí
업무별 결과 안내|Outputs by workflow|Kết quả theo nghiệp vụ
연결된 모듈 열기|Open linked module|Mở mô-đun liên kết
수출입 법인|Trading company|Công ty xuất nhập khẩu
전체 법인|All companies|Tất cả công ty
수출입 조회 기간|Reporting period|Kỳ báo cáo
9개월|9 months|9 tháng
6개월|6 months|6 tháng
3개월|3 months|3 tháng
월별 표와 집계 기준|Monthly data and counting method|Số liệu theo tháng và cách tính
수출 인보이스|Export invoices|Hóa đơn xuất khẩu
수입 인보이스|Import invoices|Hóa đơn nhập khẩu
건|invoices|hóa đơn
월별 수출입 인보이스 건수|Monthly export and import invoice counts|Số hóa đơn xuất nhập khẩu theo tháng
고유 인보이스 기준|Unique invoices|Hóa đơn không trùng
밸런스 시트와 세관 자료 · 자재|Balance sheet and customs records · Materials|Balance Sheet và dữ liệu hải quan · Nguyên liệu
분류 기준|Classification method|Tiêu chí phân loại
대조 그룹|Groups|Nhóm đối chiếu
미해결|Unresolved|Chưa xử lý
월 이월|Carried over|Chuyển tháng
일치|Matched|Khớp
월별 물류비 내역|Monthly logistics cost details|Chi tiết chi phí logistics theo tháng
베트남 물류비|Vietnam logistics|Logistics Việt Nam
월별 베트남 물류비 추이, 단위 VND|Monthly logistics costs in Vietnam, in VND|Chi phí logistics hằng tháng tại Việt Nam, đơn vị VND
과부족 금액 기준과 표|Inventory valuation and figures|Cách tính và giá trị thừa thiếu
2026년 9월 · 법인별 재고 금액|September 2026 · Inventory value by company|Tháng 9/2026 · Giá trị tồn kho theo công ty
전체 과부족 금액|Total surplus and shortage value|Tổng giá trị thừa thiếu
과잉|Surplus|Thừa
부족|Shortage|Thiếu
컨테이너 규격|Container size|Quy cách container
규격별 기본 화물 적입 비교|Standard load by container size|So sánh lượng hàng theo quy cách container
적입 완료 화물|Units loaded|Kiện đã xếp
개|units|kiện
화물 부피|Cargo volume|Thể tích hàng
문 앞 여유|Door clearance|Khoảng trống trước cửa
제품 P1 · 자재 M1 예제|Product P1 · Material M1 example|Ví dụ sản phẩm P1 · Nguyên liệu M1
출하 가능 제품|Products ready to ship|Sản phẩm có thể xuất
가용 자재|Available material|Nguyên liệu khả dụng
제품 1개 소요량|Material per product|Định mức mỗi sản phẩm
일반 검수와 선택 방식 · VND|Standard vs. selected inspection · VND|Kiểm tra thông thường và phương án đã chọn · VND
선택 방식 차액|Difference for selected method|Chênh lệch của phương án đã chọn
일반 검수|Standard inspection|Kiểm tra thông thường
선택 방식|Selected method|Phương án đã chọn
원천 자료에서 연결되는 결과|Outputs from source records|Kết quả từ dữ liệu nguồn
한국어 신고서|Korean declaration|Tờ khai tiếng Hàn
베트남 세관신고서|Vietnamese customs declaration|Tờ khai hải quan Việt Nam
협정별 원산지 검토|Origin review by agreement|Kiểm tra xuất xứ theo hiệp định
월간 리포트|Monthly report|Báo cáo tháng
두 법인의 누적 자료|Cumulative records for both companies|Dữ liệu lũy kế của hai công ty
9월 30일 · 일일 검증 수행|30 Sep · Daily checks|30/9 · Kiểm tra hằng ngày
9월 30일 · 확인 요청 메일 발송|30 Sep · Verification emails|30/9 · Email yêu cầu xác nhận
완료|Complete|Hoàn tất
미완료|Pending|Chưa xong
주간 완료|Weekly sent|Tuần: đã gửi
주간 미완료|Weekly pending|Tuần: chưa gửi
월간 완료|Monthly sent|Tháng: đã gửi
월간 미완료|Monthly pending|Tháng: chưa gửi
과부족 조회 법인|Inventory company|Công ty tra cứu tồn kho
기존 화면 · 검토용 캡처|Original module screenshot|Ảnh chụp mô-đun gốc
입력|Input|Đầu vào
결과|Output|Kết quả
표시할 항목|Visible summaries|Nội dung hiển thị
빈 칸|Empty|Ô trống
배치 미리보기|Layout preview|Xem trước bố cục
끌어서 옮기거나 목록에서 위치를 선택하세요. 두 검증 현황을 같은 칸에 놓으면 함께 표시됩니다.|Drag a summary or choose its position in the list. Place both verification summaries in one cell to group them.|Kéo nội dung hoặc chọn vị trí trong danh sách. Đặt hai mục kiểm tra vào cùng ô để hiển thị chung.
기본 배치|Default layout|Bố cục mặc định
배치 저장|Save layout|Lưu bố cục
브라우저 저장 공간을 사용할 수 없어 이 창에서만 배치를 유지합니다.|Browser storage is unavailable. This layout is kept in this window.|Bộ nhớ trình duyệt không khả dụng. Bố cục được giữ trong cửa sổ này.
찾는 업무가 없습니다. 다른 업무명이나 자료명을 입력하세요.|No tools found. Try another tool or data name.|Không tìm thấy công cụ. Hãy thử tên công cụ hoặc dữ liệu khác.
업무 검색|Search tools|Tìm công cụ
업무명, 약어 또는 입력 자료명으로 찾기|Search by tool name, abbreviation or input data|Tìm theo tên công cụ, chữ viết tắt hoặc dữ liệu đầu vào
업무 검색어|Search query|Từ khóa tìm kiếm
예: 수책, 인보이스, UTM|Try inventory, invoice, UTM|Ví dụ: tồn kho, hóa đơn, UTM
↑ ↓ 이동|↑ ↓ Navigate|↑ ↓ Di chuyển
Enter 열기|Enter to open|Enter để mở
수출입 실적 · 집계 기준|Trade performance · Counting method|Xuất nhập khẩu · Cách tính
월|Month|Tháng
기간 내 고유 건수|Unique invoices in period|Hóa đơn không trùng trong kỳ
한 건을 세는 기준|How invoices are counted|Cách đếm hóa đơn
자재는 DATE, 제품은 PICK UP DATE의 거래일을 사용합니다. 원본 STATUS가 EXPORT 또는 IMPORT인 행에서 공백을 정리한 인보이스 번호를 법인과 거래 방향별로 한 번씩 셉니다. 빈 번호는 제외합니다.|Materials use DATE and products use PICK UP DATE. For rows marked EXPORT or IMPORT, invoice numbers are trimmed and counted once per company and direction. Blank numbers are excluded.|Nguyên liệu dùng DATE, sản phẩm dùng PICK UP DATE. Với các dòng EXPORT hoặc IMPORT, số hóa đơn được bỏ khoảng trắng và đếm một lần theo công ty và chiều giao dịch. Bỏ qua số trống.
전체 법인은 두 법인의 건수를 합산합니다. 여러 달에 걸친 번호는 기간 합계에서 한 번만 세므로 월별 합산과 차이가 날 수 있습니다. 이 검토판의 거래는 예제로 생성했습니다.|The combined figure adds both companies. An invoice that spans months is counted once in the period total, so monthly figures may not add up to it. Transactions in this review use sample data.|Số tổng cộng là tổng của hai công ty. Một hóa đơn xuất hiện trong nhiều tháng chỉ được đếm một lần trong kỳ nên tổng theo tháng có thể khác. Giao dịch ở bản xem thử dùng dữ liệu mẫu.
물류비 (VND)|Logistics costs (VND)|Chi phí logistics (VND)
자료 건수|Records|Số bản ghi
과부족 현황 · 금액 기준|Inventory gap · Valuation|Tồn kho thừa thiếu · Cách tính giá trị
2026년 9월 · 예제 재고 · USD|September 2026 · Sample inventory · USD|Tháng 9/2026 · Tồn kho mẫu · USD
법인|Company|Công ty
합계|Total|Tổng cộng
과부족 수량이 양수인 자재는 과잉, 음수인 자재는 부족으로 분류합니다. 금액은 재고 모듈과 같은 기준으로 자재별 과부족 금액의 절대값을 합산합니다.|Positive quantity gaps are surpluses and negative gaps are shortages. Values use the inventory module’s method: the absolute gap values are added across materials.|Chênh lệch số lượng dương là thừa, âm là thiếu. Giá trị được tính như trong mô-đun tồn kho bằng cách cộng trị tuyệt đối của chênh lệch từng nguyên liệu.
세관 자료 대조 · 분류 기준|Customs reconciliation · Classification|Đối chiếu dữ liệu hải quan · Phân loại
자재 검증 결과의 (M) DASHBOARD 예제에서 월·자재 코드·거래 상태가 같은 행을 한 그룹으로 묶습니다.|Rows in the sample (M) DASHBOARD are grouped by month, material code and transaction status.|Các dòng trong (M) DASHBOARD mẫu được nhóm theo tháng, mã nguyên liệu và trạng thái giao dịch.
분류|Classification|Phân loại
그룹 수|Groups|Số nhóm
전체|Total|Tổng
월별 불일치 16개 그룹을 미해결 14개와 월 이월 2개로 나눠 표시했습니다.|Of 16 groups with monthly differences, 14 are unresolved and 2 are carried over.|Trong 16 nhóm chênh lệch theo tháng, 14 nhóm chưa xử lý và 2 nhóm chuyển tháng.
오픈소스 라이선스|Open-source licenses|Giấy phép nguồn mở
예제 자료와 출처|Sample data and sources|Dữ liệu mẫu và nguồn
기존 프로그램 설정|Desktop app settings|Cài đặt ứng dụng
운영 프로그램에서 언어와 연결을 설정하고 업데이트를 확인할 수 있습니다.|The desktop app includes language, connection and update settings.|Ứng dụng có cài đặt ngôn ngữ, kết nối và cập nhật.
검토 자료|Review data|Dữ liệu xem thử
수출입 실적과 과부족 현황은 두 법인의 업무 구조를 본뜬 예제입니다. 물류비는 기존 모듈의 예제 원장을 사용합니다. 밸런스 시트는 일일 검증 수행 여부, 세관 자료는 주간·월간 확인 요청 메일 발송 여부를 표시합니다. 홈의 다섯 영역과 연결된 상세 화면은 같은 예제를 사용합니다. 그 외 업무 모듈은 배포본의 화면 캡처로 볼 수 있습니다.|Trade and stock figures use examples based on the two companies’ workflows. Logistics costs come from the module’s sample ledger. Balance sheet status shows daily checks. Customs status tracks weekly and monthly verification emails. All five summaries use the same samples as their detail views. The other modules are shown as screenshots from the desktop release.|Số liệu xuất nhập khẩu và tồn kho là ví dụ theo nghiệp vụ của hai công ty. Chi phí logistics lấy từ sổ mẫu của mô-đun. Trạng thái Balance Sheet thể hiện kiểm tra hằng ngày. Trạng thái hải quan theo dõi email xác nhận theo tuần và tháng. Năm mục tổng quan dùng cùng dữ liệu mẫu với màn hình chi tiết. Các mô-đun khác dùng ảnh chụp từ phiên bản phát hành.
개인 설정|Personal preferences|Tùy chọn cá nhân
검토 사용자마다 언어, 테마, 배율, 텍스트 크기, 모듈 순서, 현황판 배치와 즐겨찾기를 이 브라우저에 저장합니다.|Each review profile saves its language, theme, zoom, text size, module order, overview layout and favorites in this browser.|Mỗi hồ sơ lưu ngôn ngữ, giao diện, mức thu phóng, cỡ chữ, thứ tự mô-đun, bố cục tổng quan và mục yêu thích trong trình duyệt này.
디자인 참고|Design references|Tham khảo thiết kế
`);
function inLanguage(ko,en,vi) {return state.lang==='vi'?vi:state.lang==='en'?en:ko;}
function tr(ko) {return terms.get(ko)?.[state.lang]||ko;}
function monthShort(n) {
  return inLanguage(n+'월',['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'][n-1],'T'+n);
}
function periodText(from,to) {
  return inLanguage('2026년 '+from+'–'+to+'월',monthShort(from)+'–'+monthShort(to)+' 2026','Tháng '+from+'–'+to+'/2026');
}
const sourceAttrs=['aria-label','title','placeholder','alt'];
// Only translate the shell's copy. The original module documents and example records have their own display rules.
function localizeNode(root) {
  if(state.lang==='ko')return;
  const walker=document.createTreeWalker(root,NodeFilter.SHOW_ELEMENT|NodeFilter.SHOW_TEXT);
  for(let node=root;node;node=walker.nextNode()){
    if(node.nodeType===Node.TEXT_NODE){
      const before=node.nodeValue, key=before.trim(), result=tr(key);
      if(key!==result)node.nodeValue=before.replace(key,()=>result);
    } else {
      if(node.hasAttribute('data-autonym'))continue;
      for(const name of sourceAttrs)if(node.hasAttribute(name)){
        const value=node.getAttribute(name), result=tr(value);
        if(result!==value)node.setAttribute(name,result);
      }
    }
  }
}
function appearanceKey(name) {return name;}
function readAppearance() {
  const lang=host.language(),theme=readPref(appearanceKey('theme'),'dark');
  state.lang=Object.hasOwn(languageNames,lang)?lang:'ko';
  state.theme=theme==='light'?'light':'dark';
  state.textSize=readPref(appearanceKey('textSize'),'large')==='standard'?'standard':'large';
  
  applyDocumentAppearance();
}
function applyDocumentAppearance() {
  document.documentElement.lang=state.lang;
  document.documentElement.dataset.theme=state.theme;
  applyReadingScale();
  document.title='Trade Operations · '+tr('업무 현황판');
  document.querySelector('.skip').textContent=tr('본문으로 이동');
  document.querySelector('#side').setAttribute('aria-label',tr('업무 탐색'));
  document.querySelector('.nav-shade')?.setAttribute('aria-label',tr('업무 탐색 닫기'));
}
function preferenceControls() {
  const languages=Object.entries(languageNames).map(([lang,name])=>'<button type="button" lang="'+lang+'" data-lang="'+lang+'" data-autonym aria-pressed="'+(lang===state.lang)+'">'+name+'</button>').join('');
  const themes=[['dark','다크','moon'],['light','라이트','sun']].map(([theme,label,icon])=>'<button type="button" data-theme-choice="'+theme+'" aria-pressed="'+(state.theme===theme)+'">'+glyph(icon)+tr(label)+'</button>').join('');
  return '<div class="appearance"><div class="pref-segment languages" role="group" aria-label="'+tr('표시 언어')+'">'+languages+'</div><div class="pref-segment themes" role="group" aria-label="'+tr('화면 테마')+'">'+themes+'</div></div>';
}
async function chooseAppearance(lang,theme) {
  if(lang&&!Object.hasOwn(languageNames,lang)||theme&&!['dark','light'].includes(theme))return;
  if(lang===state.lang||theme===state.theme)return;
  const previousDrawer=document.body.classList.contains('nav-visible');
  const save=lang?true:writePref('theme',theme);
  if(lang)host.setLanguage(lang);
  if(lang)state.lang=lang;
  if(theme)state.theme=theme;
  applyDocumentAppearance();
  if(lang){
    renderChrome();
    renderPage();
  }else{
    side.querySelectorAll('[data-theme-choice]').forEach(b=>b.setAttribute('aria-pressed',String(b.dataset.themeChoice===theme)));
  }
  if(previousDrawer)document.querySelector('.nav-open').setAttribute('aria-expanded','true');
  document.querySelector(lang?'[data-lang="'+lang+'"]':'[data-theme-choice="'+theme+'"]')?.focus({preventScroll:true});
  if(!await save)toast(tr('이 창에서 선택한 설정을 유지합니다.'));
}


for(const m of DATA.mods){terms.set(m.title,m.names);terms.set(m.description,m.descriptions);}
