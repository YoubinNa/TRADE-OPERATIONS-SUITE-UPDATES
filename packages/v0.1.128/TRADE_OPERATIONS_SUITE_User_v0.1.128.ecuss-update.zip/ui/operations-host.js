/* The native workspace owns module identities, access checks, work tabs, and file dialogs. */
(() => {
  'use strict';
  const suite=window.__ECUSS_SUITE__,desktop=window.EcussDesktop;
  if(!suite||!desktop)return;
  const frame=document.createElement('iframe');
  frame.id='operations-home';
  frame.title='Trade Operations';
  const call=(path,payload)=>desktop.call(path,payload);
  let theme='dark',reading='large',pendingRoute=null,routeObserver=null,wasModule=false;
  const child=()=>frame.contentWindow;
  const language=()=>document.documentElement.lang||suite.lang||'ko';
  const local=(ko,en,vi)=>({ko,en,vi}[language()]||ko);
  const isHome=()=>!document.body.classList.contains('module-mode');
  const feedback=message=>{const node=document.querySelector('.shell-notice');if(node)node.textContent=message;};
  const ready=(async()=>{
    const reply=await call('/desktop/home-preferences/load',null).catch(()=>null);
    const values={};
    if(reply?.status===200)for(const [key,value] of Object.entries(reply.value||{})){try{values[key]=JSON.parse(value);}catch{}}
    await window.EcussFavorites?.ready;
    return values;
  })();
  async function savePreference(key,value){
    const result=await call('/desktop/home-preferences/change',{key,value:JSON.stringify(value)});
    if(result.status!==200)throw Error('preference');
  }
  function moduleSkin(doc,id){
    if(!doc?.head||doc.URL==='about:blank')return;
    doc.documentElement.dataset.workTheme=theme;
    doc.documentElement.dataset.workSize=reading;
    doc.documentElement.dataset.workModule=id;
    if(!doc.getElementById('operations-skin')){
      const link=doc.createElement('link');link.rel='stylesheet';link.id='operations-skin';
      link.href=new URL('operations/native.css',location.href).href;doc.head.append(link);
      const style=doc.createElement('style');style.textContent=workStyleFor(id);doc.head.append(style);
    }
    if(id==='psr-rvc-lvc-calculator')for(const nested of doc.querySelectorAll('iframe')){
      try{if(nested.contentDocument?.URL!=='about:blank')moduleSkin(nested.contentDocument,'psr-sheet');}catch{}
    }
  }
  function appearance(next,size){
    theme=next==='light'?'light':'dark';reading=size==='standard'?'standard':'large';
    document.documentElement.dataset.operationsTheme=theme;
    for(const f of document.querySelectorAll('iframe[data-workspace-module]'))moduleSkin(f.contentDocument,f.dataset.workspaceModule);
  }
  function status(){return {balance:window.EcussRecords?.snapshot?.(),mail:window.EcussMailChecks?.snapshot?.()};}
  function statusChanged(id){child()?.redrawBoard?.(id);}
  function refreshStatus(force){
    window.EcussRecords?.refresh(force);window.EcussMailChecks?.refresh(force);
  }
  function settings(){
    const panel=document.querySelector('.connection-panel');
    if(!panel||panel.closest('dialog'))return;
    const placeholder=document.createComment('connection-panel');panel.before(placeholder);
    const dialog=document.createElement('dialog');dialog.className='operations-settings';
    const close=document.createElement('button');close.textContent=local('닫기','Close','Đóng');close.onclick=()=>dialog.close();
    dialog.append(panel,close);document.body.append(dialog);
    dialog.addEventListener('close',()=>{placeholder.replaceWith(panel);dialog.remove();frame.focus();},{once:true});
    dialog.showModal();
  }
  function applyRoute(){
    if(!pendingRoute||isHome())return;
    const {id,route}=pendingRoute;
    const f=document.querySelector('iframe[data-workspace-module="'+id+'"]:not([hidden])'),doc=f?.contentDocument;
    if(!doc||doc.readyState!=='complete')return;
    const {company,period,anchor}=route;
    if(id==='stock-dashboard'){
      const co=doc.getElementById(company);if(co){pendingRoute=null;co.click();}
      return;
    }
    const co=doc.querySelector('[data-company="'+company+'"]'),direction=doc.getElementById('direction-group');
    if(!co||!direction)return;
    if(co.getAttribute('aria-pressed')!=='true'||direction.hidden){
      if(routeObserver)return;
      routeObserver=new MutationObserver(applyRoute);routeObserver.observe(direction,{attributes:true,attributeFilter:['hidden']});
      co.click();return;
    }
    routeObserver?.disconnect();routeObserver=null;pendingRoute=null;
    doc.querySelector('[data-direction="Export"]')?.click();
    doc.querySelector('[data-period="'+period+'"]')?.click();
    const input=doc.getElementById(period+'-value');
    if(input){input.value=period==='month'?anchor.slice(0,7):anchor;input.dispatchEvent(new f.contentWindow.Event('input',{bubbles:true}));}
    const fee=doc.querySelector('#ranking-options input[value="fee"]');if(fee&&!fee.checked)fee.click();
  }
  function cancelRoute(){pendingRoute=null;routeObserver?.disconnect();routeObserver=null;}
  async function open(id,route){
    if(id==='validation-status'||id==='mail-check-status'){
      (id==='validation-status'?window.EcussRecords:window.EcussMailChecks)?.show();return;
    }
    cancelRoute();
    if(route&&['stock-dashboard','import-export-performance'].includes(id)&&['amo','agv'].includes(route.company))pendingRoute={id,route};
    const result=await call('/desktop/open',id);
    if(result.status!==200||result.value?.ok===false){cancelRoute();if(result.value?.access)window.EcussUpdateStatus?.accept(result.value.access);throw Error('open');}
    applyRoute();
  }
  function sessionSummary(id){
    const selectors={'balance-ecuss':'.result-summary,.kpi','container-stuffing-simulator':'.counter','materials-shipping':'.stat','customs-inspection-cost-comparison':'.verdict'};
    const doc=document.querySelector('iframe[data-workspace-module="'+id+'"]')?.contentDocument;
    if(!doc||!selectors[id])return '';
    return [...doc.querySelectorAll(selectors[id])].filter(n=>!n.closest('[hidden]')).map(n=>n.textContent.trim()).filter(Boolean).slice(0,3).join(' · ').slice(0,300);
  }
  function viewChanged(){
    const module=!isHome();
    if(module===wasModule)return;
    wasModule=module;
    if(module)applyRoute();
    else {cancelRoute();child()?.loadHome?.();}
  }
  const favorites=()=>window.EcussFavorites?.ids()||[];
  function readBoard(path,payload){
    if(path!=='/home-board/logistics'&&!/^\/home-board\/(catalog|inventory)\/(status|restore|start|chunk|confirm|commit|release|forget)$/.test(path))throw Error('Unsupported dashboard read');
    return call(path,payload);
  }
  window.OperationsWorkspace={suite,ready,call:readBoard,settings,open,favorites,savePreference,language,isHome,status,statusChanged,refreshStatus,appearance,sessionSummary,
    async favorite(id){const ids=favorites();if(!await window.EcussFavorites.save(ids.includes(id)?ids.filter(x=>x!==id):[...ids,id]))throw Error('favorites');},
    async orderFavorites(ids){if(!await window.EcussFavorites.save(ids))throw Error('favorites');},
    setLanguage(lang){window.EcussWorkspace.language(lang);},
    textSize(size){reading=size;child()?.syncPreferences?.({textSize:size});appearance(theme,size);}
  };
  new MutationObserver(()=>child()?.changeHomeLanguage?.()).observe(document.documentElement,{attributes:true,attributeFilter:['lang']});
  new MutationObserver(viewChanged).observe(document.body,{attributes:true,attributeFilter:['class']});
  document.addEventListener('load',event=>{
    const f=event.target;
    if(f.tagName!=='IFRAME'||!f.dataset.workspaceModule)return;
    moduleSkin(f.contentDocument,f.dataset.workspaceModule);applyRoute();
    f.contentDocument.addEventListener('click',e=>{if(e.isTrusted&&e.target.closest('[data-company],[data-direction],[data-period]'))cancelRoute();},true);
    if(f.dataset.workspaceModule==='psr-rvc-lvc-calculator')f.contentDocument.addEventListener('load',e=>{if(e.target.tagName==='IFRAME')moduleSkin(e.target.contentDocument,'psr-sheet');},true);
  },true);
  frame.src='operations/index.html';
  document.getElementById('home-content').prepend(frame);
  frame.addEventListener('load',()=>{
    ready.then(()=>{if(frame.contentDocument?.querySelector('#main h1'))document.body.classList.add('operations-enabled');});
  });
  // Native update/close guards continue to run in the outer workspace.
  document.addEventListener('ecuss-operations-ready',()=>document.body.classList.add('operations-enabled'));
})();
