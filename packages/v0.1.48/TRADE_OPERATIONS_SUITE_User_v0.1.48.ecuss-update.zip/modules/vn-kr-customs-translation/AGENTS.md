# 작업 시작 지침

이 저장소는 베트남 수입면장 한글 번역 업무의 기준입니다.

- 작업 전 `README.md`, `docs/CURRENT_STATE.md`, `docs/TRANSLATION_GUIDE.md`, `docs/QUALITY_CHECKLIST.md`, `standard-form/README.md`, `glossary/vi-ko-terms.csv`를 읽습니다.
- 원본 XLSX는 수정하지 않습니다. Standard form도 사용자 승인 없이 수정·재저장하지 않습니다.
- 번역 지침 4.1의 회사명·주소·세관장 명칭·출자 설명 예외를 항목과 문맥으로 적용합니다. 이 예외는 일반 고유명사 보존 규칙보다 우선하며 고정 셀 주소에 종속되지 않습니다. 그 외 영문·고유명사·단위·코드는 원문 보존합니다.
- 과거 기준 번역본의 병합 누락, 열 너비·글꼴 차이, 숨김 상태 변화, 빈 문자열의 `34` 변환을 복제하지 않습니다. 현재 기준은 사용자 승인된 v1.2 Standard_form_KO.xlsx이며 대응 원본은 해당 파일 내부 TKN/HANG입니다.
- 새 번역 결과의 레이아웃은 해당 요청에서 받은 원본 시트를 복제하여 유지합니다. Standard form의 페이지 수나 품목 수를 강제하지 않습니다.
- 실제 통관자료는 명시적으로 승인된 기준 파일 외에는 GitHub에 추가하지 않습니다.
- 기준 변경은 Work에서 검토·테스트하고 사용자 확정 및 저장 요청 후 반영합니다. `CHANGELOG.md`에 배경과 검증 결과를 남깁니다.
- 개인정보·업무정보가 포함된 Standard form이 있으므로 저장소 공개 전 별도 검토가 필요합니다.

- 승인된 변경을 저장할 때 README 현황판, docs/CURRENT_STATE.md, CHANGELOG.md를 함께 갱신합니다. 상세 번역 규칙은 담당 문서에서 관리하고, 현황판의 요약만으로 기준을 변경하지 않습니다. 검증 완료·미실행·미확정·사용자 확인을 구분합니다.


## 번역 모듈 개발·연결

- 모듈 작업 전 `docs/MODULE_README.md`, `docs/MODULE_OPERATING_POLICY.md`, `docs/MODULE_INTEGRATION.md`, `docs/MODULE_VALIDATION.md`를 추가로 읽습니다.
- Master 확인 대상은 오류·실패·대기가 아닙니다. `level=notify`, `blocking=false`로만 안내하며 해당 문구의 원문을 유지하고 작업·결과 저장·후속 단계를 정상 수행합니다. 알림이 있어도 종료 코드 0과 `status=completed`를 유지합니다.
- 파일 손상·입력 구조 미지원·저장 실패 등 실제 수행 불가 사유와 Master 알림을 구분합니다.
- 모듈은 루트 용어표와 기존 지침을 직접 참조합니다. 코드별 별도 기준 사본을 만들지 않습니다. 외부 AI/API·자동 전송은 별도 결정 없이 추가하지 않습니다.
- 통합 프로그램 UI·런타임 포함·설치파일·배포는 프로그램·모듈 개발 설계 프로젝트에서 담당합니다.
- 코드 변경 시 관련 동작을 검증하고 검증 기록에 실행 환경과 미실행 범위를 기재합니다. 기본 테스트 명령은 `python -m unittest discover -s tests -v`입니다.
- GitHub에는 코드·합성 테스트·문서만 추가합니다. 실제 통관자료·번역 결과·demo 패키지는 별도 승인 없이 올리지 않습니다.
