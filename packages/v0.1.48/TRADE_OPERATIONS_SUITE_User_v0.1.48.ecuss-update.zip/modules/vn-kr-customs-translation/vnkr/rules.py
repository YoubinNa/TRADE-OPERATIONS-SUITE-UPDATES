"""Conservative, auditable rules. Never translate from source cell addresses."""
import csv
import re
import unicodedata
from dataclasses import dataclass
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
REUSE = {}
with (ROOT / "glossary/vi-ko-terms.csv").open(encoding="utf-8-sig", newline="") as f:
    for row in csv.DictReader(f):
        if row["usage"] == "reuse":
            key = unicodedata.normalize("NFC", row["vi"])
            if key in REUSE and REUSE[key] != row["ko_reference"]:
                raise ValueError("Conflicting glossary entries")
            REUSE[key] = row["ko_reference"]

COMPANY_SECTIONS = {"Người nhập khẩu", "Người xuất khẩu", "Người ủy thác nhập khẩu",
                    "Người ủy thác xuất khẩu"}
CORE_NAMES = {"AMO VINA", "AMOGREEN VINA", "AMOSENSE", "SEV", "SEVT", "WITS", "SIEL"}
UNITS_CODES = {"VND", "USD", "EUR", "KRW", "CNY", "JPY", "KR", "VN", "CN", "US",
               "KGM", "KG", "PCE", "PCS", "SET", "PK", "CT", "CTN", "MTR", "LTR"}
CAPITAL = "Hàng nhập về phục vụ sản xuất trong nhà máy bằng hình thức đầu tư, góp vốn"
CAPITAL_KO = "공장 내 생산에 사용하기 위해 투자·현물출자 형태로 수입한 물품"

def norm(s):
    return unicodedata.normalize("NFC", s.strip())

def position(ref):
    m = re.fullmatch(r"([A-Z]+)([1-9][0-9]*)", ref)
    if not m:
        raise ValueError("Invalid cell address")
    col = 0
    for c in m[1]:
        col = col * 26 + ord(c) - 64
    return int(m[2]), col

def context(ref, texts):
    row, col = position(ref)
    left = [(position(a)[1], norm(v)) for a, v in texts.items()
            if position(a)[0] == row and position(a)[1] < col and norm(v)]
    labels = {v for _, v in left}
    sections = [(position(a)[0], v) for a, v in texts.items()
                if position(a)[0] <= row and norm(v) in COMPANY_SECTIONS]
    section_near = sections and row - max(r for r, _ in sections) <= 9
    if "Địa chỉ" in labels:
        return "address"
    if "Tên trưởng đơn vị Hải quan" in labels:
        return "customs_chief"
    if "Tên" in labels and section_near:
        return "company"
    return "general"

@dataclass(frozen=True)
class Decision:
    text: str
    status: str  # translated / preserved / review
    reason: str

def wrapped(original, translated):
    leading = original[:len(original)-len(original.lstrip())]
    trailing = original[len(original.rstrip()):]
    return leading + translated + trailing

def decide(text, field="general"):
    t = norm(text)
    if not t:
        return Decision(text, "preserved", "빈 문자열·공백 보존")
    if t in REUSE:
        return Decision(wrapped(text, REUSE[t]), "translated", "확정 용어표 reuse 완전 일치")
    if field == "company":
        m = re.fullmatch(r"Công ty TNHH\s+(.+)", t, re.I)
        if m:
            return Decision(wrapped(text, m[1] + " 유한회사"), "translated", "지침 4.1: 회사명 항목의 법인형태")
    if field == "address":
        pieces = t.split(",")
        rendered = []
        patterns = [("Lô", ""), ("Khu công nghiệp", " 산업단지"),
                    ("Phường", " 동"), ("Tỉnh", " 성")]
        valid = True
        for piece in pieces:
            p = piece.strip()
            if p.casefold() == "việt nam":
                rendered.append("베트남")
                continue
            match = None
            for prefix, suffix in patterns:
                m = re.fullmatch(re.escape(prefix) + r"\s+(.+)", p, re.I)
                if m:
                    match = m[1] + suffix
                    break
            if match is None:
                valid = False
                break
            rendered.append(match)
        if valid and rendered:
            return Decision(wrapped(text, ", ".join(rendered)), "translated", "지침 4.1: 주소 구성요소·상세 지명 보존")
    if field == "customs_chief" and t == "Trưởng Hải quan Vĩnh Phúc":
        return Decision(wrapped(text, "빈푹 세관장"), "translated", "지침 4.1: 승인된 세관장 명칭")
    # Exact clause plus a numeric/punctuation prefix only. Never reuse old transaction values.
    if t.endswith(CAPITAL):
        prefix = t[:-len(CAPITAL)]
        if not any(ch.isalpha() for ch in prefix):
            return Decision(wrapped(text, prefix + CAPITAL_KO), "translated", "지침 4.1: 생산용 투자·현물출자 문맥")
    if t in CORE_NAMES or t in UNITS_CODES:
        return Decision(text, "preserved", "명시된 고유명사·단위·국가/통화 코드 보존")
    if not any(ch.isalpha() for ch in t):
        return Decision(text, "preserved", "숫자·날짜·구분기호 보존")
    if re.fullmatch(r"[A-Z0-9_.+/#&*()\[\] :\-]+", t) and any(c.isdigit() for c in t):
        # A short individual code may be kept; alphabetic phrases remain reviewable.
        words = re.findall(r"[A-Z]+", t)
        if len(words) <= 1 and len(t) <= 48:
            return Decision(text, "preserved", "숫자를 포함한 단일 코드 형식 보존")
    if re.search(r"[가-힣]", t) and not re.search(r"[A-Za-zÀ-ỹ]", t):
        return Decision(text, "preserved", "기존 한국어 보존")
    return Decision(text, "review", "확정 자동 규칙 없음: 번역 또는 영문·고유명사 보존 여부를 Master가 확인")

def numeric_tokens(text):
    # Preserve each numeric token including separators, sign and precision.
    return re.findall(r"[+-]?\d+(?:[.,:/-]\d+)*", text)
