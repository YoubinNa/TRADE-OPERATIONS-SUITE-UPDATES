"""Self-contained, offline review report; source strings are HTML-escaped."""
import html
import json

def render(report):
    h = lambda v: html.escape(str(v), quote=True)
    labels = {"translated": "자동 번역", "preserved": "원문 보존", "review": "Master 확인 알림",
              "master_translated": "Master 확인 번역", "master_preserved": "Master 확인 보존"}
    pending = [r for r in report.get("records", []) if r["status"] == "review"]
    def rows(records):
        return "".join("<tr><td>" + h(r["ko_sheet"] + "!" + r["cell"]) + "</td><td>" +
                       h(labels[r["status"]]) + "</td><td class='text'>" + h(r["source"]) +
                       "</td><td class='text'>" + h(r["target"]) + "</td><td>" + h(r["reason"]) +
                       "</td></tr>" for r in records)
    def table(records):
        return "<div class='scroll'><table><thead><tr><th>위치</th><th>처리</th><th>원문</th><th>현재 결과</th><th>사유</th></tr></thead><tbody>" + rows(records) + "</tbody></table></div>"
    request = "Master 확인 요청\n기준: " + report["baseline_commit"] + "\n원본 SHA256: " + report["input_sha256"] + "\n\n"
    request += "신규 문구의 번역 또는 원문 보존 여부를 확인해 주세요. 숫자·날짜·코드·영문·고유명사는 지침에 따라 보존해 주세요.\n\n"
    request += "\n\n".join(r["sheet"] + "!" + r["cell"] + "\n원문: " + r["source"] + "\n사유: " + r["reason"] for r in pending)
    counts = report.get("counts", {})
    summary = "".join("<div class='count'><strong>" + str(counts.get(k, 0)) + "</strong><span>" + v + " 셀</span></div>" for k, v in labels.items())
    limitations = "".join("<li>" + h(x) + "</li>" for x in report.get("limitations", []))
    translated = [r for r in report.get("records", []) if r["status"] != "review" and r["source"].strip()]
    return """<!doctype html><html lang="ko"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>베트남 수입면장 번역 검토</title><style>
body{font:15px/1.6 'Malgun Gothic','Noto Sans KR',sans-serif;background:#f3f5f8;color:#182c42;margin:0}main{max-width:1280px;margin:auto;padding:36px 28px}h1{font-size:28px;margin:0 0 8px}h2{font-size:19px;margin-top:30px}.muted{color:#526576}section{background:white;padding:24px;border:1px solid #d8e0e8;border-radius:10px;margin:20px 0}.status{font-size:20px;color:#176251;font-weight:bold}.counts{display:flex;flex-wrap:wrap;gap:14px}.count{flex:1;min-width:130px;padding:15px;background:#f0f4f8}.count strong{display:block;font-size:29px}.count span{color:#526576}.scroll{overflow:auto}table{border-collapse:collapse;width:100%;font-size:13px}th{background:#e9eff5;text-align:left;position:sticky;top:0}th,td{padding:12px;border-bottom:1px solid #dce3eb;vertical-align:top}.text{white-space:pre-wrap;min-width:220px;overflow-wrap:anywhere}textarea{box-sizing:border-box;width:100%;height:260px;font:13px/1.6 monospace;padding:12px}button{background:#18486b;color:white;border:0;border-radius:5px;padding:10px 18px;cursor:pointer}a{color:#18486b}code{overflow-wrap:anywhere}summary{cursor:pointer;font-weight:bold}@media print{button,textarea{display:none}main{padding:0}.scroll{overflow:visible}table{font-size:10px}}
</style><main><h1>베트남 수입면장 번역 검토</h1><p class="muted">오프라인 규칙 적용 · v""" + h(report["module_version"]) + "</p><section><div class='status'>" + h(report["message"]) + "</div><p>Master 확인 항목은 오류가 아닌 알림입니다. 해당 문구는 원문으로 유지하고 번역·파일 저장은 정상 완료했습니다. 필요할 경우 Master에게 확인을 요청하세요.</p><div class='counts'>" + summary + "</div></section><section><h2>검증 상태</h2><p>원본 시트·기존 리소스 불변 및 한국어 시트의 서식·수식 구조 보존 검사: 통과</p><p><b>실제 Excel 표시 확인: 별도 확인 사항(모듈 실행에는 영향 없음)</b></p><p>외부 전송 없음 · Master 자동 연락 없음</p><p>기준 커밋: <code>" + h(report["baseline_commit"]) + "</code></p></section><section><h2>Master 확인 알림 · " + str(len(pending)) + "개 셀</h2>" + (table(pending) if pending else "<p>현재 자동 검사에서 남은 확인 문구는 없습니다.</p>") + "</section><section><h2>Master에게 요청할 내용</h2><p>필요한 문구만 선택해 전달할 수 있습니다. 아래 버튼은 요청문을 복사하며 전송하지 않습니다.</p><textarea id='request'>" + h(request) + "</textarea><p><button onclick='copyRequest()'>요청문 복사</button> <span id='notice'></span></p><p><a href='master_request.json'>확인 목록 JSON</a> · <a href='master_response_template.json'>응답 작성 양식 JSON</a> · <a href='report.json'>전체 검증 기록 JSON</a></p></section><section><details><summary>번역·원문 보존 내역</summary>" + table(translated) + "</details></section><section><h2>처리 범위와 한계</h2><ul>" + limitations + "</ul></section></main><script>async function copyRequest(){const t=document.getElementById('request');t.select();try{await navigator.clipboard.writeText(t.value);document.getElementById('notice').textContent='복사했습니다.'}catch(e){document.getElementById('notice').textContent='선택된 내용을 Ctrl+C로 복사하세요.'}}</script></html>"
