"""CLI returns a compact JSON result. No network, automatic upload or messages."""
import argparse
import json
import os
from pathlib import Path
import shutil
import sys
import tempfile

from .core import ModuleError, translate_bytes
from .report import render

def write_json(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

def run(input_path, output_dir, resolutions_path=None):
    source = Path(input_path).resolve()
    output_dir = Path(output_dir).resolve()
    if source.suffix.lower() != ".xlsx":
        raise ModuleError("UNSUPPORTED_EXTENSION", ".xlsx 파일만 지원합니다.")
    if output_dir.exists():
        raise ModuleError("OUTPUT_EXISTS", "결과 폴더가 이미 존재합니다. 새 폴더를 지정하세요.")
    data = source.read_bytes()
    resolutions = json.loads(Path(resolutions_path).read_text(encoding="utf-8-sig")) if resolutions_path else None
    result, report, request = translate_bytes(data, resolutions)
    output_dir.parent.mkdir(parents=True, exist_ok=True)
    stage = Path(tempfile.mkdtemp(prefix=".vnkr-", dir=output_dir.parent))
    try:
        filename = source.stem + "_한글번역.xlsx"
        (stage / filename).write_bytes(result)
        write_json(stage / "report.json", report)
        write_json(stage / "master_request.json", request)
        template = {"schema_version": 1, "input_sha256": request["input_sha256"],
                    "instructions": "확인한 항목만 decisions에 남기세요. action을 translate 또는 preserve로 바꾸고 approved_by를 입력하세요. 이것은 작업별 확인이며 공통 기준을 변경하지 않습니다.",
                    "decisions": [{"id": i["id"], "sheet": i["sheet"], "cell": i["cell"],
                                   "source": i["source"], "action": "pending", "target": "",
                                   "approved_by": "", "reason": ""} for i in request["items"]]}
        write_json(stage / "master_response_template.json", template)
        (stage / "review.html").write_text(render(report), encoding="utf-8")
        # Reserve the destination exclusively so an existing job can never be overwritten.
        output_dir.mkdir()
        for child in stage.iterdir():
            os.replace(child, output_dir / child.name)
    finally:
        shutil.rmtree(stage, ignore_errors=True)
    return {"schema_version": 1, "status": report["status"], "message": report["message"],
            "output_file": str(output_dir / filename), "review_file": str(output_dir / "review.html"),
            "report_file": str(output_dir / "report.json"), "master_request_file": str(output_dir / "master_request.json"),
            "counts": report["counts"], "has_notifications": report["has_notifications"],
            "notification_count": report["notification_count"],
            "notifications": report["notifications"], "network_used": False}

def main(argv=None):
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8")
    parser = argparse.ArgumentParser(description="베트남 수입면장 오프라인 번역·Master 검토 모듈")
    parser.add_argument("--input", required=True, help="원본 XLSX")
    parser.add_argument("--output-dir", required=True, help="새 결과 폴더")
    parser.add_argument("--resolutions", help="원본에 대응하는 Master 확인 JSON")
    args = parser.parse_args(argv)
    try:
        result = run(args.input, args.output_dir, args.resolutions)
        print(json.dumps(result, ensure_ascii=False))
        return 0
    except ModuleError as error:
        result = {"schema_version": 1, "status": "blocked", "code": error.code,
                  "message": str(error), "output_file": None, "network_used": False}
        print(json.dumps(result, ensure_ascii=False))
        return 3
    except (OSError, ValueError, KeyError, TypeError) as error:
        print(json.dumps({"schema_version": 1, "status": "error", "code": type(error).__name__,
                          "message": "파일 접근 또는 입력 형식을 확인하세요. " + str(error),
                          "output_file": None, "network_used": False}, ensure_ascii=False))
        return 1

if __name__ == "__main__":
    raise SystemExit(main())
