"""Offline Vietnamese customs declaration translation review module."""
__version__ = "0.1.0"

