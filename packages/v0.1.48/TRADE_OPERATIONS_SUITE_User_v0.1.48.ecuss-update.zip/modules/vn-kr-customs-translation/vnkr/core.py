"""XLSX package patcher: existing worksheets and resources remain byte-identical.

Only workbook manifests and optional application sheet-list metadata are changed.
Unsupported target-sheet objects block processing instead of being dropped.
"""
import copy
import hashlib
import io
import json
import posixpath
import re
import zipfile
import xml.etree.ElementTree as ET
from pathlib import Path
from xml.dom import minidom
from xml.sax.saxutils import escape, quoteattr

from . import __version__
from .rules import ROOT, context, decide, numeric_tokens

S = "http://schemas.openxmlformats.org/spreadsheetml/2006/main"
R = "http://schemas.openxmlformats.org/officeDocument/2006/relationships"
P = "http://schemas.openxmlformats.org/package/2006/relationships"
C = "http://schemas.openxmlformats.org/package/2006/content-types"
BASELINE_COMMIT = "9f11934edaa2e4483710e1c817ed4e3bf0d90fb5"
CELL = re.compile(r"<c\b[^>]*?(?:/>|>.*?</c>)", re.S)
MAX_UNCOMPRESSED = 200 * 1024 * 1024

class ModuleError(Exception):
    def __init__(self, code, message):
        self.code = code
        super().__init__(message)

def sha(data):
    return hashlib.sha256(data).hexdigest()

def xml(data):
    if b"<!DOCTYPE" in data.upper() or b"<!ENTITY" in data.upper():
        raise ModuleError("UNSUPPORTED_XML", "DTD/ENTITY가 있는 XML은 지원하지 않습니다. Master에게 확인을 요청하세요.")
    try:
        return ET.fromstring(data)
    except ET.ParseError as e:
        raise ModuleError("INVALID_XML", "엑셀 내부 XML이 올바르지 않습니다.") from e

def dom(data):
    xml(data)
    return minidom.parseString(data)

def elements(node, namespace, local):
    return list(node.getElementsByTagNameNS(namespace, local))

def rel_path(part):
    return posixpath.join(posixpath.dirname(part), "_rels", posixpath.basename(part) + ".rels")

def target_path(base, target):
    path = posixpath.normpath(posixpath.join(posixpath.dirname(base), target))
    if target.startswith("/"):
        path = target.lstrip("/")
    if path.startswith("../") or path.startswith("/"):
        raise ModuleError("INVALID_RELATIONSHIP", "패키지 밖의 상대 경로입니다.")
    return path

def read_package(data):
    try:
        with zipfile.ZipFile(io.BytesIO(data)) as z:
            infos = z.infolist()
            names = [i.filename for i in infos]
            if len(names) != len(set(names)) or len(names) > 10000:
                raise ModuleError("INVALID_PACKAGE", "중복되거나 과도한 패키지 항목이 있습니다.")
            if sum(i.file_size for i in infos) > MAX_UNCOMPRESSED:
                raise ModuleError("FILE_TOO_LARGE", "압축 해제 크기 200MiB를 초과합니다.")
            parts = {i.filename: z.read(i) for i in infos}
            comment = z.comment
    except (zipfile.BadZipFile, RuntimeError) as e:
        raise ModuleError("INVALID_XLSX", "암호화되었거나 정상 XLSX 파일이 아닙니다.") from e
    for name in ("xl/workbook.xml", "xl/_rels/workbook.xml.rels", "[Content_Types].xml"):
        if name not in parts:
            raise ModuleError("INVALID_XLSX", "필수 엑셀 구성 파일이 없습니다.")
    if any("vbaproject" in p.lower() or p.startswith("_xmlsignatures/") for p in parts):
        raise ModuleError("UNSUPPORTED_PACKAGE", "매크로 또는 전자서명이 있는 파일은 Master 확인이 필요합니다.")
    return parts, infos, comment

def sheets_of(parts):
    root = xml(parts["xl/workbook.xml"])
    if root.tag != "{" + S + "}workbook":
        raise ModuleError("UNSUPPORTED_FORMAT", "Transitional XLSX 형식만 지원합니다.")
    rels = {r.get("Id"): r for r in xml(parts["xl/_rels/workbook.xml.rels"])}
    result = []
    for sheet in root.findall("{" + S + "}sheets/{" + S + "}sheet"):
        rel = rels.get(sheet.get("{" + R + "}id"))
        if rel is None or rel.get("TargetMode") == "External":
            raise ModuleError("INVALID_RELATIONSHIP", "시트 연결 정보가 올바르지 않습니다.")
        result.append({"name": sheet.get("name"), "id": sheet.get("sheetId"),
                       "state": sheet.get("state", "visible"),
                       "part": target_path("xl/workbook.xml", rel.get("Target", ""))})
    return result

def shared_strings(parts):
    # Resolve the relationship instead of assuming a shared-strings filename.
    for r in xml(parts["xl/_rels/workbook.xml.rels"]):
        if r.get("Type", "").endswith("/sharedStrings"):
            part = target_path("xl/workbook.xml", r.get("Target", ""))
            return list(xml(parts[part]))
    return []

def cell_text(cell, strings):
    if cell.find("{" + S + "}f") is not None:
        return None, False
    if cell.get("t") == "s":
        value = cell.find("{" + S + "}v")
        try:
            index = int(value.text)
            if index < 0:
                raise ValueError()
            node = strings[index]
        except (IndexError, ValueError, AttributeError, TypeError) as e:
            raise ModuleError("INVALID_SHARED_STRING", "문자열 참조 번호가 올바르지 않습니다.") from e
    elif cell.get("t") == "inlineStr":
        node = cell.find("{" + S + "}is")
    elif cell.get("t") == "str":
        node = cell.find("{" + S + "}v")
        return (node.text or "") if node is not None else "", False
    else:
        return None, False
    if node is None:
        return "", False
    # Phonetic annotation text must never enter the visible text.
    direct = node.find("{" + S + "}t")
    runs = node.findall("{" + S + "}r/{" + S + "}t")
    text = direct.text or "" if direct is not None else "".join(x.text or "" for x in runs)
    rich = any(c.tag != "{" + S + "}t" for c in node)
    return text, rich

def inspect_sheet(data, strings):
    root = xml(data)
    texts, rich = {}, set()
    for cell in root.findall("{" + S + "}sheetData/{" + S + "}row/{" + S + "}c"):
        value, is_rich = cell_text(cell, strings)
        if value is not None:
            texts[cell.get("r")] = value
            if is_rich:
                rich.add(cell.get("r"))
    return root, texts, rich

def ensure_supported(parts, sheet):
    part = sheet["part"]
    if posixpath.dirname(part) != "xl/worksheets":
        raise ModuleError("UNSUPPORTED_SHEET_PATH", "일반적인 worksheet 경로가 아닙니다. Master 확인이 필요합니다.")
    root = xml(parts[part])
    blocked = {"drawing", "legacyDrawing", "legacyDrawingHF", "tableParts", "oleObjects",
               "controls", "extLst", "picture", "pivotTableParts"}
    found = {n.tag.rsplit("}", 1)[-1] for n in root.iter()} & blocked
    if found:
        raise ModuleError("UNSUPPORTED_OBJECT", "대상 시트의 미지원 객체(" + ", ".join(sorted(found)) + ")를 보존 검증할 수 없어 중단합니다. Master에게 요청하세요.")
    if rel_path(part) in parts:
        for rel in xml(parts[rel_path(part)]):
            kind = rel.get("Type", "").rsplit("/", 1)[-1]
            if kind not in {"printerSettings", "hyperlink"}:
                raise ModuleError("UNSUPPORTED_RELATIONSHIP", "대상 시트의 " + kind + " 연결은 Master 확인이 필요합니다.")
            if rel.get("TargetMode") != "External":
                target = target_path(part, rel.get("Target", ""))
                if target not in parts:
                    raise ModuleError("INVALID_RELATIONSHIP", "시트 리소스를 찾을 수 없습니다.")
    # Raw lexical editing preserves namespace declarations and every untouched byte.
    lexical = parts[part].decode("utf-8-sig")
    if re.search(r"<(?:\w+:)(?:worksheet|c)\b", lexical):
        raise ModuleError("UNSUPPORTED_XML_PREFIX", "접두사가 붙은 시트 XML은 Master 확인이 필요합니다.")

def patch_cells(data, replacements):
    seen = set()
    def replace(match):
        raw = match[0]
        address = re.search(r'\br="([A-Z]+[0-9]+)"', raw)
        if address is None or address[1] not in replacements:
            return raw
        ref = address[1]
        if ref in seen:
            raise ModuleError("DUPLICATE_CELL", "중복 셀 주소입니다.")
        seen.add(ref)
        opening = raw[:raw.index(">") + 1]
        opening = re.sub(r'\s+t="[^"]*"', "", opening)
        opening = opening.rstrip(">").rstrip("/") + ' t="inlineStr">'
        return opening + '<is><t xml:space="preserve">' + escape(replacements[ref]) + "</t></is></c>"
    result = CELL.sub(replace, data.decode("utf-8-sig")).encode("utf-8")
    if seen != set(replacements):
        raise ModuleError("PATCH_FAILED", "번역 셀을 안전하게 찾지 못했습니다.")
    xml(result)
    return result

def item_id(sheet, cell, source):
    return sha((sheet + "\0" + cell + "\0" + source).encode())[:24]

def resolution_map(resolutions, input_hash):
    if resolutions is None:
        return {}
    if resolutions.get("schema_version") != 1 or resolutions.get("input_sha256") != input_hash:
        raise ModuleError("STALE_RESOLUTION", "Master 응답의 버전 또는 원본 해시가 다릅니다.")
    result = {}
    for item in resolutions.get("decisions", []):
        if item.get("id") in result:
            raise ModuleError("DUPLICATE_RESOLUTION", "Master 응답에 중복 항목이 있습니다.")
        if not str(item.get("approved_by", "")).strip():
            raise ModuleError("UNAPPROVED_RESOLUTION", "Master 응답에 확인자 approved_by가 필요합니다.")
        if item.get("action") not in {"translate", "preserve"}:
            raise ModuleError("INVALID_RESOLUTION", "Master action은 translate 또는 preserve여야 합니다.")
        result[item.get("id")] = item
    return result

def add_manifests(parts, sheets, clones):
    wb = dom(parts["xl/workbook.xml"])
    rels = dom(parts["xl/_rels/workbook.xml.rels"])
    types = dom(parts["[Content_Types].xml"])
    container = elements(wb, S, "sheets")[0]
    original_nodes = elements(container, S, "sheet")
    max_id = max(int(s["id"]) for s in sheets)
    used_ids = {r.getAttribute("Id") for r in elements(rels, P, "Relationship")}
    for offset, (source, dest) in enumerate(clones):
        i = sheets.index(source)
        rid = "rIdVNKR" + str(offset + 1)
        while rid in used_ids:
            rid += "x"
        used_ids.add(rid)
        node = original_nodes[i].cloneNode(True)
        node.setAttribute("name", dest["name"])
        node.setAttribute("sheetId", str(max_id + offset + 1))
        node.setAttributeNS(R, "r:id", rid)
        if node.hasAttribute("state"):
            node.removeAttribute("state")
        container.appendChild(node)
        rel = rels.createElementNS(P, "Relationship")
        rel.setAttribute("Id", rid)
        rel.setAttribute("Type", R + "/worksheet")
        rel.setAttribute("Target", posixpath.relpath(dest["part"], "xl"))
        rels.documentElement.appendChild(rel)
        override = types.createElementNS(C, "Override")
        override.setAttribute("PartName", "/" + dest["part"])
        override.setAttribute("ContentType", "application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml")
        types.documentElement.appendChild(override)
        # Copy sheet-local names, including print area/titles; original names are untouched.
        for defined in list(elements(wb, S, "definedName")):
            if defined.getAttribute("localSheetId") == str(i):
                new = defined.cloneNode(True)
                new.setAttribute("localSheetId", str(len(sheets) + offset))
                for child in new.childNodes:
                    if child.nodeType == child.TEXT_NODE:
                        child.data = re.sub(r"(?<![A-Za-z0-9_'])" + re.escape(source["name"]) + r"!",
                                            dest["name"] + "!", child.data)
                        child.data = child.data.replace("'" + source["name"] + "'!", "'" + dest["name"] + "'!")
                defined.parentNode.appendChild(new)
    modified = {"xl/workbook.xml": wb.toxml(encoding="utf-8"),
                "xl/_rels/workbook.xml.rels": rels.toxml(encoding="utf-8"),
                "[Content_Types].xml": types.toxml(encoding="utf-8")}
    if "docProps/app.xml" in parts:
        app = dom(parts["docProps/app.xml"])
        ns = "http://schemas.openxmlformats.org/officeDocument/2006/extended-properties"
        vt = "http://schemas.openxmlformats.org/officeDocument/2006/docPropsVTypes"
        titles = elements(app, ns, "TitlesOfParts")
        if titles:
            vectors = elements(titles[0], vt, "vector")
            if vectors:
                vector = vectors[0]
                for _, dest in clones:
                    node = app.createElementNS(vt, "vt:lpstr")
                    node.appendChild(app.createTextNode(dest["name"]))
                    vector.appendChild(node)
                vector.setAttribute("size", str(len(elements(vector, vt, "lpstr"))))
        headings = elements(app, ns, "HeadingPairs")
        if headings:
            variants = elements(headings[0], vt, "variant")
            for i in range(len(variants)-1):
                labels = elements(variants[i], vt, "lpstr")
                counts = elements(variants[i+1], vt, "i4")
                if labels and labels[0].firstChild and labels[0].firstChild.data == "Worksheets" and counts:
                    counts[0].firstChild.data = str(len(sheets) + len(clones))
        modified["docProps/app.xml"] = app.toxml(encoding="utf-8")
    return modified

def verify(parts, after, clones, changes, modified):
    for part, data in parts.items():
        if part not in modified and after.get(part) != data:
            raise ModuleError("PRESERVATION_FAILED", "기존 구성요소가 변경되었습니다: " + part)
    old_sheets = sheets_of(parts)
    new_sheets = sheets_of(after)
    if new_sheets[:len(old_sheets)] != old_sheets:
        raise ModuleError("PRESERVATION_FAILED", "기존 시트 순서·숨김 상태·연결이 변경되었습니다.")
    strings = shared_strings(after)
    for source, dest in clones:
        old, _, _ = inspect_sheet(parts[source["part"]], strings)
        new, texts, _ = inspect_sheet(after[dest["part"]], strings)
        by_ref = {c.get("r"): c for c in new.findall(".//{" + S + "}c")}
        originals = {c.get("r"): c for c in old.findall(".//{" + S + "}c")}
        for ref, translated in changes[dest["name"]].items():
            if texts.get(ref) != translated:
                raise ModuleError("VALIDATION_FAILED", "저장한 번역값이 다릅니다.")
            # Reset only content and type, then compare the entire source/clone tree.
            current = by_ref[ref]
            original = originals[ref]
            for key in set(current.attrib) | set(original.attrib):
                if key != "t" and current.get(key) != original.get(key):
                    raise ModuleError("PRESERVATION_FAILED", "셀 서식 속성이 달라졌습니다.")
            current.attrib.clear()
            current.attrib.update(original.attrib)
            current.text = original.text
            current[:] = [copy.deepcopy(n) for n in original]
        if ET.tostring(old) != ET.tostring(new):
            raise ModuleError("PRESERVATION_FAILED", "한국어 시트의 서식·수식·구조가 달라졌습니다.")
        if dest["state"] != "visible":
            raise ModuleError("VALIDATION_FAILED", "한국어 시트가 표시되지 않습니다.")
    return {"original_parts_byte_identical": True, "original_sheets_unchanged": True,
            "clone_format_and_formula_structure_equal": True,
            "modified_manifest_parts": sorted(modified),
            "visual_review": "not_performed", "excel_desktop_open": "not_performed"}

def translate_bytes(data, resolutions=None):
    parts, infos, comment = read_package(data)
    sheets = sheets_of(parts)
    names = [s["name"] for s in sheets]
    if not all(n in names for n in ("TKN", "HANG")):
        raise ModuleError("UNEXPECTED_SHEETS", "TKN·HANG 시트가 모두 필요합니다. 다른 양식은 Master에게 요청하세요.")
    if any(n.casefold() in {"tkn_ko", "hang_ko"} for n in names):
        raise ModuleError("EXISTING_KO_SHEETS", "이미 한국어 시트가 있습니다. 덮어쓰지 않습니다. Master에게 처리 범위를 요청하세요.")
    input_hash = sha(data)
    resolved = resolution_map(resolutions, input_hash)
    used_resolutions = set()
    strings = shared_strings(parts)
    additions, clones, changes = {}, [], {}
    records = []
    max_sheet_number = max([int(m[1]) for p in parts if (m := re.fullmatch(r"xl/worksheets/sheet(\d+)\.xml", p))] + [0])
    for offset, name in enumerate(("TKN", "HANG")):
        source = next(s for s in sheets if s["name"] == name)
        ensure_supported(parts, source)
        dest = {"name": name + "_KO", "part": "xl/worksheets/sheet" + str(max_sheet_number + offset + 1) + ".xml", "state": "visible"}
        _, texts, rich = inspect_sheet(parts[source["part"]], strings)
        replacements = {}
        for ref, original in texts.items():
            field = context(ref, texts)
            decision = decide(original, field)
            target, status, reason = decision.text, decision.status, decision.reason
            if ref in rich and status == "translated":
                target, status, reason = original, "review", "셀 내 혼합 서식·발음 주석 보존 확인이 필요합니다. Master에게 요청하세요."
            identity = item_id(name, ref, original)
            approval = None
            if status == "review" and identity in resolved:
                approval = resolved[identity]
                if approval.get("source") != original or approval.get("sheet") != name or approval.get("cell") != ref:
                    raise ModuleError("STALE_RESOLUTION", "Master 응답의 셀·원문이 다릅니다.")
                used_resolutions.add(identity)
                if approval["action"] == "translate":
                    target = approval.get("target")
                    if not isinstance(target, str) or not target.strip() or target == original or len(target) > 32767:
                        raise ModuleError("INVALID_RESOLUTION", "Master 번역문이 없거나 원문과 같거나 셀 길이 제한을 초과합니다.")
                    if ref in rich:
                        raise ModuleError("RICH_TEXT_REVIEW", "혼합 서식 셀의 번역은 이 버전에서 적용할 수 없습니다.")
                    if numeric_tokens(original) != numeric_tokens(target):
                        raise ModuleError("PROTECTED_NUMBER_CHANGED", "Master 번역문에서 숫자·날짜·식별자의 숫자 부분이 변경되었습니다.")
                    if any(ord(ch) < 32 and ch not in "\t\n\r" for ch in target):
                        raise ModuleError("INVALID_RESOLUTION", "번역문에 XML에서 허용하지 않는 제어문자가 있습니다.")
                    status = "master_translated"
                else:
                    target, status = original, "master_preserved"
                reason = "Master 작업별 확인: " + str(approval.get("reason", ""))
            if target != original:
                if numeric_tokens(original) != numeric_tokens(target):
                    raise ModuleError("PROTECTED_NUMBER_CHANGED", "자동 번역 중 숫자 표현 차이가 발견되었습니다.")
                replacements[ref] = target
            records.append({"id": identity, "sheet": name, "ko_sheet": dest["name"], "cell": ref,
                            "source": original, "target": target, "field": field, "status": status,
                            "reason": reason, "approved_by": approval.get("approved_by") if approval else None})
        additions[dest["part"]] = patch_cells(parts[source["part"]], replacements)
        if rel_path(source["part"]) in parts:
            additions[rel_path(dest["part"])] = parts[rel_path(source["part"])]
        clones.append((source, dest))
        changes[dest["name"]] = replacements
    if set(resolved) != used_resolutions:
        raise ModuleError("UNUSED_RESOLUTION", "현재 확인 대상에 없는 Master 응답이 있습니다.")
    modified = add_manifests(parts, sheets, clones)
    after = {**parts, **additions, **modified}
    checks = verify(parts, after, clones, changes, modified)
    out = io.BytesIO()
    with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as z:
        z.comment = comment
        for info in infos:
            z.writestr(info, after[info.filename])
        for part, content in additions.items():
            z.writestr(part, content)
    output = out.getvalue()
    # Reopen ZIP and repeat checks on the actual saved bytes.
    saved, _, _ = read_package(output)
    verify(parts, saved, clones, changes, modified)
    pending = [r for r in records if r["status"] == "review"]
    counts = {s: sum(r["status"] == s for r in records) for s in
              ("translated", "preserved", "review", "master_translated", "master_preserved")}
    report = {"schema_version": 1, "module_version": __version__, "baseline_commit": BASELINE_COMMIT,
              "rules_sha256": {name: sha((ROOT / name).read_bytes()) for name in
                               ("glossary/vi-ko-terms.csv", "docs/TRANSLATION_GUIDE.md", "docs/QUALITY_CHECKLIST.md")},
              "input_sha256": input_hash, "output_sha256": sha(output),
              "status": "completed", "has_notifications": bool(pending),
              "notification_count": len(pending),
              "message": "처리 완료 · Master 확인 알림 " + str(len(pending)) + "개" if pending else "처리 완료",
              "notifications": [{"level": "notify", "type": "master_review", "blocking": False,
                                 "id": r["id"], "sheet": r["sheet"], "cell": r["cell"],
                                 "message": r["reason"]} for r in pending],
              "network_used": False, "counts": counts, "checks": checks,
              "records": records,
              "limitations": ["신규·무성조 베트남어와 영문·고유명사를 일반 언어 모델처럼 판별하지 않습니다.",
                              "확인 대상에는 번역이 필요 없는 영문·고유명사가 포함될 수 있습니다.",
                              "Master 응답의 숫자는 검사하지만 의미·영문·고유명사 보존은 Master가 확인해야 합니다.",
                              "자동 구조 검증은 실제 Excel의 글자 잘림·인쇄 표시 검증을 대신하지 않습니다.",
                              "시트 내 이미지·도형·주석·표 등 미지원 객체가 있으면 전체 처리를 중단합니다."]}
    request = {"schema_version": 1, "input_sha256": input_hash, "baseline_commit": BASELINE_COMMIT,
               "notification_only": True, "blocking": False,
               "instruction": "필요할 경우 Master에게 확인 항목을 전달하세요. 확인 여부와 관계없이 모듈은 정상 수행되며 자동 전송하지 않습니다.",
               "items": pending}
    return output, report, request
