# 통합 프로그램 연결 계약

버전: `0.1.0` · JSON schema_version: `1`

이 프로젝트는 번역 규칙·코드·검증을 담당합니다. 통합 프로그램 프로젝트는 파일 선택 화면, 작업 실행, 결과 표시, Python 런타임 포함 또는 다른 실행 방식의 포장, Windows 설치파일을 담당합니다. 이 문서의 CLI/JSON 계약은 사용자 승인된 모듈 연결 기준이며 실제 통합 프로그램과의 연결 테스트는 미실행입니다.

## 권장 호출

명령 문자열을 연결하지 말고 인수 배열로 자식 프로세스를 실행합니다. cwd는 저장소 루트 폴더, 출력 인코딩은 UTF-8입니다.

```python
import json
import subprocess
result = subprocess.run(
    [python_executable, '-m', 'vnkr', '--input', original_xlsx,
     '--output-dir', new_job_directory],
    cwd=module_directory, capture_output=True, text=True, encoding='utf-8'
)
payload = json.loads(result.stdout)
```

Python 안에서 연결한다면 `vnkr.__main__.run(input_path, output_dir, resolutions_path=None)`를 호출할 수 있습니다. 메모리 바이트 인터페이스는 `vnkr.core.translate_bytes(data, resolutions=None)`이며 결과 XLSX bytes·report dict·master request dict를 반환합니다. Python 함수 호출 시 `ModuleError`를 잡아 화면에 표시하세요.

## 입력

| 입력 | 요구사항 |
|---|---|
| `--input` | 읽을 수 있는 `.xlsx`; TKN·HANG 존재; 암호화·매크로·전자서명 미지원 |
| `--output-dir` | 아직 존재하지 않는 결과 폴더. 작업별 고유 폴더 사용 |
| `--resolutions` | 선택사항. 원본 SHA256 및 원문·셀·항목 ID가 일치하는 Master 확인 JSON |

대상 시트에 이미지·도형·주석·표·확장 객체 등 미지원 구조가 있거나 한국어 시트가 이미 있으면 중단합니다. 그 밖의 기존 시트·리소스는 그대로 유지합니다. 압축 해제 크기 200MiB 초과 파일은 중단합니다. 여러 파일은 원본별로 별도 작업을 호출하세요.

## 상태와 종료 코드

| 종료 코드 | status | 통합 화면 안내 |
|---|---|---|
| 0 | `completed` | 정상 완료. 알림이 있어도 결과 열기·저장 및 통합 프로그램의 후속 작업을 계속 진행 |
| 3 | `blocked` | 잘못된 입력·미지원 구조·기존 KO 충돌 등 실제 처리 불가 사유 표시 |
| 1 | `error` | 파일 접근·저장·입력 형식 등 실제 실행 오류 표시 |

**Master 확인 항목은 오류·실패·대기 상태가 아닙니다.** `notification_count > 0`이어도 종료 코드 0입니다. 각 알림은 `level=notify`, `blocking=false`입니다. Master 확인을 모듈 완료·저장·다음 단계의 필수 조건으로 연결하지 않습니다. 실제 번역 범위와 Excel 표시 검증 범위는 별도로 안내합니다. 인수 누락 등 CLI 사용 오류는 argparse가 종료 코드 2를 사용할 수 있으나 Master 알림에는 사용하지 않습니다.

정상 작업 stdout은 JSON 한 개입니다. 주요 필드: `schema_version`, `status`, `message`, `output_file`, `review_file`, `report_file`, `master_request_file`, `counts`, `has_notifications`, `notification_count`, `notifications`, `network_used`.

## 생성 파일

| 파일 | 내용 |
|---|---|
| 원본파일명_한글번역.xlsx | 기존 시트 보존 + TKN_KO/HANG_KO |
| review.html | 오프라인 확인 화면, 원문·결과·위치·사유, 요청문 복사 |
| report.json | 모든 문자열 셀의 처리 이력, 원본/결과 해시, 검사 범위 |
| master_request.json | 미확인 항목과 원본 해시 |
| master_response_template.json | Master 확인 결과 입력 양식 |

`report.json`의 preserved 수에는 빈 문자열·숫자 문자열도 포함됩니다. 번역률이나 정확도 백분율로 해석하지 않습니다. 네트워크 사용은 없지만 JSON·HTML에 원문이 포함되므로 통합 프로그램에서 원문을 외부 로그 서비스로 전송하지 않습니다.

## Master 응답

응답 양식의 `decisions`에는 확인한 항목만 남깁니다. `action`을 `translate` 또는 `preserve`로 바꾸고 `approved_by`를 입력합니다. 번역이면 `target`, 사유는 `reason`에 입력합니다. 미처리 `pending` 항목은 제거하고 다음 검토에서 처리합니다. `approved_by`는 작업별 확인 기록이며 사용자 인증·전자서명 기능은 아닙니다.

```json
{
  "schema_version": 1,
  "input_sha256": "원본 해시를 그대로 유지",
  "decisions": [
    {
      "id": "요청의 항목 ID",
      "sheet": "TKN",
      "cell": "G150",
      "source": "요청의 원문 그대로",
      "action": "translate",
      "target": "Master가 확인한 번역문",
      "approved_by": "확인자",
      "reason": "확인 근거"
    }
  ]
}
```

숫자 토큰 변경은 차단합니다. 의미 정확성 및 영문·고유명사·단위·공백 보존은 Master가 확인해야 합니다. 응답을 적용해도 공통 규칙은 변경되지 않으며 다른 원본에 자동 재사용하지 않습니다.

