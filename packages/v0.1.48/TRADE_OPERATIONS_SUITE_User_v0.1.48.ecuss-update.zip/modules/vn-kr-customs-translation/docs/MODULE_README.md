# 베트남 수입면장 번역 모듈 v0.1.0

사용자 확정·저장 승인: **2026-09-30 (한국시간)**

확정된 용어·규칙으로 자동 처리하고, 자동 판단이 어려운 항목은 원문을 유지하여 Master 확인 알림을 제공합니다. **알림은 오류가 아니며 모듈 수행·결과 저장·후속 작업을 차단하지 않습니다.** 외부 AI·API 키·인터넷·자동 전송을 사용하지 않습니다.

## 실행

Python 3.10 이상이 필요하며 외부 Python 패키지는 필요하지 않습니다. 저장소 루트에서 실행합니다.

```bash
python -m vnkr --input "원본.xlsx" --output-dir "새로운_결과폴더"
```

Windows에서는 `py -3`로 실행하거나 Python/Tk가 설치된 검토 PC에서 루트의 `검토실행.bat`을 사용할 수 있습니다. Windows 실행기 자체와 통합 프로그램 연결은 아직 Windows 환경에서 검증하지 않았습니다.

Master 알림이 있어도 `status=completed`, 종료 코드 `0`으로 정상 완료합니다. 같은 결과 폴더를 덮어쓰지 않으며 기존 KO 시트가 있는 입력은 원본 보호를 위해 거절합니다. 입력 구조 미지원·파일 접근·저장 실패 등 실제 수행 불가 사유는 별도로 반환합니다.

## 결과

- 원본파일명_한글번역.xlsx: 원본 시트 유지 + TKN_KO/HANG_KO 추가
- review.html: 자동 번역·원문 보존·Master 알림 확인
- report.json: 적용 기준 해시·원본/결과 해시·처리 이력·검사 범위
- master_request.json 및 master_response_template.json: 필요 시 사용하는 작업별 확인 양식

모든 문구의 번역 확정과 모듈의 정상 실행 완료는 구분합니다. 신규 문구는 원문으로 남을 수 있고 실제 Excel 표시 검증은 별도입니다. 이 사실을 안내하되 확인 절차를 실행·저장·후속 단계의 선행조건으로 두지 않습니다.

## 선택적 Master 응답 적용

같은 원본에 대해 확인한 항목만 응답 파일에 담아 다시 실행합니다. 공통 용어표를 자동 변경하지 않습니다.

```bash
python -m vnkr --input "원본.xlsx" --output-dir "확인반영_결과폴더" --resolutions "master_response.json"
```

상세 입력·출력·응답 형식은 [연결 계약](MODULE_INTEGRATION.md)을 따릅니다.

## 검증 및 배포 담당

```bash
python -m unittest discover -s tests -v
```

17개 자동 테스트와 기준자료 실행을 검증했습니다. [검증 기록](MODULE_VALIDATION.md)에서 확인 완료와 미실행 범위를 구분합니다. 테스트는 합성 자료로 실행되며 실제 통관자료를 포함하지 않습니다.

이 저장소는 번역 모듈·기준·검증을 담당합니다. 통합 프로그램 프로젝트는 파일 선택 화면·호출·결과 표시·런타임 포함·Windows 설치파일·배포를 담당합니다. 실제 통합·Windows Excel 확인은 그 프로젝트에서 수행합니다.

## 단일 기준 관리

모듈은 루트의 `glossary/vi-ko-terms.csv` 및 `docs/TRANSLATION_GUIDE.md`, `docs/QUALITY_CHECKLIST.md`를 참조합니다. 별도의 rules 사본을 중복 관리하지 않습니다. 통합 프로그램에 배포할 때는 같은 커밋의 `vnkr/`, `glossary/`, 위 기준 문서를 함께 포함하고 적용 커밋을 기록합니다. 자동 GitHub 동기화는 구현하지 않았습니다.

모듈 검토 패키지의 demo 통관자료와 결과물은 이 저장소에 등록하지 않습니다. 현재 Standard form v1.2도 교체하지 않습니다.

