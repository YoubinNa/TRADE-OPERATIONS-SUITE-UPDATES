(() => {
  'use strict';
  const $ = id => document.getElementById(id);
  const copy = {
    ko:{dropHelp:'또는 원본 XLSX 파일 하나를 여기에 끌어놓으세요.',invalidDrop:'0바이트 초과, 32MiB 이하의 XLSX 파일 하나를 선택하세요.',eyebrow:'문서 번역 · VI → KO',title:'베트남 세관신고서 → 한국어 버전 변환',intro:'승인된 용어표와 규칙을 적용하고 한국어 시트를 추가합니다. 확인이 필요한 문구는 원문으로 유지합니다.',language:'언어',source:'원본 XLSX',select:'파일 선택',run:'한글화 실행',inputHelp:'TKN·HANG 시트가 있는 원본 · 최대 32MiB\n이미 한국어 시트가 있는 파일은 원본으로 사용할 수 없습니다.',noFile:'수입면장 원본을 선택하세요',result:'완료 결과',empty:'번역 후 Excel을 선택하여 저장하고 알림 보고서를 확인할 수 있습니다.',completed:'처리 완료',translated:'자동 번역',preserved:'원문 보존',notify:'Master 확인 알림',open:'Excel 열기',save:'Excel 저장',report:'알림 보고서',bundle:'결과·보고서 ZIP 저장',folder:'보관 폴더 열기',close:'닫기',savedNote:'결과는 자동 저장되지 않습니다. 필요한 경우 Excel 저장을 선택하세요. 화면을 나가면 저장하지 않은 결과는 사라집니다.',masterTitle:'Master 확인은 선택 사항',masterHelp:'알림 보고서에서 원문·위치·사유를 확인하고 필요한 경우 요청문을 복사하세요. 자동 전송하지 않으며, 확인 여부와 관계없이 저장과 다음 작업을 진행할 수 있습니다.',scopeTitle:'원본·서식 보존',scopeHelp:'원본 파일을 변경하지 않습니다. 미지원 구조는 사유를 표시합니다. 자동 구조 검사는 실제 Excel의 글자 잘림·인쇄 표시 확인을 대신하지 않습니다.',versionDetails:'적용 버전',running:'한글화 처리 중… 잠시 기다려 주세요.',saved:'저장했습니다: ',failure:'작업을 완료하지 못했습니다.',unavailable:'통합 프로그램에서 이 모듈을 열어 주세요.',cancelled:'저장을 취소했습니다. 현재 화면에서 다시 저장할 수 있습니다.',allClear:'확인 알림이 없습니다. 필요한 결과를 저장하고 다음 작업을 진행하세요.',notified:n=>`Master 확인 알림 ${n}개 · 해당 문구는 원문으로 유지했습니다. 번역은 정상 완료했으며 확인 여부와 관계없이 저장·다음 작업을 진행할 수 있습니다.`},
    en:{dropHelp:'Or drop one original XLSX file here.',invalidDrop:'Choose one nonempty XLSX file, up to 32MiB.',eyebrow:'DOCUMENT TRANSLATION · VI → KO',title:'Vietnamese customs declaration → Korean',intro:'Apply the approved glossary and rules, then add Korean sheets. Text requiring review stays in its original language.',language:'Language',source:'Original XLSX',select:'Choose file',run:'Translate into Korean',inputHelp:'Original TKN and HANG sheets · Up to 32MiB. Files with existing Korean sheets are not accepted as originals.',noFile:'Choose the original declaration',result:'Latest completed result',empty:'After translation, choose Save Excel or view the notification report.',completed:'Completed',translated:'Auto-translated',preserved:'Preserved',notify:'Master notifications',open:'Open Excel',save:'Save Excel',report:'Notification report',bundle:'Save Excel and reports ZIP',folder:'Open saved folder',close:'Close',savedNote:'Results are not saved automatically. Choose Save Excel if needed. Unsaved results are discarded when you leave this screen.',masterTitle:'Master review is optional',masterHelp:'View source text, locations and reasons in the report. Copy the request if needed. Nothing is sent automatically; saving and subsequent work remain available.',scopeTitle:'Source and formatting',scopeHelp:'The original file is unchanged. Unsupported structures show a reason. Automated structure checks do not replace visual checks for clipped text and printing in Excel.',versionDetails:'Applied version',running:'Translating… Please wait.',saved:'Saved: ',failure:'The operation could not be completed.',unavailable:'Open this module in the integrated desktop application.',cancelled:'Saving cancelled. You can save again while this screen remains open.',allClear:'No review notifications. Save the result if needed and continue working.',notified:n=>`${n} Master notification(s). The corresponding text was preserved. Translation is complete. Saving and subsequent work remain available.`},
    vi:{dropHelp:'Hoặc kéo một tệp XLSX gốc vào đây.',invalidDrop:'Chọn một tệp XLSX không rỗng, tối đa 32MiB.',eyebrow:'DỊCH TÀI LIỆU · VI → KO',title:'Dịch tờ khai nhập khẩu sang tiếng Hàn',intro:'Áp dụng thuật ngữ và quy tắc đã duyệt, thêm sheet tiếng Hàn. Nội dung cần xem xét được giữ nguyên.',language:'Ngôn ngữ',source:'XLSX gốc',select:'Chọn tệp',run:'Dịch sang tiếng Hàn',inputHelp:'Sheet TKN và HANG gốc · Tối đa 32MiB. Không dùng tệp đã có sheet tiếng Hàn làm bản gốc.',noFile:'Chọn tờ khai nhập khẩu gốc',result:'Kết quả hoàn tất gần nhất',empty:'Sau khi dịch, chọn lưu Excel hoặc xem báo cáo thông báo.',completed:'Đã hoàn tất',translated:'Dịch tự động',preserved:'Giữ nguyên',notify:'Thông báo Master',open:'Mở Excel',save:'Lưu Excel',report:'Báo cáo thông báo',bundle:'Lưu Excel và báo cáo ZIP',folder:'Mở thư mục đã lưu',close:'Đóng',savedNote:'Không tự động lưu kết quả. Chọn Lưu Excel nếu cần. Kết quả chưa lưu sẽ bị xóa khi rời màn hình.',masterTitle:'Không bắt buộc Master xác nhận',masterHelp:'Xem nguyên văn, vị trí và lý do trong báo cáo. Sao chép yêu cầu khi cần. Không tự gửi; vẫn có thể lưu và tiếp tục công việc.',scopeTitle:'Bản gốc và định dạng',scopeHelp:'Không thay đổi tệp gốc. Cấu trúc không hỗ trợ sẽ có lý do. Kiểm tra cấu trúc tự động không thay thế việc xem chữ bị cắt và bản in trong Excel.',versionDetails:'Phiên bản áp dụng',running:'Đang dịch… Vui lòng chờ.',saved:'Đã lưu: ',failure:'Không thể hoàn tất thao tác.',unavailable:'Mở mô-đun này trong chương trình tích hợp.',cancelled:'Đã hủy lưu. Có thể lưu lại khi vẫn ở màn hình này.',allClear:'Không có thông báo cần xem xét. Lưu nếu cần và tiếp tục.',notified:n=>`${n} thông báo Master. Nội dung tương ứng được giữ nguyên. Đã dịch xong; vẫn có thể lưu và tiếp tục công việc.`}
  };
  let lang = window.__ECUSS_SUITE__?.lang || 'ko', selection = null, result = null, busy = false;
  if (!copy[lang]) lang = 'ko';
  const t = () => copy[lang];
  window.EcussModuleUI = {workControls:'#run,#select-original,#original-dropzone'};
  window.EcussModuleState = {busy:()=>busy,hasWork:()=>!!selection,hasResult:()=>!!result};
  function controls(){
    $('select-original').disabled=busy; $('run').disabled=busy||!selection; $('language').disabled=busy;
    for(const id of ['save-excel','open-review','save-bundle'])$(id).disabled=busy||!result;
  }
  function message(text,error=false){const el=$('message');el.textContent=text;el.hidden=!text;el.dataset.error=String(error);el.setAttribute('role',error?'alert':'status');}
  function render(){
    document.documentElement.lang=lang;$('language').value=lang;document.title=t().title;
    for(const el of document.querySelectorAll('[data-copy]'))el.textContent=t()[el.dataset.copy];
    $('source-name').textContent=selection?.name||t().noFile;
    document.querySelector('.file-box').dataset.selected=String(!!selection);
    $('source-size').textContent=selection?`${(selection.size/1024).toLocaleString(lang,{maximumFractionDigits:1})} KB`:'';
    $('result').hidden=!result;$('empty-result').hidden=!!result;
    $('notification-summary').textContent=t().notify+' · '+(result?result.notificationCount:0);
    $('master-notifications').hidden=!result;
    if(result){
      $('result-name').textContent=result.outputName;$('result-date').textContent=new Date(result.completedUtc).toLocaleString(lang);
      $('count-translated').textContent=result.counts.translated;$('count-preserved').textContent=result.counts.preserved;
      $('count-notify').textContent=result.notificationCount;
      $('notification').textContent=result.notificationCount?t().notified(result.notificationCount):t().allClear;
    }
    controls();
  }
  async function call(path,payload){
    if(!window.EcussDesktop)throw new Error(t().unavailable);
    const r=await window.EcussDesktop.call(path,payload);
    if(r.status!==200||r.value?.ok===false)throw new Error(r.value?.message||t().failure);
    return r.value;
  }
  async function act(fn){
    if(busy)return;busy=true;controls();message('');
    try{await fn();}catch(e){message(e.message||t().failure,true);}finally{busy=false;controls();}
  }
  $('language').addEventListener('change',()=>{lang=$('language').value;message('');render();});
  $('select-original').addEventListener('click',()=>act(async()=>{const r=await call('/translation/select');if(r.selection){selection=r.selection;render();}}));
  const dropzone=$('original-dropzone');let dragDepth=0;
  const canDrop=()=>!busy&&document.body.dataset.ecussWorkBlocked!=='true';
  for(const event of ['dragenter','dragover'])dropzone.addEventListener(event,e=>{
    e.preventDefault();if(e.dataTransfer)e.dataTransfer.dropEffect=canDrop()?'copy':'none';
    if(canDrop()){if(event==='dragenter')dragDepth++;dropzone.classList.add('dragover');}
  });
  dropzone.addEventListener('dragleave',e=>{e.preventDefault();if(--dragDepth<=0){dragDepth=0;dropzone.classList.remove('dragover');}});
  dropzone.addEventListener('drop',e=>{
    e.preventDefault();dragDepth=0;dropzone.classList.remove('dragover');if(!canDrop())return;
    const files=Array.from(e.dataTransfer?.files||[]);
    if(files.length!==1||!/\.xlsx$/i.test(files[0].name)||files[0].size===0||files[0].size>32*1024*1024){message(t().invalidDrop,true);return;}
    act(async()=>{
      const file=files[0];
      const base64=await new Promise((resolve,reject)=>{const reader=new FileReader();reader.onerror=()=>reject(new Error(t().failure));reader.onload=()=>resolve(String(reader.result).split(',')[1]);reader.readAsDataURL(file);});
      const r=await call('/translation/import',{fileName:file.name,base64});
      if(r.selection){selection=r.selection;render();}
    });
  });
  for(const event of ['dragover','drop'])document.addEventListener(event,e=>{if(Array.from(e.dataTransfer?.types||[]).includes('Files'))e.preventDefault();});
  $('run').addEventListener('click',()=>act(async()=>{
    if(!selection)return;message(t().running);
    const r=await call('/translation/run',{selectionId:selection.id});
    if(r.cancelled){message('');return;}
    if(r.result?.status!=='completed'){message(r.result?.message||t().failure,true);return;}
    result=r.result;$('master-notifications').open=false;render();message('');
  }));
  $('open-review').addEventListener('click',()=>act(async()=>{
    const r=await call('/translation/open',{jobId:result.jobId,kind:'review'});
    const html=r.html.replace('번역·파일 저장은 정상 완료했습니다.','번역은 정상 완료했습니다. 파일은 사용자가 저장할 때만 보관됩니다.');
    const script="<script>document.addEventListener('click',e=>{const a=e.target.closest('a');if(!a)return;e.preventDefault();parent.postMessage({ecussReportSave:a.getAttribute('href')},'*');});<"+"/script>";
    $('report-frame').srcdoc=html.replace('</html>',script+'</html>');$('report-dialog').showModal();
  }));
  $('close-report').addEventListener('click',()=>$('report-dialog').close());
  $('report-dialog').addEventListener('close',()=>{$('report-frame').srcdoc='';});
  window.addEventListener('message',e=>{
    if(e.source!==$('report-frame').contentWindow||!$('report-dialog').open||!result)return;
    const kind={'report.json':'report','master_request.json':'request','master_response_template.json':'response'}[e.data?.ecussReportSave];
    if(typeof kind==='string')act(async()=>{await call('/translation/save',{jobId:result.jobId,kind});});
  });
  for(const [id,kind] of [['save-excel','excel'],['save-bundle','bundle']])
    $(id).addEventListener('click',()=>act(async()=>{const r=await call('/translation/save',{jobId:result.jobId,kind});message(r.cancelled?t().cancelled:t().saved+r.savedName);}));
  render();
  window.addEventListener('load',()=>act(async()=>{const r=await call('/translation/state');result=r.result||null;render();}),{once:true});
})();
