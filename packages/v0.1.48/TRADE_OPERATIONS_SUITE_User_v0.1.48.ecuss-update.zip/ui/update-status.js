/* Connection, published-version status and explicit full-release downloads. No business uploads. */
(() => {
 'use strict';
 const copy={
  ko:{unknown:'연결 확인 전',unavailable:'연결 여부 미확인',checking:'연결·최신 지침 확인 중…',check:'최신 여부 확인',settings:'업데이트 연결 안내',update:'업데이트·복구',time:'확인 시각',rules:'지침',states:{unchecked:'최신 여부 미확인',current:'최신 버전 사용 중',available:'업데이트 필요',authRequired:'저장소 연결 설정 필요',notPublished:'배포 정보 등록 전',newerLocal:'설치본이 배포 기준보다 최신',invalidCatalog:'배포 정보 확인 필요',connectionError:'연결 확인 실패',offline:'로컬 지침 사용 중'},details:{unchecked:'현재 PC에 설치된 지침으로 사용할 수 있습니다.',current:'설치된 프로그램과 모듈 지침이 GitHub에 게시된 최신 기준과 일치합니다.',available:'새 버전이 있습니다. 업데이트·복구에서 최신 배포 파일을 적용하세요.',authRequired:'비공개 저장소의 최신 정보를 읽으려면 연결 설정이 필요합니다. 로컬 업무는 계속 사용할 수 있습니다.',notPublished:'GitHub 연결은 확인했지만 최신 배포 정보가 아직 등록되지 않아 최신 여부는 미확인입니다.',newerLocal:'현재 설치본의 버전이 게시된 배포 기준보다 높습니다. 설치본을 그대로 사용할 수 있습니다.',invalidCatalog:'배포 정보를 검증하지 못했습니다. 최신 여부는 미확인이며 로컬 지침을 유지합니다.',connectionError:'GitHub 접속 또는 응답을 확인하지 못했습니다. 네트워크를 확인하고 다시 시도하세요.',offline:'최신 지침 확인을 위해 네트워크에 잠시 연결해 주세요. 지금은 설치된 로컬 지침으로 계속 사용할 수 있습니다.'}},
  en:{unknown:'Connection not checked',unavailable:'Connection not verified',checking:'Checking connection and versions…',check:'Check for updates',settings:'Update connection',update:'Updates / Restore',time:'Checked',rules:'Rules',states:{unchecked:'Latest version not verified',current:'Up to date',available:'Update available',authRequired:'Repository connection required',notPublished:'Release information not published',newerLocal:'Installed version is ahead',invalidCatalog:'Release information needs review',connectionError:'Connection check failed',offline:'Using local rules'},details:{unchecked:'You can use the rules installed on this PC.',current:'The installed application and module rules match the latest published GitHub versions.',available:'A newer version is available. Apply the latest release file through Updates / Restore.',authRequired:'Connect to the private repository to read release information. Local work remains available.',notPublished:'GitHub is reachable, but release information has not been published. The latest version is not verified.',newerLocal:'The installed version is newer than the published release. You can keep using it.',invalidCatalog:'Release information could not be verified. Local rules remain active.',connectionError:'Could not verify GitHub access or its response. Check the network and try again.',offline:'Connect to the network temporarily to check the latest rules. You can continue using installed local rules.'}},
  vi:{unknown:'Chưa kiểm tra kết nối',unavailable:'Chưa xác nhận kết nối',checking:'Đang kiểm tra kết nối và phiên bản…',check:'Kiểm tra cập nhật',settings:'Kết nối cập nhật',update:'Cập nhật / Khôi phục',time:'Đã kiểm tra',rules:'Quy tắc',states:{unchecked:'Chưa xác nhận phiên bản mới nhất',current:'Đang dùng bản mới nhất',available:'Có bản cập nhật',authRequired:'Cần kết nối kho riêng tư',notPublished:'Chưa công bố thông tin phát hành',newerLocal:'Bản đã cài mới hơn bản công bố',invalidCatalog:'Cần kiểm tra thông tin phát hành',connectionError:'Không xác nhận được kết nối',offline:'Đang dùng quy tắc cục bộ'},details:{unchecked:'Có thể sử dụng quy tắc đã cài trên máy này.',current:'Chương trình và quy tắc mô-đun khớp với bản mới nhất đã công bố trên GitHub.',available:'Có phiên bản mới. Áp dụng tệp phát hành mới qua Cập nhật / Khôi phục.',authRequired:'Cần kết nối kho riêng tư để đọc thông tin phát hành. Vẫn có thể làm việc cục bộ.',notPublished:'Đã kết nối GitHub nhưng chưa có thông tin phát hành. Chưa xác nhận được bản mới nhất.',newerLocal:'Bản đã cài mới hơn bản được công bố. Bạn có thể tiếp tục sử dụng.',invalidCatalog:'Không xác minh được thông tin phát hành. Giữ nguyên quy tắc cục bộ.',connectionError:'Không xác nhận được truy cập hoặc phản hồi GitHub. Kiểm tra mạng rồi thử lại.',offline:'Hãy kết nối mạng tạm thời để kiểm tra quy tắc mới nhất. Vẫn có thể dùng quy tắc cục bộ đã cài.'}}
 };
 const extra={
  ko:{network:{online:'온라인',local:'네트워크 연결 · 인터넷 확인 안 됨',offline:'오프라인',unknown:'네트워크 상태 미확인'},github:{reachable:'GitHub 접속 가능',unreachable:'GitHub 접속 불가',responseError:'GitHub 응답 확인 필요',unchecked:'GitHub 확인 전'},networkSource:'네트워크 표시는 Windows의 연결 판단 기준입니다.',settingsSummary:'업데이트 연결 안내',diagnostics:'진단 기록',offlineHint:'최신 지침 확인을 위해 네트워크에 잠시 연결해 주세요. 설치된 지침으로 계속 작업할 수 있습니다.',failedHint:'업데이트 서버에 연결하지 못했습니다. 설치된 지침으로 계속 작업할 수 있습니다.',userStates:{unchecked:'최신 여부 미확인',authRequired:'최신 여부 미확인',notPublished:'최신 여부 미확인',invalidCatalog:'최신 여부 미확인',connectionError:'최신 여부 미확인',newerLocal:'현재 버전 사용 가능'},userDetails:{unchecked:'설치된 지침으로 작업할 수 있습니다.',current:'프로그램과 모듈 지침이 최신입니다.',available:'새 버전이 있습니다. 업데이트를 진행해 주세요.',authRequired:'최신 여부를 확인하려면 아래의 업데이트 연결 설정을 확인해 주세요. 작업은 계속할 수 있습니다.',notPublished:'아직 최신 버전을 확인할 수 없습니다. 현재 설치된 지침으로 작업할 수 있습니다.',invalidCatalog:'업데이트 정보를 확인하지 못했습니다. 현재 설치된 지침을 유지합니다.',newerLocal:'현재 설치된 버전을 계속 사용할 수 있습니다.'}},
  en:{network:{online:'Online',local:'Network connected · Internet not verified',offline:'Offline',unknown:'Network status not verified'},github:{reachable:'GitHub reachable',unreachable:'GitHub unavailable',responseError:'GitHub response needs review',unchecked:'GitHub not checked'},networkSource:'Network status uses the Windows connectivity assessment.',settingsSummary:'Update connection',diagnostics:'Diagnostics',offlineHint:'Connect temporarily to check the latest rules. You can continue working with installed rules.',failedHint:'The update server could not be reached. You can continue working with installed rules.',userStates:{unchecked:'Latest version not verified',authRequired:'Latest version not verified',notPublished:'Latest version not verified',invalidCatalog:'Latest version not verified',connectionError:'Latest version not verified',newerLocal:'Installed version usable'},userDetails:{unchecked:'You can work with the installed rules.',current:'The application and module rules are up to date.',available:'A newer version is available. Please update.',authRequired:'Open Update connection settings below to check the latest version. You can keep working.',notPublished:'The latest version cannot be checked yet. You can work with the installed rules.',invalidCatalog:'Update information could not be verified. The installed rules are retained.',newerLocal:'You can continue using the installed version.'}},
  vi:{network:{online:'Trực tuyến',local:'Đã kết nối mạng · Chưa xác nhận Internet',offline:'Ngoại tuyến',unknown:'Chưa xác nhận trạng thái mạng'},github:{reachable:'Truy cập được GitHub',unreachable:'Không truy cập được GitHub',responseError:'Cần kiểm tra phản hồi GitHub',unchecked:'Chưa kiểm tra GitHub'},networkSource:'Trạng thái mạng dựa trên đánh giá kết nối của Windows.',settingsSummary:'Cài đặt kết nối cập nhật',diagnostics:'Nhật ký',offlineHint:'Hãy kết nối mạng tạm thời để kiểm tra quy tắc mới nhất. Vẫn có thể làm việc với quy tắc đã cài.',failedHint:'Không kết nối được máy chủ cập nhật. Vẫn có thể làm việc với quy tắc đã cài.',userStates:{unchecked:'Chưa xác nhận bản mới nhất',authRequired:'Chưa xác nhận bản mới nhất',notPublished:'Chưa xác nhận bản mới nhất',invalidCatalog:'Chưa xác nhận bản mới nhất',connectionError:'Chưa xác nhận bản mới nhất',newerLocal:'Có thể dùng bản đã cài'},userDetails:{unchecked:'Có thể làm việc với quy tắc đã cài.',current:'Chương trình và quy tắc mô-đun là bản mới nhất.',available:'Có phiên bản mới. Vui lòng cập nhật.',authRequired:'Mở Cài đặt kết nối cập nhật bên dưới để kiểm tra bản mới nhất. Vẫn có thể làm việc.',notPublished:'Chưa kiểm tra được bản mới nhất. Có thể dùng quy tắc đã cài.',invalidCatalog:'Không xác minh được thông tin cập nhật. Giữ nguyên quy tắc đã cài.',newerLocal:'Có thể tiếp tục dùng phiên bản đã cài.'}}
 };
 const policy={
  ko:{required:'필수 업데이트 · 업무 실행 제한',requiredDetail:'최신 승인 버전을 적용한 후 업무를 시작할 수 있습니다. 업데이트를 취소하거나 적용에 실패하면 실행 제한이 유지됩니다.',cached:'이전에 확인한 필수 업데이트가 아직 적용되지 않았습니다. 연결 확인 실패로 제한이 해제되지는 않습니다.',offlineKnown:'오프라인에서는 설치된 지침으로 사용할 수 있습니다. 연결되면 확인된 필수 업데이트를 적용해야 합니다.',checking:'최신 승인 버전을 확인한 뒤 모듈을 열 수 있습니다.'},
  en:{required:'Required update · Work paused',requiredDetail:'Install the latest approved version before starting work. Cancelling or a failed update keeps work blocked.',cached:'A previously confirmed required update is still pending. A connection failure does not remove this restriction.',offlineKnown:'Installed rules are available offline. Apply the confirmed required update when connected.',checking:'Modules can open after the approved-version check finishes.'},
  vi:{required:'Bắt buộc cập nhật · Tạm dừng công việc',requiredDetail:'Cài bản mới nhất đã duyệt trước khi làm việc. Hủy hoặc cập nhật thất bại vẫn giữ hạn chế.',cached:'Bản cập nhật bắt buộc đã xác nhận vẫn chưa áp dụng. Lỗi kết nối không gỡ bỏ hạn chế này.',offlineKnown:'Có thể dùng quy tắc đã cài khi ngoại tuyến. Khi có mạng phải áp dụng bản cập nhật bắt buộc đã xác nhận.',checking:'Có thể mở mô-đun sau khi kiểm tra xong phiên bản đã duyệt.'}
 };
 let state=window.__ECUSS_SUITE__?.access||{network:'unknown',github:'unchecked',state:'unchecked',modules:[],workBlocked:false},busy=false;
 const byId=id=>document.getElementById(id);
 function render(){
  if(!byId('connection-status'))return;
  const lang=document.documentElement.lang,t=copy[lang]||copy.ko,x=extra[lang]||extra.ko;
  const master=window.__ECUSS_SUITE__?.profile==='master';
  const p=policy[lang]||policy.ko;
  const status=byId('connection-status');status.textContent=busy?t.checking:x.network[state.network]||x.network.unknown;
  status.dataset.state=busy?'checking':state.network==='online'?'online':state.network==='offline'?'offline':'attention';
  const github=byId('github-status');github.hidden=!master;github.textContent=busy?x.github.unchecked:x.github[state.github]||x.github.unchecked;
  github.dataset.state=busy?'checking':state.github==='reachable'?'online':state.github==='unreachable'?'offline':'attention';
  const stateText=s=>(!master&&x.userStates[s])||t.states[s]||t.states.unchecked;
  byId('version-status').textContent=busy?'':stateText(state.state);
  byId('version-status').dataset.required=String(!!state.workBlocked);
  byId('connection-status').closest('.connection-panel').dataset.required=String(!!state.workBlocked);
  let detail=(!master&&x.userDetails[state.state])||t.details[state.state]||t.details.unchecked;
  if(state.state==='connectionError')detail=x.failedHint;
  if(state.network==='offline'&&state.github!=='reachable')detail=x.offlineHint;
  if(!busy&&state.state==='available'&&state.downloadAvailable)detail=lang==='en'?'Download the update, then review its changes before applying. Cancelling keeps your current version.':lang==='vi'?'Tải bản cập nhật rồi xem thay đổi trước khi áp dụng. Nếu hủy, giữ nguyên bản hiện tại.':'업데이트를 내려받은 뒤 변경 내용을 확인하고 적용하세요. 취소하면 현재 버전을 유지합니다.';
  if(!busy&&state.state==='available'&&state.requiresSetup)detail=lang==='en'?'A newer Setup is required. Use the installer matching Master or User.':lang==='vi'?'Cần bộ cài mới hơn. Dùng bộ cài đúng bản Master hoặc User.':'새 Setup이 필요합니다. Master/User에 맞는 최신 설치 프로그램을 사용하세요.';
  if(state.workBlocked){byId('version-status').textContent=p.required;detail=p.requiredDetail+(state.confirmationSource==='cached'?' '+p.cached:'');}
  else if(state.network==='offline'&&state.updateRequired)detail=p.offlineKnown;
  byId('connection-detail').textContent=busy?p.checking:detail;
  byId('check-updates').textContent=t.check;byId('github-settings').textContent=master?t.settings:x.settingsSummary;byId('open-updates').textContent=t.update;
  byId('settings-summary').textContent=x.settingsSummary;byId('open-diagnostics').textContent=x.diagnostics;
  const settings=byId('connection-settings');
  if(master){settings.open=true;settings.dataset.master='';}else delete settings.dataset.master;
  byId('open-diagnostics').hidden=master;
  byId('download-update').textContent=lang==='en'?'Download update…':lang==='vi'?'Tải bản cập nhật…':'업데이트 다운로드…';
  byId('download-update').hidden=state.state!=='available'||!state.downloadAvailable;
  byId('download-update').disabled=busy;
  byId('check-updates').disabled=byId('github-settings').disabled=busy;
  byId('open-updates').hidden=state.state!=='available'&&!state.workBlocked;
  let info='App '+(state.currentVersion||window.__ECUSS_SUITE__?.appVersion||'');
  if(state.latestVersion)info+=' → '+state.latestVersion;
  if(state.checkedAt)info+=' · '+t.time+': '+new Date(state.checkedAt).toLocaleString(lang==='ko'?'ko-KR':lang==='vi'?'vi-VN':'en-US');
  byId('connection-time').hidden=!master;byId('connection-time').textContent=master?info+' · '+x.networkSource:'';
  for(const box of document.querySelectorAll('[data-module-version]')){
   const m=state.modules?.find(x=>x.id===box.dataset.moduleVersion);
   const current=window.__ECUSS_SUITE__?.modules.find(x=>x.id===box.dataset.moduleVersion);
   box.textContent=(busy?t.checking:stateText(m?.state))+(master?' · '+(m?.currentVersion||current?.version||'')+' · '+t.rules+' '+(m?.currentRules||current?.rulesVersion||''):'');
  }
  window.EcussHome?.syncAccess(state,busy);
 }
 async function check(force){
  if(busy)return;busy=true;render();
  try{const r=await EcussDesktop.call('/updates/check',!!force);if(r.status!==200)throw new Error('status');state=r.value;}
  catch{state={...state,network:'unknown',github:'unchecked',state:'connectionError',modules:state.modules?.map(m=>({...m,state:'unchecked'}))||[]};}
  finally{busy=false;render();}
 }
 window.EcussUpdateStatus={render,accept(next){state=next;render();}};
 window.addEventListener('DOMContentLoaded',()=>{
  byId('check-updates').addEventListener('click',()=>check(true));
  byId('github-settings').addEventListener('click',async()=>{try{const r=await EcussDesktop.call('/updates/settings');if(r.status===200&&r.value.changed)await check(true);}catch{state={...state,state:'connectionError'};render();}});
  byId('open-diagnostics').addEventListener('click',()=>EcussDesktop.call('/desktop/log').catch(()=>{}));
  byId('download-update').addEventListener('click',async()=>{
   if(busy)return;busy=true;render();
   try{const r=await EcussDesktop.call('/updates/download');if(r.status!==200)throw new Error('download');}
   catch{state={...state,downloadAvailable:false,state:'connectionError'};}
   finally{busy=false;render();}
  });
  byId('open-updates').addEventListener('click',async()=>{try{await EcussDesktop.call('/desktop/update');}catch{state={...state,state:'connectionError'};render();}});
  render();check(false);
 },{once:true});
})();
