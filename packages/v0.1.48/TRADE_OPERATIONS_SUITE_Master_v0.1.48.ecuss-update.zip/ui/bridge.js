/* Host API v1. Local WebView2 messages only; no network fallback. */
(() => {
  'use strict';
  if (window !== window.top || !window.chrome?.webview || !window.__ECUSS_HOST_NONCE__) return;
  const pending = new Map();
  window.chrome.webview.addEventListener('message', event => {
    const message = event.data;
    if (message?.kind === 'work-access') { applyAccess(message.value); return; }
    if (!message || message.kind !== 'rpc-reply') return;
    const entry = pending.get(message.id);
    if (!entry) return;
    pending.delete(message.id);
    clearTimeout(entry.timer);
    entry.resolve(message);
  });
  function call(path, payload = null) {
    const id = Array.from(crypto.getRandomValues(new Uint8Array(16)), x => x.toString(16).padStart(2, '0')).join('');
    return new Promise((resolve, reject) => {
      // A native dialog may wait for user input; do not retry the operation.
      const timer = path.startsWith('/stock/') || path.startsWith('/translation/') || ['/api/send','/api/prepare','/desktop/home','/updates/settings','/updates/download'].includes(path) ? null : setTimeout(() => {
        pending.delete(id); reject(new Error('The desktop connection did not respond.'));
      }, 60000);
      pending.set(id, { resolve, reject, timer });
      try { window.chrome.webview.postMessage({ kind: 'rpc', id, nonce: window.__ECUSS_HOST_NONCE__, path, payload: JSON.stringify(payload) }); }
      catch (error) { clearTimeout(timer); pending.delete(id); reject(error); }
    });
  }
  let access = window.__ECUSS_SUITE__?.access || {workBlocked:false,gateReason:'unverifiedAllowed'}, authorizing = false, accessError = false;
  const accessCopy = {
    ko:{title:'필수 업데이트 · 업무 실행 제한',detail:'최신 승인 버전을 적용해야 업무를 계속할 수 있습니다. 현재 결과는 HTML·Excel로 저장한 뒤 메인화면에서 업데이트하세요.',checking:'최신 버전 확인 중…',failure:'실행 허용 여부를 확인하지 못했습니다. 다시 시도해 주세요.',offline:'오프라인 · 설치된 지침으로 작업합니다. 연결되면 최신 버전을 다시 확인합니다.'},
    en:{title:'Required update · Work paused',detail:'Install the latest approved version to continue working. Save existing HTML/Excel results, then return to the main screen to update.',checking:'Checking the latest version…',failure:'Could not verify permission to start work. Please try again.',offline:'Offline · Using installed rules. Versions will be checked again when connected.'},
    vi:{title:'Bắt buộc cập nhật · Tạm dừng công việc',detail:'Cài bản mới nhất đã được duyệt để tiếp tục. Lưu kết quả HTML/Excel hiện có rồi về màn hình chính để cập nhật.',checking:'Đang kiểm tra phiên bản mới nhất…',failure:'Không xác nhận được quyền bắt đầu công việc. Vui lòng thử lại.',offline:'Ngoại tuyến · Dùng quy tắc đã cài. Kiểm tra lại phiên bản khi có mạng.'}
  };
  function renderAccess(){
    const banner=document.getElementById('ecuss-work-access');if(!banner)return;
    const t=accessCopy[document.documentElement.lang]||accessCopy.ko;
    const blocked=!!access.workBlocked;
    banner.hidden=!blocked&&!authorizing&&!accessError&&access.network!=='offline';
    banner.dataset.blocked=String(blocked);
    banner.textContent=authorizing?t.checking:accessError?t.failure:blocked?t.title+' — '+t.detail:t.offline;
    document.body.dataset.ecussWorkBlocked=String(blocked||authorizing);
    for(const el of document.querySelectorAll('#analyze,#run,#mail-preview-open')){
      if(blocked||authorizing)el.setAttribute('aria-disabled','true');else el.removeAttribute('aria-disabled');
    }
  }
  function applyAccess(next){
    if(!next || typeof next.workBlocked!=='boolean')return;
    access=next;renderAccess();window.EcussUpdateStatus?.accept(next);
  }
  async function authorizeWork(){
    if(authorizing)return false;authorizing=true;accessError=false;renderAccess();
    try{
      const r=await call('/desktop/authorize');
      if(r.status!==200||typeof r.value?.allowed!=='boolean')throw new Error('gate');
      applyAccess(r.value.access);return r.value.allowed===true;
    }catch{
      accessError=true;const banner=document.getElementById('ecuss-work-access');
      if(banner){banner.hidden=false;banner.textContent=(accessCopy[document.documentElement.lang]||accessCopy.ko).failure;}
      return false;
    }finally{authorizing=false;renderAccess();}
  }
  window.EcussDesktop = { call, authorizeWork };
  /* MASTER_TRANSPORT_BEGIN */
  const allowed = new Set(['/api/bootstrap', '/api/prepare', '/api/send']);
  window.fetch = async (input, init = {}) => {
    const url = new URL(typeof input === 'string' ? input : input.url, location.href);
    if (url.origin !== location.origin || (!allowed.has(url.pathname) && !/^\/download\/[0-9a-f]{32}\/(html|excel)$/.test(url.pathname)))
      throw new Error('This application does not make external requests.');
    const response = await call(url.pathname, init.body ? JSON.parse(init.body) : null);
    if (response.value?.binary) {
      const bytes = Uint8Array.from(atob(response.value.binary), c => c.charCodeAt(0));
      return new Response(bytes, { status: response.status, headers: { 'Content-Type': response.value.type } });
    }
    return new Response(JSON.stringify(response.value), { status: response.status, headers: { 'Content-Type': 'application/json' } });
  };
  /* MASTER_TRANSPORT_END */
  window.EcussDesktopState = () => ({
    busy: authorizing || !!window.EcussModuleState?.busy?.() || !!window.EcussMailBusy || !!document.querySelector('#analyze[data-desktop-running="true"]') ||
      (!!window.EcussModuleState?.hasResult() && !!document.querySelector('#download:disabled,#save-html:disabled')),
    hasWork: !!window.EcussModuleState?.hasWork?.() || !!window.EcussModuleState?.hasResult?.() || !!document.querySelector('.upload-card.ready') ||
      [...document.querySelectorAll('input[type="file"]')].some(x => x.files.length > 0)
  });
  let homeButton, homeNotice, homePending = false;
  const homeText = {
    ko: {home:'메인화면으로',busy:'진행 중인 작업이 끝난 뒤 다시 눌러 주세요.',error:'메인화면으로 돌아가지 못했습니다. 다시 시도하거나 상단의 업무 모듈을 이용하세요.'},
    en: {home:'Back to main screen',busy:'Wait for the current task to finish.',error:'Could not return to the main screen. Try again or use Work modules above.'},
    vi: {home:'Về màn hình chính',busy:'Chờ tác vụ hiện tại hoàn tất.',error:'Không thể về màn hình chính. Thử lại hoặc chọn Mô-đun công việc ở phía trên.'}
  };
  function homeCopy() { return homeText[document.documentElement.lang] || homeText.ko; }
  function installModuleNavigation() {
    if (!window.__ECUSS_DESKTOP_CONTEXT__?.moduleId || document.getElementById('ecuss-module-navigation')) return;
    const style=document.createElement('style');style.setAttribute('data-ecuss-desktop','');
    style.textContent='#ecuss-module-navigation{background:#123751;color:#fff;font-family:Segoe UI,Malgun Gothic,sans-serif}#ecuss-module-navigation .ecuss-nav-inner{max-width:1480px;margin:0 auto;padding:14px 28px;display:flex;align-items:center;gap:18px;flex-wrap:wrap}#ecuss-home-button{display:inline-flex;align-items:center;gap:9px;border:1px solid #91c4d2;border-radius:8px;background:#fff;color:#16475e;padding:10px 16px;font:600 14px Segoe UI,Malgun Gothic,sans-serif;cursor:pointer}#ecuss-home-button:hover{background:#e9f4f8}#ecuss-home-button:disabled{opacity:.65;cursor:wait}#ecuss-home-button:focus-visible{outline:3px solid #88e0ef;outline-offset:3px}#ecuss-home-notice{font-size:13px;color:#fff3d9;line-height:1.6}';
    document.head.append(style);
    const policyStyle=document.createElement('style');policyStyle.setAttribute('data-ecuss-desktop','');
    policyStyle.textContent='#ecuss-work-access{margin:0;padding:16px 28px;background:#fff4dc;color:#724d12;font:14px/1.65 Segoe UI,Malgun Gothic,sans-serif;border-bottom:1px solid #e8c987}#ecuss-work-access[data-blocked="true"]{background:#fff0ec;color:#9c3829;border-color:#e5b9af}body[data-ecuss-work-blocked="true"] #analyze,body[data-ecuss-work-blocked="true"] #mail-preview-open,body[data-ecuss-work-blocked="true"] .upload-card{opacity:.55;cursor:not-allowed}';
    document.head.append(policyStyle);
    const notice=document.createElement('section');notice.id='ecuss-work-access';notice.setAttribute('data-ecuss-desktop','');notice.setAttribute('role','alert');notice.hidden=true;document.body.prepend(notice);
    for(const name of ['click','drop','keydown']) document.addEventListener(name,event=>{
      if((access.workBlocked||authorizing)&&event.target.closest?.('#analyze,.upload-card,#mail-preview-open,#ecuss-mail-dialog,'+(window.EcussModuleUI?.workControls||'#run'))){
        if(name==='keydown'&&!['Enter',' '].includes(event.key))return;
        event.preventDefault();event.stopImmediatePropagation();renderAccess();
      }
    },true);
    const nav=document.createElement('nav');nav.id='ecuss-module-navigation';nav.setAttribute('data-ecuss-desktop','');
    const inner=document.createElement('div');inner.className='ecuss-nav-inner';
    homeButton=document.createElement('button');homeButton.type='button';homeButton.id='ecuss-home-button';
    const arrow=document.createElement('span');arrow.textContent='←';arrow.setAttribute('aria-hidden','true');
    const label=document.createElement('span');label.textContent=homeCopy().home;homeButton.append(arrow,label);
    homeNotice=document.createElement('span');homeNotice.id='ecuss-home-notice';homeNotice.setAttribute('role','status');homeNotice.setAttribute('aria-live','polite');
    inner.append(homeButton,homeNotice);nav.append(inner);
    const header=document.querySelector('body > header');if(header)header.before(nav);else document.body.prepend(nav);
    homeButton.addEventListener('click',async()=>{
      if(homePending)return;
      homeNotice.textContent='';
      if(window.EcussDesktopState().busy){homeNotice.textContent=homeCopy().busy;return;}
      homePending=true;homeButton.disabled=true;
      try{const response=await call('/desktop/home');if(response.status!==200)throw new Error(response.value?.message||homeCopy().error);}
      catch(error){homeNotice.textContent=homeCopy().error;}
      finally{homePending=false;homeButton.disabled=false;}
    });
  }
  // Bind each same-origin document: keyboard events inside PSR frames do not bubble to the host page.
  const homeDocuments=new WeakSet();
  function bindHomeShortcut(doc){
    if(homeDocuments.has(doc))return;homeDocuments.add(doc);
    doc.addEventListener('keydown',event=>{
      const backspace=event.key==='Backspace'&&!event.altKey;
      const altLeft=event.key==='ArrowLeft'&&event.altKey;
      if((!backspace&&!altLeft)||event.ctrlKey||event.metaKey||event.shiftKey)return;
      if(!homeButton)return;
      // Consume browser Back even while guarded, so history cannot bypass the work confirmation.
      const handled=event.defaultPrevented;
      if(altLeft)event.preventDefault();
      if(handled||event.isComposing||event.keyCode===229)return;
      const nodes=event.composedPath?.()||[event.target];
      if(nodes.some(el=>el?.closest?.('dialog,[role="dialog"]')))return;
      if(doc.querySelector('dialog[open], [role="dialog"][aria-modal="true"]:not([hidden])'))return;
      if(backspace&&nodes.some(el=>el?.isContentEditable||el?.closest?.('input,textarea,select,[contenteditable]:not([contenteditable="false"]),[role="textbox"],[role="combobox"],[role="spinbutton"]')))return;
      event.preventDefault();
      if(!event.repeat&&!homePending)homeButton.click();
    });
    for(const frame of doc.querySelectorAll('iframe')){
      const bind=()=>{try{if(frame.contentDocument)bindHomeShortcut(frame.contentDocument);}catch{}};
      frame.addEventListener('load',bind);bind();
    }
  }
  function language() {
    const lang = document.documentElement.lang;
    renderAccess();
    if(homeButton){homeButton.lastElementChild.textContent=homeCopy().home;homeNotice.textContent='';}
    if (['ko', 'en', 'vi'].includes(lang)) call('/desktop/language', lang).catch(() => {});
  }
  window.addEventListener('load', () => {
    installModuleNavigation();
    if(homeButton){homeButton.setAttribute("aria-keyshortcuts","Backspace Alt+ArrowLeft");bindHomeShortcut(document);}
    language();
    new MutationObserver(language).observe(document.documentElement, { attributes: true, attributeFilter: ['lang'] });
    call('/desktop/ready').catch(() => {});
    if(window.__ECUSS_DESKTOP_CONTEXT__?.moduleId)call('/updates/check',false).then(r=>{if(r.status===200)applyAccess(r.value);}).catch(()=>{});
  }, { once: true });
})();



/* Integration UI only: company IDs and the approved validation engine stay unchanged. */
(() => {
  'use strict';
  if (!window.EcussDesktop) return;
  const companies={AMO:'AMOVINA',AMOGREEN:'AMOGREEN VINA'};
  const copy={
    ko:{title:'검증 수행 현황',unknown:'확인 불가',notConfigured:'연결 미설정',checking:'확인 중',pending:'동기화 대기',connected:'동기화 완료',unavailable:'연결 확인 필요',unread:'기록을 불러오지 못했습니다',retry:'다시 확인',authentication:'연결 인증 갱신 필요',authHelp:'기록 저장소의 연결 인증을 갱신해야 합니다. Master에게 알려 주세요.',cached:'마지막 저장 결과입니다. 최신 상태는 연결 복구 후 확인할 수 있습니다.',cachedDownload:'마지막 저장 HTML 다운로드',NA:'수행 대상 아님',none:'완료 기록 없음',view:'최신 기록·결과',html:'공유용 HTML 열기',download:'최신 검증 결과 HTML 다운로드',close:'닫기',started:'시작',completed:'완료',incomplete:'미완료',profile:'실행 구분',state:'최근 실행 상태',running:'진행 중',failed:'실패',interrupted:'중단',done:'완료',error:'기록을 저장·조회하지 못했습니다. 검증 결과는 그대로 사용할 수 있습니다.',zone:'베트남 시각 · 월~토 · 회사별 매일 1회',saving:'검증 결과 동기화 중'},
    en:{title:'Validation status',unknown:'Unavailable',notConfigured:'Not connected',checking:'Checking',pending:'Sync pending',connected:'Synced',unavailable:'Check connection',unread:'Could not load the record',retry:'Check again',authentication:'Connection renewal required',authHelp:'The records connection needs renewed credentials. Contact the Master.',cached:'Last saved result. Reconnect to verify the latest status.',cachedDownload:'Download last saved HTML',NA:'Not required',none:'No completed record',view:'Latest record / result',html:'Open shared HTML',download:'Download latest validation HTML',close:'Close',started:'Started',completed:'Completed',incomplete:'Incomplete',profile:'Profile',state:'Latest attempt',running:'Running',failed:'Failed',interrupted:'Interrupted',done:'Completed',error:'Could not save/read the record. Your validation result remains available.',zone:'Vietnam time · Mon–Sat · Once daily per company',saving:'Synchronizing validation result'},
    vi:{title:'Trạng thái kiểm tra',unknown:'Không xác định',notConfigured:'Chưa kết nối',checking:'Đang kiểm tra',pending:'Chờ đồng bộ',connected:'Đã đồng bộ',unavailable:'Cần kiểm tra kết nối',unread:'Không tải được bản ghi',retry:'Kiểm tra lại',authentication:'Cần gia hạn xác thực',authHelp:'Cần cập nhật xác thực kết nối bản ghi. Vui lòng báo Master.',cached:'Kết quả đã lưu gần nhất. Kết nối lại để xác nhận trạng thái mới nhất.',cachedDownload:'Tải HTML đã lưu gần nhất',NA:'Không yêu cầu',none:'Chưa có lần hoàn tất',view:'Bản ghi / kết quả mới nhất',html:'Mở HTML chia sẻ',download:'Tải HTML kết quả kiểm tra mới nhất',close:'Đóng',started:'Bắt đầu',completed:'Hoàn tất',incomplete:'Chưa hoàn tất',profile:'Vai trò',state:'Lần chạy mới nhất',running:'Đang chạy',failed:'Thất bại',interrupted:'Gián đoạn',done:'Hoàn tất',error:'Không lưu/đọc được bản ghi. Kết quả kiểm tra vẫn sử dụng được.',zone:'Giờ Việt Nam · Thứ 2–7 · Mỗi công ty một lần/ngày',saving:'Đang đồng bộ kết quả'}
  };
  const t=()=>copy[document.documentElement.lang]||copy.ko;
  const el=(tag,text,cls)=>{const x=document.createElement(tag);if(text)x.textContent=text;if(cls)x.className=cls;return x;};
  function time(value,short=false){if(!value)return '—';const d=new Date(value);if(Number.isNaN(d.getTime()))return '—';return new Intl.DateTimeFormat('en-GB',{timeZone:'Asia/Ho_Chi_Minh',...(short?{hour:'2-digit',minute:'2-digit'}:{dateStyle:'short',timeStyle:'medium'}),hour12:false}).format(d);}
  const inModule=()=>window.__ECUSS_DESKTOP_CONTEXT__?.moduleId==='balance-sheet-validation';
  let rows=[],fetching=false,notice,activeCompany;
  function message(text){if(!notice){notice=el('p','','ecuss-record-notice');notice.dataset.ecussDesktop='';notice.setAttribute('role','status');(document.getElementById('dropzone')||document.body).append(notice);}notice.textContent=text;}
  async function rpc(path,payload){const r=await EcussDesktop.call(path,payload);if(r.status!==200)throw new Error('records');return r.value;}
  window.EcussRecords={
    async begin(company){activeCompany=company;try{const r=await rpc('/records/begin',company);message(t().running+' · '+companies[company]);return {runId:r.runId,company};}catch{message(t().error);return null;}},
    async complete(run,build){if(!run)return;let html;try{html=await build();}catch{await this.fail(run);message(t().error);return;}try{message(t().saving);await rpc('/records/finish',{...run,state:'completed',html});message(t().pending);refresh();}catch{message(t().error);}},
    async fail(run){if(!run)return;try{await rpc('/records/finish',{...run,state:'failed'});message(t().failed+' · '+t().pending);refresh();}catch{message(t().error);}}
  };
  const style=el('style');style.dataset.ecussDesktop='';style.textContent=`
.ecuss-record-footer{grid-column:2;display:flex;align-items:center;justify-content:space-between;gap:12px;flex-wrap:wrap;min-width:0}.ecuss-record-footer>.open{flex-shrink:0;margin:0}.ecuss-records{display:flex;flex-direction:column;gap:8px;margin-left:auto;max-width:100%;font-size:11px}.ecuss-record-row{display:flex;align-items:center;gap:14px;justify-content:space-between;min-width:0}.ecuss-record-summary{display:flex;align-items:center;gap:7px;white-space:nowrap}.ecuss-record-company{font-weight:650}.ecuss-record-status{display:inline-flex;align-items:center;gap:5px;font-weight:650;color:#64748b}.ecuss-record-dot{width:7px;height:7px;border-radius:50%;background:currentColor;flex-shrink:0}.ecuss-record-row[data-mark=O] .ecuss-record-status{color:#08783d}.ecuss-record-row[data-mark=X] .ecuss-record-status{color:#bd2525}.ecuss-record-row[data-connection=unavailable] .ecuss-record-status{color:#a35c00}.ecuss-record-time{font-variant-numeric:tabular-nums;color:#52667d}.ecuss-record-sync{font-size:10px;color:#735e26}.ecuss-records>button.ecuss-record-row{border:0;background:none;padding:0;text-align:left;color:inherit;font:inherit;cursor:pointer;border-radius:4px}.ecuss-records>button.ecuss-record-row:hover{text-decoration:underline;text-underline-offset:3px}.ecuss-records>button.ecuss-record-row:focus-visible{outline:2px solid #5276cf;outline-offset:4px}
.ecuss-records-module{margin:0 0 16px;padding:20px 24px;border:1px solid #e1e7f2;border-radius:18px;background:#fff;color:#26374e}.ecuss-records-module header{display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:10px;padding:0;margin:0 0 14px;background:none;border:0;position:static}.ecuss-records-module h2{font-size:15px;margin:0}.ecuss-records-module header p{font-size:11px;color:#64748b;margin:5px 0 0}.ecuss-records-module .ecuss-records{margin:0;font-size:13px;gap:10px}.ecuss-records-module .ecuss-record-row{padding:10px 0;border-top:1px solid #edf0f5;flex-wrap:wrap}.ecuss-record-download,.ecuss-record-details,.ecuss-record-dialog button{padding:8px 12px;border:1px solid #dce5fa;border-radius:9px;background:#f0f4ff;color:#4361a0;font-size:12px;cursor:pointer}.ecuss-record-download:disabled{opacity:.5;cursor:default}.ecuss-record-dialog{max-width:700px;width:90%;border:1px solid #c4d3dd;border-radius:12px;padding:24px}.ecuss-record-dialog::backdrop{background:#12375188}.ecuss-record-dialog section{border-top:1px solid #dde5eb;margin-top:15px;padding-top:15px}.ecuss-record-notice{font-size:12px;margin:8px 0 0;color:#52667d}@media(max-width:500px){.ecuss-record-footer{grid-column:1/-1}.ecuss-records-module{padding:16px}.ecuss-records-module .ecuss-record-summary{gap:5px;font-size:12px}}`;
  document.head.append(style);
  async function download(company,button){
    button.disabled=true;
    try{
      const result=await rpc('/records/html',company);
      if(typeof result.html!=='string'||!result.html)throw new Error('empty result');
      const url=URL.createObjectURL(new Blob([result.html],{type:'text/html;charset=utf-8'}));
      const link=el('a');link.href=url;link.download=companies[company].replaceAll(' ','_')+'_latest_validation.html';document.body.append(link);link.click();link.remove();setTimeout(()=>URL.revokeObjectURL(url),60000);
    }catch{message(t().error);}finally{button.disabled=false;}
  }
  function summary(r){
    const result=el('span','','ecuss-record-summary'),status=el('span','','ecuss-record-status');
    const label=r.mark==='O'?t().completed:r.mark==='X'?t().incomplete:r.mark==='NA'?t().NA:(r.errorCode==='authentication'?t().authentication:t()[r.connection]||t().unknown);
    const dot=el('span','','ecuss-record-dot');dot.setAttribute('aria-hidden','true');status.append(dot,el('span',label));
    result.append(el('span',companies[r.company],'ecuss-record-company'),status);
    if(r.mark==='O'&&r.latest)result.append(el('time',time(r.latest.completedAt,true),'ecuss-record-time'));
    if(r.connection==='pending')result.append(el('span',r.errorCode==='authentication'?t().authentication:t().pending,'ecuss-record-sync'));
    return result;
  }
  function emptyText(r){
    if(r.errorCode==='authentication')return t().authHelp;
    return r.connection==='connected'?t().none:r.connection==='checking'?t().checking:r.connection==='notConfigured'?t().notConfigured:t().unread;
  }
  function fill(panel,module){
    panel.replaceChildren();
    for(const company of Object.keys(companies)){
      const r=rows.find(x=>x.company===company)||{company,mark:'?',connection:'checking'};
      const row=el(module?'div':'button','','ecuss-record-row');row.dataset.mark=r.mark;row.dataset.connection=r.connection;row.dataset.company=company;
      const description=summary(r);
      row.title=companies[company]+' · '+t().zone+' · '+(r.latest?t().completed+': '+time(r.latest.completedAt):emptyText(r));
      row.append(description);
      if(module){const b=el('button',r.connection==='unavailable'?t().cachedDownload:t().download,'ecuss-record-download');b.type='button';b.dataset.company=company;b.disabled=!r.hasHtml;b.title=row.title;b.setAttribute('aria-label',companies[company]+' · '+b.textContent);b.onclick=()=>download(company,b);row.append(b);}
      else{row.type='button';row.setAttribute('aria-label',description.textContent+' · '+t().view);row.onclick=show;}
      panel.append(row);
    }
  }
  function render(){
    if(inModule()){
      const drop=document.getElementById('dropzone');if(!drop)return;
      let block=document.querySelector('.ecuss-records-module');
      if(!block){block=el('section','','ecuss-records-module');block.dataset.ecussDesktop='';drop.before(block);}
      let panel=block.querySelector('.ecuss-records');
      if(!panel){const header=el('header'),heading=el('div');heading.append(el('h2'),el('p'));const b=el('button','','ecuss-record-details');b.type='button';b.onclick=show;header.append(heading,b);panel=el('div','','ecuss-records');panel.setAttribute('aria-live','polite');block.append(header,panel);}
      block.querySelector('h2').textContent=t().title;block.querySelector('header p').textContent=t().zone;block.querySelector('.ecuss-record-details').textContent=t().view;fill(panel,true);return;
    }
    const card=document.querySelector('[data-module-card="balance-sheet-validation"]');if(!card)return;
    let panel=card.querySelector('.ecuss-records');
    if(!panel){const footer=el('div','','ecuss-record-footer'),open=card.querySelector('button.open');if(!open)return;open.before(footer);footer.append(open);panel=el('div','','ecuss-records');panel.setAttribute('aria-live','polite');footer.append(panel);}
    fill(panel,false);
  }
  function details(d){
    for(const s of d.querySelectorAll('section'))s.remove();
    const close=d.querySelector('.ecuss-record-close');
    for(const r of rows){const s=el('section');
      const row=el('div','','ecuss-record-row');row.dataset.mark=r.mark;row.dataset.connection=r.connection;row.dataset.company=r.company;row.append(summary(r));s.append(row);
      if(r.latest)s.append(el('p',t().profile+': '+r.latest.profile),el('p',t().started+': '+time(r.latest.startedAt)),el('p',t().completed+': '+time(r.latest.completedAt)));else s.append(el('p',emptyText(r)));
      if(r.latest&&r.connection==='unavailable')s.append(el('p',t().cached),el('p',r.errorCode==='authentication'?t().authHelp:t().unread));
      if(r.attempt)s.append(el('p',t().state+': '+(r.attempt.state==='completed'?t().done:t()[r.attempt.state]||r.attempt.state)+' · '+time(r.attempt.completedAt||r.attempt.startedAt)));
      const b=el('button',t().html);b.disabled=!r.hasHtml;b.onclick=async()=>{b.disabled=true;try{await rpc('/records/open',r.company);}catch{s.append(el('p',t().error));}finally{b.disabled=false;}};s.append(b);d.insertBefore(s,close);
    }
  }
  function show(){
    document.querySelector('.ecuss-record-dialog')?.remove();const d=el('dialog','','ecuss-record-dialog');d.append(el('h2',t().title),el('p',t().zone));
    const close=el('button',t().close,'ecuss-record-close');close.onclick=()=>d.close();d.append(close);
    const retry=el('button',t().retry,'ecuss-record-retry');retry.onclick=async()=>{retry.disabled=true;try{await refresh(true);}finally{retry.disabled=false;}};d.append(retry);
    details(d);document.body.append(d);d.showModal();
  }
  async function refresh(force=false){if(fetching)return;fetching=true;try{rows=await rpc('/records/status',force===true);}catch{rows=Object.keys(companies).map(company=>({company,mark:'?',connection:'unavailable'}));}finally{fetching=false;render();const dialog=document.querySelector('.ecuss-record-dialog[open]');if(dialog)details(dialog);if(notice&&activeCompany){const r=rows.find(x=>x.company===activeCompany);if(r)message(companies[activeCompany]+' · '+(t()[r.connection]||t().unknown));}}}
  window.addEventListener('load',()=>{
    const module=window.__ECUSS_DESKTOP_CONTEXT__?.moduleId;if(module&&!inModule())return;
    if(!module){const modules=document.getElementById('modules');if(modules)new MutationObserver(()=>{if(!document.querySelector('.ecuss-records'))render();}).observe(modules,{childList:true,subtree:true});}
    new MutationObserver(render).observe(document.documentElement,{attributes:true,attributeFilter:['lang']});
    render();refresh();setInterval(refresh,inModule()?15000:60000);window.addEventListener('focus',refresh);
  },{once:true});
})();

/* Suite integration only: capture approved module outputs without recalculation. */
(() => {
  'use strict';
  if (!window.EcussDesktop) return;
  const companies = {AMO:'AMOVINA', AMOGREEN:'AMOGREEN VINA'};
  const modules = {AMO:'stock-status-amovina', AMOGREEN:'stock-status-amogreen-vina'};
  const company = Object.keys(modules).find(c => modules[c] === window.__ECUSS_DESKTOP_CONTEXT__?.moduleId);
  const master = window.__ECUSS_SUITE__?.profile === 'master';
  const texts = {
    ko:{file:'최신 파일',gap:'과부족 현황',none:'미등록',waiting:'승인 대기',unknown:'확인 불가',title:'최신 취합 파일·과부족 공유',year:'년',month:'월',version:'버전',register:'현재 최종 취합 파일 등록',preview:'과부족 요약 미리보기',approve:'승인·공유',cancel:'등록 대기 취소',retry:'등록 대기 재시도',refresh:'새로고침',select:'모듈에 최종 취합 파일을 선택하세요.',run:'동일한 파일로 과부족 현황 출력을 실행한 후 미리보기·승인하세요.',pending:'등록이 완료되지 않았습니다. 재시도해 주세요.',busy:'공유 작업 중…',done:'공유 완료',cancelled:'취소했습니다.',error:'작업을 완료하지 못했습니다. 연결·등록 파일을 확인하세요.',period:'기준 연월·버전을 확인해 주세요.',limits:'최종 파일과 과부족 Excel은 각각 50MB 이하입니다. 공유 시 같은 회사의 이전 자료를 교체·삭제합니다.',source:'등록할 원본',needsRegister:'먼저 이 최종 취합 파일을 등록하세요.'},
    en:{file:'Latest file',gap:'Shortage / surplus',none:'Not registered',waiting:'Awaiting approval',unknown:'Unavailable',title:'Share final workbook and summary',year:'Year',month:'Month',version:'Version',register:'Register current final workbook',preview:'Preview summary',approve:'Approve and share',cancel:'Cancel pending registration',retry:'Retry pending registration',refresh:'Refresh',select:'Select the final workbook in the module.',run:'Run shortage / surplus for the same workbook, then preview and approve.',pending:'Registration is pending. Please retry.',busy:'Sharing…',done:'Shared',cancelled:'Cancelled.',error:'Could not complete. Check the connection and registered file.',period:'Confirm the reporting year, month and version.',limits:'Each workbook must be 50MB or smaller. Sharing replaces and deletes previous files for this company.',source:'Source to register',needsRegister:'Register this final workbook first.'},
    vi:{file:'Tệp mới nhất',gap:'Thừa / thiếu',none:'Chưa đăng ký',waiting:'Chờ duyệt',unknown:'Không xác định',title:'Chia sẻ tệp tổng hợp và bảng tóm tắt',year:'Năm',month:'Tháng',version:'Phiên bản',register:'Đăng ký tệp tổng hợp đang chọn',preview:'Xem trước bảng tóm tắt',approve:'Duyệt và chia sẻ',cancel:'Hủy đăng ký đang chờ',retry:'Thử lại đăng ký đang chờ',refresh:'Làm mới',select:'Chọn tệp tổng hợp cuối cùng trong mô-đun.',run:'Xuất thừa / thiếu từ cùng tệp, sau đó xem trước và duyệt.',pending:'Đăng ký chưa hoàn tất. Vui lòng thử lại.',busy:'Đang chia sẻ…',done:'Đã chia sẻ',cancelled:'Đã hủy.',error:'Không hoàn tất. Kiểm tra kết nối và tệp đã đăng ký.',period:'Xác nhận năm, tháng và phiên bản.',limits:'Mỗi tệp tối đa 50MB. Chia sẻ sẽ thay thế và xóa dữ liệu trước của công ty này.',source:'Tệp nguồn đăng ký',needsRegister:'Đăng ký tệp tổng hợp này trước.'}
  };
  const t=()=>texts[document.documentElement.lang]||texts.ko;
  const el=(tag,text,cls)=>{const e=document.createElement(tag);if(text!==undefined)e.textContent=text;if(cls)e.className=cls;return e;};
  let rows=[],fetching=false,working=false,source=null,result=null,preview=null,panel=null,notice=null;
  const rpc=async(path,payload)=>{const r=await EcussDesktop.call('/stock/'+path,payload);if(r.status!==200)throw new Error(r.value?.message||t().error);return r.value;};
  const current=()=>rows.find(r=>r.company===company);
  const label=i=>i?(document.documentElement.lang==='ko'?`${i.year}년 ${String(i.month).padStart(2,'0')}월 V${i.version}`:`${i.year}-${String(i.month).padStart(2,'0')} V${i.version}`):'';
  const message=s=>{if(notice)notice.textContent=s;};
  function sourceNow(){return window.EcussStockSource?.()||null;}
  function available(){return !!source&&sourceNow()===source&&window.EcussStockSourceReady?.()!==false;}
  function clearPreview(){preview=null;panel?.querySelector('.stock-preview')?.replaceChildren();controls();}
  function controls(){if(!panel)return;const availableSource=available(),pending=current()?.pending;panel.querySelector('[data-action=register]').disabled=working||!availableSource||pending;panel.querySelector('[data-action=preview]').disabled=working||!availableSource||!result||result.file!==source||pending;panel.querySelector('[data-action=approve]').disabled=working||!preview||preview.file!==source||pending;panel.querySelector('[data-action=retry]').hidden=!pending;panel.querySelector('[data-action=cancel]').hidden=!pending;panel.querySelectorAll('[data-action=retry],[data-action=cancel],[data-action=refresh]').forEach(b=>b.disabled=working);panel.querySelectorAll('input').forEach(x=>x.disabled=working);}
  function suggest(file,period){
    const date=period?.year&&period?.month?[period.year,period.month]:null;
    const m=(file?.name||'').match(/(20\d{2})\s*(?:[-_.\/]|년)\s*(0?[1-9]|1[0-2])(?:\D|$)/);
    const v=(file?.name||'').match(/(?:^|[^a-z0-9])V\s*(\d+)(?:\D|$)/i);
    if(!panel)return;
    for(const [key,value] of [['year',date?.[0]||m?.[1]||''],['month',date?.[1]||m?.[2]||''],['version',v?.[1]||'']]){const input=panel.querySelector('[name='+key+']');if(!input.value&&value)input.value=value;}
  }
  async function action(fn){if(working)return;working=true;window.EcussStockSharing=true;controls();message(t().busy);try{await fn();}catch(e){message(e.message||t().error);}finally{await refresh(true);working=false;window.EcussStockSharing=false;controls();}}
  async function digest(bytes){return Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',bytes)),b=>b.toString(16).padStart(2,'0')).join('');}
  async function upload(bytes,name,kind){
    if(!bytes.byteLength||bytes.byteLength>50000000)throw new Error(t().limits);
    const hash=await digest(bytes),start=await rpc('upload/start',{company,name,kind,size:bytes.byteLength,hash});const data=new Uint8Array(bytes);
    for(let offset=0;offset<data.length;offset+=1024*1024){const chunk=data.subarray(offset,offset+1024*1024);let raw='';for(let i=0;i<chunk.length;i+=32768)raw+=String.fromCharCode(...chunk.subarray(i,i+32768));await rpc('upload/chunk',{company,id:start.id,offset,data:btoa(raw)});}
    return start.id;
  }
  async function register(){await action(async()=>{
    if(!available())throw new Error(t().select);const file=source;
    const period=Object.fromEntries(['year','month','version'].map(k=>[k,Number(panel.querySelector('[name='+k+']').value)]));
    if(!Number.isInteger(period.year)||period.year<2000||period.year>2199||!Number.isInteger(period.month)||period.month<1||period.month>12||!Number.isInteger(period.version)||period.version<1||period.version>9999)throw new Error(t().period);
    await refresh(true);if(current()?.state!=='connected')throw new Error(t().error);const expectedId=current()?.info?.id||null;
    const uploadId=await upload(await file.arrayBuffer(),file.name,'final');if(file!==sourceNow())throw new Error(t().select);
    const r=await rpc('register',{company,uploadId,expectedId,...period});clearPreview();await refresh(true);message(r.cancelled?t().cancelled:t().done);
  });}
  function table(cells){const table=el('table');for(let r=0;r<11;r++){const tr=el('tr');for(const c of cells.filter(c=>c.row===r)){const td=el('td',c.text);td.rowSpan=c.rows;td.colSpan=c.columns;tr.append(td);}table.append(tr);}return table;}
  async function prepare(){await action(async()=>{
    clearPreview();if(!available()||!result||result.file!==source)throw new Error(t().run);const captured=result,file=source;
    await refresh(true);const info=current()?.info,sourceHash=await digest(await file.arrayBuffer());if(!info||info.finalHash!==sourceHash)throw new Error(t().needsRegister);
    const uploadId=await upload(captured.bytes,captured.name,'gap'),r=await rpc('preview',{company,uploadId});
    if(file!==sourceNow()||result!==captured)throw new Error(t().run);
    preview={file,company,uploadId,expectedId:info.id,sourceHash};panel.querySelector('.stock-preview').replaceChildren(el('p',label(info)+' · '+info.finalName),table(r.cells));message(t().run);
  });}
  async function approve(){await action(async()=>{
    if(!preview||preview.file!==sourceNow()||!available())throw new Error(t().run);
    const r=await rpc('approve',{company,uploadId:preview.uploadId,expectedId:preview.expectedId,sourceHash:preview.sourceHash});if(!r.cancelled)clearPreview();await refresh(true);message(r.cancelled?t().cancelled:t().done);
  });}
  function renderCards(){for(const c of Object.keys(companies)){
    const card=document.querySelector('[data-module-card="'+modules[c]+'"]');if(!card)continue;let box=card.querySelector('.stock-card');
    if(!box){const open=card.querySelector('button.open'),footer=el('div',undefined,'stock-footer');box=el('div',undefined,'stock-card');box.dataset.ecussDesktop='';if(open){open.before(footer);footer.append(open,box);}else card.append(box);}box.replaceChildren();
    const r=rows.find(x=>x.company===c),i=r?.info,connected=r?.state==='connected';
    const file=el('button',t().file+' · '+(connected?(i?label(i):t().none):t().unknown)),gap=el('button',t().gap+(connected&&i?.gapHash?'':' · '+(connected?(i?t().waiting:t().none):t().unknown)));
    file.type=gap.type='button';file.disabled=!connected||!i;gap.disabled=!connected||!i?.gapHash;file.title=i?.finalName||'';
    file.onclick=()=>cardAction(file,'download',c);gap.onclick=()=>cardAction(gap,'open',c);box.append(file,gap);
  }}
  async function cardAction(button,path,c){button.disabled=true;try{await rpc(path,c);}catch(e){window.alert(e.message);}finally{await refresh(true);}}
  function buildPanel(){
    if(!company||!master||panel)return;
    panel=el('section',undefined,'stock-management');panel.dataset.ecussDesktop='';panel.append(el('h2',t().title));
    const name=el('p',t().select,'stock-source');panel.append(name);const fields=el('div',undefined,'stock-fields');
    for(const [key,min,max]of [['year',2000,2199],['month',1,12],['version',1,9999]]){const lab=el('label',t()[key]);lab.dataset.label=key;const input=el('input');input.type='number';input.name=key;input.min=min;input.max=max;input.step=1;lab.append(input);fields.append(lab);}panel.append(fields);
    const buttons=el('div',undefined,'stock-actions');for(const[key,fn]of [['register',register],['preview',prepare],['approve',approve],['retry',()=>action(async()=>{await rpc('retry',company);await refresh(true);message(t().done);})],['cancel',()=>action(async()=>{await rpc('cancel',company);await refresh(true);message(t().cancelled);})],['refresh',()=>refresh()]]){const b=el('button',t()[key]);b.type='button';b.dataset.action=key;b.onclick=fn;buttons.append(b);}panel.append(buttons);
    notice=el('p','');notice.setAttribute('role','status');panel.append(notice,el('p',t().limits,'stock-limits'),el('div',undefined,'stock-preview'));
    (document.querySelector('body>main')||document.body).prepend(panel);controls();
  }
  function language(){renderCards();if(!panel)return;panel.querySelector('h2').textContent=t().title;panel.querySelector('.stock-limits').textContent=t().limits;panel.querySelectorAll('[data-action]').forEach(b=>b.textContent=t()[b.dataset.action]);panel.querySelectorAll('[data-label]').forEach(l=>l.firstChild.textContent=t()[l.dataset.label]);}
  async function refresh(force=false){if(fetching||(working&&force!==true))return;fetching=true;try{rows=await rpc('status');}catch{rows=Object.keys(companies).map(company=>({company,state:'unavailable'}));}finally{fetching=false;renderCards();controls();}}
  window.EcussStock={invalidate(){result=null;clearPreview();},capture(file,bytes,name,period){if(!master)return;result={file,bytes:bytes instanceof Uint8Array?bytes.slice().buffer:bytes.slice(0),name};clearPreview();suggest(file,period);controls();}};
  const style=el('style');style.dataset.ecussDesktop='';style.textContent=`.stock-footer{grid-column:2;display:flex;justify-content:space-between;align-items:center;gap:12px;flex-wrap:wrap;min-width:0}.stock-footer>.open{margin:0;flex-shrink:0}.stock-card{margin-left:auto;display:flex;flex-direction:column;align-items:flex-end;gap:8px;justify-self:end;max-width:100%}.stock-card button{border:0;background:transparent;color:#365da3;font:inherit;font-size:12px;cursor:pointer;text-align:right;padding:3px 0}.stock-card button:disabled{color:#768393;cursor:default}.stock-management{padding:20px;margin:12px 0 20px;border:1px solid #d5deeb;border-radius:14px;background:#fff;color:#26374e}.stock-management h2{font-size:16px}.stock-fields,.stock-actions{display:flex;flex-wrap:wrap;gap:12px;margin:12px 0}.stock-fields label{display:flex;align-items:center;gap:8px}.stock-fields input{width:95px;padding:7px;border:1px solid #ccd5e3;border-radius:6px}.stock-actions button{padding:9px;border:1px solid #cbd7ed;border-radius:8px;background:#f1f5ff;color:#365da3;cursor:pointer}.stock-actions button:disabled{opacity:.45;cursor:default}.stock-management p{font-size:12px;overflow-wrap:anywhere}.stock-preview{overflow:auto}.stock-preview table{width:100%;border-collapse:collapse}.stock-preview td{border:1px solid #ccd5e3;white-space:pre-wrap;padding:10px}@media(max-width:600px){.stock-card{grid-column:1/-1;align-items:flex-start;justify-self:start}.stock-card button{text-align:left}}`;
  document.head.append(style);
  window.addEventListener('load',()=>{
    if(window.__ECUSS_DESKTOP_CONTEXT__?.moduleId&&!company)return;
    buildPanel();renderCards();refresh();
    if(!company){const container=document.getElementById('modules');if(container)new MutationObserver(()=>{if(Object.values(modules).some(id=>{const c=document.querySelector('[data-module-card="'+id+'"]');return c&&!c.querySelector('.stock-card');}))renderCards();}).observe(container,{childList:true,subtree:true});}
    if(master&&company)setInterval(()=>{const next=sourceNow();if(next!==source){source=next;result=null;clearPreview();for(const input of panel.querySelectorAll('input'))input.value='';suggest(source);panel.querySelector('.stock-source').textContent=source?t().source+': '+source.name:t().select;}controls();},400);
    new MutationObserver(language).observe(document.documentElement,{attributes:true,attributeFilter:['lang']});setInterval(refresh,60000);window.addEventListener('focus',refresh);
  },{once:true});
})();

/* Shared presentation adapter. Existing module controls and business events are retained. */
(() => {
  'use strict';
  window.addEventListener('load', () => {
    if (!window.EcussDesktop || window.__VALIDATION_VIEWER__) return;
    const id=window.__ECUSS_DESKTOP_CONTEXT__?.moduleId;
    const module=window.__ECUSS_SUITE__?.modules?.find(m=>m.id===id);
    const nav=document.getElementById('ecuss-module-navigation');
    if(!module||!nav)return;
    let header=document.querySelector('body>header');
    if(!header&&id==='vn-kr-customs-translation'){
      const heading=document.querySelector('main>.heading');
      if(heading){header=document.createElement('header');heading.before(header);header.append(heading);nav.after(header);}
    }
    if(!header)return;
    document.body.classList.add('ecuss-module-ui');document.body.dataset.suiteCategory=module.category;document.body.dataset.suiteModule=id;
    header.id='ecuss-page-header';
    if(id==='stock-status-amovina'){
      const top=header.querySelector('.topbar'),left=top?.firstElementChild,date=header.querySelector('.datebox'),rate=header.querySelector('.ratebox:not(.datebox)');
      if(top&&left&&date&&rate){const options=document.createElement('div');options.className='top-options';options.append(date,rate);header.append(left,options);top.remove();}
    }else if(id==='stock-status-amogreen-vina'){
      const title=header.querySelector('.header-title');if(title)header.prepend(title);
    }
    if(id==='stock-status-amovina'||id==='stock-status-amogreen-vina'){
      // Move the existing nodes only; their listeners, enabled state and module rules stay intact.
      document.body.classList.add('ecuss-stock-ui');
      const title=id==='stock-status-amovina'?header.firstElementChild:header.querySelector('.header-title>div');
      const version=header.querySelector('.version,.pilot');
      if(title&&version){title.append(version);version.classList.add('suite-stock-version');
        version.textContent=(id==='stock-status-amovina'?'AMOVINA':'AMOGREEN VINA')+' · '+window.EcussModuleUI.sourceVersion;}
      const options=header.querySelector('.top-options');
      options?.classList.add('suite-stock-options');
      if(id==='stock-status-amovina'){
        const field=header.querySelector('.ratebox:not(.datebox)'),input=field?.querySelector('input'),unit=field?.querySelector('span');
        if(input&&unit){const row=document.createElement('span');row.className='rate-input';input.before(row);row.append(input,unit);}
      }
      const run=document.getElementById('run'),gap=document.getElementById(id==='stock-status-amovina'?'shortage':'gapRun');
      const actions=run?.parentElement;
      if(actions&&gap){actions.classList.add('suite-stock-actions');actions.prepend(run);
        run.classList.add('suite-stock-primary');gap.classList.add('suite-stock-secondary');
        const label=()=>{if(run.textContent==='재고자료 업데이트')run.textContent='선택 자료 업데이트';};
        label();new MutationObserver(label).observe(run,{childList:true,subtree:true,characterData:true});}
      document.getElementById(id==='stock-status-amovina'?'shortageResult':'gapResults')?.classList.add('suite-stock-result');
      const download=document.getElementById(id==='stock-status-amovina'?'shortageXlsx':'gapDownload');
      if(download){download.classList.add('suite-stock-primary');download.textContent='과부족 현황 Excel 다운로드';}
    }
    const style=document.createElement('style');style.setAttribute('data-ecuss-desktop','');style.textContent="/* Desktop presentation only. Never included in shared result documents. */\nbody.ecuss-module-ui{--suite-accent:#0866d9;--suite-tint:#edf4ff;background:#f5f6fa;font-family:'Segoe UI Variable','Segoe UI','Malgun Gothic',sans-serif}\nbody.ecuss-module-ui[data-suite-category=translation]{--suite-accent:#7650a2;--suite-tint:#f5effc}\nbody.ecuss-module-ui[data-suite-category=inventory]{--suite-accent:#a65720;--suite-tint:#fff4e9}\nbody.ecuss-module-ui #ecuss-module-navigation{position:sticky;top:0;z-index:101;background:#f9fafded;color:#425c7b;backdrop-filter:blur(20px);border-bottom:1px solid #e1e6ef}\nbody.ecuss-module-ui #ecuss-module-navigation .ecuss-nav-inner{max-width:1488px;padding:8px 24px;gap:12px;flex-wrap:nowrap}\nbody.ecuss-module-ui #ecuss-home-button{font-size:13px;padding:7px 12px;flex-shrink:0}\n#ecuss-category-label{color:#65768d;font-size:12px;font-weight:600;white-space:nowrap}\nbody.ecuss-module-ui #ecuss-page-header{position:sticky!important;top:var(--suite-nav-height,52px)!important;z-index:100;display:block!important;visibility:visible!important;background:#ffffffed;backdrop-filter:blur(20px);color:#202b3b;padding:22px max(24px,calc((100vw - 1440px)/2));margin:0;border-radius:0;border-bottom:1px solid #dfe5ef;box-shadow:0 5px 12px #19354e16;max-height:55vh;overflow:auto}\nbody.ecuss-module-ui #ecuss-page-header h1{font:650 25px/1.35 'Segoe UI Variable','Segoe UI','Malgun Gothic',sans-serif;letter-spacing:-.4px;margin:0 0 6px;overflow-wrap:anywhere;color:#202b3b}\nbody.ecuss-module-ui #ecuss-page-header p{font-size:13px;line-height:1.5;color:#65768d;margin:0}\nbody.ecuss-module-ui #ecuss-page-header .top-inner,body.ecuss-module-ui #ecuss-page-header .heading{max-width:1440px;margin:0 auto;display:flex;gap:18px;align-items:center;justify-content:space-between}\nbody.ecuss-module-ui #ecuss-page-header .language-picker,body.ecuss-module-ui #ecuss-page-header .lang{margin:0;align-self:center;color:#65768d;flex-shrink:0}\nbody.ecuss-module-ui #ecuss-page-header select{background:#fff;color:#234056;max-width:100%;border-radius:8px;padding:7px 10px}\nbody.ecuss-module-ui #ecuss-page-header .eyebrow,body.ecuss-module-ui #ecuss-page-header .brand{font-size:10px;letter-spacing:1px;margin:0 0 5px;color:#6d7e94}\nbody.ecuss-module-ui #ecuss-page-header .version,body.ecuss-module-ui #ecuss-page-header .pilot{font-size:11px;color:#65768d;margin-top:4px}\nbody.ecuss-module-ui #ecuss-page-header .header-title{display:flex;align-items:center;justify-content:space-between;gap:14px}\nbody.ecuss-module-ui #ecuss-page-header .top-options{display:flex;gap:16px;flex-wrap:wrap;margin:10px 0 0;justify-content:flex-start;align-items:flex-start}\nbody.ecuss-module-ui #ecuss-page-header .top-options .field,body.ecuss-module-ui #ecuss-page-header .ratebox{min-width:0;max-width:100%;color:#405878;background:#eef2f8;padding:8px 12px;border-radius:8px;margin:0;flex:0 1 auto}\nbody.ecuss-module-ui #ecuss-page-header .top-options small,body.ecuss-module-ui #ecuss-page-header .ratebox small{font-size:10px;color:#65768d}\nbody.ecuss-module-ui #ecuss-page-header input{max-width:100%;font-size:13px;padding:5px 8px}\nbody.ecuss-module-ui main,body.ecuss-module-ui .container{max-width:1488px;margin:0 auto;padding:24px 24px 48px}\nbody.ecuss-module-ui .panel,body.ecuss-module-ui .card,body.ecuss-module-ui .upload-card{border-radius:18px;border-color:#e0e6ee;box-shadow:0 5px 20px #24364b05}\nbody.ecuss-module-ui .upload-card,body.ecuss-module-ui .dropzone,body.ecuss-module-ui [data-card],body.ecuss-module-ui .file-box{border-color:#c9d7e2;transition:background-color .12s,border-color .12s}\nbody.ecuss-module-ui .upload-card.ready,body.ecuss-module-ui .dropzone.selected,body.ecuss-module-ui .dropzone.has-file,body.ecuss-module-ui #dropzone[data-selected=true],body.ecuss-module-ui [data-card].selected,body.ecuss-module-ui .file-box[data-selected=true]{border:2px solid var(--suite-accent);background:var(--suite-tint)}\nbody.ecuss-module-ui .file-box.dragover,body.ecuss-module-ui .upload-card.dragover,body.ecuss-module-ui .upload-card.drag,body.ecuss-module-ui .dropzone.dragover,body.ecuss-module-ui .dropzone.drag-over,body.ecuss-module-ui [data-card].dragover{outline:3px solid var(--suite-accent);outline-offset:2px;background:var(--suite-tint)}\nbody.ecuss-module-ui .result-actions{top:var(--suite-header-bottom,150px);z-index:30}\nbody.ecuss-module-ui :is(#results,#result){scroll-margin-top:calc(var(--suite-header-bottom,150px) + 16px)}\n@media(max-width:700px){body.ecuss-module-ui #ecuss-module-navigation .ecuss-nav-inner{padding:8px 16px}#ecuss-home-notice{max-width:45vw;font-size:11px!important}body.ecuss-module-ui #ecuss-page-header{padding:12px 16px}body.ecuss-module-ui #ecuss-page-header h1{font-size:19px}body.ecuss-module-ui #ecuss-page-header .top-inner,body.ecuss-module-ui #ecuss-page-header .heading{flex-direction:row;flex-wrap:wrap;gap:8px}body.ecuss-module-ui #ecuss-page-header .top-options{gap:8px}body.ecuss-module-ui #ecuss-page-header .header-title{flex-wrap:wrap}body.ecuss-module-ui main,body.ecuss-module-ui .container{padding:18px 16px 36px}}\n@media print{body.ecuss-module-ui #ecuss-module-navigation{display:none}body.ecuss-module-ui #ecuss-page-header{position:static!important;max-height:none;overflow:visible}}\n\nbody.ecuss-module-ui #ecuss-page-header:has(>#lang){display:flex!important;justify-content:space-between;align-items:center;gap:16px;flex-wrap:wrap}\n\nbody.ecuss-module-ui #ecuss-page-header select.lang{color:#234056}\n\nbody.ecuss-module-ui #ecuss-home-button{color:#315374;background:#fff;border:1px solid #dce3ed;border-radius:10px}\nbody.ecuss-module-ui button,body.ecuss-module-ui select{border-radius:10px}body.ecuss-module-ui button{font-family:inherit}body.ecuss-module-ui :is(button,input,select):focus-visible{outline:3px solid #2278e6;outline-offset:3px}\nbody.ecuss-module-ui #ecuss-page-header input{background:#fff;color:#293b54;border:1px solid #dce3ed;border-radius:7px}body.ecuss-module-ui .result-actions{background:#ffffffed;backdrop-filter:blur(16px);border-color:#e0e6ee}\n/* A single vertical scroller leaves the mail sheet header and actions visible. */\nbody.ecuss-module-ui #ecuss-mail-dialog{overflow:hidden;border-radius:22px;border:1px solid #ffffffa0;color:#26354b;background:#f4f6fa;box-shadow:0 25px 90px #172b4650}body.ecuss-module-ui #ecuss-mail-dialog[open]{display:flex;flex-direction:column}body.ecuss-module-ui #ecuss-mail-dialog::backdrop{background:#1c2d4666;backdrop-filter:blur(6px)}body.ecuss-module-ui #ecuss-mail-dialog .em-head,body.ecuss-module-ui #ecuss-mail-dialog .em-foot{position:static;flex:0 0 auto;padding:17px 24px;background:#ffffffef;border-color:#e1e6ef}body.ecuss-module-ui #ecuss-mail-dialog h2{font-size:21px;letter-spacing:-.5px}body.ecuss-module-ui #ecuss-mail-dialog .em-content{flex:1 1 auto;min-height:0;overflow:auto;padding:20px 24px;scrollbar-gutter:stable}body.ecuss-module-ui #ecuss-mail-dialog .em-card{border:1px solid #e0e6ee;border-radius:15px;padding:20px}body.ecuss-module-ui #ecuss-mail-dialog .em-choice{background:#f6f8fb;border:1px solid #e1e6ef;border-radius:9px;color:#566880}body.ecuss-module-ui #ecuss-mail-dialog .em-choice:has(input:checked){color:#285583;border-color:#b9d0ef;background:#eef5ff}body.ecuss-module-ui #ecuss-mail-dialog input[type=checkbox]{accent-color:#0866d9}body.ecuss-module-ui #ecuss-mail-dialog select,body.ecuss-module-ui #ecuss-mail-dialog .em-quiet{border-color:#dce3ed;border-radius:9px;background:#f8fafc;color:#3b577a}body.ecuss-module-ui #ecuss-mail-dialog #em-subject{display:block;width:100%;min-width:0;font:600 14px/1.6 'Segoe UI','Malgun Gothic',sans-serif;padding:11px 13px;border:1px solid #b8c9df;border-radius:10px;color:#233b5b;background:#fff}body.ecuss-module-ui #ecuss-mail-dialog #em-subject:disabled{color:#7d8796;background:#f3f5f8}body.ecuss-module-ui #ecuss-mail-dialog #em-send{background:#0866d9;border-radius:11px;padding:12px 25px}body.ecuss-module-ui #ecuss-mail-dialog #em-send:disabled{background:#9caabe;color:#fff}body.ecuss-module-ui #ecuss-mail-dialog #em-viewport{max-height:none;min-height:0;overflow-x:auto;overflow-y:hidden}body.ecuss-module-ui #ecuss-mail-dialog #em-count{font-size:13px}body.ecuss-module-ui #ecuss-mail-dialog .em-note{font-size:11px;line-height:1.7;color:#687c94}body.ecuss-module-ui #ecuss-mail-dialog .em-preview-title{flex-wrap:wrap;font-size:13px}body.ecuss-module-ui #ecuss-mail-dialog .em-file{border-radius:8px;background:#f0f5fc;border-color:#dbe5f2}\n@media(max-width:700px){body.ecuss-module-ui #ecuss-category-label{font-size:10px;white-space:normal}body.ecuss-module-ui #ecuss-mail-dialog .em-head,body.ecuss-module-ui #ecuss-mail-dialog .em-content,body.ecuss-module-ui #ecuss-mail-dialog .em-foot{padding:12px 14px}body.ecuss-module-ui #ecuss-mail-dialog .em-card{padding:14px}body.ecuss-module-ui #ecuss-mail-dialog .em-foot .em-note{margin:4px 0}body.ecuss-module-ui #ecuss-mail-dialog .em-head .em-note{display:none}}\n@media(prefers-reduced-motion:reduce){body.ecuss-module-ui *{transition:none!important;scroll-behavior:auto!important}}\n\nbody.ecuss-module-ui #ecuss-home-notice{color:#975527}\n\nbody.ecuss-module-ui #ecuss-page-header .version{background:#eef2f8;color:#61738d;border-radius:20px;padding:6px 12px}\n\n/* Glass Workspace: shared navigation materials; document content keeps an opaque reading surface. */\nbody.ecuss-module-ui{--suite-accent:#4260da;--suite-tint:#eff3ff;background:radial-gradient(ellipse at 0 0,#e9edfc 0,transparent 48%),#f4f6fb;color:#253148}\nbody.ecuss-module-ui #ecuss-module-navigation{background:#eef2fbdc;border-bottom-color:#e0e6f2;backdrop-filter:blur(24px)}\nbody.ecuss-module-ui #ecuss-page-header{background:#f9faffea;box-shadow:0 6px 20px #34436808;border-bottom-color:#e0e6f2;backdrop-filter:blur(24px)}\nbody.ecuss-module-ui #ecuss-home-button{border-color:#d8e2f4;background:#ffffffc9;color:#4c649b;border-radius:12px}\nbody.ecuss-module-ui .panel,body.ecuss-module-ui .card,body.ecuss-module-ui .upload-card{border-radius:20px;border-color:#e0e6f1;box-shadow:0 8px 26px #34436806}\nbody.ecuss-module-ui #ecuss-page-header .top-options .field,body.ecuss-module-ui #ecuss-page-header .ratebox{background:#eaf0fa9c;border:1px solid #dfe7f5;border-radius:11px}\nbody.ecuss-module-ui #ecuss-mail-dialog{background:#f3f5fb;border-color:#e1e7f2;box-shadow:0 30px 100px #26344e45}\nbody.ecuss-module-ui #ecuss-mail-dialog .em-head,body.ecuss-module-ui #ecuss-mail-dialog .em-foot{background:#f6f8ffed;backdrop-filter:blur(22px)}\nbody.ecuss-module-ui #ecuss-mail-dialog #em-send{background:#4260da}\nbody.ecuss-module-ui dialog::backdrop{background:#26344e66;backdrop-filter:blur(7px)}\n@media(forced-colors:active){body.ecuss-module-ui,body.ecuss-module-ui #ecuss-page-header,body.ecuss-module-ui #ecuss-module-navigation,body.ecuss-module-ui #ecuss-mail-dialog,body.ecuss-module-ui #ecuss-mail-dialog .em-head,body.ecuss-module-ui #ecuss-mail-dialog .em-foot{background:Canvas;color:CanvasText;backdrop-filter:none}body.ecuss-module-ui #ecuss-page-header h1,body.ecuss-module-ui #ecuss-page-header p{color:CanvasText}body.ecuss-module-ui #ecuss-home-button{border:1px solid ButtonText;color:ButtonText;background:ButtonFace}}\n\nbody.ecuss-module-ui #report-dialog{border:1px solid #e1e7f2;border-radius:22px;background:#f3f5fb;box-shadow:0 30px 100px #26344e45;overflow:hidden}body.ecuss-module-ui #report-dialog .report-toolbar{background:#f6f8ffed;border-bottom:1px solid #dfe5f1;color:#354868;gap:14px}body.ecuss-module-ui #report-dialog #close-report{border:1px solid #d8e2f4;border-radius:10px;background:white;color:#4c649b;padding:8px 13px}\n\n/* Shared desktop presentation. No engine, workbook, result data or source payload changes. */\nbody.ecuss-module-ui{min-height:100vh}\nbody:is(.ecuss-module-ui,.ecuss-module-frame)[data-suite-module]{\n --suite-accent:#4260da;--suite-tint:#eff3ff;--suite-ink:#253148;--suite-muted:#626f85;\n --suite-line:#dfe5f1;--suite-surface:#ffffffed;--suite-radius:20px;\n --accent:var(--suite-accent);--blue:var(--suite-accent);\n --navy:var(--suite-ink);--ink:var(--suite-ink);--muted:var(--suite-muted);--line:var(--suite-line);\n font:14px/1.65 'Segoe UI Variable','Segoe UI','Malgun Gothic',sans-serif;\n color:var(--suite-ink);background:radial-gradient(ellipse at 0 0,#e5eaff 0,transparent 50%),radial-gradient(ellipse at 100% 65%,#f0ecfb 0,transparent 45%),#f4f6fb;\n}\nbody:is(.ecuss-module-ui,.ecuss-module-frame) :is(h1,h2,h3,h4){color:var(--suite-ink);line-height:1.4;letter-spacing:-.35px}\nbody:is(.ecuss-module-ui,.ecuss-module-frame) h2{font-size:18px;font-weight:650}\nbody:is(.ecuss-module-ui,.ecuss-module-frame) h3{font-size:15px;font-weight:650}\nbody:is(.ecuss-module-ui,.ecuss-module-frame) :is(.muted,.desc,.hint,.help,.note,.intro,.file-size,.drop-hint){color:var(--suite-muted)}\nbody.ecuss-module-ui #ecuss-module-navigation{background:#f2f5ffde;border-bottom:1px solid #ffffffc9;backdrop-filter:blur(24px)}\nbody.ecuss-module-ui #ecuss-page-header{background:#f8faffdb;border-bottom:1px solid #dfe5f1;backdrop-filter:blur(24px);box-shadow:0 8px 28px #2a395505}\nbody.ecuss-module-ui #ecuss-page-header h1{font-size:25px;font-weight:650;color:var(--suite-ink)}\nbody.ecuss-module-ui #ecuss-page-header :is(.version,.pilot){display:inline-block;background:#edf1fc;border:1px solid #dfe6f5;border-radius:20px;color:#68799a;font-size:11px;padding:4px 10px}\nbody.ecuss-module-ui main{min-width:0}\nbody:is(.ecuss-module-ui,.ecuss-module-frame) :is(.panel,.card,.upload-card,.upload,section.method,details.method){\n background:var(--suite-surface);border:1px solid var(--suite-line);border-radius:var(--suite-radius);\n box-shadow:inset 0 1px 0 #fff,0 10px 32px #2a395508;min-width:0;\n}\nbody:is(.ecuss-module-ui,.ecuss-module-frame) :is(.card,.upload-card,.panel){padding:22px}\nbody:is(.ecuss-module-ui,.ecuss-module-frame) :is(button,select,input,textarea){font-family:inherit;font-size:13px}\nbody:is(.ecuss-module-ui,.ecuss-module-frame) button,\nbody:is(.ecuss-module-ui,.ecuss-module-frame) :is(.pick,.filelabel,.file-label,a.secondary,a.primary){\n min-height:38px;padding:9px 14px;border:1px solid #d8e1f3;border-radius:11px;background:#f0f3fd;\n color:#4261a1;font-weight:600;line-height:1.4;box-shadow:none;transition:background-color .15s,border-color .15s;\n}\nbody:is(.ecuss-module-ui,.ecuss-module-frame) button:hover:not(:disabled),\nbody:is(.ecuss-module-ui,.ecuss-module-frame) :is(.pick,.filelabel,.file-label,a.secondary):hover{background:#e7edfc;border-color:#bdcbed}\nbody:is(.ecuss-module-ui,.ecuss-module-frame) :is(button.primary,a.primary,#calculate){background:#4260da;color:#fff;border-color:#4260da;box-shadow:0 4px 12px #4260da18}\nbody:is(.ecuss-module-ui,.ecuss-module-frame) :is(button.primary,a.primary,#calculate):hover:not(:disabled){background:#354ec0;border-color:#354ec0;color:#fff}\nbody:is(.ecuss-module-ui,.ecuss-module-frame) button:disabled{opacity:.48;cursor:not-allowed;box-shadow:none}\nbody:is(.ecuss-module-ui,.ecuss-module-frame) button[aria-pressed=true]{background:#e8eeff;border-color:#b8c8f2;color:#354eb8}\nbody:is(.ecuss-module-ui,.ecuss-module-frame) :is(input:not([type=file]):not([type=checkbox]):not([type=radio]):not([type=range]),select,textarea){\n min-height:36px;max-width:100%;padding:8px 10px;border:1px solid #d7dfed;border-radius:10px;background:#fff;color:var(--suite-ink);box-shadow:inset 0 1px 2px #25314803;\n}\nbody:is(.ecuss-module-ui,.ecuss-module-frame) :is(input[type=checkbox],input[type=radio]){accent-color:var(--suite-accent)}\nbody:is(.ecuss-module-ui,.ecuss-module-frame) :is(button,input,select,textarea,summary,a):focus-visible{outline:3px solid #4260da;outline-offset:3px}\nbody:is(.ecuss-module-ui,.ecuss-module-frame) :is(.file-box,.file-row,.drop,.dropzone){border-color:#cbd7ed;background:#f8faff;border-radius:16px}\nbody:is(.ecuss-module-ui,.ecuss-module-frame) :is(.file-prompt,.step,.tag,.number,.selection-state){color:#5b6f9e}\nbody:is(.ecuss-module-ui,.ecuss-module-frame) :is(.tag,.number,.selection-state){background:#edf2fc;border-color:#dce5f6;border-radius:9px}\nbody:is(.ecuss-module-ui,.ecuss-module-frame) :is(.file-box[data-selected=true],.card.selected,.drop.selected,.drop.has-file,.dropzone.selected,.dropzone.has-file,.upload-card.ready,#dropzone[data-selected=true]){border-color:#4260da;background:#eff3ff;box-shadow:0 0 0 1px #4260da26}\nbody:is(.ecuss-module-ui,.ecuss-module-frame) :is(.dragover,.drag-over,.drag){outline:3px solid #4260da;outline-offset:2px;background:#eaf0ff}\nbody:is(.ecuss-module-ui,.ecuss-module-frame) :is(.clear,.clear-file){min-height:28px;padding:5px 9px;font-size:12px;border-radius:8px}\nbody:is(.ecuss-module-ui,.ecuss-module-frame) details{background:#ffffffad;border:1px solid #dfe5f1;border-radius:15px;padding:14px 17px;margin-top:14px;color:var(--suite-ink)}\nbody:is(.ecuss-module-ui,.ecuss-module-frame) summary{cursor:pointer;color:#4c608c;font-size:13px;font-weight:600;line-height:1.6}\nbody:is(.ecuss-module-ui,.ecuss-module-frame) summary::marker{color:#7c8fbc}\nbody:is(.ecuss-module-ui,.ecuss-module-frame) details[open]>summary{margin-bottom:12px}\nbody:is(.ecuss-module-ui,.ecuss-module-frame) :is(th,.table-head){background:#edf2fc;color:#40567c;border-color:#dce4f2;font-weight:600}\n/* The mismatch grid keeps its original sticky navy header; pair it with light text.\n   Compact filter controls must not inherit full-size workspace button padding. */\nbody.ecuss-module-ui[data-suite-module=balance-ecuss] .mismatch-table thead th{background:#17365d;color:#fff}\nbody.ecuss-module-ui[data-suite-module=balance-ecuss] #mismatch-head .filter-trigger{\n min-height:22px;width:19px;height:22px;padding:0;border:1px solid #88a4c4;border-radius:4px;\n background:#244b77;color:#fff;font-size:11px;line-height:1;box-shadow:none;\n}\nbody.ecuss-module-ui[data-suite-module=balance-ecuss] #mismatch-head .filter-trigger:is(:hover,:focus-visible){background:#315e8f;color:#fff;border-color:#b9d0eb}\nbody.ecuss-module-ui[data-suite-module=balance-ecuss] #mismatch-head .filter-trigger.active{background:#67e8f9;color:#17365d;border-color:#67e8f9}\nbody:is(.ecuss-module-ui,.ecuss-module-frame) :is(table,.tablewrap,.scroll){border-color:#dfe5f1}\nbody:is(.ecuss-module-ui,.ecuss-module-frame) :is(.actions,.toolbar,.resulthead,.result-head){gap:12px}\nbody:is(.ecuss-module-ui,.ecuss-module-frame) :is(dialog,.dialog){border:1px solid #dfe5f1;border-radius:20px;background:#f8faff;box-shadow:0 28px 90px #25314835;color:var(--suite-ink)}\nbody:is(.ecuss-module-ui,.ecuss-module-frame) :is(.dialoghead,.dialog-head){background:#f0f4ff;border-color:#dfe5f1}\nbody.ecuss-module-ui[data-suite-module=stock-status-amovina]>section:not(#ecuss-work-access){max-width:1440px;margin:24px auto 0;padding:22px;border:1px solid #dfe5f1;border-radius:20px;background:#ffffffed;box-shadow:0 10px 32px #2a395508}\nbody.ecuss-module-ui[data-suite-module=stock-status-amovina] .notice{background:#edf2fc;border-color:#b8c8ed;border-radius:14px;color:#40567c;padding:16px 18px}\nbody.ecuss-module-ui[data-suite-module=stock-status-amogreen-vina] :is(.local,.tag.required){background:#edf2fc;color:#4c6497;border-color:#dce5f6}\nbody.ecuss-module-ui[data-suite-module=stock-status-amogreen-vina] .inactive{background:#edf0f6;border-style:dashed;box-shadow:none}\nbody.ecuss-module-ui[data-suite-module=monthly-report-consolidation] .shell{max-width:1800px;margin:auto;grid-template-columns:220px minmax(0,1fr)}\nbody.ecuss-module-ui[data-suite-module=monthly-report-consolidation] .sidebar{background:linear-gradient(150deg,#e9edfcc9,#eef2fbc4 60%,#eeebf8c0);border-color:#dce3f0;padding:28px 18px;backdrop-filter:blur(24px)}\nbody.ecuss-module-ui[data-suite-module=monthly-report-consolidation] .navlink{color:#647497;border:1px solid transparent;border-radius:12px;font-size:13px}\nbody.ecuss-module-ui[data-suite-module=monthly-report-consolidation] .navlink.active{background:#ffffffeb;color:#36539d;border-color:#fff;box-shadow:0 5px 18px #334c7808}\nbody.ecuss-module-ui[data-suite-module=monthly-report-consolidation] .main{margin:0;max-width:none;padding:28px 30px 48px}\nbody.ecuss-module-ui[data-suite-module=monthly-report-consolidation] .side-note{color:#72819c;font-size:11px;border-top:1px solid #dce3f0;padding-top:18px}\nbody.ecuss-module-ui[data-suite-module=monthly-report-consolidation] :is(.period,.rule-box,.rate-card){background:#f4f7fd;border-color:#dfe5f1;border-radius:13px}\nbody.ecuss-module-ui[data-suite-module=psr-rvc-lvc-calculator] #frames{max-width:1488px;padding:0;margin:0 auto}\nbody.ecuss-module-ui[data-suite-module=psr-rvc-lvc-calculator] #frames iframe{background:transparent}\nbody.ecuss-module-frame{max-width:none;margin:0;padding:24px;min-width:0}\nbody.ecuss-module-frame>section:not(.notice){padding:22px;margin-bottom:18px;background:#ffffffed;border:1px solid #dfe5f1;border-radius:20px;box-shadow:0 10px 32px #2a395508}\nbody.ecuss-module-frame>h1{font-size:22px;margin:0 0 12px}\nbody.ecuss-module-frame :is(.notice,#suite-user-psr-scope){background:#edf2fc;border-color:#d9e3f6;border-radius:13px;color:#496187;padding:14px 17px;font-size:13px}\nbody.ecuss-module-frame :is(table input,table select,table button){font-size:12px;min-height:30px;padding:6px 8px;border-radius:8px}\nbody.ecuss-module-frame #excelPanel{background:#f7f9ff;border-color:#cbd7ed;border-radius:14px}\n@media(max-width:900px){body.ecuss-module-ui[data-suite-module=monthly-report-consolidation] .shell{grid-template-columns:180px minmax(0,1fr)}body.ecuss-module-ui[data-suite-module=monthly-report-consolidation] .main{padding:22px 18px 36px}}\n@media(max-width:760px){body.ecuss-module-ui[data-suite-module=monthly-report-consolidation] .shell{display:block}body.ecuss-module-ui[data-suite-module=monthly-report-consolidation] .sidebar{padding:15px 18px}body.ecuss-module-ui[data-suite-module=monthly-report-consolidation] .side-note{display:none}body.ecuss-module-frame{padding:16px}body:is(.ecuss-module-ui,.ecuss-module-frame) :is(.card,.upload-card,.panel){padding:17px}body.ecuss-module-ui[data-suite-module=stock-status-amovina]>section:not(#ecuss-work-access){margin:18px 16px 0}body.ecuss-module-ui #ecuss-page-header h1{font-size:20px}}\n@media(prefers-reduced-motion:reduce){body:is(.ecuss-module-ui,.ecuss-module-frame) *{transition:none!important}}\n@media(forced-colors:active){body:is(.ecuss-module-ui,.ecuss-module-frame)[data-suite-module],body:is(.ecuss-module-ui,.ecuss-module-frame) :is(.panel,.card,.upload,.drop,.file-box,details,.notice){background:Canvas;color:CanvasText;border-color:CanvasText;box-shadow:none}body:is(.ecuss-module-ui,.ecuss-module-frame) :is(button,.primary){background:ButtonFace;color:ButtonText;border-color:ButtonText}}\n@media print{body:is(.ecuss-module-ui,.ecuss-module-frame)[data-suite-module]{background:white}body:is(.ecuss-module-ui,.ecuss-module-frame) :is(.panel,.card,.upload,section){box-shadow:none;backdrop-filter:none}}\n";document.head.append(style);
    const stockStyle=document.getElementById('ecuss-stock-style');if(stockStyle)document.head.append(stockStyle);
    // PSR uses same-origin srcdoc frames. Style their DOM without changing payloads or engines.
    if(id==='psr-rvc-lvc-calculator'){
      const applyFrameTheme=frame=>{
        const doc=frame.contentDocument;
        if(!doc?.body||doc.getElementById('suite-frame-theme'))return;
        doc.body.classList.add('ecuss-module-frame');doc.body.dataset.suiteModule=id;
        const sheet=doc.createElement('style');sheet.id='suite-frame-theme';sheet.setAttribute('data-ecuss-desktop','');sheet.textContent="/* Shared desktop presentation. No engine, workbook, result data or source payload changes. */\nbody.ecuss-module-ui{min-height:100vh}\nbody:is(.ecuss-module-ui,.ecuss-module-frame)[data-suite-module]{\n --suite-accent:#4260da;--suite-tint:#eff3ff;--suite-ink:#253148;--suite-muted:#626f85;\n --suite-line:#dfe5f1;--suite-surface:#ffffffed;--suite-radius:20px;\n --accent:var(--suite-accent);--blue:var(--suite-accent);\n --navy:var(--suite-ink);--ink:var(--suite-ink);--muted:var(--suite-muted);--line:var(--suite-line);\n font:14px/1.65 'Segoe UI Variable','Segoe UI','Malgun Gothic',sans-serif;\n color:var(--suite-ink);background:radial-gradient(ellipse at 0 0,#e5eaff 0,transparent 50%),radial-gradient(ellipse at 100% 65%,#f0ecfb 0,transparent 45%),#f4f6fb;\n}\nbody:is(.ecuss-module-ui,.ecuss-module-frame) :is(h1,h2,h3,h4){color:var(--suite-ink);line-height:1.4;letter-spacing:-.35px}\nbody:is(.ecuss-module-ui,.ecuss-module-frame) h2{font-size:18px;font-weight:650}\nbody:is(.ecuss-module-ui,.ecuss-module-frame) h3{font-size:15px;font-weight:650}\nbody:is(.ecuss-module-ui,.ecuss-module-frame) :is(.muted,.desc,.hint,.help,.note,.intro,.file-size,.drop-hint){color:var(--suite-muted)}\nbody.ecuss-module-ui #ecuss-module-navigation{background:#f2f5ffde;border-bottom:1px solid #ffffffc9;backdrop-filter:blur(24px)}\nbody.ecuss-module-ui #ecuss-page-header{background:#f8faffdb;border-bottom:1px solid #dfe5f1;backdrop-filter:blur(24px);box-shadow:0 8px 28px #2a395505}\nbody.ecuss-module-ui #ecuss-page-header h1{font-size:25px;font-weight:650;color:var(--suite-ink)}\nbody.ecuss-module-ui #ecuss-page-header :is(.version,.pilot){display:inline-block;background:#edf1fc;border:1px solid #dfe6f5;border-radius:20px;color:#68799a;font-size:11px;padding:4px 10px}\nbody.ecuss-module-ui main{min-width:0}\nbody:is(.ecuss-module-ui,.ecuss-module-frame) :is(.panel,.card,.upload-card,.upload,section.method,details.method){\n background:var(--suite-surface);border:1px solid var(--suite-line);border-radius:var(--suite-radius);\n box-shadow:inset 0 1px 0 #fff,0 10px 32px #2a395508;min-width:0;\n}\nbody:is(.ecuss-module-ui,.ecuss-module-frame) :is(.card,.upload-card,.panel){padding:22px}\nbody:is(.ecuss-module-ui,.ecuss-module-frame) :is(button,select,input,textarea){font-family:inherit;font-size:13px}\nbody:is(.ecuss-module-ui,.ecuss-module-frame) button,\nbody:is(.ecuss-module-ui,.ecuss-module-frame) :is(.pick,.filelabel,.file-label,a.secondary,a.primary){\n min-height:38px;padding:9px 14px;border:1px solid #d8e1f3;border-radius:11px;background:#f0f3fd;\n color:#4261a1;font-weight:600;line-height:1.4;box-shadow:none;transition:background-color .15s,border-color .15s;\n}\nbody:is(.ecuss-module-ui,.ecuss-module-frame) button:hover:not(:disabled),\nbody:is(.ecuss-module-ui,.ecuss-module-frame) :is(.pick,.filelabel,.file-label,a.secondary):hover{background:#e7edfc;border-color:#bdcbed}\nbody:is(.ecuss-module-ui,.ecuss-module-frame) :is(button.primary,a.primary,#calculate){background:#4260da;color:#fff;border-color:#4260da;box-shadow:0 4px 12px #4260da18}\nbody:is(.ecuss-module-ui,.ecuss-module-frame) :is(button.primary,a.primary,#calculate):hover:not(:disabled){background:#354ec0;border-color:#354ec0;color:#fff}\nbody:is(.ecuss-module-ui,.ecuss-module-frame) button:disabled{opacity:.48;cursor:not-allowed;box-shadow:none}\nbody:is(.ecuss-module-ui,.ecuss-module-frame) button[aria-pressed=true]{background:#e8eeff;border-color:#b8c8f2;color:#354eb8}\nbody:is(.ecuss-module-ui,.ecuss-module-frame) :is(input:not([type=file]):not([type=checkbox]):not([type=radio]):not([type=range]),select,textarea){\n min-height:36px;max-width:100%;padding:8px 10px;border:1px solid #d7dfed;border-radius:10px;background:#fff;color:var(--suite-ink);box-shadow:inset 0 1px 2px #25314803;\n}\nbody:is(.ecuss-module-ui,.ecuss-module-frame) :is(input[type=checkbox],input[type=radio]){accent-color:var(--suite-accent)}\nbody:is(.ecuss-module-ui,.ecuss-module-frame) :is(button,input,select,textarea,summary,a):focus-visible{outline:3px solid #4260da;outline-offset:3px}\nbody:is(.ecuss-module-ui,.ecuss-module-frame) :is(.file-box,.file-row,.drop,.dropzone){border-color:#cbd7ed;background:#f8faff;border-radius:16px}\nbody:is(.ecuss-module-ui,.ecuss-module-frame) :is(.file-prompt,.step,.tag,.number,.selection-state){color:#5b6f9e}\nbody:is(.ecuss-module-ui,.ecuss-module-frame) :is(.tag,.number,.selection-state){background:#edf2fc;border-color:#dce5f6;border-radius:9px}\nbody:is(.ecuss-module-ui,.ecuss-module-frame) :is(.file-box[data-selected=true],.card.selected,.drop.selected,.drop.has-file,.dropzone.selected,.dropzone.has-file,.upload-card.ready,#dropzone[data-selected=true]){border-color:#4260da;background:#eff3ff;box-shadow:0 0 0 1px #4260da26}\nbody:is(.ecuss-module-ui,.ecuss-module-frame) :is(.dragover,.drag-over,.drag){outline:3px solid #4260da;outline-offset:2px;background:#eaf0ff}\nbody:is(.ecuss-module-ui,.ecuss-module-frame) :is(.clear,.clear-file){min-height:28px;padding:5px 9px;font-size:12px;border-radius:8px}\nbody:is(.ecuss-module-ui,.ecuss-module-frame) details{background:#ffffffad;border:1px solid #dfe5f1;border-radius:15px;padding:14px 17px;margin-top:14px;color:var(--suite-ink)}\nbody:is(.ecuss-module-ui,.ecuss-module-frame) summary{cursor:pointer;color:#4c608c;font-size:13px;font-weight:600;line-height:1.6}\nbody:is(.ecuss-module-ui,.ecuss-module-frame) summary::marker{color:#7c8fbc}\nbody:is(.ecuss-module-ui,.ecuss-module-frame) details[open]>summary{margin-bottom:12px}\nbody:is(.ecuss-module-ui,.ecuss-module-frame) :is(th,.table-head){background:#edf2fc;color:#40567c;border-color:#dce4f2;font-weight:600}\n/* The mismatch grid keeps its original sticky navy header; pair it with light text.\n   Compact filter controls must not inherit full-size workspace button padding. */\nbody.ecuss-module-ui[data-suite-module=balance-ecuss] .mismatch-table thead th{background:#17365d;color:#fff}\nbody.ecuss-module-ui[data-suite-module=balance-ecuss] #mismatch-head .filter-trigger{\n min-height:22px;width:19px;height:22px;padding:0;border:1px solid #88a4c4;border-radius:4px;\n background:#244b77;color:#fff;font-size:11px;line-height:1;box-shadow:none;\n}\nbody.ecuss-module-ui[data-suite-module=balance-ecuss] #mismatch-head .filter-trigger:is(:hover,:focus-visible){background:#315e8f;color:#fff;border-color:#b9d0eb}\nbody.ecuss-module-ui[data-suite-module=balance-ecuss] #mismatch-head .filter-trigger.active{background:#67e8f9;color:#17365d;border-color:#67e8f9}\nbody:is(.ecuss-module-ui,.ecuss-module-frame) :is(table,.tablewrap,.scroll){border-color:#dfe5f1}\nbody:is(.ecuss-module-ui,.ecuss-module-frame) :is(.actions,.toolbar,.resulthead,.result-head){gap:12px}\nbody:is(.ecuss-module-ui,.ecuss-module-frame) :is(dialog,.dialog){border:1px solid #dfe5f1;border-radius:20px;background:#f8faff;box-shadow:0 28px 90px #25314835;color:var(--suite-ink)}\nbody:is(.ecuss-module-ui,.ecuss-module-frame) :is(.dialoghead,.dialog-head){background:#f0f4ff;border-color:#dfe5f1}\nbody.ecuss-module-ui[data-suite-module=stock-status-amovina]>section:not(#ecuss-work-access){max-width:1440px;margin:24px auto 0;padding:22px;border:1px solid #dfe5f1;border-radius:20px;background:#ffffffed;box-shadow:0 10px 32px #2a395508}\nbody.ecuss-module-ui[data-suite-module=stock-status-amovina] .notice{background:#edf2fc;border-color:#b8c8ed;border-radius:14px;color:#40567c;padding:16px 18px}\nbody.ecuss-module-ui[data-suite-module=stock-status-amogreen-vina] :is(.local,.tag.required){background:#edf2fc;color:#4c6497;border-color:#dce5f6}\nbody.ecuss-module-ui[data-suite-module=stock-status-amogreen-vina] .inactive{background:#edf0f6;border-style:dashed;box-shadow:none}\nbody.ecuss-module-ui[data-suite-module=monthly-report-consolidation] .shell{max-width:1800px;margin:auto;grid-template-columns:220px minmax(0,1fr)}\nbody.ecuss-module-ui[data-suite-module=monthly-report-consolidation] .sidebar{background:linear-gradient(150deg,#e9edfcc9,#eef2fbc4 60%,#eeebf8c0);border-color:#dce3f0;padding:28px 18px;backdrop-filter:blur(24px)}\nbody.ecuss-module-ui[data-suite-module=monthly-report-consolidation] .navlink{color:#647497;border:1px solid transparent;border-radius:12px;font-size:13px}\nbody.ecuss-module-ui[data-suite-module=monthly-report-consolidation] .navlink.active{background:#ffffffeb;color:#36539d;border-color:#fff;box-shadow:0 5px 18px #334c7808}\nbody.ecuss-module-ui[data-suite-module=monthly-report-consolidation] .main{margin:0;max-width:none;padding:28px 30px 48px}\nbody.ecuss-module-ui[data-suite-module=monthly-report-consolidation] .side-note{color:#72819c;font-size:11px;border-top:1px solid #dce3f0;padding-top:18px}\nbody.ecuss-module-ui[data-suite-module=monthly-report-consolidation] :is(.period,.rule-box,.rate-card){background:#f4f7fd;border-color:#dfe5f1;border-radius:13px}\nbody.ecuss-module-ui[data-suite-module=psr-rvc-lvc-calculator] #frames{max-width:1488px;padding:0;margin:0 auto}\nbody.ecuss-module-ui[data-suite-module=psr-rvc-lvc-calculator] #frames iframe{background:transparent}\nbody.ecuss-module-frame{max-width:none;margin:0;padding:24px;min-width:0}\nbody.ecuss-module-frame>section:not(.notice){padding:22px;margin-bottom:18px;background:#ffffffed;border:1px solid #dfe5f1;border-radius:20px;box-shadow:0 10px 32px #2a395508}\nbody.ecuss-module-frame>h1{font-size:22px;margin:0 0 12px}\nbody.ecuss-module-frame :is(.notice,#suite-user-psr-scope){background:#edf2fc;border-color:#d9e3f6;border-radius:13px;color:#496187;padding:14px 17px;font-size:13px}\nbody.ecuss-module-frame :is(table input,table select,table button){font-size:12px;min-height:30px;padding:6px 8px;border-radius:8px}\nbody.ecuss-module-frame #excelPanel{background:#f7f9ff;border-color:#cbd7ed;border-radius:14px}\n@media(max-width:900px){body.ecuss-module-ui[data-suite-module=monthly-report-consolidation] .shell{grid-template-columns:180px minmax(0,1fr)}body.ecuss-module-ui[data-suite-module=monthly-report-consolidation] .main{padding:22px 18px 36px}}\n@media(max-width:760px){body.ecuss-module-ui[data-suite-module=monthly-report-consolidation] .shell{display:block}body.ecuss-module-ui[data-suite-module=monthly-report-consolidation] .sidebar{padding:15px 18px}body.ecuss-module-ui[data-suite-module=monthly-report-consolidation] .side-note{display:none}body.ecuss-module-frame{padding:16px}body:is(.ecuss-module-ui,.ecuss-module-frame) :is(.card,.upload-card,.panel){padding:17px}body.ecuss-module-ui[data-suite-module=stock-status-amovina]>section:not(#ecuss-work-access){margin:18px 16px 0}body.ecuss-module-ui #ecuss-page-header h1{font-size:20px}}\n@media(prefers-reduced-motion:reduce){body:is(.ecuss-module-ui,.ecuss-module-frame) *{transition:none!important}}\n@media(forced-colors:active){body:is(.ecuss-module-ui,.ecuss-module-frame)[data-suite-module],body:is(.ecuss-module-ui,.ecuss-module-frame) :is(.panel,.card,.upload,.drop,.file-box,details,.notice){background:Canvas;color:CanvasText;border-color:CanvasText;box-shadow:none}body:is(.ecuss-module-ui,.ecuss-module-frame) :is(button,.primary){background:ButtonFace;color:ButtonText;border-color:ButtonText}}\n@media print{body:is(.ecuss-module-ui,.ecuss-module-frame)[data-suite-module]{background:white}body:is(.ecuss-module-ui,.ecuss-module-frame) :is(.panel,.card,.upload,section){box-shadow:none;backdrop-filter:none}}\n";doc.head.append(sheet);
      };
      document.querySelectorAll('#frames iframe').forEach(frame=>{applyFrameTheme(frame);frame.addEventListener('load',()=>applyFrameTheme(frame));});
    }
    const category=document.createElement('span');category.id='ecuss-category-label';nav.querySelector('.ecuss-nav-inner').append(category);
    const categories={ko:{reporting:'월간리포트 취합',validation:'Balance Sheet 검증',translation:'문서 번역',inventory:'재고 취합',tools:'업무 도구'},en:{reporting:'Monthly reporting',validation:'Balance Sheet validation',translation:'Document translation',inventory:'Stock consolidation',tools:'Work tools'},vi:{reporting:'Báo cáo tháng',validation:'Kiểm tra Balance Sheet',translation:'Dịch tài liệu',inventory:'Tổng hợp tồn kho',tools:'Công cụ công việc'}};
    function labels(){const lang=document.documentElement.lang||'ko',name=module.name[lang]||module.name.ko;const h=header.querySelector('h1');if(h&&h.textContent!==name)h.textContent=name;document.title=name;category.textContent=(categories[lang]||categories.ko)[module.category]||'';}
    function measure(){const n=nav.getBoundingClientRect().height,h=header.getBoundingClientRect().height;document.body.style.setProperty('--suite-nav-height',n+'px');document.body.style.setProperty('--suite-header-bottom',(n+h)+'px');}
    if(id==='balance-sheet-validation'){const filename=document.getElementById('filename'),zone=document.getElementById('dropzone');const selected=()=>{zone.dataset.selected=String(!!window.EcussModuleState?.hasWork?.());};selected();new MutationObserver(selected).observe(filename,{childList:true,subtree:true,characterData:true});}
    labels();measure();new ResizeObserver(measure).observe(header);new ResizeObserver(measure).observe(nav);
    new MutationObserver(labels).observe(document.documentElement,{attributes:true,attributeFilter:['lang']});
    // Modules can render their own title again when language or result state changes.
    new MutationObserver(labels).observe(header.querySelector('h1'),{childList:true,subtree:true,characterData:true});
  },{once:true});
})();
