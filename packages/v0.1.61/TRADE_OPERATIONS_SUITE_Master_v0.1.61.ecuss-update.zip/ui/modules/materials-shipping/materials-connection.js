/* Suite adapter: authenticated host storage, atomic version refresh, native Excel save. */
(()=>{'use strict';
const strings={ko:{current:'최신 버전 확인됨',checking:'최신 버전 확인 중…',loading:'자료 불러오는 중…',empty:'등록된 자료가 없습니다.',stale:'최신 여부 확인 불가 · 마지막 확인 자료 표시',error:'자료를 불러오지 못했습니다.',checked:'마지막 확인',refresh:'새로 확인',ambiguous:'제품코드 중복으로 ITEM·단위 확인이 필요한 항목',saved:'Excel 파일을 저장했습니다.',cancelled:'저장을 취소했습니다.',failed:'저장 결과를 확인하지 못했습니다.'},en:{current:'Latest version confirmed',checking:'Checking latest version…',loading:'Loading…',empty:'No registered file.',stale:'Latest version unavailable · Showing last checked data',error:'Could not load data.',checked:'Last checked',refresh:'Refresh',ambiguous:'Products requiring ITEM/unit review due to duplicate codes',saved:'Excel file saved.',cancelled:'Save cancelled.',failed:'Could not confirm the save result.'},vi:{current:'Đã xác nhận phiên bản mới nhất',checking:'Đang kiểm tra phiên bản mới nhất…',loading:'Đang tải…',empty:'Chưa có tệp được đăng ký.',stale:'Không xác nhận được bản mới nhất · Hiển thị dữ liệu đã kiểm tra',error:'Không tải được dữ liệu.',checked:'Kiểm tra lần cuối',refresh:'Kiểm tra lại',ambiguous:'Sản phẩm cần kiểm tra ITEM/đơn vị do trùng mã',saved:'Đã lưu tệp Excel.',cancelled:'Đã hủy lưu.',failed:'Không xác nhận được kết quả lưu.'}};
const copy=()=>strings[ShippingI18n.lang]||strings.ko;
window.SuiteMaterialsSaveNotice=r=>r?.saved?copy().saved:r?.cancelled?copy().cancelled:copy().failed;
const bar=document.createElement('section');bar.id='suite-catalog-status';bar.className='panel';bar.setAttribute('aria-live','polite');
const title=document.createElement('strong'),detail=document.createElement('span'),warning=document.createElement('div'),refresh=document.createElement('button');
bar.style.cssText='display:flex;align-items:center;gap:14px;flex-wrap:wrap';detail.className='muted';warning.className='error';refresh.type='button';refresh.className='small';refresh.style.marginLeft='auto';bar.append(title,detail,warning,refresh);document.getElementById('view').before(bar);
if(!window.EcussDesktop){title.textContent=copy().error;refresh.disabled=true;return;}
let selectedCompany=null,active=false,event={state:'loading'},applied={};bar.style.display='none';
function render(){const t=copy();title.textContent=t[event.state]||t.error;bar.dataset.state=event.state;detail.textContent=event.snapshot?t.checked+' '+new Date(event.snapshot.checkedAt).toLocaleString(ShippingI18n.lang):'';warning.textContent=event.snapshot?.data.ambiguous?t.ambiguous+': '+event.snapshot.data.ambiguous:'';refresh.textContent=t.refresh;refresh.disabled=['loading','checking'].includes(event.state);bar.title=window.__ECUSS_SUITE__?.profile==='master'?(event.error||''):'';}
const provider=StockDashboardSync.nativeProvider({call:(path,payload)=>EcussDesktop.call(path.replace('/stock/dashboard/','/stock/materials/'),payload)},'catalog');
const sync=new StockDashboardSync.Sync(provider,SuiteMaterialsCatalog.parse,e=>{event=e;if(e.state==='empty'){delete applied[e.key];MaterialsShippingCatalog.clear(e.key);}else if(e.snapshot&&applied[e.key]!==e.snapshot.info.finalHash){MaterialsShippingCatalog.set(e.key,e.snapshot.data);applied[e.key]=e.snapshot.info.finalHash;}render();});
refresh.addEventListener('click',()=>{if(active&&selectedCompany)sync.refresh();});
function checkPage(){const view=window.SuiteMaterialsView?.(),next=view?.page==='catalog'&&!!view.company;
 const entered=next&&(!active||view.company!==selectedCompany);active=next;selectedCompany=view?.company||null;bar.style.display=active?'flex':'none';
 if(entered&&!document.hidden)sync.select(selectedCompany);render();}
// The module's own click handler first commits the accepted company/page change.
document.addEventListener('click',()=>queueMicrotask(checkPage));
const visible=()=>{if(!document.hidden){checkPage();if(active)sync.select(selectedCompany);}};
document.addEventListener('visibilitychange',visible);
const timer=setInterval(()=>{if(active&&!document.hidden)sync.refresh();},60000);
window.addEventListener('pagehide',()=>{clearInterval(timer);sync.dispose();document.removeEventListener('visibilitychange',visible);},{once:true});
ShippingExport.download=async(report,filename)=>{const bytes=await ShippingExport.build(report);let binary='';for(let i=0;i<bytes.length;i+=32768)binary+=String.fromCharCode(...bytes.subarray(i,i+32768));const r=await EcussDesktop.call('/stock/materials/export-xlsx',{filename,data:btoa(binary)});if(r.status!==200)throw Error(r.value?.message||copy().failed);return r.value;};
// Wait for explicit company selection before reading shared source data.
})();

