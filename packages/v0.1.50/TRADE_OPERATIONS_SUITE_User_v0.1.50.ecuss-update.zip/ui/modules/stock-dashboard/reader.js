/* Read-only cached-value OOXML reader. No formulas, macros or external links execute. */
(function(root){
'use strict';
const norm=s=>String(s??'').toUpperCase().replace(/[^A-Z0-9]/g,'');
const decode=s=>String(s??'').replace(/&(#x[\da-f]+|#\d+|amp|lt|gt|quot|apos);/gi,(_,x)=>x[0]==='#'?String.fromCodePoint(x[1].toLowerCase()==='x'?parseInt(x.slice(2),16):+x.slice(1)):({amp:'&',lt:'<',gt:'>',quot:'"',apos:"'"}[x]));
const attr=(s,k)=>decode((s.match(new RegExp('(?:^|\\s)'+k+'="([^"]*)"'))||[])[1]);
function decimal(s){
 const m=String(s).match(/^([+-]?)(\d+)(?:\.(\d*))?(?:[eE]([+-]?\d+))?$/);if(!m)throw Error('숫자 형식 오류');
 const e=+(m[4]||0),digits=m[2]+(m[3]||'');if(Math.abs(e)>64||digits.length>80)throw Error('숫자 범위 초과');
 const at=m[2].length+e;let out=at<=0?'0.'+'0'.repeat(-at)+digits:at>=digits.length?digits+'0'.repeat(at-digits.length):digits.slice(0,at)+'.'+digits.slice(at);
 out=out.replace(/^0+(?=\d)/,'');return (m[1]==='-'?'-':'')+out;
}
function zipBounds(bytes){
 if(bytes.length<22||bytes.length>50000000)throw Error('원본 파일 크기 오류');
 const v=new DataView(bytes.buffer,bytes.byteOffset,bytes.byteLength);let end=-1;
 for(let p=bytes.length-22;p>=Math.max(0,bytes.length-65557);p--)if(v.getUint32(p,true)===0x06054b50&&p+22+v.getUint16(p+20,true)===bytes.length){end=p;break;}
 if(end<0||v.getUint16(end+4,true)||v.getUint16(end+6,true))throw Error('지원하지 않는 ZIP');
 const n=v.getUint16(end+10,true);let p=v.getUint32(end+16,true),total=0;
 if(!n||n>10000||p+v.getUint32(end+12,true)!==end)throw Error('ZIP 목록 오류');
 for(let i=0;i<n;i++){
  if(p+46>end||v.getUint32(p,true)!==0x02014b50)throw Error('ZIP 항목 오류');
  const size=v.getUint32(p+24,true),flags=v.getUint16(p+8,true),method=v.getUint16(p+10,true);total+=size;
  if(flags&1||![0,8].includes(method)||size>64000000||total>256000000)throw Error('지원하지 않는 압축 크기/형식');
  p+=46+v.getUint16(p+28,true)+v.getUint16(p+30,true)+v.getUint16(p+32,true);
 }if(p!==end)throw Error('ZIP 목록 경계 오류');
}
async function parse(bytes,key,info,Zip=root.JSZip){
 if(!['amo','agv'].includes(key))throw Error('법인 오류');zipBounds(bytes);const zip=await Zip.loadAsync(bytes);
 async function read(path){const f=zip.file(path);if(!f)throw Error('필수 Excel 구성 누락: '+path);const s=await f.async('string');if(s.length>64000000||/<!DOCTYPE|<!ENTITY/i.test(s))throw Error('지원하지 않는 XML');return s.replace(/\r\n?/g,'\n');}
 const wb=await read('xl/workbook.xml'),rels=await read('xl/_rels/workbook.xml.rels');
 const sheets=[...wb.matchAll(/<sheet\s([^>]*?)\/?\s*>/g)].filter(m=>norm(attr(m[1],'name'))==='SUMMARYLIQUIDATION');if(sheets.length!==1)throw Error('Summary Liquidation 시트 확인 필요');
 const id=attr(sheets[0][1],'r:id'),rel=[...rels.matchAll(/<Relationship\s([^>]*?)\/?\s*>/g)].find(m=>attr(m[1],'Id')===id);
 if(!rel||attr(rel[1],'TargetMode')==='External')throw Error('시트 연결 오류');
 const target=attr(rel[1],'Target'),parts=[];for(const part of (target.startsWith('/')?target.slice(1):'xl/'+target).split('/')){if(part==='..')parts.pop();else if(part&&part!=='.')parts.push(part);}const path=parts.join('/');if(!path.startsWith('xl/worksheets/'))throw Error('시트 경로 오류');
 const strings=zip.file('xl/sharedStrings.xml')?[...(await read('xl/sharedStrings.xml')).matchAll(/<si(?:\s[^>]*)?>([\s\S]*?)<\/si>/g)].map(m=>[...m[1].matchAll(/<t(?:\s[^>]*)?>([\s\S]*?)<\/t>/g)].map(t=>decode(t[1])).join('')):[];
 const raw=await read(path),cells=new Map();
 for(const m of raw.matchAll(/<c\b([^>]*?)(?:\/>|>([\s\S]*?)<\/c>)/g)){
  const a=attr(m[1],'r'),t=attr(m[1],'t'),body=m[2]||'';if(!/^[A-Z]{1,3}[1-9]\d{0,6}$/.test(a)||cells.has(a))throw Error('셀 주소 오류');
  let val=(body.match(/<v(?:\s[^>]*)?>([\s\S]*?)<\/v>/)||[])[1]??null;val=val===null?null:decode(val);
  if(t==='s')val=val===null?null:strings[+val]??null;
  if(t==='inlineStr')val=[...body.matchAll(/<t(?:\s[^>]*)?>([\s\S]*?)<\/t>/g)].map(x=>decode(x[1])).join('');
  cells.set(a,{v:val,t,f:/<f\b/.test(body)});
 }
 const get=a=>cells.get(a)?.v??null;
 for(const [a,expected] of Object.entries({A4:'Item',F4:'MaterialCode',G4:'MaterialName',H4:'Unit',I4:'HSCODE',L4:'Price'}))if(norm(get(a))!==norm(expected))throw Error('원본 양식 변경: '+a);
 const ag=key==='agv',columns={qty:ag?'AL':'AM',amount:ag?'AU':'AT',penalty:ag?'AR':'AS'};
 if(norm(get(columns.qty+'5'))!=='QTY'||norm(get(columns.penalty+'4'))!=='TOTAL')throw Error('금액/수량 열 확인 필요');
 const ends=[...cells].filter(([a,c])=>/^A\d+$/.test(a)&&+a.slice(1)>=6&&['TOTAL','GRANDTOTAL'].includes(norm(c.v))).map(([a])=>+a.slice(1));
 if(ends.length!==1||ends[0]>100006)throw Error('합계 행 확인 필요');const end=ends[0],rows=[],codes=new Set();
 for(let row=6;row<end;row++){
  const code=get('F'+row);if(!code){if(['L',...Object.values(columns)].some(c=>{const x=cells.get(c+row);return x?.f||x?.v!=null&&x.v!==''&&x.v!=='0';}))throw Error('자재코드 없는 데이터: '+row+'행');continue;}
  if(cells.get('F'+row).t==='e'||codes.has(code))throw Error('자재코드 오류/중복: '+row+'행');codes.add(code);
  const issues=[];let item=get('A'+row);if(!item||cells.get('A'+row)?.t==='e'){item='Item 확인 필요';issues.push('Item 공란 또는 오류');}
  const r={row,item,code,name:get('G'+row)||'자재명 확인 필요',unit:get('H'+row)||'—',hs:get('I'+row)||'—'};
  for(const [k,c] of Object.entries({price:'L',...columns})){
   const a=c+row,x=cells.get(a);try{if(!x||!['','n'].includes(x.t)||x.v===null)throw Error();r[k]=decimal(x.v);if(k==='amount')r[k]=r[k].replace(/^-/,'');}
   catch{r[k]=null;issues.push(k+' '+a+': '+(x?.v||'저장값 없음'));}
  }r.issues=issues;rows.push(r);
 }if(!rows.length)throw Error('자재 자료 없음');
 let fxValue=null;const fxCell=ag?'AS2':'AT2',fxRaw=cells.get(fxCell);try{if(fxRaw&&['','n'].includes(fxRaw.t)&&fxRaw.v!==null){const v=decimal(fxRaw.v);if(!v.startsWith('-')&&/[1-9]/.test(v))fxValue=v;}}catch{}
 return {label:ag?'아모그린비나':'아모비나',english:ag?'AMOGREEN VINA':'AMOVINA',filename:info.finalName,date:get('A1'),sha256:info.finalHash,range:'Summary Liquidation!6:'+(end-1),columns,fx:{value:fxValue,cell:'Summary Liquidation!'+fxCell},excluded:[],rows};
}
root.StockDashboardReader={parse,decimal,zipBounds};if(typeof module!=='undefined')module.exports=root.StockDashboardReader;
})(globalThis);
