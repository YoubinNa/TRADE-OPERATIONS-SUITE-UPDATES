(function(root){
'use strict';
const ids={amo:'AMO',agv:'AMOGREEN'};
class Sync {
 constructor(provider,parse,update){this.p=provider;this.parse=parse;this.update=update;this.cache={};this.key='amo';this.busy=false;this.again=false;this.disposed=false;}
 emit(state,error){if(!this.disposed)this.update({key:this.key,state,error,snapshot:this.cache[this.key]||null});}
 select(key){if(!ids[key])throw Error('법인 오류');this.key=key;this.emit(this.cache[key]?'checking':'loading');return this.refresh();}
 async refresh(){
  if(this.disposed)return;if(this.busy){this.again=true;return;}this.busy=true;const key=this.key;this.emit(this.cache[key]?'checking':'loading');
  try{
   for(let attempt=0;attempt<3;attempt++){
    const info=await this.p.status(ids[key]);
    if(!info){delete this.cache[key];if(key===this.key)this.emit('empty');break;}
    if(this.cache[key]?.info.finalHash===info.finalHash){this.cache[key].info=info;this.cache[key].checkedAt=new Date().toISOString();if(key===this.key)this.emit('current');break;}
    const result=await this.p.read(ids[key],info.finalHash),data=await this.parse(result.bytes,key,result.info);
    const after=await this.p.status(ids[key]);if(!after||after.finalHash!==result.info.finalHash){if(attempt===2)throw Error('원본이 계속 변경되어 다시 확인해야 합니다.');continue;}
    this.cache[key]={data,info:after,checkedAt:new Date().toISOString()};if(key===this.key)this.emit('current');break;
   }
  }catch(e){if(key===this.key)this.emit(this.cache[key]?'stale':'error',e.message);}
  finally{this.busy=false;if(this.again&&!this.disposed){this.again=false;await this.refresh();}}
 }
 async download(){if(this.busy)throw Error('원본 확인이 끝난 뒤 다시 시도하세요.');const key=this.key,s=this.cache[key];if(!s)throw Error('확인된 원본이 없습니다.');this.busy=true;
  try{return await this.p.download(ids[key],s.info.finalHash);}finally{this.busy=false;await this.refresh();}
 }
 dispose(){this.disposed=true;}
}
function nativeProvider(bridge){
 async function rpc(action,payload){const r=await bridge.call('/stock/dashboard/'+action,payload);if(r.status!==200)throw Error(r.value?.message||'공유 자료 연결 실패');return r.value;}
 return {
  async status(company){const rows=await rpc('status',null),row=rows.find(r=>r.company===company);if(row?.state!=='connected')throw Error('연결 실패 · 최신 여부 확인 불가');return row.info;},
  async read(company,expectedHash){const s=await rpc('start',{company,expectedHash});try{
   if(!Number.isSafeInteger(s.size)||s.size<1||s.size>50000000||s.info.company!==company||s.info.finalHash!==expectedHash)throw Error('원본 메타데이터 오류');
   const bytes=new Uint8Array(s.size);for(let offset=0;offset<s.size;){const c=await rpc('chunk',{company,id:s.id,offset});const part=Uint8Array.from(atob(c.data),c=>c.charCodeAt(0));if(c.offset!==offset||!part.length||part.length>1048576||offset+part.length>s.size)throw Error('원본 수신 오류');bytes.set(part,offset);offset+=part.length;}
   const hash=Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',bytes)),x=>x.toString(16).padStart(2,'0')).join('');if(hash!==expectedHash)throw Error('원본 무결성 확인 실패');return {bytes,info:s.info};
  }finally{await rpc('release',{company,id:s.id}).catch(()=>{});}},
  download:(company,expectedHash)=>rpc('download',{company,expectedHash})
 };
}
root.StockDashboardSync={Sync,nativeProvider};if(typeof module!=='undefined')module.exports=root.StockDashboardSync;
})(globalThis);
