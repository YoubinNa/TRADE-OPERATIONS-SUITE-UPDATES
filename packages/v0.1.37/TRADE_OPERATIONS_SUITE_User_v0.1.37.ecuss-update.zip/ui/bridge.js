/* Host API v1. Local WebView2 messages only; no network fallback. */
(() => {
  'use strict';
  if (window !== window.top || !window.chrome?.webview || !window.__ECUSS_HOST_NONCE__) return;
  const pending = new Map();
  window.chrome.webview.addEventListener('message', event => {
    const message = event.data;
    if (message?.kind === 'work-access') { applyAccess(message.value); return; }
    if (!message || message.kind !== 'rpc-reply') return;
    const entry = pending.get(message.id);
    if (!entry) return;
    pending.delete(message.id);
    clearTimeout(entry.timer);
    entry.resolve(message);
  });
  function call(path, payload = null) {
    const id = Array.from(crypto.getRandomValues(new Uint8Array(16)), x => x.toString(16).padStart(2, '0')).join('');
    return new Promise((resolve, reject) => {
      // A native dialog may wait for user input; do not retry the operation.
      const timer = path.startsWith('/translation/') || ['/desktop/home','/updates/settings','/updates/download'].includes(path) ? null : setTimeout(() => {
        pending.delete(id); reject(new Error('The desktop connection did not respond.'));
      }, 60000);
      pending.set(id, { resolve, reject, timer });
      try { window.chrome.webview.postMessage({ kind: 'rpc', id, nonce: window.__ECUSS_HOST_NONCE__, path, payload: JSON.stringify(payload) }); }
      catch (error) { clearTimeout(timer); pending.delete(id); reject(error); }
    });
  }
  let access = window.__ECUSS_SUITE__?.access || {workBlocked:false,gateReason:'unverifiedAllowed'}, authorizing = false, accessError = false;
  const accessCopy = {
    ko:{title:'필수 업데이트 · 업무 실행 제한',detail:'최신 승인 버전을 적용해야 업무를 계속할 수 있습니다. 현재 결과는 HTML·Excel로 저장한 뒤 메인화면에서 업데이트하세요.',checking:'최신 버전 확인 중…',failure:'실행 허용 여부를 확인하지 못했습니다. 다시 시도해 주세요.',offline:'오프라인 · 설치된 지침으로 작업합니다. 연결되면 최신 버전을 다시 확인합니다.'},
    en:{title:'Required update · Work paused',detail:'Install the latest approved version to continue working. Save existing HTML/Excel results, then return to the main screen to update.',checking:'Checking the latest version…',failure:'Could not verify permission to start work. Please try again.',offline:'Offline · Using installed rules. Versions will be checked again when connected.'},
    vi:{title:'Bắt buộc cập nhật · Tạm dừng công việc',detail:'Cài bản mới nhất đã được duyệt để tiếp tục. Lưu kết quả HTML/Excel hiện có rồi về màn hình chính để cập nhật.',checking:'Đang kiểm tra phiên bản mới nhất…',failure:'Không xác nhận được quyền bắt đầu công việc. Vui lòng thử lại.',offline:'Ngoại tuyến · Dùng quy tắc đã cài. Kiểm tra lại phiên bản khi có mạng.'}
  };
  function renderAccess(){
    const banner=document.getElementById('ecuss-work-access');if(!banner)return;
    const t=accessCopy[document.documentElement.lang]||accessCopy.ko;
    const blocked=!!access.workBlocked;
    banner.hidden=!blocked&&!authorizing&&!accessError&&access.network!=='offline';
    banner.dataset.blocked=String(blocked);
    banner.textContent=authorizing?t.checking:accessError?t.failure:blocked?t.title+' — '+t.detail:t.offline;
    document.body.dataset.ecussWorkBlocked=String(blocked||authorizing);
    for(const el of document.querySelectorAll('#analyze,#run,#mail-preview-open')){
      if(blocked||authorizing)el.setAttribute('aria-disabled','true');else el.removeAttribute('aria-disabled');
    }
  }
  function applyAccess(next){
    if(!next || typeof next.workBlocked!=='boolean')return;
    access=next;renderAccess();window.EcussUpdateStatus?.accept(next);
  }
  async function authorizeWork(){
    if(authorizing)return false;authorizing=true;accessError=false;renderAccess();
    try{
      const r=await call('/desktop/authorize');
      if(r.status!==200||typeof r.value?.allowed!=='boolean')throw new Error('gate');
      applyAccess(r.value.access);return r.value.allowed===true;
    }catch{
      accessError=true;const banner=document.getElementById('ecuss-work-access');
      if(banner){banner.hidden=false;banner.textContent=(accessCopy[document.documentElement.lang]||accessCopy.ko).failure;}
      return false;
    }finally{authorizing=false;renderAccess();}
  }
  window.EcussDesktop = { call, authorizeWork };
  window.fetch = async () => { throw new Error('External requests are disabled.'); };
  window.EcussDesktopState = () => ({
    busy: authorizing || !!window.EcussModuleState?.busy?.() || !!document.querySelector('#analyze[data-desktop-running="true"]') ||
      (!!window.EcussModuleState?.hasResult() && !!document.querySelector('#download:disabled,#save-html:disabled')),
    hasWork: !!window.EcussModuleState?.hasWork?.() || !!window.EcussModuleState?.hasResult?.() || !!document.querySelector('.upload-card.ready') ||
      [...document.querySelectorAll('input[type="file"]')].some(x => x.files.length > 0)
  });
  let homeButton, homeNotice, homePending = false;
  const homeText = {
    ko: {home:'메인화면으로',busy:'진행 중인 작업이 끝난 뒤 다시 눌러 주세요.',error:'메인화면으로 돌아가지 못했습니다. 다시 시도하거나 상단의 업무 모듈을 이용하세요.'},
    en: {home:'Back to main screen',busy:'Wait for the current task to finish.',error:'Could not return to the main screen. Try again or use Work modules above.'},
    vi: {home:'Về màn hình chính',busy:'Chờ tác vụ hiện tại hoàn tất.',error:'Không thể về màn hình chính. Thử lại hoặc chọn Mô-đun công việc ở phía trên.'}
  };
  function homeCopy() { return homeText[document.documentElement.lang] || homeText.ko; }
  function installModuleNavigation() {
    if (!window.__ECUSS_DESKTOP_CONTEXT__?.moduleId || document.getElementById('ecuss-module-navigation')) return;
    const style=document.createElement('style');style.setAttribute('data-ecuss-desktop','');
    style.textContent='#ecuss-module-navigation{background:#123751;color:#fff;font-family:Segoe UI,Malgun Gothic,sans-serif}#ecuss-module-navigation .ecuss-nav-inner{max-width:1480px;margin:0 auto;padding:14px 28px;display:flex;align-items:center;gap:18px;flex-wrap:wrap}#ecuss-home-button{display:inline-flex;align-items:center;gap:9px;border:1px solid #91c4d2;border-radius:8px;background:#fff;color:#16475e;padding:10px 16px;font:600 14px Segoe UI,Malgun Gothic,sans-serif;cursor:pointer}#ecuss-home-button:hover{background:#e9f4f8}#ecuss-home-button:disabled{opacity:.65;cursor:wait}#ecuss-home-button:focus-visible{outline:3px solid #88e0ef;outline-offset:3px}#ecuss-home-notice{font-size:13px;color:#fff3d9;line-height:1.6}';
    document.head.append(style);
    const policyStyle=document.createElement('style');policyStyle.setAttribute('data-ecuss-desktop','');
    policyStyle.textContent='#ecuss-work-access{margin:0;padding:16px 28px;background:#fff4dc;color:#724d12;font:14px/1.65 Segoe UI,Malgun Gothic,sans-serif;border-bottom:1px solid #e8c987}#ecuss-work-access[data-blocked="true"]{background:#fff0ec;color:#9c3829;border-color:#e5b9af}body[data-ecuss-work-blocked="true"] #analyze,body[data-ecuss-work-blocked="true"] #mail-preview-open,body[data-ecuss-work-blocked="true"] .upload-card{opacity:.55;cursor:not-allowed}';
    document.head.append(policyStyle);
    const notice=document.createElement('section');notice.id='ecuss-work-access';notice.setAttribute('data-ecuss-desktop','');notice.setAttribute('role','alert');notice.hidden=true;document.body.prepend(notice);
    for(const name of ['click','drop','keydown']) document.addEventListener(name,event=>{
      if((access.workBlocked||authorizing)&&event.target.closest?.('#analyze,.upload-card,#mail-preview-open,#ecuss-mail-dialog,'+(window.EcussModuleUI?.workControls||'#run'))){
        if(name==='keydown'&&!['Enter',' '].includes(event.key))return;
        event.preventDefault();event.stopImmediatePropagation();renderAccess();
      }
    },true);
    const nav=document.createElement('nav');nav.id='ecuss-module-navigation';nav.setAttribute('data-ecuss-desktop','');
    const inner=document.createElement('div');inner.className='ecuss-nav-inner';
    homeButton=document.createElement('button');homeButton.type='button';homeButton.id='ecuss-home-button';
    const arrow=document.createElement('span');arrow.textContent='←';arrow.setAttribute('aria-hidden','true');
    const label=document.createElement('span');label.textContent=homeCopy().home;homeButton.append(arrow,label);
    homeNotice=document.createElement('span');homeNotice.id='ecuss-home-notice';homeNotice.setAttribute('role','status');homeNotice.setAttribute('aria-live','polite');
    inner.append(homeButton,homeNotice);nav.append(inner);
    const header=document.querySelector('body > header');if(header)header.before(nav);else document.body.prepend(nav);
    homeButton.addEventListener('click',async()=>{
      if(homePending)return;
      homeNotice.textContent='';
      if(window.EcussDesktopState().busy){homeNotice.textContent=homeCopy().busy;return;}
      homePending=true;homeButton.disabled=true;
      try{const response=await call('/desktop/home');if(response.status!==200)throw new Error(response.value?.message||homeCopy().error);}
      catch(error){homeNotice.textContent=homeCopy().error;}
      finally{homePending=false;homeButton.disabled=false;}
    });
  }
  // Bind each same-origin document: keyboard events inside PSR frames do not bubble to the host page.
  const homeDocuments=new WeakSet();
  function bindHomeShortcut(doc){
    if(homeDocuments.has(doc))return;homeDocuments.add(doc);
    doc.addEventListener('keydown',event=>{
      const backspace=event.key==='Backspace'&&!event.altKey;
      const altLeft=event.key==='ArrowLeft'&&event.altKey;
      if((!backspace&&!altLeft)||event.ctrlKey||event.metaKey||event.shiftKey)return;
      if(!homeButton)return;
      // Consume browser Back even while guarded, so history cannot bypass the work confirmation.
      const handled=event.defaultPrevented;
      if(altLeft)event.preventDefault();
      if(handled||event.isComposing||event.keyCode===229)return;
      const nodes=event.composedPath?.()||[event.target];
      if(nodes.some(el=>el?.closest?.('dialog,[role="dialog"]')))return;
      if(doc.querySelector('dialog[open], [role="dialog"][aria-modal="true"]:not([hidden])'))return;
      if(backspace&&nodes.some(el=>el?.isContentEditable||el?.closest?.('input,textarea,select,[contenteditable]:not([contenteditable="false"]),[role="textbox"],[role="combobox"],[role="spinbutton"]')))return;
      event.preventDefault();
      if(!event.repeat&&!homePending)homeButton.click();
    });
    for(const frame of doc.querySelectorAll('iframe')){
      const bind=()=>{try{if(frame.contentDocument)bindHomeShortcut(frame.contentDocument);}catch{}};
      frame.addEventListener('load',bind);bind();
    }
  }
  function language() {
    const lang = document.documentElement.lang;
    renderAccess();
    if(homeButton){homeButton.lastElementChild.textContent=homeCopy().home;homeNotice.textContent='';}
    if (['ko', 'en', 'vi'].includes(lang)) call('/desktop/language', lang).catch(() => {});
  }
  window.addEventListener('load', () => {
    installModuleNavigation();
    if(homeButton){homeButton.setAttribute("aria-keyshortcuts","Backspace Alt+ArrowLeft");bindHomeShortcut(document);}
    language();
    new MutationObserver(language).observe(document.documentElement, { attributes: true, attributeFilter: ['lang'] });
    call('/desktop/ready').catch(() => {});
    if(window.__ECUSS_DESKTOP_CONTEXT__?.moduleId)call('/updates/check',false).then(r=>{if(r.status===200)applyAccess(r.value);}).catch(()=>{});
  }, { once: true });
})();


/* Shared presentation adapter. Existing module controls and business events are retained. */
(() => {
  'use strict';
  window.addEventListener('load', () => {
    if (!window.EcussDesktop || window.__VALIDATION_VIEWER__) return;
    const id=window.__ECUSS_DESKTOP_CONTEXT__?.moduleId;
    const module=window.__ECUSS_SUITE__?.modules?.find(m=>m.id===id);
    const nav=document.getElementById('ecuss-module-navigation');
    if(!module||!nav)return;
    let header=document.querySelector('body>header');
    if(!header&&id==='vn-kr-customs-translation'){
      const heading=document.querySelector('main>.heading');
      if(heading){header=document.createElement('header');heading.before(header);header.append(heading);nav.after(header);}
    }
    if(!header)return;
    document.body.classList.add('ecuss-module-ui');document.body.dataset.suiteCategory=module.category;document.body.dataset.suiteModule=id;
    header.id='ecuss-page-header';
    if(id==='stock-status-amovina'){
      const top=header.querySelector('.topbar'),left=top?.firstElementChild,date=header.querySelector('.datebox'),rate=header.querySelector('.ratebox:not(.datebox)');
      if(top&&left&&date&&rate){const options=document.createElement('div');options.className='top-options';options.append(date,rate);header.append(left,options);top.remove();}
    }else if(id==='stock-status-amogreen-vina'){
      const title=header.querySelector('.header-title');if(title)header.prepend(title);
    }
    const style=document.createElement('style');style.setAttribute('data-ecuss-desktop','');style.textContent="/* Desktop presentation only. Never included in shared result documents. */\nbody.ecuss-module-ui{--suite-accent:#0866d9;--suite-tint:#edf4ff;background:#f5f6fa;font-family:'Segoe UI Variable','Segoe UI','Malgun Gothic',sans-serif}\nbody.ecuss-module-ui[data-suite-category=translation]{--suite-accent:#7650a2;--suite-tint:#f5effc}\nbody.ecuss-module-ui[data-suite-category=inventory]{--suite-accent:#a65720;--suite-tint:#fff4e9}\nbody.ecuss-module-ui #ecuss-module-navigation{position:sticky;top:0;z-index:101;background:#f9fafded;color:#425c7b;backdrop-filter:blur(20px);border-bottom:1px solid #e1e6ef}\nbody.ecuss-module-ui #ecuss-module-navigation .ecuss-nav-inner{max-width:1488px;padding:8px 24px;gap:12px;flex-wrap:nowrap}\nbody.ecuss-module-ui #ecuss-home-button{font-size:13px;padding:7px 12px;flex-shrink:0}\n#ecuss-category-label{color:#65768d;font-size:12px;font-weight:600;white-space:nowrap}\nbody.ecuss-module-ui #ecuss-page-header{position:sticky!important;top:var(--suite-nav-height,52px)!important;z-index:100;display:block!important;visibility:visible!important;background:#ffffffed;backdrop-filter:blur(20px);color:#202b3b;padding:22px max(24px,calc((100vw - 1440px)/2));margin:0;border-radius:0;border-bottom:1px solid #dfe5ef;box-shadow:0 5px 12px #19354e16;max-height:55vh;overflow:auto}\nbody.ecuss-module-ui #ecuss-page-header h1{font:650 25px/1.35 'Segoe UI Variable','Segoe UI','Malgun Gothic',sans-serif;letter-spacing:-.4px;margin:0 0 6px;overflow-wrap:anywhere;color:#202b3b}\nbody.ecuss-module-ui #ecuss-page-header p{font-size:13px;line-height:1.5;color:#65768d;margin:0}\nbody.ecuss-module-ui #ecuss-page-header .top-inner,body.ecuss-module-ui #ecuss-page-header .heading{max-width:1440px;margin:0 auto;display:flex;gap:18px;align-items:center;justify-content:space-between}\nbody.ecuss-module-ui #ecuss-page-header .language-picker,body.ecuss-module-ui #ecuss-page-header .lang{margin:0;align-self:center;color:#65768d;flex-shrink:0}\nbody.ecuss-module-ui #ecuss-page-header select{background:#fff;color:#234056;max-width:100%;border-radius:8px;padding:7px 10px}\nbody.ecuss-module-ui #ecuss-page-header .eyebrow,body.ecuss-module-ui #ecuss-page-header .brand{font-size:10px;letter-spacing:1px;margin:0 0 5px;color:#6d7e94}\nbody.ecuss-module-ui #ecuss-page-header .version,body.ecuss-module-ui #ecuss-page-header .pilot{font-size:11px;color:#65768d;margin-top:4px}\nbody.ecuss-module-ui #ecuss-page-header .header-title{display:flex;align-items:center;justify-content:space-between;gap:14px}\nbody.ecuss-module-ui #ecuss-page-header .top-options{display:flex;gap:16px;flex-wrap:wrap;margin:10px 0 0;justify-content:flex-start;align-items:flex-start}\nbody.ecuss-module-ui #ecuss-page-header .top-options .field,body.ecuss-module-ui #ecuss-page-header .ratebox{min-width:0;max-width:100%;color:#405878;background:#eef2f8;padding:8px 12px;border-radius:8px;margin:0;flex:0 1 auto}\nbody.ecuss-module-ui #ecuss-page-header .top-options small,body.ecuss-module-ui #ecuss-page-header .ratebox small{font-size:10px;color:#65768d}\nbody.ecuss-module-ui #ecuss-page-header input{max-width:100%;font-size:13px;padding:5px 8px}\nbody.ecuss-module-ui main,body.ecuss-module-ui .container{max-width:1488px;margin:0 auto;padding:24px 24px 48px}\nbody.ecuss-module-ui .panel,body.ecuss-module-ui .card,body.ecuss-module-ui .upload-card{border-radius:18px;border-color:#e0e6ee;box-shadow:0 5px 20px #24364b05}\nbody.ecuss-module-ui .upload-card,body.ecuss-module-ui .dropzone,body.ecuss-module-ui [data-card],body.ecuss-module-ui .file-box{border-color:#c9d7e2;transition:background-color .12s,border-color .12s}\nbody.ecuss-module-ui .upload-card.ready,body.ecuss-module-ui .dropzone.selected,body.ecuss-module-ui .dropzone.has-file,body.ecuss-module-ui #dropzone[data-selected=true],body.ecuss-module-ui [data-card].selected,body.ecuss-module-ui .file-box[data-selected=true]{border:2px solid var(--suite-accent);background:var(--suite-tint)}\nbody.ecuss-module-ui .file-box.dragover,body.ecuss-module-ui .upload-card.dragover,body.ecuss-module-ui .upload-card.drag,body.ecuss-module-ui .dropzone.dragover,body.ecuss-module-ui .dropzone.drag-over,body.ecuss-module-ui [data-card].dragover{outline:3px solid var(--suite-accent);outline-offset:2px;background:var(--suite-tint)}\nbody.ecuss-module-ui .result-actions{top:var(--suite-header-bottom,150px);z-index:30}\nbody.ecuss-module-ui :is(#results,#result){scroll-margin-top:calc(var(--suite-header-bottom,150px) + 16px)}\n@media(max-width:700px){body.ecuss-module-ui #ecuss-module-navigation .ecuss-nav-inner{padding:8px 16px}#ecuss-home-notice{max-width:45vw;font-size:11px!important}body.ecuss-module-ui #ecuss-page-header{padding:12px 16px}body.ecuss-module-ui #ecuss-page-header h1{font-size:19px}body.ecuss-module-ui #ecuss-page-header .top-inner,body.ecuss-module-ui #ecuss-page-header .heading{flex-direction:row;flex-wrap:wrap;gap:8px}body.ecuss-module-ui #ecuss-page-header .top-options{gap:8px}body.ecuss-module-ui #ecuss-page-header .header-title{flex-wrap:wrap}body.ecuss-module-ui main,body.ecuss-module-ui .container{padding:18px 16px 36px}}\n@media print{body.ecuss-module-ui #ecuss-module-navigation{display:none}body.ecuss-module-ui #ecuss-page-header{position:static!important;max-height:none;overflow:visible}}\n\nbody.ecuss-module-ui #ecuss-page-header:has(>#lang){display:flex!important;justify-content:space-between;align-items:center;gap:16px;flex-wrap:wrap}\n\nbody.ecuss-module-ui #ecuss-page-header select.lang{color:#234056}\n\nbody.ecuss-module-ui #ecuss-home-button{color:#315374;background:#fff;border:1px solid #dce3ed;border-radius:10px}\nbody.ecuss-module-ui button,body.ecuss-module-ui select{border-radius:10px}body.ecuss-module-ui button{font-family:inherit}body.ecuss-module-ui :is(button,input,select):focus-visible{outline:3px solid #2278e6;outline-offset:3px}\nbody.ecuss-module-ui #ecuss-page-header input{background:#fff;color:#293b54;border:1px solid #dce3ed;border-radius:7px}body.ecuss-module-ui .result-actions{background:#ffffffed;backdrop-filter:blur(16px);border-color:#e0e6ee}\n/* A single vertical scroller leaves the mail sheet header and actions visible. */\nbody.ecuss-module-ui #ecuss-mail-dialog{overflow:hidden;border-radius:22px;border:1px solid #ffffffa0;color:#26354b;background:#f4f6fa;box-shadow:0 25px 90px #172b4650}body.ecuss-module-ui #ecuss-mail-dialog[open]{display:flex;flex-direction:column}body.ecuss-module-ui #ecuss-mail-dialog::backdrop{background:#1c2d4666;backdrop-filter:blur(6px)}body.ecuss-module-ui #ecuss-mail-dialog .em-head,body.ecuss-module-ui #ecuss-mail-dialog .em-foot{position:static;flex:0 0 auto;padding:17px 24px;background:#ffffffef;border-color:#e1e6ef}body.ecuss-module-ui #ecuss-mail-dialog h2{font-size:21px;letter-spacing:-.5px}body.ecuss-module-ui #ecuss-mail-dialog .em-content{flex:1 1 auto;min-height:0;overflow:auto;padding:20px 24px;scrollbar-gutter:stable}body.ecuss-module-ui #ecuss-mail-dialog .em-card{border:1px solid #e0e6ee;border-radius:15px;padding:20px}body.ecuss-module-ui #ecuss-mail-dialog .em-choice{background:#f6f8fb;border:1px solid #e1e6ef;border-radius:9px;color:#566880}body.ecuss-module-ui #ecuss-mail-dialog .em-choice:has(input:checked){color:#285583;border-color:#b9d0ef;background:#eef5ff}body.ecuss-module-ui #ecuss-mail-dialog input[type=checkbox]{accent-color:#0866d9}body.ecuss-module-ui #ecuss-mail-dialog select,body.ecuss-module-ui #ecuss-mail-dialog .em-quiet{border-color:#dce3ed;border-radius:9px;background:#f8fafc;color:#3b577a}body.ecuss-module-ui #ecuss-mail-dialog #em-subject{display:block;width:100%;min-width:0;font:600 14px/1.6 'Segoe UI','Malgun Gothic',sans-serif;padding:11px 13px;border:1px solid #b8c9df;border-radius:10px;color:#233b5b;background:#fff}body.ecuss-module-ui #ecuss-mail-dialog #em-subject:disabled{color:#7d8796;background:#f3f5f8}body.ecuss-module-ui #ecuss-mail-dialog #em-send{background:#0866d9;border-radius:11px;padding:12px 25px}body.ecuss-module-ui #ecuss-mail-dialog #em-send:disabled{background:#9caabe;color:#fff}body.ecuss-module-ui #ecuss-mail-dialog #em-viewport{max-height:none;min-height:0;overflow-x:auto;overflow-y:hidden}body.ecuss-module-ui #ecuss-mail-dialog #em-count{font-size:13px}body.ecuss-module-ui #ecuss-mail-dialog .em-note{font-size:11px;line-height:1.7;color:#687c94}body.ecuss-module-ui #ecuss-mail-dialog .em-preview-title{flex-wrap:wrap;font-size:13px}body.ecuss-module-ui #ecuss-mail-dialog .em-file{border-radius:8px;background:#f0f5fc;border-color:#dbe5f2}\n@media(max-width:700px){body.ecuss-module-ui #ecuss-category-label{font-size:10px;white-space:normal}body.ecuss-module-ui #ecuss-mail-dialog .em-head,body.ecuss-module-ui #ecuss-mail-dialog .em-content,body.ecuss-module-ui #ecuss-mail-dialog .em-foot{padding:12px 14px}body.ecuss-module-ui #ecuss-mail-dialog .em-card{padding:14px}body.ecuss-module-ui #ecuss-mail-dialog .em-foot .em-note{margin:4px 0}body.ecuss-module-ui #ecuss-mail-dialog .em-head .em-note{display:none}}\n@media(prefers-reduced-motion:reduce){body.ecuss-module-ui *{transition:none!important;scroll-behavior:auto!important}}\n\nbody.ecuss-module-ui #ecuss-home-notice{color:#975527}\n\nbody.ecuss-module-ui #ecuss-page-header .version{background:#eef2f8;color:#61738d;border-radius:20px;padding:6px 12px}\n\n/* Glass Workspace: shared navigation materials; document content keeps an opaque reading surface. */\nbody.ecuss-module-ui{--suite-accent:#4260da;--suite-tint:#eff3ff;background:radial-gradient(ellipse at 0 0,#e9edfc 0,transparent 48%),#f4f6fb;color:#253148}\nbody.ecuss-module-ui #ecuss-module-navigation{background:#eef2fbdc;border-bottom-color:#e0e6f2;backdrop-filter:blur(24px)}\nbody.ecuss-module-ui #ecuss-page-header{background:#f9faffea;box-shadow:0 6px 20px #34436808;border-bottom-color:#e0e6f2;backdrop-filter:blur(24px)}\nbody.ecuss-module-ui #ecuss-home-button{border-color:#d8e2f4;background:#ffffffc9;color:#4c649b;border-radius:12px}\nbody.ecuss-module-ui .panel,body.ecuss-module-ui .card,body.ecuss-module-ui .upload-card{border-radius:20px;border-color:#e0e6f1;box-shadow:0 8px 26px #34436806}\nbody.ecuss-module-ui #ecuss-page-header .top-options .field,body.ecuss-module-ui #ecuss-page-header .ratebox{background:#eaf0fa9c;border:1px solid #dfe7f5;border-radius:11px}\nbody.ecuss-module-ui #ecuss-mail-dialog{background:#f3f5fb;border-color:#e1e7f2;box-shadow:0 30px 100px #26344e45}\nbody.ecuss-module-ui #ecuss-mail-dialog .em-head,body.ecuss-module-ui #ecuss-mail-dialog .em-foot{background:#f6f8ffed;backdrop-filter:blur(22px)}\nbody.ecuss-module-ui #ecuss-mail-dialog #em-send{background:#4260da}\nbody.ecuss-module-ui dialog::backdrop{background:#26344e66;backdrop-filter:blur(7px)}\n@media(forced-colors:active){body.ecuss-module-ui,body.ecuss-module-ui #ecuss-page-header,body.ecuss-module-ui #ecuss-module-navigation,body.ecuss-module-ui #ecuss-mail-dialog,body.ecuss-module-ui #ecuss-mail-dialog .em-head,body.ecuss-module-ui #ecuss-mail-dialog .em-foot{background:Canvas;color:CanvasText;backdrop-filter:none}body.ecuss-module-ui #ecuss-page-header h1,body.ecuss-module-ui #ecuss-page-header p{color:CanvasText}body.ecuss-module-ui #ecuss-home-button{border:1px solid ButtonText;color:ButtonText;background:ButtonFace}}\n\nbody.ecuss-module-ui #report-dialog{border:1px solid #e1e7f2;border-radius:22px;background:#f3f5fb;box-shadow:0 30px 100px #26344e45;overflow:hidden}body.ecuss-module-ui #report-dialog .report-toolbar{background:#f6f8ffed;border-bottom:1px solid #dfe5f1;color:#354868;gap:14px}body.ecuss-module-ui #report-dialog #close-report{border:1px solid #d8e2f4;border-radius:10px;background:white;color:#4c649b;padding:8px 13px}\n\n/* Shared desktop presentation. No engine, workbook, result data or source payload changes. */\nbody.ecuss-module-ui{min-height:100vh}\nbody:is(.ecuss-module-ui,.ecuss-module-frame)[data-suite-module]{\n --suite-accent:#4260da;--suite-tint:#eff3ff;--suite-ink:#253148;--suite-muted:#626f85;\n --suite-line:#dfe5f1;--suite-surface:#ffffffed;--suite-radius:20px;\n --accent:var(--suite-accent);--blue:var(--suite-accent);\n --navy:var(--suite-ink);--ink:var(--suite-ink);--muted:var(--suite-muted);--line:var(--suite-line);\n font:14px/1.65 'Segoe UI Variable','Segoe UI','Malgun Gothic',sans-serif;\n color:var(--suite-ink);background:radial-gradient(ellipse at 0 0,#e5eaff 0,transparent 50%),radial-gradient(ellipse at 100% 65%,#f0ecfb 0,transparent 45%),#f4f6fb;\n}\nbody:is(.ecuss-module-ui,.ecuss-module-frame) :is(h1,h2,h3,h4){color:var(--suite-ink);line-height:1.4;letter-spacing:-.35px}\nbody:is(.ecuss-module-ui,.ecuss-module-frame) h2{font-size:18px;font-weight:650}\nbody:is(.ecuss-module-ui,.ecuss-module-frame) h3{font-size:15px;font-weight:650}\nbody:is(.ecuss-module-ui,.ecuss-module-frame) :is(.muted,.desc,.hint,.help,.note,.intro,.file-size,.drop-hint){color:var(--suite-muted)}\nbody.ecuss-module-ui #ecuss-module-navigation{background:#f2f5ffde;border-bottom:1px solid #ffffffc9;backdrop-filter:blur(24px)}\nbody.ecuss-module-ui #ecuss-page-header{background:#f8faffdb;border-bottom:1px solid #dfe5f1;backdrop-filter:blur(24px);box-shadow:0 8px 28px #2a395505}\nbody.ecuss-module-ui #ecuss-page-header h1{font-size:25px;font-weight:650;color:var(--suite-ink)}\nbody.ecuss-module-ui #ecuss-page-header :is(.version,.pilot){display:inline-block;background:#edf1fc;border:1px solid #dfe6f5;border-radius:20px;color:#68799a;font-size:11px;padding:4px 10px}\nbody.ecuss-module-ui main{min-width:0}\nbody:is(.ecuss-module-ui,.ecuss-module-frame) :is(.panel,.card,.upload-card,.upload,section.method,details.method){\n background:var(--suite-surface);border:1px solid var(--suite-line);border-radius:var(--suite-radius);\n box-shadow:inset 0 1px 0 #fff,0 10px 32px #2a395508;min-width:0;\n}\nbody:is(.ecuss-module-ui,.ecuss-module-frame) :is(.card,.upload-card,.panel){padding:22px}\nbody:is(.ecuss-module-ui,.ecuss-module-frame) :is(button,select,input,textarea){font-family:inherit;font-size:13px}\nbody:is(.ecuss-module-ui,.ecuss-module-frame) button,\nbody:is(.ecuss-module-ui,.ecuss-module-frame) :is(.pick,.filelabel,.file-label,a.secondary,a.primary){\n min-height:38px;padding:9px 14px;border:1px solid #d8e1f3;border-radius:11px;background:#f0f3fd;\n color:#4261a1;font-weight:600;line-height:1.4;box-shadow:none;transition:background-color .15s,border-color .15s;\n}\nbody:is(.ecuss-module-ui,.ecuss-module-frame) button:hover:not(:disabled),\nbody:is(.ecuss-module-ui,.ecuss-module-frame) :is(.pick,.filelabel,.file-label,a.secondary):hover{background:#e7edfc;border-color:#bdcbed}\nbody:is(.ecuss-module-ui,.ecuss-module-frame) :is(button.primary,a.primary,#calculate){background:#4260da;color:#fff;border-color:#4260da;box-shadow:0 4px 12px #4260da18}\nbody:is(.ecuss-module-ui,.ecuss-module-frame) :is(button.primary,a.primary,#calculate):hover:not(:disabled){background:#354ec0;border-color:#354ec0;color:#fff}\nbody:is(.ecuss-module-ui,.ecuss-module-frame) button:disabled{opacity:.48;cursor:not-allowed;box-shadow:none}\nbody:is(.ecuss-module-ui,.ecuss-module-frame) button[aria-pressed=true]{background:#e8eeff;border-color:#b8c8f2;color:#354eb8}\nbody:is(.ecuss-module-ui,.ecuss-module-frame) :is(input:not([type=file]):not([type=checkbox]):not([type=radio]):not([type=range]),select,textarea){\n min-height:36px;max-width:100%;padding:8px 10px;border:1px solid #d7dfed;border-radius:10px;background:#fff;color:var(--suite-ink);box-shadow:inset 0 1px 2px #25314803;\n}\nbody:is(.ecuss-module-ui,.ecuss-module-frame) :is(input[type=checkbox],input[type=radio]){accent-color:var(--suite-accent)}\nbody:is(.ecuss-module-ui,.ecuss-module-frame) :is(button,input,select,textarea,summary,a):focus-visible{outline:3px solid #4260da;outline-offset:3px}\nbody:is(.ecuss-module-ui,.ecuss-module-frame) :is(.file-box,.file-row,.drop,.dropzone){border-color:#cbd7ed;background:#f8faff;border-radius:16px}\nbody:is(.ecuss-module-ui,.ecuss-module-frame) :is(.file-prompt,.step,.tag,.number,.selection-state){color:#5b6f9e}\nbody:is(.ecuss-module-ui,.ecuss-module-frame) :is(.tag,.number,.selection-state){background:#edf2fc;border-color:#dce5f6;border-radius:9px}\nbody:is(.ecuss-module-ui,.ecuss-module-frame) :is(.file-box[data-selected=true],.card.selected,.drop.selected,.drop.has-file,.dropzone.selected,.dropzone.has-file,.upload-card.ready,#dropzone[data-selected=true]){border-color:#4260da;background:#eff3ff;box-shadow:0 0 0 1px #4260da26}\nbody:is(.ecuss-module-ui,.ecuss-module-frame) :is(.dragover,.drag-over,.drag){outline:3px solid #4260da;outline-offset:2px;background:#eaf0ff}\nbody:is(.ecuss-module-ui,.ecuss-module-frame) :is(.clear,.clear-file){min-height:28px;padding:5px 9px;font-size:12px;border-radius:8px}\nbody:is(.ecuss-module-ui,.ecuss-module-frame) details{background:#ffffffad;border:1px solid #dfe5f1;border-radius:15px;padding:14px 17px;margin-top:14px;color:var(--suite-ink)}\nbody:is(.ecuss-module-ui,.ecuss-module-frame) summary{cursor:pointer;color:#4c608c;font-size:13px;font-weight:600;line-height:1.6}\nbody:is(.ecuss-module-ui,.ecuss-module-frame) summary::marker{color:#7c8fbc}\nbody:is(.ecuss-module-ui,.ecuss-module-frame) details[open]>summary{margin-bottom:12px}\nbody:is(.ecuss-module-ui,.ecuss-module-frame) :is(th,.table-head){background:#edf2fc;color:#40567c;border-color:#dce4f2;font-weight:600}\nbody:is(.ecuss-module-ui,.ecuss-module-frame) :is(table,.tablewrap,.scroll){border-color:#dfe5f1}\nbody:is(.ecuss-module-ui,.ecuss-module-frame) :is(.actions,.toolbar,.resulthead,.result-head){gap:12px}\nbody:is(.ecuss-module-ui,.ecuss-module-frame) :is(dialog,.dialog){border:1px solid #dfe5f1;border-radius:20px;background:#f8faff;box-shadow:0 28px 90px #25314835;color:var(--suite-ink)}\nbody:is(.ecuss-module-ui,.ecuss-module-frame) :is(.dialoghead,.dialog-head){background:#f0f4ff;border-color:#dfe5f1}\nbody.ecuss-module-ui[data-suite-module=stock-status-amovina]>section:not(#ecuss-work-access){max-width:1440px;margin:24px auto 0;padding:22px;border:1px solid #dfe5f1;border-radius:20px;background:#ffffffed;box-shadow:0 10px 32px #2a395508}\nbody.ecuss-module-ui[data-suite-module=stock-status-amovina] .notice{background:#edf2fc;border-color:#b8c8ed;border-radius:14px;color:#40567c;padding:16px 18px}\nbody.ecuss-module-ui[data-suite-module=stock-status-amogreen-vina] :is(.local,.tag.required){background:#edf2fc;color:#4c6497;border-color:#dce5f6}\nbody.ecuss-module-ui[data-suite-module=stock-status-amogreen-vina] .inactive{background:#edf0f6;border-style:dashed;box-shadow:none}\nbody.ecuss-module-ui[data-suite-module=monthly-report-consolidation] .shell{max-width:1800px;margin:auto;grid-template-columns:220px minmax(0,1fr)}\nbody.ecuss-module-ui[data-suite-module=monthly-report-consolidation] .sidebar{background:linear-gradient(150deg,#e9edfcc9,#eef2fbc4 60%,#eeebf8c0);border-color:#dce3f0;padding:28px 18px;backdrop-filter:blur(24px)}\nbody.ecuss-module-ui[data-suite-module=monthly-report-consolidation] .navlink{color:#647497;border:1px solid transparent;border-radius:12px;font-size:13px}\nbody.ecuss-module-ui[data-suite-module=monthly-report-consolidation] .navlink.active{background:#ffffffeb;color:#36539d;border-color:#fff;box-shadow:0 5px 18px #334c7808}\nbody.ecuss-module-ui[data-suite-module=monthly-report-consolidation] .main{margin:0;max-width:none;padding:28px 30px 48px}\nbody.ecuss-module-ui[data-suite-module=monthly-report-consolidation] .side-note{color:#72819c;font-size:11px;border-top:1px solid #dce3f0;padding-top:18px}\nbody.ecuss-module-ui[data-suite-module=monthly-report-consolidation] :is(.period,.rule-box,.rate-card){background:#f4f7fd;border-color:#dfe5f1;border-radius:13px}\nbody.ecuss-module-ui[data-suite-module=psr-rvc-lvc-calculator] #frames{max-width:1488px;padding:0;margin:0 auto}\nbody.ecuss-module-ui[data-suite-module=psr-rvc-lvc-calculator] #frames iframe{background:transparent}\nbody.ecuss-module-frame{max-width:none;margin:0;padding:24px;min-width:0}\nbody.ecuss-module-frame>section:not(.notice){padding:22px;margin-bottom:18px;background:#ffffffed;border:1px solid #dfe5f1;border-radius:20px;box-shadow:0 10px 32px #2a395508}\nbody.ecuss-module-frame>h1{font-size:22px;margin:0 0 12px}\nbody.ecuss-module-frame :is(.notice,#suite-user-psr-scope){background:#edf2fc;border-color:#d9e3f6;border-radius:13px;color:#496187;padding:14px 17px;font-size:13px}\nbody.ecuss-module-frame :is(table input,table select,table button){font-size:12px;min-height:30px;padding:6px 8px;border-radius:8px}\nbody.ecuss-module-frame #excelPanel{background:#f7f9ff;border-color:#cbd7ed;border-radius:14px}\n@media(max-width:900px){body.ecuss-module-ui[data-suite-module=monthly-report-consolidation] .shell{grid-template-columns:180px minmax(0,1fr)}body.ecuss-module-ui[data-suite-module=monthly-report-consolidation] .main{padding:22px 18px 36px}}\n@media(max-width:760px){body.ecuss-module-ui[data-suite-module=monthly-report-consolidation] .shell{display:block}body.ecuss-module-ui[data-suite-module=monthly-report-consolidation] .sidebar{padding:15px 18px}body.ecuss-module-ui[data-suite-module=monthly-report-consolidation] .side-note{display:none}body.ecuss-module-frame{padding:16px}body:is(.ecuss-module-ui,.ecuss-module-frame) :is(.card,.upload-card,.panel){padding:17px}body.ecuss-module-ui[data-suite-module=stock-status-amovina]>section:not(#ecuss-work-access){margin:18px 16px 0}body.ecuss-module-ui #ecuss-page-header h1{font-size:20px}}\n@media(prefers-reduced-motion:reduce){body:is(.ecuss-module-ui,.ecuss-module-frame) *{transition:none!important}}\n@media(forced-colors:active){body:is(.ecuss-module-ui,.ecuss-module-frame)[data-suite-module],body:is(.ecuss-module-ui,.ecuss-module-frame) :is(.panel,.card,.upload,.drop,.file-box,details,.notice){background:Canvas;color:CanvasText;border-color:CanvasText;box-shadow:none}body:is(.ecuss-module-ui,.ecuss-module-frame) :is(button,.primary){background:ButtonFace;color:ButtonText;border-color:ButtonText}}\n@media print{body:is(.ecuss-module-ui,.ecuss-module-frame)[data-suite-module]{background:white}body:is(.ecuss-module-ui,.ecuss-module-frame) :is(.panel,.card,.upload,section){box-shadow:none;backdrop-filter:none}}\n";document.head.append(style);
    // PSR uses same-origin srcdoc frames. Style their DOM without changing payloads or engines.
    if(id==='psr-rvc-lvc-calculator'){
      const applyFrameTheme=frame=>{
        const doc=frame.contentDocument;
        if(!doc?.body||doc.getElementById('suite-frame-theme'))return;
        doc.body.classList.add('ecuss-module-frame');doc.body.dataset.suiteModule=id;
        const sheet=doc.createElement('style');sheet.id='suite-frame-theme';sheet.setAttribute('data-ecuss-desktop','');sheet.textContent="/* Shared desktop presentation. No engine, workbook, result data or source payload changes. */\nbody.ecuss-module-ui{min-height:100vh}\nbody:is(.ecuss-module-ui,.ecuss-module-frame)[data-suite-module]{\n --suite-accent:#4260da;--suite-tint:#eff3ff;--suite-ink:#253148;--suite-muted:#626f85;\n --suite-line:#dfe5f1;--suite-surface:#ffffffed;--suite-radius:20px;\n --accent:var(--suite-accent);--blue:var(--suite-accent);\n --navy:var(--suite-ink);--ink:var(--suite-ink);--muted:var(--suite-muted);--line:var(--suite-line);\n font:14px/1.65 'Segoe UI Variable','Segoe UI','Malgun Gothic',sans-serif;\n color:var(--suite-ink);background:radial-gradient(ellipse at 0 0,#e5eaff 0,transparent 50%),radial-gradient(ellipse at 100% 65%,#f0ecfb 0,transparent 45%),#f4f6fb;\n}\nbody:is(.ecuss-module-ui,.ecuss-module-frame) :is(h1,h2,h3,h4){color:var(--suite-ink);line-height:1.4;letter-spacing:-.35px}\nbody:is(.ecuss-module-ui,.ecuss-module-frame) h2{font-size:18px;font-weight:650}\nbody:is(.ecuss-module-ui,.ecuss-module-frame) h3{font-size:15px;font-weight:650}\nbody:is(.ecuss-module-ui,.ecuss-module-frame) :is(.muted,.desc,.hint,.help,.note,.intro,.file-size,.drop-hint){color:var(--suite-muted)}\nbody.ecuss-module-ui #ecuss-module-navigation{background:#f2f5ffde;border-bottom:1px solid #ffffffc9;backdrop-filter:blur(24px)}\nbody.ecuss-module-ui #ecuss-page-header{background:#f8faffdb;border-bottom:1px solid #dfe5f1;backdrop-filter:blur(24px);box-shadow:0 8px 28px #2a395505}\nbody.ecuss-module-ui #ecuss-page-header h1{font-size:25px;font-weight:650;color:var(--suite-ink)}\nbody.ecuss-module-ui #ecuss-page-header :is(.version,.pilot){display:inline-block;background:#edf1fc;border:1px solid #dfe6f5;border-radius:20px;color:#68799a;font-size:11px;padding:4px 10px}\nbody.ecuss-module-ui main{min-width:0}\nbody:is(.ecuss-module-ui,.ecuss-module-frame) :is(.panel,.card,.upload-card,.upload,section.method,details.method){\n background:var(--suite-surface);border:1px solid var(--suite-line);border-radius:var(--suite-radius);\n box-shadow:inset 0 1px 0 #fff,0 10px 32px #2a395508;min-width:0;\n}\nbody:is(.ecuss-module-ui,.ecuss-module-frame) :is(.card,.upload-card,.panel){padding:22px}\nbody:is(.ecuss-module-ui,.ecuss-module-frame) :is(button,select,input,textarea){font-family:inherit;font-size:13px}\nbody:is(.ecuss-module-ui,.ecuss-module-frame) button,\nbody:is(.ecuss-module-ui,.ecuss-module-frame) :is(.pick,.filelabel,.file-label,a.secondary,a.primary){\n min-height:38px;padding:9px 14px;border:1px solid #d8e1f3;border-radius:11px;background:#f0f3fd;\n color:#4261a1;font-weight:600;line-height:1.4;box-shadow:none;transition:background-color .15s,border-color .15s;\n}\nbody:is(.ecuss-module-ui,.ecuss-module-frame) button:hover:not(:disabled),\nbody:is(.ecuss-module-ui,.ecuss-module-frame) :is(.pick,.filelabel,.file-label,a.secondary):hover{background:#e7edfc;border-color:#bdcbed}\nbody:is(.ecuss-module-ui,.ecuss-module-frame) :is(button.primary,a.primary,#calculate){background:#4260da;color:#fff;border-color:#4260da;box-shadow:0 4px 12px #4260da18}\nbody:is(.ecuss-module-ui,.ecuss-module-frame) :is(button.primary,a.primary,#calculate):hover:not(:disabled){background:#354ec0;border-color:#354ec0;color:#fff}\nbody:is(.ecuss-module-ui,.ecuss-module-frame) button:disabled{opacity:.48;cursor:not-allowed;box-shadow:none}\nbody:is(.ecuss-module-ui,.ecuss-module-frame) button[aria-pressed=true]{background:#e8eeff;border-color:#b8c8f2;color:#354eb8}\nbody:is(.ecuss-module-ui,.ecuss-module-frame) :is(input:not([type=file]):not([type=checkbox]):not([type=radio]):not([type=range]),select,textarea){\n min-height:36px;max-width:100%;padding:8px 10px;border:1px solid #d7dfed;border-radius:10px;background:#fff;color:var(--suite-ink);box-shadow:inset 0 1px 2px #25314803;\n}\nbody:is(.ecuss-module-ui,.ecuss-module-frame) :is(input[type=checkbox],input[type=radio]){accent-color:var(--suite-accent)}\nbody:is(.ecuss-module-ui,.ecuss-module-frame) :is(button,input,select,textarea,summary,a):focus-visible{outline:3px solid #4260da;outline-offset:3px}\nbody:is(.ecuss-module-ui,.ecuss-module-frame) :is(.file-box,.file-row,.drop,.dropzone){border-color:#cbd7ed;background:#f8faff;border-radius:16px}\nbody:is(.ecuss-module-ui,.ecuss-module-frame) :is(.file-prompt,.step,.tag,.number,.selection-state){color:#5b6f9e}\nbody:is(.ecuss-module-ui,.ecuss-module-frame) :is(.tag,.number,.selection-state){background:#edf2fc;border-color:#dce5f6;border-radius:9px}\nbody:is(.ecuss-module-ui,.ecuss-module-frame) :is(.file-box[data-selected=true],.card.selected,.drop.selected,.drop.has-file,.dropzone.selected,.dropzone.has-file,.upload-card.ready,#dropzone[data-selected=true]){border-color:#4260da;background:#eff3ff;box-shadow:0 0 0 1px #4260da26}\nbody:is(.ecuss-module-ui,.ecuss-module-frame) :is(.dragover,.drag-over,.drag){outline:3px solid #4260da;outline-offset:2px;background:#eaf0ff}\nbody:is(.ecuss-module-ui,.ecuss-module-frame) :is(.clear,.clear-file){min-height:28px;padding:5px 9px;font-size:12px;border-radius:8px}\nbody:is(.ecuss-module-ui,.ecuss-module-frame) details{background:#ffffffad;border:1px solid #dfe5f1;border-radius:15px;padding:14px 17px;margin-top:14px;color:var(--suite-ink)}\nbody:is(.ecuss-module-ui,.ecuss-module-frame) summary{cursor:pointer;color:#4c608c;font-size:13px;font-weight:600;line-height:1.6}\nbody:is(.ecuss-module-ui,.ecuss-module-frame) summary::marker{color:#7c8fbc}\nbody:is(.ecuss-module-ui,.ecuss-module-frame) details[open]>summary{margin-bottom:12px}\nbody:is(.ecuss-module-ui,.ecuss-module-frame) :is(th,.table-head){background:#edf2fc;color:#40567c;border-color:#dce4f2;font-weight:600}\nbody:is(.ecuss-module-ui,.ecuss-module-frame) :is(table,.tablewrap,.scroll){border-color:#dfe5f1}\nbody:is(.ecuss-module-ui,.ecuss-module-frame) :is(.actions,.toolbar,.resulthead,.result-head){gap:12px}\nbody:is(.ecuss-module-ui,.ecuss-module-frame) :is(dialog,.dialog){border:1px solid #dfe5f1;border-radius:20px;background:#f8faff;box-shadow:0 28px 90px #25314835;color:var(--suite-ink)}\nbody:is(.ecuss-module-ui,.ecuss-module-frame) :is(.dialoghead,.dialog-head){background:#f0f4ff;border-color:#dfe5f1}\nbody.ecuss-module-ui[data-suite-module=stock-status-amovina]>section:not(#ecuss-work-access){max-width:1440px;margin:24px auto 0;padding:22px;border:1px solid #dfe5f1;border-radius:20px;background:#ffffffed;box-shadow:0 10px 32px #2a395508}\nbody.ecuss-module-ui[data-suite-module=stock-status-amovina] .notice{background:#edf2fc;border-color:#b8c8ed;border-radius:14px;color:#40567c;padding:16px 18px}\nbody.ecuss-module-ui[data-suite-module=stock-status-amogreen-vina] :is(.local,.tag.required){background:#edf2fc;color:#4c6497;border-color:#dce5f6}\nbody.ecuss-module-ui[data-suite-module=stock-status-amogreen-vina] .inactive{background:#edf0f6;border-style:dashed;box-shadow:none}\nbody.ecuss-module-ui[data-suite-module=monthly-report-consolidation] .shell{max-width:1800px;margin:auto;grid-template-columns:220px minmax(0,1fr)}\nbody.ecuss-module-ui[data-suite-module=monthly-report-consolidation] .sidebar{background:linear-gradient(150deg,#e9edfcc9,#eef2fbc4 60%,#eeebf8c0);border-color:#dce3f0;padding:28px 18px;backdrop-filter:blur(24px)}\nbody.ecuss-module-ui[data-suite-module=monthly-report-consolidation] .navlink{color:#647497;border:1px solid transparent;border-radius:12px;font-size:13px}\nbody.ecuss-module-ui[data-suite-module=monthly-report-consolidation] .navlink.active{background:#ffffffeb;color:#36539d;border-color:#fff;box-shadow:0 5px 18px #334c7808}\nbody.ecuss-module-ui[data-suite-module=monthly-report-consolidation] .main{margin:0;max-width:none;padding:28px 30px 48px}\nbody.ecuss-module-ui[data-suite-module=monthly-report-consolidation] .side-note{color:#72819c;font-size:11px;border-top:1px solid #dce3f0;padding-top:18px}\nbody.ecuss-module-ui[data-suite-module=monthly-report-consolidation] :is(.period,.rule-box,.rate-card){background:#f4f7fd;border-color:#dfe5f1;border-radius:13px}\nbody.ecuss-module-ui[data-suite-module=psr-rvc-lvc-calculator] #frames{max-width:1488px;padding:0;margin:0 auto}\nbody.ecuss-module-ui[data-suite-module=psr-rvc-lvc-calculator] #frames iframe{background:transparent}\nbody.ecuss-module-frame{max-width:none;margin:0;padding:24px;min-width:0}\nbody.ecuss-module-frame>section:not(.notice){padding:22px;margin-bottom:18px;background:#ffffffed;border:1px solid #dfe5f1;border-radius:20px;box-shadow:0 10px 32px #2a395508}\nbody.ecuss-module-frame>h1{font-size:22px;margin:0 0 12px}\nbody.ecuss-module-frame :is(.notice,#suite-user-psr-scope){background:#edf2fc;border-color:#d9e3f6;border-radius:13px;color:#496187;padding:14px 17px;font-size:13px}\nbody.ecuss-module-frame :is(table input,table select,table button){font-size:12px;min-height:30px;padding:6px 8px;border-radius:8px}\nbody.ecuss-module-frame #excelPanel{background:#f7f9ff;border-color:#cbd7ed;border-radius:14px}\n@media(max-width:900px){body.ecuss-module-ui[data-suite-module=monthly-report-consolidation] .shell{grid-template-columns:180px minmax(0,1fr)}body.ecuss-module-ui[data-suite-module=monthly-report-consolidation] .main{padding:22px 18px 36px}}\n@media(max-width:760px){body.ecuss-module-ui[data-suite-module=monthly-report-consolidation] .shell{display:block}body.ecuss-module-ui[data-suite-module=monthly-report-consolidation] .sidebar{padding:15px 18px}body.ecuss-module-ui[data-suite-module=monthly-report-consolidation] .side-note{display:none}body.ecuss-module-frame{padding:16px}body:is(.ecuss-module-ui,.ecuss-module-frame) :is(.card,.upload-card,.panel){padding:17px}body.ecuss-module-ui[data-suite-module=stock-status-amovina]>section:not(#ecuss-work-access){margin:18px 16px 0}body.ecuss-module-ui #ecuss-page-header h1{font-size:20px}}\n@media(prefers-reduced-motion:reduce){body:is(.ecuss-module-ui,.ecuss-module-frame) *{transition:none!important}}\n@media(forced-colors:active){body:is(.ecuss-module-ui,.ecuss-module-frame)[data-suite-module],body:is(.ecuss-module-ui,.ecuss-module-frame) :is(.panel,.card,.upload,.drop,.file-box,details,.notice){background:Canvas;color:CanvasText;border-color:CanvasText;box-shadow:none}body:is(.ecuss-module-ui,.ecuss-module-frame) :is(button,.primary){background:ButtonFace;color:ButtonText;border-color:ButtonText}}\n@media print{body:is(.ecuss-module-ui,.ecuss-module-frame)[data-suite-module]{background:white}body:is(.ecuss-module-ui,.ecuss-module-frame) :is(.panel,.card,.upload,section){box-shadow:none;backdrop-filter:none}}\n";doc.head.append(sheet);
      };
      document.querySelectorAll('#frames iframe').forEach(frame=>{applyFrameTheme(frame);frame.addEventListener('load',()=>applyFrameTheme(frame));});
    }
    const category=document.createElement('span');category.id='ecuss-category-label';nav.querySelector('.ecuss-nav-inner').append(category);
    const categories={ko:{reporting:'월간리포트 취합',validation:'Balance Sheet 검증',translation:'문서 번역',inventory:'재고 취합',tools:'업무 도구'},en:{reporting:'Monthly reporting',validation:'Balance Sheet validation',translation:'Document translation',inventory:'Stock consolidation',tools:'Work tools'},vi:{reporting:'Báo cáo tháng',validation:'Kiểm tra Balance Sheet',translation:'Dịch tài liệu',inventory:'Tổng hợp tồn kho',tools:'Công cụ công việc'}};
    function labels(){const lang=document.documentElement.lang||'ko',name=module.name[lang]||module.name.ko;const h=header.querySelector('h1');if(h&&h.textContent!==name)h.textContent=name;document.title=name;category.textContent=(categories[lang]||categories.ko)[module.category]||'';}
    function measure(){const n=nav.getBoundingClientRect().height,h=header.getBoundingClientRect().height;document.body.style.setProperty('--suite-nav-height',n+'px');document.body.style.setProperty('--suite-header-bottom',(n+h)+'px');}
    if(id==='balance-sheet-validation'){const filename=document.getElementById('filename'),zone=document.getElementById('dropzone');const selected=()=>{zone.dataset.selected=String(!!window.EcussModuleState?.hasWork?.());};selected();new MutationObserver(selected).observe(filename,{childList:true,subtree:true,characterData:true});}
    labels();measure();new ResizeObserver(measure).observe(header);new ResizeObserver(measure).observe(nav);
    new MutationObserver(labels).observe(document.documentElement,{attributes:true,attributeFilter:['lang']});
    // Modules can render their own title again when language or result state changes.
    new MutationObserver(labels).observe(header.querySelector('h1'),{childList:true,subtree:true,characterData:true});
  },{once:true});
})();

/* User-only presentation. Pinned business engines, inputs and output rules are untouched. */
(() => {
 'use strict';
 if(window.__ECUSS_SUITE__?.profile!=='user')return;
 const words={
  ko:{vn:'등록된 기준으로 PSR을 검토합니다. 지원하지 않는 조건은 판정을 보류합니다. 최종 원산지 충족 여부는 근거와 증빙을 확인하세요.',kr:'KR 비율 계산을 제공합니다. 품목별 충족·불충족 판정과 증빙 심사는 제공하지 않습니다.'},
  en:{vn:'Review PSR using the registered criteria. Unsupported conditions remain pending. Check the source rules and evidence before confirming origin qualification.',kr:'KR ratio calculation is available. Product-specific pass/fail decisions and evidence verification are not provided.'},
  vi:{vn:'Kiểm tra PSR theo tiêu chí đã đăng ký. Điều kiện chưa được hỗ trợ vẫn chưa kết luận. Kiểm tra quy tắc gốc và chứng từ trước khi xác nhận xuất xứ.',kr:'Cung cấp tính tỷ lệ KR. Không kết luận đạt/không đạt theo sản phẩm và không thẩm định chứng từ.'}
 };
 const hide=el=>{if(el){el.dataset.suiteManagement='';el.style.setProperty('display','none','important');}};
 function psr(doc,region,lang){
  if(!doc?.body||!doc.querySelector('section.notice'))return;
  hide(doc.querySelector('body>h1'));hide(doc.querySelector('section.notice'));
  if(region==='VN'){
   doc.querySelectorAll('body>p').forEach(hide);
   hide(doc.querySelector('body>section:last-of-type > p:not([id])'));
  }
  let notice=doc.getElementById('suite-user-psr-scope');
  if(!notice){notice=doc.createElement('section');notice.id='suite-user-psr-scope';notice.className='notice';doc.querySelector('section.notice').after(notice);}
  const text=(words[lang]||words.ko)[region.toLowerCase()];if(notice.textContent!==text)notice.textContent=text;
 }
 window.EcussUserPresentation={psr};
 window.addEventListener('DOMContentLoaded',()=>{
  const id=window.__ECUSS_DESKTOP_CONTEXT__?.moduleId;
  const sections=[...document.querySelectorAll('section')];
  if(id==='stock-status-amovina'){
   for(const section of sections){
    const heading=section.querySelector(':scope>h2,:scope>b')?.textContent||'';
    if(/^검토본 (17|19) 수정 사항$/.test(heading))section.remove();
    if(heading.startsWith('REVIEW18')||heading==='이번 검토본 보완 내용')section.remove();
   }
   // Remove only the duplicate introduction; retain all lower disclosure guidance.
   const intro=document.querySelector('body>main>.notice');
   if(intro?.textContent.trim().startsWith('창고 최초 취합:')&&!intro.querySelector('input,button,select,textarea'))intro.remove();
   for(const summary of document.querySelectorAll('summary')){
    if(summary.textContent==='현재 적용 지침')summary.textContent='담당자별 반영 범위';
    if(summary.textContent==='WIP 적용 지침')summary.textContent='WIP 반영 범위와 주의사항';
    if(summary.textContent==='사용 방법과 테스트 범위'){
     summary.textContent='사용 방법';
     const paragraphs=summary.parentElement.querySelectorAll('p');
     paragraphs[0].textContent='파일은 이 PC에서 처리합니다. 원본을 덮어쓰지 않고 결과 파일을 따로 저장합니다.';
     for(const p of paragraphs)if(p.textContent.startsWith('제공된 양식의 .xlsx'))p.textContent='제공된 양식의 .xlsx, 파일별 최대 80MB. 결과 Excel을 열어 전체 재계산 후 수량과 서식을 확인하세요. JSZip 3.10.1 (MIT).';
    }
   }
   for(const p of document.querySelectorAll('p')){if(p.textContent.includes('현재 담당자별 누적/1:1 교체 규칙은 향후 업무 변경에 맞춰 수정할 수 있습니다.'))p.textContent=p.textContent.replace('현재 담당자별 누적/1:1 교체 규칙은 향후 업무 변경에 맞춰 수정할 수 있습니다.','');}
   document.querySelector('footer')?.remove();
  }
  if(id==='stock-status-amogreen-vina'){
   for(const summary of document.querySelectorAll('summary')){
    if(summary.textContent==='검증 기록 및 확인 범위')summary.parentElement.remove();
    if(summary.textContent==='적용 규칙과 검토 방법'){
     summary.textContent='사용 방법과 확인사항';
     const rules=summary.parentElement.querySelector('.rules');
     rules.innerHTML=rules.innerHTML.replace('외주 입출고 두 시트는 지침 확정 후 활성화합니다.','외주 입출고 두 시트는 처리 대상에서 제외하며 기존 내용을 보존합니다.').replace('아모그린비나 전용 V1.0.5 확정본입니다. ','').replace(' 전체 지침과 변경 이력은 전용 저장소에서 관리합니다.','');
    }
   }
   for(const el of document.querySelectorAll('span,p,small,strong,b'))if(el.childElementCount===0&&el.textContent==='지침 보류')el.textContent='처리 대상 아님';
   for(const p of document.querySelectorAll('p.note'))if(p.textContent.includes('지침 보류 중인'))p.textContent=p.textContent.replace('지침 보류 중인','처리 대상에서 제외된');
   const title=document.querySelector('#results .result-head h2');if(title)title.textContent='결과 파일이 준비되었습니다';
   document.querySelector('footer')?.remove();
  }
  if(id==='monthly-report-consolidation'){
   const guide=document.getElementById('guide');
   if(guide){
    const walker=document.createTreeWalker(guide,NodeFilter.SHOW_TEXT);let node;
    while((node=walker.nextNode()))node.nodeValue=node.nodeValue.replace('이 검토본은 제공된 6개 시트 양식을 대상으로 합니다.','제공된 6개 시트 양식을 사용하세요.').replace('Glass Workspace 참고: TRADE-OPERATIONS-SUITE / docs/MODULE_UI_STANDARD_KO.md · ','');
   }
  }
  if(id==='customs-inspection-cost-comparison')hide(document.querySelector('header>small'));
  if(id==='balance-ecuss')hide(document.getElementById('ecuss-provenance'));
 },{once:true});
})();
