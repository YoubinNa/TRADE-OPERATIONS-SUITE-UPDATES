function workL(ko,en,vi){return inLanguage(ko,en,vi);}
function reviewPanel(id,body){
  const target=widgets[id].target;
  return `<article class="panel widget-${id}${id==='imex'?' export-panel':''}" aria-labelledby="title-${id}" data-widget="${id}"${target?' data-panel-target="'+target+'"':''}>${body}</article>`;
}

function stockItemName(group){
  if(group.other)return workL('그 외','Other','Còn lại');
  return group.item||workL('ITEM 미기재','Unspecified item','Chưa ghi ITEM');
}

function inventoryCompanyRow(co,summary){
  const {excess,short,items}=summary;
  const top=items.slice(0,3);
  const topSum=top.reduce((sum,item)=>sum+item.value,0);
  const amount=value=>fmt(value,{maximumFractionDigits:0});
  const signed=(value,sign)=>value===0?'0':sign+(value<.5?'&lt;1':amount(value));
  const describe=item=>stockItemName(item)+' · '+tr('과잉')+' '+amount(item.excess)+' USD · '+tr('부족')+' '+amount(item.short)+' USD';
  const band=top.map((item,i)=>{
    const share=topSum?item.value/topSum:0;
    return '<span class="variance-segment variance-rank-'+(i+1)+'" style="flex-grow:'+share+'" title="'+escapeText(describe(item)+' · '+fmt(share,{style:'percent',maximumFractionDigits:1}))+'"></span>';
  }).join('');
  const rows=top.map((item,i)=>
    '<span class="variance-row"><span class="variance-item"><i class="variance-marker variance-rank-'+(i+1)+'" aria-hidden="true"></i><b title="'+escapeText(stockItemName(item))+'">'+escapeText(stockItemName(item))+'</b></span>'+
    '<span class="'+(item.excess?'variance-plus':'variance-zero')+'">'+signed(item.excess,'+')+'</span>'+
    '<span class="'+(item.short?'variance-minus':'variance-zero')+'">'+signed(item.short,'−')+'</span></span>').join('');
  const company=companies[co],totalLabel=summary.missing?workL('확인된 합계','Verified total','Tổng đã xác nhận'):tr('합계');
  const heading='<span class="variance-heading"><b>'+company+'</b><span class="variance-total"><small>'+totalLabel+'</small><strong>'+amount(excess+short)+'</strong><small>USD</small></span></span>';
  const title=workL('전체 품목의 과잉 금액과 부족 금액 절댓값 합계','Surplus plus absolute shortage across all items','Tổng giá trị thừa và trị tuyệt đối của giá trị thiếu cho tất cả mặt hàng');
  const barTip=workL('상위 3개 품목 내 비중','Share among the top three items','Tỷ trọng trong ba mặt hàng đứng đầu');
  const details=rows?'<span class="variance-band" aria-hidden="true" title="'+barTip+'">'+band+'</span><span class="variance-list"><span class="variance-labels"><small>ITEM</small><small>'+tr('과잉')+'</small><small>'+tr('부족')+'</small></span>'+rows+'</span>':'<span class="variance-empty">'+workL('표시할 과부족 품목 없음','No items with variance','Không có mặt hàng thừa thiếu')+'</span>';
  return '<button type="button" class="variance-company" data-stock-company="'+co+'" data-open="stock-dashboard" aria-label="'+escapeText(company+' · '+totalLabel+' '+amount(excess+short)+' USD. '+top.map(describe).join('. '))+'"><span title="'+title+'">'+heading+'</span>'+details+'</button>';
}

function workInventoryPanel(){
  const title=panelHead('inventory','');
  const companiesHtml=Object.entries(live.stock).map(([co,rec])=>
    '<div class="variance-group">'+(rec.data?inventoryCompanyRow(co,rec.data)+staleNote(rec):companyMessage(co,rec))+'</div>').join('');
  return reviewPanel('inventory',title+'<div class="variance-companies">'+companiesHtml+'</div>');
}

function logisticsPeriod(year,months){
  if(!months.length)return String(year);
  const a=months[0].month,b=months.at(-1).month;
  if(a===b)return workL(`${year}년 ${a}월`,`${monthShort(a)} ${year}`,`Tháng ${a}/${year}`);
  return workL(`${year}년 ${a}–${b}월`,`${monthShort(a)}–${monthShort(b)} ${year}`,`Tháng ${a}–${b}/${year}`);
}

function freightChart(months, costName, caseName){
  const byMonth=new Map(months.map(m=>[m.month,m]));
  const costs=months.map(m=>m.costKrw);
  function axisBound(value){
    if(value<=0)return 0;
    const magnitude=10**Math.floor(Math.log10(value));
    return Math.ceil(value/magnitude)*magnitude;
  }
  const low=-axisBound(-Math.min(0,...costs)) || 0,high=axisBound(Math.max(0,...costs)) || (low===0?1:0);
  const casesMax=axisBound(Math.max(0,...months.map(m=>m.cases))) || 1;
  const width=600,top=19,bottom=92;
  const x=month=>(month-.5)*width/12;
  const y=(n,min,max)=>bottom-(n-min)/(max-min)*(bottom-top);
  const barWidth=24;
  const bars=months.map(m=>{
    const h=y(m.cases,0,casesMax);
    return '<rect class="case-bar" x="'+(x(m.month)-barWidth/2)+'" y="'+h+'" width="'+barWidth+'" height="'+(bottom-h)+'" rx="1.8"/>';
  }).join('');
  const path=months.map(m=>(byMonth.has(m.month-1)?'L':'M')+x(m.month)+','+y(m.costKrw,low,high)).join(' ');
  const dots=months.map(m=>'<circle class="cost-dot" cx="'+x(m.month)+'" cy="'+y(m.costKrw,low,high)+'" r="2.8"/>').join('');
  const grid=[top,(top+bottom)/2,bottom].map(h=>'<line x1="0" x2="'+width+'" y1="'+h+'" y2="'+h+'"/>').join('');
  const svg='<svg viewBox="0 0 '+width+' 100" preserveAspectRatio="none" aria-hidden="true"><g class="combo-grid">'+grid+'</g>'+bars+'<path class="cost-line" d="'+path+'" fill="none" stroke-width="2.25" vector-effect="non-scaling-stroke"/>'+dots+'</svg>';
  const millions=n=>fmt(n/1e6,{maximumFractionDigits:1});
  const axis=(a,b)=>'<div class="freight-axis" aria-hidden="true"><span>'+a+'</span><span>'+b+'</span></div>';
  const lastMonth=months.at(-1)?.month||1;
  const calendar=Array.from({length:12},(_,index)=>{
    const month=index+1,m=byMonth.get(month),active=month===lastMonth;
    const description=m?costName+' '+fmt(m.costKrw)+' KRW · '+caseName+' '+fmt(m.cases):workL('자료 없음','No data','Chưa có dữ liệu');
    const numbers=m?'<b class="freight-point-value" style="top:'+y(m.costKrw,low,high)+'%">'+millions(m.costKrw)+'</b><b class="freight-bar-value">'+fmt(m.cases)+'</b>':'';
    return '<button type="button" class="freight-month" data-freight-month="'+month+'" data-available="'+!!m+'" aria-label="'+escapeText(monthShort(month)+' · '+description)+'" aria-pressed="'+active+'" tabindex="'+(active?'0':'-1')+'"><span class="freight-values" aria-hidden="true">'+numbers+'</span><span class="freight-month-label" aria-hidden="true"><span>'+monthShort(month)+'</span><i>'+month+'</i></span></button>';
  }).join('');
  return '<div class="freight-chart" data-pinned-month="'+lastMonth+'">'+axis(millions(high),millions(low))+'<div class="freight-plot">'+svg+'<div class="freight-months" role="group" aria-label="'+tr('월별 물류비 내역')+'">'+calendar+'</div></div>'+axis(fmt(casesMax),'0')+'</div>';
}

function freightMetric(month,months){
  const row=months.find(m=>m.month===month),previous=months.find(m=>m.month===month-1);
  const delta=row&&previous?.costKrw>0?(row.costKrw/previous.costKrw-1)*100:null;
  const diff=delta===null?'':(delta>=0?'+':'')+fmt(delta,{minimumFractionDigits:1,maximumFractionDigits:1})+'%';
  const change=diff?workL('전월 대비 '+diff,diff+' vs. prior month',diff+' so với tháng trước'):'';
  const value=row?fmt(row.costKrw):'—',count=row?fmt(row.cases):'—';
  const countUnit=state.lang==='ko'&&row?'<small>건</small>':'';
  return '<div><span>'+monthShort(month)+' '+workL('물류비','Cost','Chi phí')+'</span><strong><span data-freight-amount>'+value+'</span> <small>KRW</small></strong></div><div class="freight-cases"><span>'+workL('처리 건수','Shipments','Số lô')+'</span><b><span data-freight-cases>'+count+'</span>'+countUnit+'</b></div><span class="freight-change">'+(row?change:workL('자료 없음','No data','Chưa có dữ liệu'))+'</span>';
}

function workLogisticsPanel(){
  const {year,months}=live.cost.data||{year:'',months:[]},last=months.at(-1);
  const title=panelHead('logistics',logisticsPeriod(year,months),infoButton('logistics',tr('월별 물류비 내역')));
  if(!live.cost.data)return reviewPanel('logistics',title+panelMessage(live.cost));
  const costName=workL('물류비','Cost','Chi phí'),caseName=workL('처리 건수','Shipments','Số lô');
  const metric='<div class="freight-metric">'+freightMetric(last?.month||1,months)+'</div>';
  const unit=workL('백만원','M KRW','triệu KRW');
  const keys='<div class="combo-keys"><span><i class="line-key"></i>'+costName+' · '+unit+'</span><span><i class="bar-key"></i>'+caseName+'</span></div>';
  return reviewPanel('logistics',title+staleNote(live.cost)+metric+keys+freightChart(months,costName,caseName));
}

function showFreightMonth(button,pin=false){
  const chart=button.closest('.freight-chart'),month=button.dataset.freightMonth;
  if(pin)chart.dataset.pinnedMonth=month;
  const selected=chart.querySelector('[aria-pressed="true"]');
  if(selected===button)return;
  if(selected){selected.setAttribute('aria-pressed','false');selected.tabIndex=-1;}
  button.setAttribute('aria-pressed','true');button.tabIndex=0;
  chart.closest('.widget-logistics').querySelector('.freight-metric').innerHTML=freightMetric(Number(month),live.cost.data.months);
}

document.addEventListener('pointerover',e=>{
  const month=e.target.closest('[data-freight-month]');
  if(month&&e.pointerType!=='touch')showFreightMonth(month);
});
document.addEventListener('focusin',e=>{
  const month=e.target.closest('[data-freight-month]');
  if(month)showFreightMonth(month);
});
document.addEventListener('click',e=>{
  const month=e.target.closest('[data-freight-month]');
  if(month)showFreightMonth(month,true);
});
function restoreFreightMonth(e){
  const chart=e.target.closest('.freight-chart');
  if(!chart||chart.contains(e.relatedTarget))return;
  const focused=e.type==='pointerout'&&chart.contains(document.activeElement)?document.activeElement:null;
  const month=focused?.closest('[data-freight-month]')||chart.querySelector('[data-freight-month="'+chart.dataset.pinnedMonth+'"]');
  showFreightMonth(month);
}
document.addEventListener('pointerout',restoreFreightMonth);
document.addEventListener('focusout',restoreFreightMonth);
document.addEventListener('keydown',e=>{
  const button=e.target.closest('[data-freight-month]');
  if(!button)return;
  const month=Number(button.dataset.freightMonth);
  const next={Home:1,End:12,ArrowLeft:Math.max(1,month-1),ArrowRight:Math.min(12,month+1)}[e.key];
  if(!next)return;
  e.preventDefault();
  button.closest('.freight-chart').querySelector('[data-freight-month="'+next+'"]').focus({preventScroll:true});
});
