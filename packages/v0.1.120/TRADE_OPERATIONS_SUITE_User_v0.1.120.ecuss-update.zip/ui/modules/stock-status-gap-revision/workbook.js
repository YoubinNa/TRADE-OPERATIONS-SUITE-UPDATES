/* Surgical OOXML edits: all ZIP entries except the target worksheet retain their bytes. */
(function (root) {
  'use strict';
  const NS = 'http://schemas.openxmlformats.org/spreadsheetml/2006/main';
  const REL = 'http://schemas.openxmlformats.org/officeDocument/2006/relationships';
  const MAX_FILE = 50000000, MAX_EXPANDED = 500000000;
  function parseXml(xml) {
    const doc = new DOMParser().parseFromString(xml, 'application/xml');
    if (doc.getElementsByTagName('parsererror').length) throw new Error('Excel 내부 XML을 읽을 수 없습니다.');
    return doc;
  }
  function pathOf(target) {
    const parts = (target.startsWith('/') ? target.slice(1) : 'xl/' + target).split('/'), out = [];
    for (const p of parts) {
      if (p === '..') { if (!out.length) throw new Error('잘못된 시트 경로입니다.'); out.pop(); }
      else if (p && p !== '.') out.push(p);
    }
    return out.join('/');
  }
  async function open(bytes, name) {
    if (!/\.xlsx$/i.test(name)) throw new Error('.xlsx 파일을 선택하세요.');
    if (bytes.byteLength > MAX_FILE) throw new Error('50MB 이하의 파일을 선택하세요.');
    const zip = await root.JSZip.loadAsync(bytes);
    // JSZip has already parsed central-directory sizes, before any entry is expanded.
    let expanded = 0;
    for (const entry of Object.values(zip.files)) expanded += entry._data?.uncompressedSize || 0;
    if (expanded > MAX_EXPANDED) throw new Error('압축 해제 후 크기가 너무 큰 Excel 파일입니다.');
    if (Object.keys(zip.files).some(p => p.startsWith('_xmlsignatures/'))) throw new Error('디지털 서명된 Excel 파일은 지원하지 않습니다.');
    const read = async path => { const f = zip.file(path); if (!f) throw new Error('Excel 구성 파일이 없습니다: ' + path); return f.async('string'); };
    const workbookXml = parseXml(await read('xl/workbook.xml'));
    const sheet = Array.from(workbookXml.getElementsByTagNameNS(NS, 'sheet')).find(s => s.getAttribute('name') === root.SummaryLiquidation.SHEET);
    if (!sheet) throw new Error('Summary Liquidation 시트를 찾을 수 없습니다.');
    const id = sheet.getAttributeNS(REL, 'id');
    const rels = parseXml(await read('xl/_rels/workbook.xml.rels'));
    const rel = Array.from(rels.documentElement.children).find(e => e.getAttribute('Id') === id);
    if (!rel || rel.getAttribute('TargetMode') === 'External') throw new Error('시트 연결 정보를 확인할 수 없습니다.');
    const sheetPath = pathOf(rel.getAttribute('Target'));
    const sheetXml = root.LiquidationViewSettings.patchXml(await read(sheetPath)), doc = parseXml(sheetXml);
    if (doc.getElementsByTagNameNS(NS, 'sheetProtection').length) throw new Error('보호된 시트입니다. Excel에서 시트 보호를 해제한 사본을 사용하세요.');
    if (doc.getElementsByTagNameNS(NS, 'tableParts').length) throw new Error('Excel 표(Table)가 있는 양식은 아직 지원하지 않습니다.');
    const wb = root.XLSX.read(bytes, { type: 'array', cellNF: true, cellText: true, cellFormula: true, sheetStubs: true });
    root.LiquidationViewSettings.initializeWorkbook(wb,root.SummaryLiquidation.SHEET);
    const analysis = root.SummaryLiquidation.analyze(wb, root.XLSX);
    // Keep the source bytes private. Every export starts from this unchanged snapshot.
    let plan = null;
    return { name, analysis,
      preparePositive: () => { if (!plan) plan = root.LiquidationDeduction.plan(wb, analysis, root.XLSX); return structuredClone(plan); },
      prepareAll: () => { if (plan?.stage!==3) plan = root.LiquidationDeduction.plan(wb, analysis, root.XLSX,{includeNegative:true,allowBlankL:true}); return structuredClone(plan); },
      export: () => plan ? exportPositive(bytes, workbookXml, rels, sheetPath, sheetXml, analysis, plan) : exportCopy(bytes, sheetPath, sheetXml, analysis, workbookXml, rels) };
  }
  function patchSheet(xml, analysis) {
    const decisions = new Map(analysis.decisions.map(d => [d.row, d.hidden]));
    const changed = new Set();
    let result = xml.replace(/<(?:[\w.-]+:)?row\b[^>]*>/g, tag => {
      const match = tag.match(/\br="(\d+)"/);
      if (!match || !decisions.has(Number(match[1]))) return tag;
      const row = Number(match[1]); changed.add(row);
      tag = tag.replace(/\s+hidden="[^"]*"/g, '');
      return decisions.get(row) ? tag.replace(/(\/?\s*>)$/, ' hidden="1"$1') : tag;
    });
    // Rows absent in XML are genuinely empty; no insertion is needed for them.
    for (const d of analysis.decisions) if (!d.hidden && !changed.has(d.row)) throw new Error('결과 행을 원본 XML에서 찾을 수 없습니다: ' + d.row);
    // Existing filter criteria must not override this new row selection on reopen.
    result = result.replace(/<(?:[\w.-]+:)?autoFilter\b[^>]*>[\s\S]*?<\/(?:[\w.-]+:)?autoFilter\s*>/g, block => {
      const opening = block.match(/^<[^>]+>/)[0];
      if (opening.endsWith('/>')) return block;
      return opening.replace(/>$/, '/>');
    });
    result = result.replace(/<(?:[\w.-]+:)?sheetPr\b[^>]*>/g, tag => tag.replace(/\s+filterMode="[^"]*"/g, ''));
    parseXml(result);
    return result;
  }
  async function revealProcessRows(zip,workbookDoc,rels){
    for(const sheet of workbookDoc.getElementsByTagNameNS(NS,'sheet')){
      if(!sheet.getAttribute('name').startsWith('Process'))continue;
      const rel=Array.from(rels.documentElement.children).find(e=>e.getAttribute('Id')===sheet.getAttributeNS(REL,'id'));
      const path=pathOf(rel.getAttribute('Target')),xml=await zip.file(path).async('string');
      zip.file(path,xml.replace(/<(?:[\w.-]+:)?row\b[^>]*>/g,tag=>tag.replace(/\s+hidden="[^"]*"/g,''))
        .replace(/<(?:[\w.-]+:)?sheetFormatPr\b[^>]*>/g,tag=>tag.replace(/\s+zeroHeight="[^"]*"/g,''))
        .replace(/<(?:[\w.-]+:)?autoFilter\b[^>]*>[\s\S]*?<\/(?:[\w.-]+:)?autoFilter\s*>/g,block=>block.match(/^<[^>]+>/)[0].replace(/>$/,'/>'))
        .replace(/<(?:[\w.-]+:)?sheetPr\b[^>]*>/g,tag=>tag.replace(/\s+filterMode="[^"]*"/g,'')));
    }
  }
  async function exportCopy(bytes, sheetPath, sheetXml, analysis, workbookDoc, rels) {
    const zip = await root.JSZip.loadAsync(bytes);
    zip.file(sheetPath, patchSheet(sheetXml, analysis));
    await revealProcessRows(zip,workbookDoc,rels);
    return zip.generateAsync({ type: 'uint8array', compression: 'DEFLATE', compressionOptions: { level: 6 } });
  }
  function escapeXml(text) { return text.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;'); }
  async function exportPositive(bytes, workbookDoc, rels, summaryPath, summaryXml, analysis, plan) {
    if(!plan.actions.length)return exportCopy(bytes,summaryPath,summaryXml,{decisions:plan.decisions},workbookDoc,rels);
    const zip=await root.JSZip.loadAsync(bytes), sheetPaths=new Map();
    for(const sheet of workbookDoc.getElementsByTagNameNS(NS,'sheet')){
      const rel=Array.from(rels.documentElement.children).find(e=>e.getAttribute('Id')===sheet.getAttributeNS(REL,'id'));
      sheetPaths.set(sheet.getAttribute('name'),pathOf(rel.getAttribute('Target')));
    }
    const styles=parseXml(await zip.file('xl/styles.xml').async('string'));
    const fills=styles.getElementsByTagNameNS(NS,'fills')[0], xfs=styles.getElementsByTagNameNS(NS,'cellXfs')[0];
    const fillIds=new Map();
    for(const color of new Set(plan.actions.map(a=>a.fill||'FFFFC000'))){
      const fillId=fills.children.length;
      const fill=styles.createElementNS(NS,'fill'), pattern=styles.createElementNS(NS,'patternFill');pattern.setAttribute('patternType','solid');
      const fg=styles.createElementNS(NS,'fgColor');fg.setAttribute('rgb',color);pattern.appendChild(fg);
      const bg=styles.createElementNS(NS,'bgColor');bg.setAttribute('indexed','64');pattern.appendChild(bg);fill.appendChild(pattern);fills.appendChild(fill);fillIds.set(color,fillId);
    }
    fills.setAttribute('count',fills.children.length);
    const styleMap=new Map();
    function highlighted(original,color){const key=original+':'+color;if(!styleMap.has(key)){const xf=xfs.children[original].cloneNode(true);xf.setAttribute('fillId',fillIds.get(color));xf.setAttribute('applyFill','1');const index=xfs.children.length;xfs.appendChild(xf);styleMap.set(key,index);}return styleMap.get(key);}
    const patches=new Map();
    function patch(sheet,ref,color,action=null){if(!patches.has(sheet))patches.set(sheet,new Map());const cells=patches.get(sheet);cells.set(ref,{color,action:action||cells.get(ref)?.action||null});}
    for(const a of plan.actions){const color=a.fill||'FFFFC000';patch(a.sheet,a.ref,color,a);patch(a.sheet,'D'+a.row,color);patch(a.sheet,'E'+a.row,color);}
    for(const m of plan.materials.filter(m=>m.status==='adjusted'))for(const col of ['F','G','AD'])patch(analysis.sheetName,col+m.row,m.fill||'FFFFC000');
    for(const [sheet,path] of sheetPaths){
      let xml=path===summaryPath?summaryXml:await zip.file(path).async('string');
      const wanted=patches.get(sheet)||new Map(),found=new Set();
      if(wanted.size){
        const doc=parseXml(xml);
        if(doc.getElementsByTagNameNS(NS,'sheetProtection').length)throw Error('보호된 공정재고 시트: '+sheet);
        // Blank L cells may have no XML cell node. Insert only the authorized action,
        // in column order, retaining the original row/column default style.
        for(const [ref,{action}]of wanted){
          if(!action?.wasBlank||doc.querySelector('c[r="'+ref+'"]'))continue;
          let inserted=false;
          xml=xml.replace(/<row\b[^>]*>[\s\S]*?<\/row>/g,block=>{
            if(Number(block.match(/^<row\b[^>]*\br="(\d+)"/)?.[1])!==action.row)return block;
            let original=Number(block.match(/^<row\b[^>]*\bs="(\d+)"/)?.[1]||0),col=root.XLSX.utils.decode_cell(ref).c+1;
            for(const c of doc.getElementsByTagNameNS(NS,'col'))if(+c.getAttribute('min')<=col&&+c.getAttribute('max')>=col&&c.hasAttribute('style'))original=+c.getAttribute('style');
            const cell='<c r="'+ref+'" s="'+original+'"/>';
            let placed=false;
            block=block.replace(/<c\b[^>]*?(?:\/>|>[\s\S]*?<\/c>)/g,existing=>{
              const at=existing.match(/\br="([A-Z]+\d+)"/)[1];
              if(!placed&&root.XLSX.utils.decode_cell(at).c>=col){placed=true;return cell+existing;}return existing;
            });
            inserted=true;return placed?block:block.replace('</row>',cell+'</row>');
          });
          if(!inserted)throw Error('빈 셀을 추가할 공정 행이 없습니다: '+sheet+'!'+ref);
        }
      }
      xml=xml.replace(/<c\b[^>]*?(?:\/>|>[\s\S]*?<\/c>)/g,block=>{
        const ref=block.match(/\br="([A-Z]+\d+)"/)?.[1];
        if(wanted.has(ref)){
          found.add(ref);const {action,color}=wanted.get(ref);
          if(action&&/<f\b[^>]*\bt="shared"/.test(block))throw Error('공유 수식 K/L 셀은 별도 검토가 필요합니다: '+sheet+'!'+ref);
          let tag=block.match(/^<c\b[^>]*>/)[0];const old=Number(tag.match(/\bs="(\d+)"/)?.[1]||0);
          tag=tag.replace(/\s+s="[^"]*"/,'').replace(/\/?\s*>$/,' s="'+highlighted(old,color)+'">');
          if(action){tag=tag.replace(/\s+t="[^"]*"/,'');block=tag+'<f>'+escapeXml(action.formula)+'</f><v>'+action.after+'</v></c>';}
          else {const body=block.endsWith('/>')?'':block.slice(block.indexOf('>')+1,-4);block=tag+body+'</c>';}
        }
        // Never publish stale calculated results. Excel rebuilds all formula caches
        // on open; Suite's native adapter can recalculate before handing off the file.
        if(plan.actions.length&&/<f\b/.test(block))block=block.replace(/<v(?:\s[^>]*)?>[\s\S]*?<\/v>/g,'').replace(/<v\s*\/>/g,'');
        return block;
      });
      for(const ref of wanted.keys())if(!found.has(ref))throw Error('원본 셀 누락: '+sheet+'!'+ref);
      if(path===summaryPath)xml=patchSheet(xml,{decisions:plan.decisions});
      zip.file(path,xml);
    }
    await revealProcessRows(zip,workbookDoc,rels);
    xfs.setAttribute('count',xfs.children.length);
    zip.file('xl/styles.xml',new XMLSerializer().serializeToString(styles));
    let book=await zip.file('xl/workbook.xml').async('string');
    const calc='<calcPr calcMode="auto" fullCalcOnLoad="1" forceFullCalc="1"/>';
    book=/<calcPr\b/.test(book)?book.replace(/<calcPr\b[^>]*(?:\/>|>[\s\S]*?<\/calcPr>)/,calc):book.replace('</workbook>',calc+'</workbook>');
    zip.file('xl/workbook.xml',book);
    let output=await zip.generateAsync({type:'uint8array',compression:'DEFLATE',compressionOptions:{level:6}});
    if(root.SummaryLiquidationHost?.recalculateFile){
      const calculated=await root.SummaryLiquidationHost.recalculateFile({bytes:output,plan:structuredClone(plan)});
      output=await mergeCalculationCaches(output,calculated);
    }
    return output;
  }
  async function mergeCalculationCaches(originalBytes,calculatedBytes){
    // Native Excel may normalize formula literals and unrelated metadata on SaveAs.
    // Import only its calculated cell results into the surgically edited archive.
    const target=await root.JSZip.loadAsync(originalBytes),calculated=await root.JSZip.loadAsync(calculatedBytes);
    for(const path of Object.keys(target.files).filter(p=>/^xl\/worksheets\/[^/]+\.xml$/.test(p))){
      if(!calculated.file(path))throw Error('재계산 시트 누락: '+path);
      const values=new Map();
      const nativeXml=await calculated.file(path).async('string');
      for(const match of nativeXml.matchAll(/<c\b[^>]*?(?:\/>|>[\s\S]*?<\/c>)/g)){
        const block=match[0],ref=block.match(/\br="([A-Z]+\d+)"/)?.[1];
        values.set(ref,{v:block.match(/<v(?:\s[^>]*)?>[\s\S]*?<\/v>|<v\s*\/>/)?.[0]||'',type:block.match(/^<c\b[^>]*\bt="([^"]*)"/)?.[1]});
      }
      let xml=await target.file(path).async('string');
      xml=xml.replace(/<c\b[^>]*?(?:\/>|>[\s\S]*?<\/c>)/g,block=>{
        if(!/<f\b/.test(block))return block;
        const ref=block.match(/\br="([A-Z]+\d+)"/)?.[1],cached=values.get(ref);
        if(!cached||!cached.v)throw Error('재계산 결과 누락: '+path+'!'+ref);
        let tag=block.match(/^<c\b[^>]*>/)[0].replace(/\s+t="[^"]*"/g,'');
        if(cached.type&&cached.type!=='n')tag=tag.replace(/>$/,' t="'+cached.type+'">');
        const body=block.slice(block.indexOf('>')+1,-4).replace(/<v(?:\s[^>]*)?>[\s\S]*?<\/v>/g,'').replace(/<v\s*\/>/g,'');
        return tag+body+cached.v+'</c>';
      });
      target.file(path,xml);
    }
    if(target.file('xl/workbook.xml')){
      let xml=await target.file('xl/workbook.xml').async('string');
      const nativeBook=await calculated.file('xl/workbook.xml').async('string');
      const id=nativeBook.match(/<calcPr\b[^>]*\bcalcId="(\d+)"/)?.[1]||'0';
      const calc='<calcPr calcId="'+id+'" calcMode="auto" calcCompleted="1" calcOnSave="1" fullCalcOnLoad="0" forceFullCalc="0"/>';
      xml=/<calcPr\b/.test(xml)?xml.replace(/<calcPr\b[^>]*?(?:\/>|>[\s\S]*?<\/calcPr>)/,calc):xml.replace('</workbook>',calc+'</workbook>');
      target.file('xl/workbook.xml',xml);
    }
    if(target.file('xl/calcChain.xml')&&calculated.file('xl/calcChain.xml'))target.file('xl/calcChain.xml',await calculated.file('xl/calcChain.xml').async('uint8array'));
    return target.generateAsync({type:'uint8array',compression:'DEFLATE',compressionOptions:{level:6}});
  }
  root.LiquidationWorkbook = { open, patchSheet, mergeCalculationCaches };
})(globalThis);
