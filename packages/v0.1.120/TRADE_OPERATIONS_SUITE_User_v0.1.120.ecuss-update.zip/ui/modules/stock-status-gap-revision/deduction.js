/* Stage 2 planner. Exact decimal budgeting; never modifies the supplied workbook. */
(function(root){
 'use strict';
 function decimal(value){
  const m=String(value).match(/^([+-]?)(\d+)(?:\.(\d*))?(?:[eE]([+-]?\d+))?$/);
  if(!m)throw Error('유효하지 않은 숫자: '+value);
  let scale=(m[3]||'').length-Number(m[4]||0),n=BigInt(m[2]+(m[3]||''))*(m[1]==='-'?-1n:1n);
  if(scale<0){n*=10n**BigInt(-scale);scale=0;}return {n,scale};
 }
 function align(a,b){const scale=Math.max(a.scale,b.scale);return [a.n*10n**BigInt(scale-a.scale),b.n*10n**BigInt(scale-b.scale),scale];}
 function add(a,b){const[x,y,scale]=align(a,b);return {n:x+y,scale};}
 function sub(a,b){const[x,y,scale]=align(a,b);return {n:x-y,scale};}
 function min(a,b){const[x,y]=align(a,b);return x<y?a:b;}
 function str(a){const sign=a.n<0n?'-':'',v=(a.n<0n?-a.n:a.n).toString().padStart(a.scale+1,'0');return sign+(a.scale?v.slice(0,-a.scale)+'.'+v.slice(-a.scale):v);}
 // 12 significant digits, always rounded down. Avoid crossing zero through Excel's
 // 15-significant-digit arithmetic; the residual stays positive and negligible.
 function conservative(a){let digits=(a.n<0n?-a.n:a.n).toString().length;const drop=Math.max(0,digits-12);const unit=10n**BigInt(drop);return {n:a.n/unit*unit,scale:a.scale};}
 const number=c=>c&&c.t==='n'&&Number.isFinite(c.v);
 function terms(sheet,formula,XLSX){
  const f=(formula||'').replace(/\$/g,'');
  const m=f.match(/^\+?SUMIFS\(([A-Z]+\d+):([A-Z]+\d+),([A-Z]+\d+):([A-Z]+\d+),([A-Z]+\d+)\)(.*)$/i);
  if(!m)throw Error('지원하지 않는 공정 집계 수식: '+formula);
  const a=XLSX.utils.decode_range(m[1]+':'+m[2]),b=XLSX.utils.decode_range(m[3]+':'+m[4]);
  if(a.s.r!==a.e.r||b.s.r!==b.e.r||a.e.c-a.s.c!==b.e.c-b.s.c)throw Error('공정 집계 범위 불일치');
  const v=sheet[m[5]]?.v,refs=[];
  for(let i=0;i<=a.e.c-a.s.c;i++)if(sheet[XLSX.utils.encode_cell({r:b.s.r,c:b.s.c+i})]?.v===v)refs.push(XLSX.utils.encode_cell({r:a.s.r,c:a.s.c+i}));
  if(m[6]){if(!/^\+[A-Z]+\d+$/.test(m[6]))throw Error('공정 집계 추가항 확인 필요');refs.push(m[6].slice(1));}return refs;
 }
 function plan(wb,analysis,XLSX,options={}){
  const summary=wb.Sheets[analysis.sheetName],process=wb.SheetNames.filter(s=>s.startsWith('Process'));
  const actions=[],materials=[],seenCodes=new Set();
  for(const item of analysis.rows){
   const increasing=options.includeNegative&&item.sign==='negative';
   if(item.sign!=='positive'&&!increasing){materials.push({...item,status:'not-processed-negative-or-zero',deduction:'0',addition:'0',remainingGap:item.am});continue;}
   if(seenCodes.has(item.materialCode))throw Error('동일 자재코드의 중복 Summary 행은 별도 검토가 필요합니다: '+item.materialCode);
   seenCodes.add(item.materialCode);
   const r=item.row;
   if(summary['AM'+r]?.f!=='AL'+r+'-AB'+r||summary['AL'+r]?.f!=='SUM(AC'+r+':AK'+r+')')throw Error('갭 계산 구조가 다릅니다: '+r+'행');
   const expected="+SUMIFS('Sumarize WIP'!$J:$J,'Sumarize WIP'!$E:$E,$F"+r+")";
   if(summary['AD'+r]?.f!==expected)throw Error('AD 집계 수식 확인 필요: '+r+'행');
   const sumMatches=Object.entries(summary).filter(([ref,c])=>/^F\d+$/.test(ref)&&c.v===item.materialCode);
   if(sumMatches.length!==1)throw Error('동일 자재코드의 다른 Summary 행에 영향을 줄 수 있습니다: '+item.materialCode);
   const wip=wb.Sheets['Sumarize WIP'];
   if(!wip)throw Error('Sumarize WIP 시트가 없습니다.');
   const wipRows=Object.entries(wip).filter(([ref,c])=>/^E\d+$/.test(ref)&&c.v===item.materialCode).map(([ref])=>Number(ref.slice(1)));
   if(wipRows.length!==1)throw Error('WIP 자재코드 중복 또는 누락: '+item.materialCode);
   const wr=wipRows[0];
   if(wip['J'+wr]?.f!=='SUM(H'+wr+':I'+wr+')')throw Error('WIP 총계 수식 확인 필요');
   for(const col of ['H','I']){
    const formula=wip[col+wr]?.f||'';
    const expectedTerms=process.map(s=>'SUMIFS('+(s.includes(' ')||/[-()]/.test(s)?"'"+s+"'":s)+'!$'+col+':$'+col+','+(s.includes(' ')||/[-()]/.test(s)?"'"+s+"'":s)+"!$D:$D,'Sumarize WIP'!$E"+wr+')');
    const actual=formula.replace(/^\+/,'').split('+');
    if(actual.length!==expectedTerms.length||!expectedTerms.every(t=>actual.includes(t)))throw Error('WIP 공정 연결 수식 확인 필요: '+col+wr);
   }
   let remaining=decimal(increasing?-item.am:item.am),total=decimal(0),available=decimal(0);
   const candidates=[],locations=[];
   for(const name of process){
    const sh=wb.Sheets[name];
    const rows=Object.entries(sh).filter(([ref,c])=>/^D\d+$/.test(ref)&&c.v===item.materialCode).map(([ref])=>Number(ref.slice(1))).sort((a,b)=>a-b);
    for(const row of rows){
     const h=terms(sh,sh['H'+row]?.f,XLSX),i=terms(sh,sh['I'+row]?.f,XLSX);
     if(increasing){
      for(const col of ['K','L']){
       const ref=col+row,c=sh[ref],coefficient=h.filter(x=>x===ref).length+i.filter(x=>x===ref).length;
       if(coefficient===1)locations.push({sheet:name,row,ref,cell:c,col});
      }
      continue;
     }
     for(const col of ['K','L']){
      const ref=col+row,c=sh[ref];if(!number(c)||c.v<=0)continue;
      if(h.filter(x=>x===ref).length+i.filter(x=>x===ref).length!==1)throw Error('K/L 수량의 갭 반영 계수가 1이 아닙니다: '+name+'!'+ref);
      candidates.push({sheet:name,row,ref,cell:c});available=add(available,decimal(c.v));
     }
    }
   }
   if(increasing){
    const blank=c=>!c||c.t==='z'||(!c.f&&(c.v==null||c.v===''));
    const k=locations.filter(c=>c.col==='K');
    // A real zero counts as existing data; never overwrite text/error/formula-without-cache.
    if(k.some(c=>!blank(c.cell)&&!number(c.cell)))throw Error('K열 데이터가 숫자가 아닙니다. 확인이 필요합니다: '+item.materialCode);
    let chosen=k.find(c=>number(c.cell));
    if(!chosen){
     const l=locations.filter(c=>c.col==='L');
     chosen=l.find(c=>number(c.cell));
     if(!chosen&&options.allowBlankL!==false)chosen=l.find(c=>blank(c.cell));
     if(!chosen&&l.some(c=>!blank(c.cell)))throw Error('L열 데이터가 숫자가 아닙니다. 확인이 필요합니다: '+item.materialCode);
    }
    if(chosen){
     const c=chosen,wasBlank=blank(c.cell),before=decimal(wasBlank?0:c.cell.v),amount=conservative(remaining);
     if(amount.n>0n){
      const existing=c.cell?.f,expression=existing?'('+existing.replace(/^\+/,'')+')':str(before);
      actions.push({sheet:c.sheet,row:c.row,ref:c.ref,materialCode:item.materialCode,summaryRow:r,before:wasBlank?null:str(before),addition:str(amount),deduction:'0',after:str(add(before,amount)),formula:expression+'+'+str(amount),originalFormula:existing||null,operation:'addition',fill:'FFFFCCFF',wasBlank});
      total=amount;remaining=sub(remaining,amount);
     }
    }
    materials.push({...item,addition:str(total),deduction:'0',remainingGap:remaining.n===0n?0:-Number(str(remaining)),status:total.n>0n?'adjusted':'no-target',fill:'FFFFCCFF'});
    continue;
   }
   for(const c of candidates){
    if(remaining.n<=0n)break;
    const before=decimal(c.cell.v),full=align(before,remaining)[0]<=align(before,remaining)[1];
    const take=full?before:conservative(min(before,remaining));
    if(take.n<=0n)continue;
    const after=sub(before,take),existing=c.cell.f;
    const expression=existing?'('+existing.replace(/^\+/,'')+')':String(c.cell.v);
    const action={sheet:c.sheet,row:c.row,ref:c.ref,materialCode:item.materialCode,summaryRow:r,before:String(c.cell.v),deduction:str(take),addition:'0',after:str(after),formula:expression+'-'+str(take),originalFormula:existing||null,operation:'deduction',fill:'FFFFC000'};
    actions.push(action);total=add(total,take);remaining=sub(remaining,take);
    // Once a conservative partial deduction reaches the numerical precision guard,
    // do not consume another cell for a tiny second subtraction.
    if(!full)break;
   }
   materials.push({...item,available:str(available),deduction:str(total),addition:'0',remainingGap:Number(str(remaining)),status:total.n>0n?'adjusted':'no-stock',fill:'FFFFC000'});
  }
  const adjusted=new Set(materials.filter(m=>m.status==='adjusted').map(m=>m.row));
  const decisions=analysis.decisions.map(d=>({...d,hidden:!adjusted.has(d.row)}));
  return {schemaVersion:2,stage:options.includeNegative?3:2,allocationOrder:'sheet-order,row-ascending,K-before-L',actions,materials,decisions,adjustedMaterials:adjusted.size,initialRows:analysis.rows.map(r=>r.row),fill:'FFFFC000',allowBlankL:options.allowBlankL!==false,requiresExcelRecalculation:true};
 }
 const api={plan,decimal,add,sub,min,str,conservative,terms};root.LiquidationDeduction=api;if(typeof module!=='undefined')module.exports=api;
})(globalThis);
