/* Layout initialization, before the immutable AS/AD selection is evaluated. */
(function(root){
 'use strict';
 const ranges=[[8,29],[31,38]];
 const shouldHide=n=>ranges.some(([a,b])=>n>=a&&n<=b);
 function initializeWorkbook(wb,sheetName){
  const sh=wb.Sheets[sheetName];if(!sh)throw Error('Summary Liquidation 시트가 없습니다.');
  const cols=sh['!cols']||(sh['!cols']=[]);
  for(const[a,b]of ranges)for(let c=a;c<=b;c++)cols[c-1]={...(cols[c-1]||{}),hidden:true};
 }
 function patchXml(xml){
  const container=xml.match(/<((?:[\w.-]+:)?cols)\b[^>]*>[\s\S]*?<\/\1\s*>/);
  const records=[],covered=new Set();
  if(container){
   for(const m of container[0].matchAll(/<((?:[\w.-]+:)?col)\b[^>]*?\/>/g)){
    const tag=m[0],lo=Number(tag.match(/\bmin="(\d+)"/)?.[1]),hi=Number(tag.match(/\bmax="(\d+)"/)?.[1]);
    if(!Number.isInteger(lo)||!Number.isInteger(hi)||lo<1||hi>16384||lo>hi)throw Error('열 설정 범위가 올바르지 않습니다.');
    for(let c=lo;c<=hi;c++){if(covered.has(c))throw Error('중복 열 설정은 별도 검토가 필요합니다.');covered.add(c);}
    const cuts=[lo,...[8,30,31,39].filter(n=>n>lo&&n<=hi),hi+1];
    for(let i=0;i<cuts.length-1;i++){
     const start=cuts[i],end=cuts[i+1]-1;
     let piece=tag.replace(/\bmin="\d+"/,'min="'+start+'"').replace(/\bmax="\d+"/,'max="'+end+'"');
     if(shouldHide(start))piece=piece.replace(/\s+hidden="[^"]*"/g,'').replace(/\/>$/,' hidden="1"/>');
     records.push({start,piece});
    }
   }
  }
  const prefix=container?.[1].replace(/cols$/,'')||xml.match(/<([\w.-]+:)worksheet\b/)?.[1]||'';
  for(const[a,b]of ranges){
   for(let c=a;c<=b;){if(covered.has(c)){c++;continue;}const start=c;while(c<=b&&!covered.has(c))c++;records.push({start,piece:'<'+prefix+'col min="'+start+'" max="'+(c-1)+'" hidden="1"/>'});}
  }
  records.sort((a,b)=>a.start-b.start);
  const cols='<'+prefix+'cols>'+records.map(r=>r.piece).join('')+'</'+prefix+'cols>';
  if(container)xml=xml.replace(container[0],cols);
  else xml=xml.replace(/<((?:[\w.-]+:)?sheetData)\b/,cols+'<$1');
  let found=false;
  xml=xml.replace(/<(?:[\w.-]+:)?sheetView\b[^>]*>/g,tag=>{
   found=true;
   return tag.replace(/\s+zoomScale(?:Normal)?="[^"]*"/g,'').replace(/(\/?\s*>)$/,' zoomScale="80" zoomScaleNormal="80"$1');
  });
  if(!found){
   const view='<'+prefix+'sheetViews><'+prefix+'sheetView workbookViewId="0" zoomScale="80" zoomScaleNormal="80"/></'+prefix+'sheetViews>';
   if(xml.match(/<(?:[\w.-]+:)?sheetViews\s*\/>/))xml=xml.replace(/<(?:[\w.-]+:)?sheetViews\s*\/>/,view);
   else xml=xml.replace(/<(?:[\w.-]+:)?(?:sheetFormatPr|cols|sheetData)\b/,view+'$&');
  }
  return xml;
 }
 const api={ranges,initializeWorkbook,patchXml};root.LiquidationViewSettings=api;if(typeof module!=='undefined')module.exports=api;
})(globalThis);
