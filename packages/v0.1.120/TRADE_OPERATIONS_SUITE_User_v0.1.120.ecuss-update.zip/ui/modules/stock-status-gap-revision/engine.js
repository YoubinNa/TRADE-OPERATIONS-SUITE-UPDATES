/* Summary Liquidation stage 1. No workbook mutation or network access. */
(function (root) {
  'use strict';
  const SHEET = 'Summary Liquidation';
  const numeric = c => c && c.t === 'n' && typeof c.v === 'number' && Number.isFinite(c.v);
  const text = c => c && c.v != null ? String(c.v).trim() : '';
  function missingCache(c) { return !!(c && c.f && (c.v == null || c.t === 'z')); }
  function sign(c) {
    if (numeric(c)) return c.v > 0 ? 'positive' : c.v < 0 ? 'negative' : 'zero';
    return 'unknown';
  }
  function analyze(wb, XLSX) {
    const sh = wb.Sheets[SHEET];
    if (!sh) throw new Error('Summary Liquidation 시트를 찾을 수 없습니다.');
    let header = 0;
    for (let r = 1; r <= 30; r++) {
      if (text(sh['F' + r]).replace(/\s+/g, '').toLowerCase() === 'materialcode') { header = r; break; }
    }
    if (!header) throw new Error('F열의 Material Code 머리글을 찾을 수 없습니다. 양식을 확인하세요.');
    let detailHeader = 0;
    for (let r = header; r <= header + 3; r++) if (text(sh['AD' + r]).toUpperCase() === 'WIP') detailHeader = r;
    if (!detailHeader) throw new Error('AD열의 WIP 머리글을 찾을 수 없습니다. 양식을 확인하세요.');
    const startRow = Math.max(header, detailHeader) + 1;
    const rangeEnd = XLSX.utils.decode_range(sh['!ref'] || 'A1').e.r + 1;
    let endRow = startRow - 1;
    for (let r = startRow; r <= rangeEnd; r++) if (text(sh['F' + r])) endRow = r;
    if (endRow < startRow) throw new Error('자재코드가 있는 데이터 행이 없습니다.');
    const rows = [], decisions = [], problems = [], cacheErrors = [];
    const counts = { material: 0, asPassed: 0, visible: 0, hidden: 0, positive: 0, negative: 0, zero: 0, unknown: 0, adExcluded: 0, asExcluded: 0, nonMaterial: 0 };
    for (let r = startRow; r <= endRow; r++) {
      const f = sh['F' + r], ad = sh['AD' + r], am = sh['AM' + r], as = sh['AS' + r];
      let reason = 'keep';
      const code = text(f);
      if (!code) { reason = 'no-material-code'; counts.nonMaterial++; }
      else {
        counts.material++;
        if (missingCache(as)) cacheErrors.push('AS' + r);
        if (!numeric(as) || Math.abs(as.v) < 100) { reason = 'as-below-threshold-or-invalid'; counts.asExcluded++; }
        else {
          counts.asPassed++;
          if (missingCache(ad)) cacheErrors.push('AD' + r);
          // In the supplied template zero is rendered as '-'. A genuine displayed 0 is valid.
          const formatted = numeric(ad) ? (ad.w == null ? XLSX.SSF.format(ad.z || 'General', ad.v) : ad.w) : text(ad);
          const zeroDash = numeric(ad) && ad.v === 0 && /^[\s\-–—−]+$/.test(formatted);
          if (!numeric(ad) || zeroDash) { reason = 'ad-empty-dash-or-invalid'; counts.adExcluded++; }
          else {
            const group = sign(am);
            counts[group]++;
            rows.push({ row: r, materialCode: code, ad: ad.v, am: numeric(am) ? am.v : null, as: as.v, sign: group });
            if (group === 'unknown') problems.push({ row: r, column: 'AM', reason: missingCache(am) ? 'missing-formula-cache' : 'invalid-number' });
          }
        }
        for (const [col, cell] of [['AS', as], ['AD', ad]]) {
          if (cell && cell.t === 'e') problems.push({ row: r, column: col, reason: 'excel-error' });
        }
      }
      decisions.push({ row: r, hidden: reason !== 'keep', reason });
    }
    if (cacheErrors.length) throw new Error('수식의 저장된 계산 결과가 없습니다 (' + cacheErrors.slice(0, 8).join(', ') + '). Excel에서 재계산 후 저장한 파일을 선택하세요.');
    counts.visible = rows.length;
    counts.hidden = decisions.filter(d => d.hidden).length;
    return { schemaVersion: 1, stage: 1, sheetName: SHEET, startRow, endRow, threshold: 100, calculationSource: 'saved-excel-values', counts, rows, decisions, problems };
  }
  const api = { analyze, SHEET };
  root.SummaryLiquidation = api;
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
})(globalThis);
