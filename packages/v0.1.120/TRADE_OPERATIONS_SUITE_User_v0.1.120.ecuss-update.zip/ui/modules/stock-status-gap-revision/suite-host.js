/* Suite presentation only; approved workbook engine remains byte-identical. */
(() => {
 'use strict';
 const state=()=>window.SummaryLiquidationModule?.getState()||{busy:false,hasWork:false,unsaved:false};
 window.EcussModuleState={busy:()=>state().busy,hasWork:()=>state().hasWork,hasResult:()=>state().unsaved};
 addEventListener('DOMContentLoaded',()=>{
  const $=id=>document.getElementById(id),upload=document.querySelector('.upload'),apply=$('apply'),download=$('download');
  document.body.dataset.stockGapCompact='true';upload.classList.add('upload-card');upload.dataset.drop='';
  upload.querySelector('label').textContent='대상 수책재고 파일';
  const hint=document.createElement('p');hint.textContent='Excel 파일을 선택하거나 여기에 끌어 놓으세요.';upload.append(hint);
  const actions=document.createElement('div');actions.className='suite-gap-actions';actions.append(apply,download);upload.after(actions);
  apply.textContent='실행';
  // Keep original controls and status targets for the pinned application handlers.
  document.querySelector('.toolbar').hidden=true;
  document.querySelector('.metrics').hidden=true;
  document.querySelector('.table-wrap').hidden=true;
  $('tableInfo').hidden=true;
  document.querySelectorAll('main>.note,#results>.note').forEach(n=>n.hidden=true);
  const header=document.querySelector('#ecuss-page-header')||document.querySelector('header');
  if(header)header.querySelectorAll('p,.stage').forEach(n=>n.hidden=true);
  const summary=document.createElement('section');summary.id='suite-gap-summary';summary.setAttribute('aria-label','과부족 조치 요약');summary.hidden=true;
  summary.innerHTML='<h2>조치 요약</h2><p id="suite-gap-counts"></p><div class="suite-gap-table"><table><thead><tr><th>자재</th><th>갭 (+/−)</th><th>조치 수량</th><th>조치 위치</th><th>조치 방법</th></tr></thead><tbody></tbody></table></div><p class="suite-gap-recalc">다운로드 파일을 Excel에서 열면 연결 수식이 재계산됩니다.</p>';
  $('results').after(summary);
  const style=document.createElement('style');style.dataset.ecussDesktop='';
  style.textContent='body[data-stock-gap-compact] main{max-width:none;padding:12px 20px}body[data-stock-gap-compact] [hidden]{display:none!important}.suite-gap-actions{display:flex;gap:8px;flex-wrap:wrap;margin:10px 0}.suite-gap-table{overflow-x:auto}.suite-gap-table table{width:100%;border-collapse:collapse}.suite-gap-table th,.suite-gap-table td{padding:8px 10px;border-bottom:1px solid var(--weekday-line);text-align:left;vertical-align:top;white-space:pre-line}.suite-gap-table th{background:var(--weekday-soft);color:var(--weekday-ink)}#suite-gap-summary h2{font-size:14px;margin:12px 0 6px}.suite-gap-recalc{font-size:12px;color:var(--weekday-ink)}body[data-stock-gap-compact] .upload{background:var(--weekday-soft);border:1px dashed var(--weekday-line);border-radius:12px;padding:12px}body[data-stock-gap-compact] button{background:var(--weekday-soft);border:1px solid var(--weekday-line);color:var(--weekday-strong);border-radius:8px;padding:7px 13px}body[data-stock-gap-compact] button:disabled{opacity:.5;cursor:default}body[data-stock-gap-compact] table{font:inherit}body[data-stock-gap-compact] header .eyebrow{display:none}';
  document.head.append(style);
  let last='',rendering=false;
  const signed=n=>n==null?'확인 필요':(n>0?'+':'')+n.toLocaleString('ko-KR',{maximumFractionDigits:6});
  function sync(){
   if(rendering)return;rendering=true;
   try{
    const module=window.SummaryLiquidationModule,plan=module?.getPlan(),analysis=module?.getAnalysis(),s=state();
    apply.disabled=s.busy||!analysis||!!plan;download.disabled=s.busy||!plan;
    if(download.textContent!=='Excel 다운로드')download.textContent='Excel 다운로드';
    const key=JSON.stringify([analysis,plan]);if(key===last)return;last=key;
    summary.hidden=!plan;if(!plan)return;
    const rows=analysis.rows.filter(r=>r.sign==='positive'||r.sign==='negative');
    $('suite-gap-counts').textContent='양수 '+rows.filter(r=>r.sign==='positive').length+'개 · 음수 '+rows.filter(r=>r.sign==='negative').length+'개 · 조치 '+plan.adjustedMaterials+'개';
    const body=summary.querySelector('tbody');body.replaceChildren();
    if(!rows.length){const tr=body.insertRow(),td=tr.insertCell();td.colSpan=5;td.textContent='갭 양수·음수 대상 자재가 없습니다.';}
    for(const row of rows){
     const changes=plan.actions.filter(a=>a.summaryRow===row.row);
     const tr=body.insertRow();
     const values=[row.materialCode,signed(row.am),changes.length?changes.map(a=>a.operation==='addition'?'+'+a.addition:'−'+a.deduction).join('\n'):'0',changes.map(a=>a.sheet+'!'+a.ref).join('\n')||'—',changes.map(a=>(a.operation==='addition'?'증량':'차감')+' · ='+a.formula).join('\n')||'미조치'];
     for(const value of values)tr.insertCell().textContent=value;
    }
   }finally{rendering=false;}
  }
  new MutationObserver(sync).observe($('status'),{childList:true,subtree:true,characterData:true});
  $('file').addEventListener('change',()=>queueMicrotask(sync));
  apply.addEventListener('click',()=>queueMicrotask(sync));download.addEventListener('click',()=>queueMicrotask(sync));
  for(const type of ['dragenter','dragover'])upload.addEventListener(type,e=>{e.preventDefault();if(e.dataTransfer)e.dataTransfer.dropEffect=state().busy?'none':'copy';});
  upload.addEventListener('drop',e=>{
   e.preventDefault();if(state().busy)return;
   const files=e.dataTransfer?.files;if(files?.length!==1||!files[0].name.toLowerCase().endsWith('.xlsx')){$('status').textContent='XLSX 파일 한 개를 선택해 주세요.';return;}
   const data=new DataTransfer();data.items.add(files[0]);$('file').files=data.files;$('file').dispatchEvent(new Event('change',{bubbles:true}));
  });
  window.SummaryLiquidationHost={saveFile:async({bytes,mimeType})=>{
   if(!window.SummaryLiquidationModule.getPlan())throw Error('실행 후 다운로드해 주세요.');
   const name=$('source').textContent;
   const url=URL.createObjectURL(new Blob([bytes],{type:mimeType})),a=document.createElement('a');
   a.href=url;a.download='REVISION FOR AUDIT_'+name;document.body.append(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),30000);
  }};
  sync();
 },{once:true});
})();
