(function () {
  'use strict';
  const $ = id => document.getElementById(id);
  let current = null, busy = false, unsaved = false, plan = null;
  const labels = { positive: '양수 (+)', negative: '음수 (−)', zero: '0', unknown: '확인 필요' };
  const fmt = value => value == null ? '확인 필요' : value.toLocaleString('ko-KR', { maximumFractionDigits: 6 });
  function status(message, error = false) { $('status').textContent = message; $('status').classList.toggle('error', error); }
  function lock(value) { busy = value; $('file').disabled = value; $('download').disabled = value; $('apply').disabled = value || !!plan; }
  function render() {
    const a = current.analysis;
    for (const id of ['material', 'asPassed', 'visible', 'adExcluded']) $(id).textContent = fmt(a.counts[id]);
    $('groups').textContent = '양수 ' + a.counts.positive + ' · 음수 ' + a.counts.negative + ' · 0 ' + a.counts.zero + ' · 확인 필요 ' + a.counts.unknown;
    const selected = $('sign').value, shown = a.rows.filter(r => selected === 'all' || r.sign === selected);
    const fragment = document.createDocumentFragment();
    for (const row of shown) {
      const tr = document.createElement('tr');
      const action = plan?.materials.find(m => m.row === row.row);
      const changed = action?.status === 'adjusted';
      for (const value of [row.row, row.materialCode, fmt(changed ? row.ad - Number(action.deduction||0)+Number(action.addition||0) : row.ad), fmt(changed ? action.remainingGap : row.am), fmt(row.as), action ? (changed ? (row.sign==='negative'?'증량 '+fmt(Number(action.addition)):'차감 '+fmt(Number(action.deduction))) : '미조치 · 숨김') : labels[row.sign]]) {
        const td = document.createElement('td'); td.textContent = value; tr.appendChild(td);
      }
      tr.lastChild.className = row.sign; fragment.appendChild(tr);
    }
    $('rows').replaceChildren(fragment);
    $('tableInfo').textContent = '최초 대상 '+a.rows.length+'행 · 화면 표시 '+shown.length+'행'+(plan?' · 다운로드에 표시될 조치 자재 '+plan.adjustedMaterials+'행':'')+'. 화면은 소수점 6자리까지 표시합니다.';
    $('issueList').replaceChildren(...a.problems.map(p => { const li = document.createElement('li'); li.textContent = p.column + p.row + ': ' + (p.reason === 'excel-error' ? 'Excel 오류 값' : 'AM 숫자 또는 계산 결과 확인 필요'); return li; }));
    $('issues').hidden = a.problems.length === 0;
    $('results').hidden = false;
  }
  $('file').addEventListener('change', async event => {
    const file = event.target.files[0]; if (!file || busy) return;
    lock(true); status('엑셀 파일을 읽고 필터 조건을 확인하고 있습니다…');
    try {
      const next = await LiquidationWorkbook.open(await file.arrayBuffer(), file.name);
      current = next; plan = null; unsaved = true; $('sign').value = 'all'; $('applied').hidden = true; $('download').textContent = '행 숨김 적용 엑셀 다운로드';
      $('source').textContent = file.name;
      render(); status('필터 완료. ' + next.analysis.counts.visible + '개 자재 행이 남습니다. 원본의 저장된 계산값을 기준으로 판정했습니다.');
    } catch (error) { status(error.message + (current ? '\n직전에 성공한 파일의 결과를 유지합니다.' : ''), true); }
    finally { lock(false); $('file').value = ''; }
  });
  $('sign').addEventListener('change', () => { if (current) render(); });
  $('apply').addEventListener('click', () => {
    if(!current || busy || plan)return;
    lock(true);
    try {
      plan=current.prepareAll();unsaved=true;render();
      $('applied').hidden=false;
      const pos=plan.materials.filter(m=>m.status==='adjusted'&&m.sign==='positive').length,neg=plan.materials.filter(m=>m.status==='adjusted'&&m.sign==='negative').length;
      $('applied').textContent='양수 갭 '+pos+'개 자재 차감, 음수 갭 '+neg+'개 자재 증량, 총 '+plan.actions.length+'개 셀 조정. 다운로드 파일을 Excel에서 열면 연결 수식이 재계산됩니다. 원본은 변경되지 않습니다.';
      $('download').textContent='갭 조정 엑셀 다운로드';
      status('조정 적용 완료. 차감은 주황색, 증량은 연분홍색으로 표시하고 수식에 조정량을 남깁니다.');
    }catch(error){status(error.message,true);}finally{lock(false);}
  });
  $('download').addEventListener('click', async () => {
    if (!current || busy) return;
    lock(true); status('원본을 보존한 다운로드 사본을 만들고 있습니다…');
    try {
      const bytes = await current.export();
      const filename = current.name.replace(/\.xlsx$/i, '') + (plan ? '_갭조정.xlsx' : '_검토1단계.xlsx');
      if (window.SummaryLiquidationHost?.saveFile) await window.SummaryLiquidationHost.saveFile({ filename, bytes, mimeType: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
      else {
        const url = URL.createObjectURL(new Blob([bytes], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' }));
        const anchor = document.createElement('a'); anchor.href = url; anchor.download = filename; document.body.appendChild(anchor); anchor.click(); anchor.remove();
        setTimeout(() => URL.revokeObjectURL(url), 30000);
      }
      unsaved = false; status('다운로드 파일을 준비했습니다. 선택한 원본 파일은 변경되지 않았습니다.');
    } catch (error) { status('파일 저장 실패: ' + error.message, true); }
    finally { lock(false); }
  });
  // Host supplies its save dialog and tab lifecycle adapter during Suite integration.
  window.SummaryLiquidationModule = { getState: () => ({ busy, hasWork: !!current, unsaved }), getAnalysis: () => current ? structuredClone(current.analysis) : null, getPlan: () => plan ? structuredClone(plan) : null };
  window.addEventListener('beforeunload', event => { if (busy || unsaved) { event.preventDefault(); event.returnValue = ''; } });
})();
