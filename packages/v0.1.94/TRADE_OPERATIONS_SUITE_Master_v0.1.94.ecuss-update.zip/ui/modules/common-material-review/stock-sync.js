(function(root){
'use strict';
const ids={amo:'AMO',agv:'AMOGREEN'};
class Sync {
 constructor(provider,parse,update){this.p=provider;this.parse=parse;this.update=update;this.cache={};this.key=null;this.busy=false;this.pending=null;this.activeKey=null;this.disposed=false;}
 emit(state,error){if(!this.disposed)this.update({key:this.key,state,error,snapshot:this.cache[this.key]||null});}
 select(key){if(!ids[key])throw Error('법인 오류');this.key=key;this.emit(this.cache[key]?'checking':'loading');return this.refresh();}
 refresh(){if(this.disposed||!this.key)return Promise.resolve();if(this.busy)return this.activeKey===this.key?this.pending:this.pending.then(()=>this.refresh());const key=this.key;this.busy=true;this.activeKey=key;this.pending=this.run(key).finally(()=>{this.busy=false;this.activeKey=null;});return this.pending;}
 async run(key){
  this.emit(this.cache[key]?'checking':'loading');
  if(!this.cache[key]&&this.p.restore){let saved;try{saved=await this.p.restore(ids[key]);if(saved){const data=await this.parse(saved.bytes,key,saved.info);this.cache[key]={data,info:saved.info,contentHash:this.p.contentHash(saved.info),checkedAt:saved.checkedAt};if(key===this.key)this.emit('checking');}}catch{}finally{await saved?.release?.();}}
  try{
   for(let attempt=0;attempt<3;attempt++){
    const info=await this.p.status(ids[key]);
    if(!info){await this.p.forget?.(ids[key]);delete this.cache[key];if(key===this.key)this.emit('empty');break;}
    const contentHash=this.p.contentHash(info);if(!/^[a-f0-9]{64}$/.test(contentHash||''))throw Error('조회 전용 자료가 준비되지 않았습니다.');
    if(this.cache[key]?.contentHash===contentHash){const confirmed=await this.p.confirm?.(ids[key],info.finalHash);this.cache[key].data.filename=info.finalName;this.cache[key].data.sha256=info.finalHash;this.cache[key].info=info;this.cache[key].checkedAt=confirmed?.checkedAt||new Date().toISOString();if(key===this.key)this.emit('current');break;}
    let result;
    try{
     result=await this.p.read(ids[key],info.finalHash);const data=await this.parse(result.bytes,key,result.info);
     const after=await this.p.status(ids[key]);if(!after||after.finalHash!==result.info.finalHash||this.p.contentHash(after)!==this.p.contentHash(result.info)||this.p.contentHash(result.info)!==contentHash){if(attempt===2)throw Error('원본이 계속 변경되어 다시 확인해야 합니다.');continue;}
     const confirmed=await result.commit?.();this.cache[key]={data,info:after,contentHash,checkedAt:confirmed?.checkedAt||new Date().toISOString()};if(key===this.key)this.emit('current');break;
    }finally{await result?.release?.();}
   }
  }catch(e){if(key===this.key)this.emit(this.cache[key]?'stale':'error',e.message);}
 }
 download(){if(this.busy)throw Error('원본 확인이 끝난 뒤 다시 시도하세요.');const key=this.key,s=this.cache[key];if(!s)throw Error('확인된 원본이 없습니다.');this.busy=true;this.activeKey=key;this.pending=this.p.download(ids[key],s.info.finalHash).finally(()=>{this.busy=false;this.activeKey=null;});return this.pending.finally(()=>this.refresh());}
 dispose(){this.disposed=true;}
}
function nativeProvider(bridge,kind='dashboard'){
 async function rpc(action,payload){const r=await bridge.call('/stock/dashboard/'+action,payload);if(r.status!==200)throw Error(r.value?.message||'공유 자료 연결 실패');return r.value;}
 async function transfer(company,expectedHash,local){
  const s=await rpc(local?'restore':'start',{company,expectedHash});if(!s&&local)return null;
  const release=()=>rpc('release',{company,id:s.id}).catch(()=>{});
  try{
   if(!Number.isSafeInteger(s.size)||s.size<1||s.size>50000000||s.info.company!==company||(!local&&s.info.finalHash!==expectedHash)||(local&&!Number.isFinite(Date.parse(s.checkedAt))))throw Error('원본 메타데이터 오류');
   const bytes=new Uint8Array(s.size);for(let offset=0;offset<s.size;){const c=await rpc('chunk',{company,id:s.id,offset});const part=Uint8Array.from(atob(c.data),c=>c.charCodeAt(0));if(c.offset!==offset||!part.length||part.length>1048576||offset+part.length>s.size)throw Error('원본 수신 오류');bytes.set(part,offset);offset+=part.length;}
   const hash=Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',bytes)),x=>x.toString(16).padStart(2,'0')).join('');if(hash!==s.hash||hash!==s.info[kind==='catalog'?'catalogHash':'dashboardHash'])throw Error('원본 무결성 확인 실패');
   return {bytes,info:s.info,checkedAt:s.checkedAt,release,commit:local?null:()=>rpc('commit',{company,id:s.id,expectedHash})};
  }catch(e){await release();throw e;}
 }
 return {contentHash:info=>info[kind==='catalog'?'catalogHash':'dashboardHash'],
  async status(company){const rows=await rpc('status',{company}),row=rows.find(r=>r.company===company);if(row?.state!=='connected')throw Error('연결 실패 · 최신 여부 확인 불가');return row.info;},
  restore:company=>transfer(company,null,true),read:(company,expectedHash)=>transfer(company,expectedHash,false),
  confirm:(company,expectedHash)=>rpc('confirm',{company,expectedHash}),forget:company=>rpc('forget',{company}),download:(company,expectedHash)=>rpc('download',{company,expectedHash})};
}
root.StockDashboardSync={Sync,nativeProvider};if(typeof module!=='undefined')module.exports=root.StockDashboardSync;
})(globalThis);
