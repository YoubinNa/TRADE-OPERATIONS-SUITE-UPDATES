/* Section-aware reading. Original workbook cells and calculation caches are never modified. */
(function(root){'use strict';
const C=root.CommonMaterialCore,baseDetect=C.detect,baseExtract=C.extract;
const text=v=>String(v??'').trim(),norm=v=>text(v).toLowerCase().replace(/[\s()._/$-]/g,''),a=(c,r)=>XLSX.utils.encode_cell({c,r}),cell=(s,c,r)=>s[a(c,r)]||{},value=(s,c,r)=>cell(s,c,r).v;
const merged=(s,c,r)=>{if(c<0)return '';const own=cell(s,c,r);if(own.v!==undefined)return text(own.v);const m=(s['!merges']||[]).find(m=>m.s.r<=r&&r<=m.e.r&&m.s.c<=c&&c<=m.e.c);return m?text(value(s,m.s.c,m.s.r)):'';};
const fields=['code','name','spec','vnName','unit','price','hs','product','project','consumption'];
function header(s,r,maxCol){
 const m=Object.fromEntries(fields.map(k=>[k,-1]));m.codes=[];
 for(let c=0;c<=Math.min(maxCol,99);c++){const n=norm(value(s,c,r));
  if(n==='materialcode'||n==='자재코드'||n==='원재료코드'){m.codes.push(c);m.code=c;}
  else if(n==='materialname'||n==='자재명'||n==='원재료명')m.name=c;
  else if(n==='productcode'||n==='제품코드'||n==='완제품코드')m.product=c;
  else if(n==='project'||n==='프로젝트')m.project=c;
  else if(n==='spec'||n.startsWith('specification')||n==='규격')m.spec=c;
  else if(/^(vnname|vietnamname|vietnamesename|베트남어명)$/.test(n))m.vnName=c;
  else if(n==='unit'||n==='단위'||n==='uom')m.unit=c;
  else if(/^(up|uprice|unitprice|단가|자재단가)/.test(n))m.price=c;
  else if(n.includes('hscode')||n==='hs'||n==='세번')m.hs=c;
  else if(n==='consumption'||n==='소요량'||n==='consumptionqty')m.consumption=c;
 }
 // In the existing contract format, the unnamed VN column follows HS.
 if(m.code>=0&&m.hs>=0&&m.vnName<0&&m.product>=0&&m.consumption>=0){const c=m.hs+1;const values=[1,2,3].map(n=>value(s,c,r+n));if(values.some(v=>typeof v==='string'&&/[A-Za-zÀ-ỹ]/.test(v)))m.vnName=c;}
 return m;
}
function detect(s){
 const fallback=baseDetect(s),range=XLSX.utils.decode_range(s['!ref']||'A1');if(range.e.r>100000)return fallback;
 const candidates=new Set();
 for(const [address,v] of Object.entries(s)){if(address[0]==='!'||typeof v?.v!=='string')continue;const n=norm(v.v);if(['materialcode','자재코드','원재료코드','productcode','제품코드','완제품코드'].includes(n))candidates.add(XLSX.utils.decode_cell(address).r);}
 const heads=[...candidates].sort((a,b)=>a-b).map(r=>({r,m:header(s,r,range.e.c)})).filter(x=>(x.m.code>=0&&x.m.price>=0)||(x.m.product>=0&&x.m.code<0));
 if(!heads.some(x=>x.m.code>=0&&x.m.product>=0&&x.m.consumption>=0))return fallback;
 const blocks=[];
 for(let i=0;i<heads.length;i++){
  const {r,m}=heads[i],kind=m.code<0?'products':m.product>=0?'bom':'master';let end=(heads[i+1]?.r??range.e.r+1)-1;
  for(let j=r+1;j<=end;j++){const left=[0,1,2].map(c=>text(value(s,c,j))).join(' ');if(/TERMS OF CONTRACT|ON BEHALF|^\s*\d+\.?\s*(?:PRODUCT\s*LIST|MATERIAL\s*LIST|BOM\s*CONSUMPTION)/i.test(left)){end=j-1;break;}}
  const codeCol=kind==='products'?m.product:m.code;
  while(end>r&&!text(value(s,codeCol,end))&&!text(value(s,m.name,end)))end--;
  if(end<=r)continue;
  blocks.push({kind,start:r+1,end,header:r,...m});
 }
 const bomCodes=new Set(blocks.filter(b=>b.kind==='bom').flatMap(b=>Array.from({length:b.end-b.start+1},(_,i)=>text(value(s,b.code,b.start+i)))).filter(Boolean));
 for(const b of blocks.filter(b=>b.kind==='master'&&b.codes.length>1)){const scored=b.codes.map(c=>({c,n:Array.from({length:b.end-b.start+1},(_,i)=>bomCodes.has(text(value(s,c,b.start+i)))).filter(Boolean).length})).sort((a,b)=>b.n-a.n);if(scored[0].n>0&&scored[0].n>scored[1].n)b.code=scored[0].c;else b.ambiguous=true;}
 return {...fallback,score:(fallback?.score||10)+20,layout:{blocks}};
}
function extract(s,map){
 if(!map?.layout)return baseExtract(s,map);
 const blocks=map.layout.blocks;validate(blocks,s);const rows=[],products=[];
 for(const [id,b] of blocks.entries()){
  if(b.kind==='products'){for(let r=b.start;r<=b.end;r++){const code=merged(s,b.product,r);if(code&&!/^(total|sum)$/i.test(code))products.push({code,project:merged(s,b.project,r),row:r+1});}continue;}
  let part;try{part=baseExtract(s,{...b,header:b.start-1,end:b.end});}catch(e){if(e.message==='rows_missing')continue;throw e;}
  for(const r of part){r.issues=r.issues.filter(k=>!['code_duplicate','internal_name','internal_unit','internal_price','internal_hs'].includes(k));delete r.duplicateRows;r.role=b.kind;r.block=id;r.product=b.kind==='bom'?merged(s,b.product,r.row-1):'';r.project=merged(s,b.project,r.row-1);r.consumption=b.consumption>=0?text(value(s,b.consumption,r.row-1)):'';r.scope=b.kind==='master'?'master':'product:'+r.product;r.issues=[...r.issues];if(b.kind==='bom'&&!r.product)r.issues.push('bom_product_missing');if(b.kind==='bom'&&r.product&&products.length&&!products.some(p=>p.code===r.product))r.issues.push('bom_product_unlisted');rows.push(r);}
 }
 if(!rows.length)throw Error('rows_missing');
 const scopes=new Map(),codes=new Map();for(const r of rows){if(!r.code||r.issues.includes('code_error'))continue;const key=r.scope+'\0'+r.code;if(!scopes.has(key))scopes.set(key,[]);scopes.get(key).push(r);if(!codes.has(r.code))codes.set(r.code,[]);codes.get(r.code).push(r);}
 for(const rs of scopes.values())if(rs.length>1)for(const r of rs){r.issues.push(r.role==='master'?'code_duplicate':'bom_duplicate');r.duplicateRows=rs.map(x=>x.row);}
 const clean=v=>text(v).normalize('NFC').replace(/\s+/g,' '),val=(r,k)=>k==='price'?r.price:k==='unit'?C.unit(r.unit):k==='hs'?C.hs(r.hs):clean(r[k]),same=(a,b,k)=>k==='price'?C.equal(val(a,k),val(b,k)):val(a,k)===val(b,k);
 for(const rs of codes.values()){
  const masters=rs.filter(r=>r.role==='master'),boms=rs.filter(r=>r.role==='bom');
  for(const r of rs){if(r.role==='bom'&&!masters.length&&blocks.some(b=>b.kind==='master'))r.issues.push('bom_master_missing');if(r.role==='master'&&!boms.length)r.issues.push('bom_unused');
   for(const k of ['name','spec','vnName','unit','hs','price']){
    const has=x=>val(x,k)!==''&&val(x,k)!==null;
    if(masters.some(m=>has(m))&&boms.some(m=>has(m))&&masters.some(m=>boms.some(b=>has(m)&&has(b)&&!same(m,b,k))))r.issues.push('masterDiff_'+k);
    if(boms.some(a=>boms.some(b=>a.product!==b.product&&has(a)&&has(b)&&!same(a,b,k))))r.issues.push('bomDiff_'+k);
   }
   r.issues=[...new Set(r.issues)];
  }
 }
 for(const p of products)if(!rows.some(r=>r.role==='bom'&&r.product===p.code))throw Error('bom_product_without_rows');
 // Keep lightweight independent evidence objects: no circular peer references.
 let evidenceCount=0;for(const rs of codes.values()){evidenceCount+=rs.length*rs.length;if(evidenceCount>200000)throw Error('too_large');const evidence=rs.map(({issues,...r})=>({...r,issues:[...issues]}));for(const r of rs)r.bomPeers=evidence;}
 return rows;
}
function validate(blocks,s){
 const end=XLSX.utils.decode_range(s['!ref']||'A1').e.r,used=[];
 if(!blocks?.some(b=>b.kind==='bom'))throw Error('bom_layout_invalid');
 for(const b of blocks){if(b.ambiguous)throw Error('bom_code_ambiguous');if(!Number.isInteger(b.start)||!Number.isInteger(b.end)||b.start<0||b.end<b.start||b.end>end)throw Error('bom_layout_invalid');if(used.some(x=>b.start<=x.end&&b.end>=x.start))throw Error('bom_layout_invalid');used.push(b);const keys=b.kind==='products'?['product']:['code','price',...(b.kind==='bom'?['product']:[])];if(keys.some(k=>!Number.isInteger(b[k])||b[k]<0||b[k]>16383))throw Error('bom_layout_invalid');const cols=fields.map(k=>b[k]).filter(c=>c>=0);if(new Set(cols).size!==cols.length)throw Error('bom_layout_invalid');}
}
function summary(s,map){const rows=extract(s,map);return {products:new Set(rows.map(r=>r.product).filter(Boolean)).size,materials:new Set(rows.map(r=>r.code).filter(Boolean)).size,masterRows:rows.filter(r=>r.role==='master').length,bomRows:rows.filter(r=>r.role==='bom').length,rows:rows.length};}
C.detect=detect;C.extract=extract;root.CommonMaterialBOM={detect,extract,validate,summary,fields};
})(typeof window!=='undefined'?window:globalThis);
