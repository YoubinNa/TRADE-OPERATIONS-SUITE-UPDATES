/* Independent contract-to-contract validation. Never accepts a reference catalog. */
(function(root){'use strict';
function compare(files){
 const C=root.CommonMaterialCore;if(files.length<2||files.length>20)throw Error('crossCount');
 const rows=[],index=new Map();let total=0;
 for(const file of files){for(const r of C.extract(file.wb.Sheets[file.sheet],file.map)){
  if(rows.length>=100000)throw Error('too_large');const item={...r,fileId:file.id,filename:file.name,sheet:file.sheet,internalIssues:[...r.issues],matches:[]};rows.push(item);
  if(r.code&&!r.issues.includes('code_error')){if(!index.has(r.code))index.set(r.code,[]);index.get(r.code).push(item);}
 }}
 const clean=v=>String(v??'').trim().normalize('NFC').replace(/\s+/g,' ');
 for(const r of rows){
  r.matches=(index.get(r.code)||[]).filter(m=>m.fileId!==r.fileId);total+=r.matches.length;if(total>200000)throw Error('excelTooLarge');
  r.status=!r.code||r.issues.includes('code_error')?'unreadable':r.matches.length?'crossShared':'crossUnique';
  for(const k of ['name','spec','vnName','hs','unit','price']){
   const value=m=>k==='price'?m.price:k==='hs'?C.hs(m[k]):k==='unit'?C.unit(m[k]):clean(m[k]);
   const present=v=>v!==null&&v!=='';const a=value(r);
   if(r.matches.some(m=>!present(value(m))))r.issues.push('crossMissing_'+k);
   if(present(a)&&r.matches.some(m=>present(value(m))&&(k==='price'?!C.equal(a,value(m)):a!==value(m))))r.issues.push('crossDiff_'+k);
  }
  if(r.issues.includes('crossDiff_unit')&&r.matches.length)r.issues.push('crossPriceUnit');
  r.issues=[...new Set(r.issues)];
 }
 return rows.map(r=>({...r,matches:r.matches.map(({matches,...m})=>m)}));
}
// Presentation groups retain every original row and every affected file.
function group(rows){
 const C=root.CommonMaterialCore, map=new Map(), clean=v=>String(v??'').trim().normalize('NFC').replace(/\s+/g,' ');
 for(const r of rows){const key=r.code&&!r.issues.includes('code_error')?'code:'+r.code:'row:'+r.fileId+':'+r.row;if(!map.has(key))map.set(key,{key,code:r.code,rows:[]});map.get(key).rows.push(r);}
 function variants(rs,field){
  const out=[],value=r=>field==='price'?r.price:field==='hs'?C.hs(r.hs):field==='unit'?C.unit(r.unit):clean(r[field]);
  for(const r of rs){const v=value(r);let bucket=out.find(b=>field==='price'&&v!==null&&b.normalized!==null?C.equal(v,b.normalized):v===b.normalized);if(!bucket){bucket={normalized:v,values:[],rows:[]};out.push(bucket);}const shown=field==='price'?r.raw:String(r[field]??'').trim();if(!bucket.values.includes(shown))bucket.values.push(shown);bucket.rows.push(r);}
  return out;
 }
 const groups=[...map.values()].map(g=>{
  g.issues=[...new Set(g.rows.flatMap(r=>r.issues))];g.names=[...new Set(g.rows.map(r=>r.name).filter(Boolean))];g.fileIds=[...new Set(g.rows.map(r=>r.fileId))];
  g.sections=['name','spec','vnName','hs','unit','price'].filter(k=>g.issues.some(i=>i==='crossDiff_'+k||i==='crossMissing_'+k||i==='masterDiff_'+k||i==='bomDiff_'+k)).map(field=>({kind:'cross',field,variants:variants(g.rows,field)}));
  const own=new Map();for(const r of g.rows){const ownIssues=r.internalIssues.filter(k=>!k.startsWith('masterDiff_')&&!k.startsWith('bomDiff_'));if(!ownIssues.length)continue;const key=[...ownIssues].sort().join('|')+'|'+JSON.stringify(r.duplicateRows||[]);if(!own.has(key))own.set(key,{kind:'internal',issues:ownIssues,rows:[]});own.get(key).rows.push(r);}
  g.internal=[...own.values()];return g;
 });
 return groups.sort((a,b)=>Number(!!b.issues.length)-Number(!!a.issues.length)||a.code.localeCompare(b.code)||a.key.localeCompare(b.key));
}
root.CommonMaterialCrossCore={compare,group};
})(typeof window!=='undefined'?window:globalThis);
