(function(root){
'use strict';
const text=v=>v==null?'':String(v).trim();
const norm=v=>text(v).replace(/[\s\n\r()._/$-]/g,'').toLowerCase();
const unit=v=>text(v).toUpperCase().replace(/\s/g,'').replace(/M²|㎡/g,'M2');
const hs=v=>text(v).replace(/[.\-\s]/g,'');
const number=v=>{if(typeof v==='number')return Number.isFinite(v)?v:null;const s=text(v);if(!/^[+-]?(?:\d+|\d{1,3}(?:,\d{3})+)(?:\.\d+)?(?:e[+-]?\d+)?$/i.test(s))return null;return Number(s.replace(/,/g,''));};
// Excel stores 15 significant decimal digits. Ignore binary serialization noise only.
const canonical=v=>Number.isFinite(v)?Number(v.toPrecision(15)):v;
const equal=(a,b)=>a!==null&&b!==null&&canonical(a)===canonical(b);
// Expand exponent notation; retain trailing zeroes in the rendered price text.
function decimalPlaces(value){
 const s=(typeof value==='number'?String(canonical(value)):text(value)).replace(/[\s,$€£₩₫¥()]/g,'');
 const m=s.match(/^[+-]?\d+(?:\.(\d+))?(?:e([+-]?\d+))?$/i);
 return m?Math.max(0,(m[1]||'').length-Number(m[2]||0)):null;
}
const col=n=>XLSX.utils.encode_col(n);
const at=(s,c,r)=>s[col(c)+(r+1)]||{};
const val=(s,c,r)=>at(s,c,r).v;
const identifier=cell=>typeof cell.v==='number'&&/^0{2,30}$/.test(cell.z||'')?XLSX.SSF.format(cell.z,cell.v):text(cell.v);
function bounds(s){try{return XLSX.utils.decode_range(s['!ref']||'A1');}catch{return {s:{r:0,c:0},e:{r:0,c:0}};}}
function detect(s){
 const b=bounds(s),found=[];
 for(let r=0;r<=Math.min(b.e.r,299);r++){
  const m={code:-1,name:-1,spec:-1,vnName:-1,unit:-1,price:-1,hs:-1};
  for(let c=0;c<=Math.min(b.e.c,99);c++){
   const n=norm(val(s,c,r));
   if(n.includes('materialcode')||n.includes('원재료코드')||n==='자재코드')m.code=c;
   else if(n.includes('materialname')||n.includes('원재료명')||n==='자재명')m.name=c;
   else if(n==='spec'||n.startsWith('specification')||n==='규격')m.spec=c;
   else if(n.includes('vnname')||n.includes('vietnamname')||n.includes('vietnamesename')||n.includes('베트남어명'))m.vnName=c;
   else if(n==='unit'||n==='unit단위'||n==='단위unit'||n==='단위'||n==='uom')m.unit=c;
   else if((n.startsWith('up')||n.startsWith('unitprice')||n==='단가'||n==='자재단가')&&!n.includes('cons'))m.price=c;
   else if(n.includes('hscode')||n==='hs'||n==='세번')m.hs=c;
  }
  if(m.code>=0&&m.price>=0){if(m.code===2&&m.price===8&&m.hs===14&&m.vnName<0)m.vnName=15;found.push({...m,header:r,score:5+(m.unit>=0?2:0)+(m.hs>=0?4:0)+(m.name>=0?1:0)+(m.spec>=0?2:0)+(m.vnName>=0?2:0)});}
 }
 return found.sort((a,b)=>b.score-a.score)[0]||null;
}
function companyOf(s){
 const b=bounds(s);let amo=false,agv=false;
 for(let r=0;r<=Math.min(b.e.r,20);r++)for(let c=0;c<=Math.min(b.e.c,16);c++){
  const t=text(val(s,c,r)).toLowerCase().replace(/[^a-z]/g,'');
  if(t.includes('amogreenvina'))agv=true;
  else if(t.includes('amovina'))amo=true;
 }
 return amo&&agv?'conflict':agv?'AGV':amo?'AMO':'';
}
function displayCheck(cell){
 const n=number(cell.v),fmt=cell.z||'General';
 if(n===null)return {shown:text(cell.w??cell.v),issue:null};
 let shown;try{shown=XLSX.SSF.format(fmt,n);}catch{return {shown:text(cell.w??cell.v),issue:'format_unknown'};}
 // SSF may emit malformed "1e-7.0000000" for tiny fixed-decimal values.
 // Use fixed-point formatting only for this narrowly detected plain-zero pattern.
 if(/^0\.0{1,15}$/.test(fmt)&&/e[+-]?\d+\./i.test(shown))shown=n.toFixed(fmt.length-2);
 if(cell.conditionalFormat)return {shown,issue:'conditional_format'};
 if(fmt==='General'){const displayed=number(shown);return {shown,issue:displayed===null?'format_unknown':equal(n,displayed)?null:'display_difference'};}
 // Only plain decimal/currency/accounting formats can be compared as prices.
 // Do not guess percentage, fraction, date, conditional or scaled-number formats.
 let quoted=false,parts=[''];for(let i=0;i<fmt.length;i++){const c=fmt[i];if(c==='\\'&&i+1<fmt.length){parts[parts.length-1]+=c+fmt[++i];continue;}if(c==='"')quoted=!quoted;if(c===';'&&!quoted)parts.push('');else parts[parts.length-1]+=c;}
 const active=n<0&&parts.length>1?parts[1]:n===0&&parts.length>2?parts[2]:parts[0];
 let cleaned=active.replace(/"[^"]*"/g,'').replace(/\\./g,'').replace(/_.|\*./g,'').replace(/\[(?:Black|Blue|Cyan|Green|Magenta|Red|White|Yellow|Color\d+)\]/gi,'');
 if(/[%/@]|[ymdhHsS]|\[[^\]]+\]|[0#?],+(?:;|$)/.test(cleaned)||/\?\s*\//.test(cleaned))return {shown,issue:'format_unknown'};
 let numeric=shown.replace(/[\s,$€£₩₫¥]/g,'');
 if(/^\(.*\)$/.test(numeric))numeric='-'+numeric.slice(1,-1);
 if(n===0&&/^[-–—]*$/.test(numeric))return {shown,issue:null};
 const displayed=number(numeric);
 if(displayed===null)return {shown,issue:'format_unknown'};
 return {shown,issue:equal(n,displayed)?null:'display_difference'};
}
function extract(s,m){
 if(!m||m.code<0||m.price<0||m.header<0)throw Error('table_missing');
 const b=bounds(s),rows=[];
 if(b.e.r>100000)throw Error('too_large');
 for(let r=m.header+1;r<=Math.min(b.e.r,m.end??b.e.r);r++){
  const left=Array.from({length:Math.min(4,b.e.c+1)},(_,c)=>text(val(s,c,r))).join(' ');
  if(/TERMS OF CONTRACT|ON BEHALF|^\s*\d+\.?\s*PRODUCT LIST/i.test(left))break;
  const codeCell=at(s,m.code,r),code=identifier(codeCell),name=m.name>=0?text(val(s,m.name,r)):'';
  const spec=m.spec>=0?text(val(s,m.spec,r)):'',vnName=m.vnName>=0?text(val(s,m.vnName,r)):'';
  const priceCell=at(s,m.price,r),u=m.unit>=0?text(val(s,m.unit,r)):'',h=m.hs>=0?identifier(at(s,m.hs,r)):'';
  if(!code&&!name&&!(typeof val(s,0,r)==='number'&&(spec||u||priceCell.v!=null)))continue;
  if(/^(total|grand total|sum)(\s|$)/i.test(code+' '+name)||norm(code).includes('materialcode'))continue;
  const issues=[],p=number(priceCell.v),d=displayCheck(priceCell);
  if(['name','spec','vnName','unit','hs'].some(k=>m[k]>=0&&(at(s,m[k],r).t==='e'||(at(s,m[k],r).f&&at(s,m[k],r).v==null))))issues.push('field_error');
  if(!code)issues.push('code_missing');else if(codeCell.t==='e')issues.push('code_error');
  if(priceCell.t==='e')issues.push('price_error');
  else if(priceCell.f&&priceCell.v==null)issues.push('formula_missing');
  else if(priceCell.v==null||text(priceCell.v)==='')issues.push('price_missing');
  else if(p===null)issues.push('price_invalid');else if(p<=0)issues.push('price_nonpositive');
  if(!u)issues.push('unit_missing');
  if(!name)issues.push('name_missing');
  if(!spec)issues.push('spec_missing');
  if(!vnName||vnName==='0')issues.push('vnName_missing');
  if(!h)issues.push('hs_missing');else if(!/^\d{8}$/.test(hs(h)))issues.push('hs_format');
  if(d.issue)issues.push(d.issue);
  if(p!==null&&decimalPlaces(p)>6)issues.push('stored_precision');
  if(p!==null&&decimalPlaces(d.shown)>6)issues.push('display_precision');
  rows.push({row:r+1,code,name,spec,vnName,unit:u,hs:h,price:p,raw:text(priceCell.v),shown:d.shown,format:priceCell.z||'General',formula:priceCell.f||'',issues,priceCell:col(m.price)+(r+1),hsCell:m.hs>=0?col(m.hs)+(r+1):'',codeCell:col(m.code)+(r+1),unitCell:m.unit>=0?col(m.unit)+(r+1):'',nameCell:m.name>=0?col(m.name)+(r+1):'',specCell:m.spec>=0?col(m.spec)+(r+1):'',vnNameCell:m.vnName>=0?col(m.vnName)+(r+1):''});
 }
 if(!rows.length)throw Error('rows_missing');
 const groups=new Map();for(const r of rows){if(!r.code||r.issues.includes('code_error'))continue;if(!groups.has(r.code))groups.set(r.code,[]);groups.get(r.code).push(r);}
 for(const a of groups.values()){
  const names=new Set(a.map(r=>text(r.name).normalize('NFC').replace(/\s+/g,' ')).filter(Boolean));
  const units=new Set(a.map(r=>unit(r.unit)).filter(Boolean));
  const prices=new Set(a.filter(r=>r.price!==null).map(r=>canonical(r.price)));
  const hss=new Set(a.map(r=>hs(r.hs)).filter(Boolean));
  for(const r of a){if(a.length>1){r.issues.push('code_duplicate');r.duplicateRows=a.map(v=>v.row);}if(names.size>1)r.issues.push('internal_name');if(units.size>1)r.issues.push('internal_unit');if(prices.size>1)r.issues.push('internal_price');if(hss.size>1)r.issues.push('internal_hs');}
 }
 return rows;
}
function compare(rows,source){
 const index=new Map();
 if(source)for(const m of source.bom){if(!index.has(m.code))index.set(m.code,[]);index.get(m.code).push(m);}
 return rows.map(r=>{
  const issues=[...r.issues],matches=source&&r.code&&!r.issues.includes('code_error')?(index.get(r.code)||[]):[];
  let status=!source?'waiting':matches.length?'common':'new';
  if(!r.code||r.issues.includes('code_error'))status='unreadable';
  if(matches.length){
   const clean=v=>text(v).normalize('NFC').replace(/\s+/g,' ');
   for(const k of ['name','spec','vnName']){
    const known=matches.filter(m=>text(m[k])&&text(m[k])!=='0');
    if(known.length<matches.length)issues.push('source_'+k+'_missing');
    if(text(r[k])&&text(r[k])!=='0'&&known.length){const same=known.filter(m=>clean(m[k])===clean(r[k]));if(!same.length)issues.push(k+'_difference');else if(same.length!==known.length)issues.push(k+'_partial');}
   }
   const u=unit(r.unit),validUnit=matches.filter(m=>unit(m.unit)===u&&u);
   if(matches.some(m=>!text(m.unit)))issues.push('source_unit_missing');
   if(matches.some(m=>number(m.price)===null))issues.push('source_price_missing');
   if(matches.some(m=>!text(m.hs)))issues.push('source_hs_missing');
   if(matches.some(m=>text(m.hs)&&!/^\d{8}$/.test(hs(m.hs))))issues.push('source_hs_format');
   if(u&&matches.some(m=>unit(m.unit)&&unit(m.unit)!==u))issues.push('unit_difference');
   const comparable=validUnit.filter(m=>number(m.price)!==null);
   if(r.price!==null&&comparable.length){const a=comparable.filter(m=>equal(number(m.price),r.price));if(!a.length)issues.push('price_difference');else if(a.length!==comparable.length)issues.push('price_partial');}
   const hh=hs(r.hs),knownHs=matches.filter(m=>text(m.hs));
   if(hh&&knownHs.length){const a=knownHs.filter(m=>hs(m.hs)===hh);if(!a.length)issues.push('hs_difference');else if(a.length!==knownHs.length)issues.push('hs_partial');}
   if(validUnit.length&&r.price!==null&&hh&&!validUnit.some(m=>equal(number(m.price),r.price)&&hs(m.hs)===hh)&&validUnit.some(m=>equal(number(m.price),r.price))&&knownHs.some(m=>hs(m.hs)===hh))issues.push('combination');
  }
  return {...r,internalIssues:[...r.issues],issues:[...new Set(issues)],status,matches};
 });
}
function sourceJSON(data,company){
 if(!data||data.schema!==1||!Array.isArray(data.bom)||!data.bom.length)throw Error('source_invalid');
 const co={AMO:'AMO',AMOVINA:'AMO',AGV:'AGV',AMOGREEN:'AGV',AMOGREENVINA:'AGV'}[String(data.company).toUpperCase()];
 if(co!==company)throw Error('company_mismatch');
 if(data.bom.length>100000||data.bom.some(m=>!m||typeof m.code!=='string'||!text(m.code)))throw Error('source_invalid');
 return {...data,company:co,bom:data.bom.map(m=>({...m,code:text(m.code)}))};
}
function sourceWorkbook(wb,company){
 const name=wb.SheetNames.find(n=>norm(n)==='bomlist');if(!name)throw Error('source_invalid');
 const s=wb.Sheets[name],b=bounds(s),bom=[];
 const pName=wb.SheetNames.find(n=>norm(n)==='product'),ps=pName?wb.Sheets[pName]:null;
 const fromProduct=ps?(norm(val(ps,5,2))==='productcode'&&norm(val(ps,6,2))==='productname'?'AMO':norm(val(ps,4,2))==='productcode'&&norm(val(ps,5,2))==='productname'?'AGV':''):'';
 const known=companyOf(s)||fromProduct;if(known&&known!==company)throw Error('company_mismatch');
 // Confirm a recognizable BOM header before using the established source mapping.
 const header=Array.from({length:4},(_,r)=>norm(val(s,4,r))).join(' ');
 if(!/code|코드/.test(header))throw Error('source_invalid');
 const expected={4:'materialcode',5:'materialname',6:'spec',7:'hscode',8:'vietnam',11:'unit',12:'uprice'};
 for(const [c,label] of Object.entries(expected))if(norm(val(s,+c,1))!==label)throw Error('source_invalid');
 const merged=(c,r)=>{const v=val(s,c,r);if(v!=null)return text(v);const m=(s['!merges']||[]).find(m=>m.s.c<=c&&m.e.c>=c&&m.s.r<=r&&m.e.r>=r);return m?text(val(s,m.s.c,m.s.r)):'';};
 for(let r=4;r<=b.e.r;r++){
  const code=identifier(at(s,4,r));if(!code)continue;
  if([4,5,6,7,8,11,12].some(c=>at(s,c,r).t==='e'||(at(s,c,r).f&&at(s,c,r).v==null)))throw Error('source_formula');
  bom.push({code,name:text(val(s,5,r)),spec:text(val(s,6,r)),vnName:text(val(s,8,r)),hs:identifier(at(s,7,r)),unit:text(val(s,11,r)),price:val(s,12,r)??'',project:merged(2,r),contract:merged(1,r),product:merged(3,r),source:name+'!'+(r+1)});
 }
 return {...sourceJSON({schema:1,company,bom},company),detectedCompany:known};
}
root.CommonMaterialCore={detect,extract,compare,sourceJSON,sourceWorkbook,companyOf,displayCheck,decimalPlaces,number,equal,unit,hs};
if(typeof module!=='undefined')module.exports=root.CommonMaterialCore;
})(typeof window!=='undefined'?window:globalThis);
