(function(){'use strict';
const fields=['classification','code','name','spec','vnName','unit','price','hs','details'];
const esc=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const isOverview=selection=>Array.isArray(selection)&&selection.length===0;
const matches=(issues,selection)=>isOverview(selection)||CommonMaterialReasonFilter.matches(issues,selection);
const value=(r,key)=>String(key==='price'?(r.raw??r.price??''):r[key]??'').trim()||'—';
const values=(rows,key)=>[...new Set(rows.map(r=>value(r,key)+(key==='price'&&new Set(rows.map(m=>m.unit)).size>1?' ['+value(r,'unit')+']':'')))].map(esc).join('<br>');
const headings=t=>'<tr>'+fields.map(k=>'<th>'+esc(t(k==='price'?'newContractPrice':k))+'</th>').join('')+'</tr>';
function cells(rows,status,button,t){return fields.map(k=>'<td class="overview-'+k+'">'+(k==='classification'?'<span class="badge '+esc(status)+'">'+esc(t(status))+'</span>':k==='details'?button:values(rows,k))+'</td>').join('');}
function detail(rows,t,location){const keys=['code','name','spec','vnName','unit','price','hs'];return '<div class="tablewrap"><table class="overview-detail"><thead><tr>'+[...keys.map(k=>k==='price'?'newContractPrice':k),'location'].map(k=>'<th>'+esc(t(k))+'</th>').join('')+'</tr></thead><tbody>'+rows.map(r=>'<tr>'+[...keys.map(k=>value(r,k)),location(r)].map(v=>'<td>'+esc(v).replace(/\n/g,'<br>')+'</td>').join('')+'</tr>').join('')+'</tbody></table></div>';}
window.CommonMaterialOverview={isOverview,matches,headings,cells,detail};
})();
