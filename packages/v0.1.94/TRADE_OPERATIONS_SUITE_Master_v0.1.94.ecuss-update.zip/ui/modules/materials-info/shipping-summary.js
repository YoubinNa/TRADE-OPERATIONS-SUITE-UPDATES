/* Additive v1 shipping projection inside the latest catalogue envelope. */
(function(root){'use strict';
const ids={AMO:'amo',AMOGREEN:'agv',amo:'amo',agv:'agv'};
const keys={
 products:['code','name','item','unit','hs','processing','price','hqPrice','source'],
 maximum:['row','code','name','item','value','source'],
 materials:['code','name','r','q','am','unit','source','unitVariants','unitConflict'],
 bom:['product','material','hsVN','per','perFormula','ak','unit','source']
};
function project(raw){
 const used=new Set(raw.bom.map(b=>b.material)),out={schema:1,company:raw.company};
 for(const [name,fields]of Object.entries(keys))out[name]=(name==='materials'?raw[name].filter(r=>used.has(r.code)):raw[name]).map(r=>Object.fromEntries(fields.map(k=>[k,r[k]])));
 out.validation={counts:raw.validation.counts,issues:raw.validation.issues};return out;
}
function read(value,company){
 if(value===undefined)return null;const key=ids[company];
 if(!value||value.schema!==1||!key||value.company!==key)throw Error('shipping_identity');
 for(const name of Object.keys(keys)){
  if(!Array.isArray(value[name])||value[name].length>100000)throw Error('shipping_rows');
  for(const row of value[name]){
   if(!row||typeof row!=='object'||Array.isArray(row))throw Error('shipping_row');
   for(const [field,v]of Object.entries(row)){
    if(!keys[name].includes(field))throw Error('shipping_field');
    if(field==='unitVariants'){if(!Array.isArray(v)||v.some(s=>typeof s!=='string'))throw Error('shipping_units');}
    else if(v!==null&&!['string','number','boolean'].includes(typeof v))throw Error('shipping_value');
   }
   for(const field of name==='bom'?['product','material']:['code'])if(typeof row[field]!=='string')throw Error('shipping_code');
  }
 }
 if(!value.validation||!Array.isArray(value.validation.issues)||value.validation.issues.length>500000||!value.validation.counts||typeof value.validation.counts!=='object')throw Error('shipping_validation');
 for(const i of value.validation.issues)if(!i||typeof i.product!=='string'||typeof i.material!=='string'||typeof i.stage!=='string'||typeof i.rule!=='string'||typeof i.level!=='string'||typeof i.source!=='string')throw Error('shipping_issue');
 return structuredClone(value);
}
async function extract(input,company){
 const bytes=input instanceof Uint8Array?input:new Uint8Array(await input.arrayBuffer()),key=ids[company];if(!key)throw Error('shipping_company');
 const data=await root.BalanceCatalog.extract(bytes,company);
 const raw=await root.ShippingXlsx.read(bytes,key,'');
 data.shipping=project(raw);read(data.shipping,company);return data;
}
root.ShippingSummary={extract,project,read};if(typeof module!=='undefined')module.exports=root.ShippingSummary;
})(globalThis);
