/* Minimal Balance Sheet catalogue. No quantities/history, no formula evaluation. */
(function(root){'use strict';
const norm=s=>String(s??'').toUpperCase().replace(/[^A-Z0-9]/g,''),ids={amo:'AMO',agv:'AMOGREEN',AMO:'AMO',AMOGREEN:'AMOGREEN'};
const decode=s=>s.replace(/\r\n?/g,'\n').replace(/&(#x[\da-f]+|#\d+|amp|lt|gt|quot|apos);/gi,(_,x)=>x[0]==='#'?String.fromCodePoint(x[1].toLowerCase()==='x'?parseInt(x.slice(2),16):+x.slice(1)):({amp:'&',lt:'<',gt:'>',quot:'"',apos:"'"}[x]));
const attr=(s,k)=>decode((s.match(new RegExp('(?:^|\\s)'+k+'="([^"]*)"'))||[])[1]||'');
const excelText=s=>s.replace(/_x([0-9a-f]{4})_/gi,(_,h)=>String.fromCharCode(parseInt(h,16)));
async function extract(input,company,Zip=root.JSZip){
 company=ids[company];if(!company)throw Error('catalog_company');
 const zip=await Zip.loadAsync(input),entries=Object.values(zip.files);if(entries.length>10000)throw Error('catalog_limit');
 let total=0;for(const e of entries){total+=e._data?.uncompressedSize||0;if((e._data?.uncompressedSize||0)>64000000||total>256000000)throw Error('catalog_limit');}
 async function read(path){const f=zip.file(path);if(!f)throw Error('catalog_sheet');const s=await f.async('string');if(s.length>64000000||/<!DOCTYPE|<!ENTITY/i.test(s))throw Error('catalog_xml');return s;}
 const wb=await read('xl/workbook.xml'),rels=await read('xl/_rels/workbook.xml.rels');
 const strings=zip.file('xl/sharedStrings.xml')?[...(await read('xl/sharedStrings.xml')).matchAll(/<si\b[^>]*>([\s\S]*?)<\/si>/g)].map(m=>[...m[1].replace(/<rPh\b[^>]*>[\s\S]*?<\/rPh>/g,'').matchAll(/<t\b[^>]*>([\s\S]*?)<\/t>/g)].map(t=>decode(t[1])).join('')):[];
 const formats=new Map();let styles=[];
 if(zip.file('xl/styles.xml')){const x=await read('xl/styles.xml');for(const m of x.matchAll(/<numFmt\s([^>]*?)\/?\s*>/g))formats.set(attr(m[1],'numFmtId'),attr(m[1],'formatCode'));styles=[...((x.match(/<cellXfs\b[^>]*>([\s\S]*?)<\/cellXfs>/)||[])[1]||'').matchAll(/<xf\s([^>]*?)\/?\s*>/g)].map(m=>formats.get(attr(m[1],'numFmtId'))||'');}
 async function sheet(name){
  const found=[...wb.matchAll(/<sheet\s([^>]*?)\/?\s*>/g)].filter(m=>norm(attr(m[1],'name'))===norm(name));if(found.length!==1)throw Error('catalog_sheet');
  const links=[...rels.matchAll(/<Relationship\s([^>]*?)\/?\s*>/g)].filter(m=>attr(m[1],'Id')===attr(found[0][1],'r:id'));if(links.length!==1||attr(links[0][1],'TargetMode')==='External')throw Error('catalog_link');
  const target=attr(links[0][1],'Target');if(/[\\:]/.test(target))throw Error('catalog_path');const parts=[];for(const p of (target.startsWith('/')?target.slice(1):'xl/'+target).split('/')){if(p==='..'){if(!parts.length)throw Error('catalog_path');parts.pop();}else if(p&&p!=='.')parts.push(p);}const path=parts.join('/');if(!path.startsWith('xl/worksheets/'))throw Error('catalog_path');
  const xml=await read(path),cells=new Map(),merged=new Map();let last=0;
  for(const m of xml.matchAll(/<c\b([^>]*?)(?:\/>|>([\s\S]*?)<\/c>)/g)){
   const a=attr(m[1],'r'),t=attr(m[1],'t'),body=m[2]||'',r=+a.replace(/^[A-Z]+/,'');if(!/^[A-Z]{1,3}[1-9]\d{0,5}$/.test(a)||r>100006||cells.has(a))throw Error('catalog_cell');last=Math.max(last,r);
   let v=(body.match(/<v\b[^>]*>([\s\S]*?)<\/v>/)||[])[1];v=v===undefined?'':decode(v);if(t==='s'){if(!/^\d+$/.test(v)||+v>=strings.length)throw Error('catalog_string');v=strings[+v];}if(t==='inlineStr')v=[...body.matchAll(/<t\b[^>]*>([\s\S]*?)<\/t>/g)].map(x=>decode(x[1])).join('');
   cells.set(a,{v,t,f:/<f\b/.test(body),fmt:styles[+attr(m[1],'s')]||''});
  }
  for(const m of xml.matchAll(/<mergeCell\s([^>]*?)\/?\s*>/g)){const a=attr(m[1],'ref').match(/^([BCD])(\d+):\1(\d+)$/);if(!a)continue;const lo=+a[2],hi=+a[3];if(lo<1||hi>100006||hi<lo)throw Error('catalog_merge');for(let r=lo;r<=hi;r++){const k=a[1]+r;if(merged.has(k))throw Error('catalog_merge');merged.set(k,lo);}}
  function get(col,row,inherit=false,id=false){const a=col+(inherit?(merged.get(col+row)||row):row),c=cells.get(a);if(!c)return '';if(c.t==='e'||c.f&&c.v==='')throw Error('catalog_value');let v=c.v;if(id&&['','n'].includes(c.t)&&/^\d+$/.test(v)&&/^0{2,30}$/.test(c.fmt))v=v.padStart(c.fmt.length,'0');return v;}
  return {get,last,header(row,cols){for(const [col,label]of Object.entries(cols))if(norm(get(col,row))!==norm(label))throw Error('catalog_header');}};
 }
 const p=await sheet('PRODUCT'),b=await sheet('BOM LIST');
 const cols=company==='AMO'?{code:'F',name:'G',unit:'E',part:'I',customer:'J',cost:'K',hs:'M',processing:'N',price:'O',item:'P'}:{code:'E',name:'F',unit:'I',part:'H',cost:'J',hs:'L',processing:'M',price:'N',item:'O'};
 p.header(3,{C:'CONTRACT NO.',D:'LIQUIDATION NO.',[cols.code]:'PRODUCT CODE',[cols.name]:'PRODUCT NAME',[cols.unit]:'UNIT',[cols.part]:'PART NAME',[cols.hs]:'HS CODE',[cols.processing]:'PROCESSING U/PRICE',[cols.price]:'HQ U/PRICE',[cols.item]:'ITEM',[cols.cost]:'COST CODE',...(cols.customer?{[cols.customer]:'CUST CODE'}:{})});
 b.header(2,{B:'CONTRACT NO.',C:'MODEL NAME',D:'PRODUCT CODE',E:'MATERIAL CODE',F:'MATERIAL NAME',G:'SPEC',H:'HS CODE',I:'VIETNAM',L:'UNIT',M:'U/PRICE',N:'BOM'});
 const products=[],bom=[];
 for(let r=6;r<=p.last;r++){const code=p.get(cols.code,r,false,true);if(!code)continue;const row={code};for(const [key,col]of Object.entries(cols))if(key!=='code')row[key]=p.get(col,r,false,key==='hs');row.contract=p.get('C',r,true);row.liquidation=p.get('D',r,true);row.source='PRODUCT!'+r;products.push(row);}
 for(let r=5;r<=b.last;r++){const code=b.get('E',r,false,true);if(!code)continue;const product=b.get('D',r,true,true);if(!product)throw Error('catalog_product_link');bom.push({code,product,contract:b.get('B',r,true),project:b.get('C',r,true),name:b.get('F',r),spec:excelText(b.get('G',r)),vnName:excelText(b.get('I',r)),hs:b.get('H',r,false,true),unit:b.get('L',r),price:b.get('M',r),qty:b.get('N',r),source:'BOM LIST!'+r});}
 if(!products.length||!bom.length)throw Error('catalog_empty');
 return {schema:1,company,products,bom};
}
function expand(data,info){
 if(data?.schema!==1||data.company!==info.company||!Array.isArray(data.products)||!Array.isArray(data.bom)||data.products.length>100000||data.bom.length>100000)throw Error('catalog_data');
 const key=(contract,code)=>JSON.stringify([contract.trim(),code]),products=data.products.map(p=>({...p,type:'product',materials:[]})),byProduct=new Map(),groups=new Map();
 for(const p of products){if(!p.code||typeof p.code!=='string')throw Error('catalog_code');const k=key(p.contract,p.code),a=byProduct.get(k)||[];a.push(p);byProduct.set(k,a);}
 const materials=data.bom.map(m=>{if(!m.code||typeof m.code!=='string'||!m.product)throw Error('catalog_code');const k=key(m.contract,m.product),a=groups.get(k)||[];a.push({...m});groups.set(k,a);const matches=byProduct.get(k)||[];return {...m,type:'material',item:matches.length===1?matches[0].item:'',processing:null};});
 for(const p of products){const k=key(p.contract,p.code);if(byProduct.get(k).length!==1){delete p.materials;p.bomConnection='계약·제품코드 연결 확인 필요';}else p.materials=groups.get(k)||[];}
 return {rows:[...materials,...products],validatedAt:info.validatedAt,sha256:info.finalHash,sourceKind:'balance',filename:'',loaded:info.validatedAt,shipping:data.shipping===undefined?null:root.ShippingSummary.read(data.shipping,info.company)};
}
async function pack(data,Zip=root.JSZip){const zip=new Zip();zip.file('catalog.json',JSON.stringify(data),{date:new Date(1980,0,1,0,0,0)});return zip.generateAsync({type:'base64',compression:'DEFLATE',compressionOptions:{level:6}});}
async function parse(bytes,key,info,Zip=root.JSZip){if(info.sourceKind!=='balance'||ids[key]!==info.company)throw Error('catalog_source');const zip=await Zip.loadAsync(bytes),f=zip.file('catalog.json');if(!f||Object.keys(zip.files).length!==1||(f._data?.uncompressedSize||0)>16000000)throw Error('catalog_archive');const text=await f.async('string');if(text.length>16000000)throw Error('catalog_limit');return expand(JSON.parse(text),info);}
root.BalanceCatalog={extract,expand,pack,parse};if(typeof module!=='undefined')module.exports=root.BalanceCatalog;
})(globalThis);
