(() => {
'use strict';
// Native settings live outside release and disposable WebView2 folders.
const $=s=>document.querySelector(s),cards=()=>[...document.querySelectorAll('[data-module-card]')];
const known=new Set(cards().map(c=>c.dataset.moduleCard));
const words={ko:{title:'즐겨찾기',add:'즐겨찾기 추가',remove:'즐겨찾기 해제',short:'즐겨찾기',hint:'끌어서 순서 변경',empty:'카드의 ☆ 버튼으로 추가하세요.',drag:'순서 변경 · 드래그 또는 Alt+↑/↓',saved:'이 PC에 저장됨',failed:'로컬 저장에 실패했습니다. 변경사항이 저장되지 않았습니다.',readFailed:'저장된 즐겨찾기를 읽지 못했습니다.',blocked:'현재 사용할 수 없습니다.'},en:{title:'Favorites',add:'Add to favorites',remove:'Remove from favorites',short:'Favorite',hint:'Drag to reorder',empty:'Use ☆ on a module card to add it.',drag:'Reorder · drag or Alt+↑/↓',saved:'Saved on this PC',failed:'Local save failed. Changes were not saved.',readFailed:'Could not read saved favorites.',blocked:'Currently unavailable.'},vi:{title:'Yêu thích',add:'Thêm vào yêu thích',remove:'Bỏ yêu thích',short:'Yêu thích',hint:'Kéo để đổi thứ tự',empty:'Nhấn ☆ trên thẻ để thêm.',drag:'Đổi thứ tự · kéo hoặc Alt+↑/↓',saved:'Đã lưu trên máy này',failed:'Không lưu được thay đổi trên máy này.',readFailed:'Không đọc được mục yêu thích đã lưu.',blocked:'Hiện không khả dụng.'}};
const t=()=>words[document.documentElement.lang]||words.ko;
let ids=[],problem='',dragged=null,dropAfter=false,busy=true;
const section=document.createElement('section');section.className='favorites';section.setAttribute('aria-labelledby','favorites-title');section.innerHTML='<div class="favorites-heading"><strong id="favorites-title"></strong><span id="favorites-count"></span></div><ol id="favorites-list"></ol><p class="favorites-empty"></p><p class="favorites-feedback" role="status" aria-live="polite"></p>';
$('.menu-controls').after(section);
const list=section.querySelector('ol'),feedback=section.querySelector('.favorites-feedback');
const cardFor=id=>cards().find(c=>c.dataset.moduleCard===id);
async function commit(next,focusId=null,focusClass='.favorite-handle'){
 if(busy)return false;busy=true;refresh();
 try{const r=await EcussDesktop.call('/desktop/favorites/save',{version:1,ids:next});if(r.status!==200)throw Error('save');ids=r.value.ids;problem='';}
 catch{problem='failed';return false;}
 finally{busy=false;refresh();}
 if(focusId){const row=[...list.children].find(r=>r.dataset.favoriteId===focusId);row?.querySelector(focusClass)?.focus();}return true;
}
async function toggle(id){const had=ids.includes(id);if(await commit(had?ids.filter(x=>x!==id):[...ids,id]))cardFor(id)?.querySelector('.favorite-toggle')?.focus();}
function move(id,target,after){if(id===target)return;const next=ids.filter(x=>x!==id),index=next.indexOf(target);if(index<0)return;next.splice(index+(after?1:0),0,id);commit(next,id);}
function refresh(){
 for(const card of cards()){
  const id=card.dataset.moduleCard,open=card.querySelector('.open');let button=card.querySelector('.favorite-toggle');
  if(!button){const actions=document.createElement('div');actions.className='card-actions';open.before(actions);actions.append(open);button=document.createElement('button');button.type='button';button.className='favorite-toggle';button.onclick=()=>toggle(id);card.append(button);}
  button.disabled=busy;const selected=ids.includes(id);button.textContent=selected?'★':'☆';button.setAttribute('aria-pressed',String(selected));button.title=(selected?t().remove:t().add)+' · '+card.querySelector('h3').textContent;button.setAttribute('aria-label',button.title);
 }
 const visible=ids.filter(id=>known.has(id));
 $('#favorites-title').textContent='★ '+t().title;$('#favorites-count').textContent=String(visible.length);
 section.querySelector('.favorites-empty').textContent=t().empty;section.querySelector('.favorites-empty').hidden=!!visible.length;
 feedback.textContent=problem?t()[problem]:'';feedback.classList.toggle('error',!!problem);list.replaceChildren();
 visible.forEach(id=>{
  const card=cardFor(id),name=card.querySelector('h3').textContent,disabled=card.querySelector('.open').disabled;
  const row=document.createElement('li');row.dataset.favoriteId=id;row.draggable=!busy;
  const handle=document.createElement('button');handle.type='button';handle.className='favorite-handle';handle.textContent='⠿';handle.title=t().drag;handle.setAttribute('aria-label',t().drag+' · '+name);
  handle.disabled=busy;handle.onkeydown=e=>{if(!e.altKey||!['ArrowUp','ArrowDown'].includes(e.key))return;e.preventDefault();const pos=visible.indexOf(id),target=visible[pos+(e.key==='ArrowUp'?-1:1)];if(target)move(id,target,e.key==='ArrowDown');};
  const launch=document.createElement('button');launch.type='button';launch.className='favorite-launch';launch.textContent=name;launch.disabled=disabled;launch.title=name+(disabled?' · '+t().blocked:'');launch.onclick=()=>cardFor(id)?.querySelector('.open')?.click();
  const remove=document.createElement('button');remove.type='button';remove.className='favorite-remove';remove.textContent='×';remove.title=t().remove;remove.setAttribute('aria-label',t().remove+' · '+name);remove.disabled=busy;remove.onclick=()=>toggle(id);
  row.append(handle,launch,remove);list.append(row);
  row.ondragstart=e=>{if(e.target.closest('.favorite-remove')){e.preventDefault();return;}dragged=id;e.dataTransfer.effectAllowed='move';e.dataTransfer.setData('text/plain',id);row.classList.add('dragging');};
  row.ondragover=e=>{if(!dragged||dragged===id)return;e.preventDefault();e.dataTransfer.dropEffect='move';const rect=row.getBoundingClientRect();dropAfter=e.clientY>=rect.top+rect.height/2;clearMarkers();row.classList.add(dropAfter?'drop-after':'drop-before');};
  row.ondrop=e=>{if(!dragged)return;e.preventDefault();move(dragged,id,dropAfter);dragged=null;clearMarkers();};
  row.ondragend=()=>{dragged=null;clearMarkers();};
 });
}
function clearMarkers(){list.querySelectorAll('li').forEach(r=>r.classList.remove('drop-before','drop-after','dragging'));}
window.EcussFavorites={refresh,ready:(async()=>{
 try{const r=await EcussDesktop.call('/desktop/favorites/load');if(r.status!==200||!Array.isArray(r.value.ids))throw Error('load');ids=r.value.ids;}
 catch{problem='readFailed';}
 finally{busy=false;refresh();}
})()};
refresh();
})();
