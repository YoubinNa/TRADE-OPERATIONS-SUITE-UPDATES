(function(root){'use strict';
const dec=s=>String(s??'').replace(/&(#x[\da-f]+|#\d+|amp|lt|gt|quot|apos);/gi,(_,x)=>x[0]==='#'?String.fromCodePoint(x[1].toLowerCase()==='x'?parseInt(x.slice(2),16):+x.slice(1)):({amp:'&',lt:'<',gt:'>',quot:'"',apos:"'"}[x]));
const attr=(s,k)=>dec((s.match(new RegExp('(?:^|\\s)'+k+'="([^"]*)"'))||[])[1]);
const norm=s=>String(s??'').toUpperCase().replace(/[^A-Z0-9]/g,'');
function scopeMaximum(w,codes){
 const key=x=>String(x??'').toUpperCase(),listed=new Set(codes.map(key)),B=w['BOM LIST'],S=w['SUMMARY LIQUIDATION'];
 const br=new Set(Object.keys(B).filter(a=>/^D\d+$/.test(a)&&listed.has(key(B[a].v))).map(a=>+a.slice(1))),materials=new Set([...br].map(r=>key(B['E'+r]?.v))),outB={},outS={mergedRanges:S.mergedRanges||[]};
 for(const [a,c] of Object.entries(B)){const m=a.match(/^([A-Z]+)(\d+)$/);if(m&&br.has(+m[2]))outB[a]=c;}
 for(const [a,c] of Object.entries(S)){const m=a.match(/^([A-Z]+)(\d+)$/);if(!m)continue;const col=m[1],r=+m[2],mat=materials.has(key(S['F'+r]?.v)),product=listed.has(key(S['E'+r]?.v));if(col==='AN'?!product:col==='F'||col==='AM'?!mat:!(mat||product))continue;outS[a]=c;}
 return {'SUMMARY LIQUIDATION':outS,'BOM LIST':outB};
}
async function read(bytes,key,filename){
 root.StockDashboardReader.zipBounds(bytes);const z=await root.JSZip.loadAsync(bytes);
 async function xml(path){const f=z.file(path);if(!f)throw Error('필수 시트 구성 누락');const s=(await f.async('string')).replace(/\r\n?/g,'\n');if(/<!DOCTYPE|<!ENTITY/.test(s))throw Error('지원하지 않는 XML');return s;}
 const wb=await xml('xl/workbook.xml'),rel=await xml('xl/_rels/workbook.xml.rels'),ss=z.file('xl/sharedStrings.xml')?[...(await xml('xl/sharedStrings.xml')).matchAll(/<si(?:\s[^>]*)?>([\s\S]*?)<\/si>/g)].map(m=>[...m[1].matchAll(/<t(?:\s[^>]*)?>([\s\S]*?)<\/t>/g)].map(t=>dec(t[1])).join('')):[];
 const parts=new Map();for(const m of rel.matchAll(/<Relationship\s([^>]*?)\/?\s*>/g))parts.set(attr(m[1],'Id'),{path:attr(m[1],'Target'),mode:attr(m[1],'TargetMode')});
 const sheets=new Map();for(const m of wb.matchAll(/<sheet\s([^>]*?)\/?\s*>/g)){const r=parts.get(attr(m[1],'r:id'));if(!r||r.mode==='External')continue;const ps=[];for(const t of (r.path.startsWith('/')?r.path.slice(1):'xl/'+r.path).split('/')){if(t==='..')ps.pop();else if(t&&t!=='.')ps.push(t);}sheets.set(norm(attr(m[1],'name')),ps.join('/'));}
 async function sheet(name){const p=sheets.get(norm(name));if(!p)throw Error('필수 시트 없음: '+name);const s=await xml(p),cells=new Map();
  for(const m of s.matchAll(/<c\b([^>]*?)(?:\/>|>([\s\S]*?)<\/c>)/g)){const a=attr(m[1],'r'),t=attr(m[1],'t'),body=m[2]||'';if(cells.has(a))throw Error('중복 셀 주소');let v=(body.match(/<v(?:\s[^>]*)?>([\s\S]*?)<\/v>/)||[])[1]??null;v=v===null?null:dec(v);if(t==='s')v=ss[+v]??null;if(t==='inlineStr')v=[...body.matchAll(/<t(?:\s[^>]*)?>([\s\S]*?)<\/t>/g)].map(x=>dec(x[1])).join('');const f=body.match(/<f\b([^>]*?)(?:\/>|>([\s\S]*?)<\/f>)/);cells.set(a,{v,t:t==='s'||t==='inlineStr'?'str':t,f:f?dec(f[2]||''):null,fa:f?{t:attr(f[1],'t'),si:attr(f[1],'si'),ref:attr(f[1],'ref')}:null});}
  const get=a=>cells.get(a)?.v??'',num=a=>{const c=cells.get(a);return c&&['','n'].includes(c.t)&&root.ShippingCore.d(c.v)!==null?c.v:null;};
  const rows=(col,start)=>[...cells.keys()].filter(a=>new RegExp('^'+col+'\\d+$').test(a)&&+a.slice(col.length)>=start&&get(a)!=='').map(a=>+a.slice(col.length)).sort((a,b)=>a-b);
  const plain=Object.fromEntries(cells);plain.mergedRanges=[...s.matchAll(/<mergeCell\s([^>]*?)\/?\s*>/g)].map(m=>attr(m[1],'ref'));return {cells,get,num,rows,plain};
 }
 const max=await sheet('Maximum'),prod=await sheet('PRODUCT'),bom=await sheet('BOM LIST'),stock=await sheet('SUMMARY LIQUIDATION');
 const detected=norm(prod.get('F3'))==='PRODUCTCODE'&&norm(prod.get('G3'))==='PRODUCTNAME'?'amo':norm(prod.get('E3'))==='PRODUCTCODE'&&norm(prod.get('F3'))==='PRODUCTNAME'?'agv':null;
 if(!detected)throw Error('지원하는 PRODUCT 양식이 아닙니다.');if(detected!==key)throw Error('선택 법인과 파일의 PRODUCT 양식이 다릅니다. 법인을 확인하세요.');
 for(const [a,h] of Object.entries({B4:'ITEM',C4:'PRODUCTCODE',D4:'NAME',E4:'BOM'}))if(norm(max.get(a))!==h)throw Error('Maximum 헤더 확인 필요: '+a);
 if(bom.rows('D',5).length>100000||stock.rows('F',5).length>100000)throw Error('행 수 범위 초과');
 const ag=key==='agv',pc=ag?'E':'F';const w={'SUMMARY LIQUIDATION':stock.plain,'BOM LIST':bom.plain};root.ValidationCapacity.expandShared(w);const checked=root.ValidationCapacity.validateMaximumChain(scopeMaximum(w,max.rows('C',5).map(r=>max.get('C'+r))),ag?'AMOGREEN':'AMO');const validation={counts:checked.counts,issues:checked.issues.map(i=>({product:i.p,material:i.m,stage:i.capacityAudit.stage,rule:i.rule,level:i.level,source:i.s+'!'+i.a}))};
 const listed=new Set(max.rows('C',5).map(r=>max.get('C'+r)));
 const products=prod.rows(pc,6).filter(r=>listed.has(prod.get(pc+r))).map(r=>({code:prod.get(pc+r),name:prod.get((ag?'F':'G')+r),item:prod.get((ag?'O':'P')+r),unit:prod.get((ag?'I':'E')+r),hs:prod.get((ag?'L':'M')+r),processing:prod.num((ag?'M':'N')+r),price:prod.num((ag?'N':'O')+r),source:'PRODUCT!'+r}));
 const maximum=max.rows('C',5).map(r=>({row:r,code:max.get('C'+r),name:max.get('D'+r),item:max.get('B'+r),value:max.num('E'+r),source:'Maximum!E'+r}));
 const materials=stock.rows('F',ag?5:6).map(r=>({code:stock.get('F'+r),name:stock.get('G'+r),r:stock.num('R'+r),q:stock.num('Q'+r),am:stock.num('AM'+r),unit:'',source:'SUMMARY LIQUIDATION!R'+r+'−Q'+r}));
 const bs=bom.rows('D',5).filter(r=>listed.has(bom.get('D'+r))).map(r=>({product:bom.get('D'+r),material:bom.get('E'+r),per:bom.num('N'+r),perFormula:bom.cells.get('N'+r)?.f||false,ak:bom.num('AK'+r),unit:bom.get('L'+r),source:'BOM LIST!'+r}));
 const units=new Map();for(const b of bs){if(!units.has(b.material))units.set(b.material,new Set());if(b.unit)units.get(b.material).add(String(b.unit).trim());}for(const m of materials){const u=[...(units.get(m.code)||[])],canonical=new Set(u.map(x=>/^(EA|PCS|PC)$/i.test(x)?'PCS':x.toUpperCase()));m.unit=canonical.size===1?u[0]:u.join(' / ');m.unitVariants=u;m.unitConflict=canonical.size>1;}
 return {company:key,filename,products,maximum,materials,bom:bs,validation};
}
root.ShippingXlsx={read,scopeMaximum};if(typeof module!=='undefined')module.exports=root.ShippingXlsx;
})(globalThis);
