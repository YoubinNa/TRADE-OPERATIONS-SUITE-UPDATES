(function(root){'use strict';
// Fixed-point exact decimals. Source numeric exponents are bounded before conversion.
const S=10n**80n;
function d(x){if(x===null||x===undefined||x==='')return null;const m=String(x).match(/^([+-]?)(\d+)(?:\.(\d*))?(?:e([+-]?\d+))?$/i);if(!m)return null;const e=+(m[4]||0),fraction=m[3]||'',shift=80+e-fraction.length;if(Math.abs(e)>40||shift<0||m[2].length+fraction.length>80)return null;return (m[1]==='-'?-1n:1n)*BigInt(m[2]+fraction)*10n**BigInt(shift);}
const abs=x=>x<0n?-x:x,ceilDiv=(a,b)=>(a+b-1n)/b;
function str(n,places=6,up=false){if(n===null)return '확인 필요';const f=10n**BigInt(80-places);let x=up?ceilDiv(abs(n),f):(abs(n)+f/2n)/f;let s=x.toString().padStart(places+1,'0'),a=places?s.slice(0,-places):s,b=places?s.slice(-places).replace(/0+$/,''):'';return(n<0n?'-':'')+a+(b?'.'+b:'');}
function tol(a,b){return abs(a-b)<=((abs(b)/10000000000n)>S/1000000n?abs(b)/10000000000n:S/1000000n);}
function analyze(raw){
 const materials=new Map(),bom=new Map(),products=new Map(),listed=new Set(raw.maximum.map(r=>r.code));
 for(const r of raw.materials){const old=materials.get(r.code);materials.set(r.code,{...r,stock:d(r.r)!==null&&d(r.q)!==null?d(r.r)-d(r.q):null,duplicate:!!old});}
 for(const r of raw.bom){if(!listed.has(r.product))continue;if(!bom.has(r.product))bom.set(r.product,[]);bom.get(r.product).push({...r,per:d(r.per)});}
 for(const r of raw.products){if(!listed.has(r.code))continue;const old=products.get(r.code);products.set(r.code,{...r,duplicate:!!old,maximum:[],issues:[],notes:[]});}
 for(const r of raw.maximum){if(!products.has(r.code))products.set(r.code,{code:r.code,name:r.name,item:r.item,unit:'',maximum:[],issues:[],notes:['PRODUCT에 없음']});products.get(r.code).maximum.push(r);}
 for(const p of products.values()){
  if(!p.maximum.length)p.notes.push('Maximum에 없음');if(p.maximum.length>1||p.duplicate)p.issues.push('제품코드 중복');
  const bs=bom.get(p.code)||[];p.bom=bs;if(!bs.length)p.issues.push('BOM 없음');const used=new Set();let cap=null,rawCap=null;
  for(const b of bs){const m=materials.get(b.material);if(!b.material||used.has(b.material)){p.issues.push('BOM 자재코드 누락/중복');continue;}used.add(b.material);
   if(b.per===null||b.per<=0n||b.perFormula){p.issues.push('BOM 소요량 확인 필요');continue;}
   if(!m||m.duplicate||m.stock===null){p.issues.push('자재 잔량 확인 필요');continue;}
   if(m.unitConflict)p.issues.push('자재 단위 충돌');
   if(d(m.am)===null||!tol(d(m.am),m.stock))p.issues.push('AM 잔량 저장값 불일치');
   if(d(b.ak)===null||!tol(d(b.ak),m.stock*S/b.per))p.issues.push('AK 환산 저장값 불일치');
   const rawQ=m.stock*S/b.per;rawCap=rawCap===null||rawQ<rawCap?rawQ:rawCap;const q=m.stock>0n?m.stock/b.per:0n;cap=cap===null||q<cap?q:cap;
  }
  p.findings=(raw.validation?.issues||[]).filter(i=>i.stage==='AM'?used.has(i.material):String(i.product).toUpperCase()===String(p.code).toUpperCase());
  if(p.findings.length)p.issues.push('Maximum 계산 경로 검증 필요');
  const mx=p.maximum[0],saved=mx?d(mx.value):null;p.saved=mx?mx.value:null;
  if(mx&&saved===null)p.issues.push('Maximum 저장값 오류');
  if(rawCap!==null&&saved!==null&&!tol(saved,rawCap))p.issues.push('Maximum 원본/재계산 불일치');
  if(saved!==null&&saved<0n)p.notes.push('원본 가능수량 음수');
  if(!p.unit)p.notes.push('제품 단위 미기재');
  p.item=mx?.item||p.item||'';p.name=mx?.name||p.name||'';
  p.issues=[...new Set(p.issues)];p.rawCapacity=rawCap;p.calculatedInteger=cap;
  p.blockers=p.issues.filter(x=>['제품코드 중복','BOM 없음','BOM 자재코드 누락/중복','BOM 소요량 확인 필요','자재 잔량 확인 필요'].includes(x));
  p.capacity=p.blockers.length?null:cap;
 }
 const order=new Map(raw.maximum.map((r,i)=>[r.code,i]));
 return {...raw,materialMap:materials,productMap:products,list:[...products.values()].sort((a,b)=>order.get(a.code)-order.get(b.code))};
}
function compare(p,input){if(input===undefined||input==='')return 'empty';if(!/^\d+$/.test(String(input))||BigInt(input)<=0n||BigInt(input)>1000000000000n||d(p.saved)===null)return 'unknown';return BigInt(input)*S<=d(p.saved)?'ok':'short';}
function simulate(model,plan,imports={}){
 if(Object.keys(plan).length>1)return {status:'unknown',rows:[],errors:['제품은 1개씩만 시뮬레이션할 수 있습니다.'],count:0,reviewProducts:[]};
 const demand=new Map(),errors=[],reviewProducts=[];let count=0;
 for(const [code,input] of Object.entries(plan)){
  if(!/^\d+$/.test(String(input))||BigInt(input)<=0n||BigInt(input)>1000000000000n){errors.push(code+': 출하계획은 1 이상의 정수');continue;}
  const p=model.productMap.get(code);if(!p||p.capacity===null){errors.push(code+': '+(p?.blockers.join(', ')||'제품 없음'));continue;}
  if(p.issues.length)reviewProducts.push(code);
  count++;const q=BigInt(input);
  for(const b of p.bom){const old=demand.get(b.material)||{need:0n,products:[]};old.need+=b.per*q;old.products.push(code);demand.set(b.material,old);}
 }
 const rows=[];for(const [code,x] of demand){const m=model.materialMap.get(code),extra=d(imports[code]??'0');if(extra===null||extra<0n){errors.push(code+': 추가 수입량 확인 필요');continue;}
  const shortage=x.need>m.stock?x.need-m.stock:0n,left=m.stock+extra-x.need;
  const piece=/^(EA|PCS|PC|CAI\/CHIEC|CÁI\/CHIẾC|TAM|TẤM)$/i.test(m.unit||'');
  const purchase=shortage===0n?'0':str(shortage,piece?0:6,true);
  rows.push({code,name:m.name,unit:m.unit,need:x.need,stock:m.stock,extra,left,shortage,purchase,products:x.products,source:m.source});
 }
 rows.sort((a,b)=>a.left<0n&&b.left>=0n?-1:b.left<0n&&a.left>=0n?1:a.code.localeCompare(b.code));
 return {status:errors.length?'unknown':!count?'empty':rows.some(r=>r.left<0n)?'short':reviewProducts.length?'review':'ok',rows,errors,count,reviewProducts};
}
root.ShippingCore={d,str,analyze,simulate,compare,close:tol,S};if(typeof module!=='undefined')module.exports=root.ShippingCore;
})(globalThis);
