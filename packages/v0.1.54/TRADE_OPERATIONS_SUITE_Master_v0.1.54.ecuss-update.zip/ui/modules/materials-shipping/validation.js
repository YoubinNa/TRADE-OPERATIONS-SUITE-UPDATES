/* Maximum-chain validator reused from YoubinNa/-Validation_for_Balance_sheet-, blob 97c8bfef2e38f2e40dbd3fd35577fddca94dc2e4. Does not run the full STOCK ON DOCUMENT validation. */
(function(root){
function colNum(s){return [...s].reduce((n,c)=>n*26+c.charCodeAt(0)-64,0)}
function colName(n){let s='';while(n>0){n--;s=String.fromCharCode(65+n%26)+s;n=Math.floor(n/26)}return s}
function shiftFormula(f,from,to){let a=from.match(/([A-Z]+)(\d+)/),b=to.match(/([A-Z]+)(\d+)/),dc=colNum(b[1])-colNum(a[1]),dr=+b[2]-a[2];return f.split(/("(?:[^"]|"")*")/g).map((p,i)=>i%2?p:p.replace(/(?<![A-Za-z0-9_])([$]?)([A-Z]{1,3})([$]?)(\d+)(?![A-Za-z0-9_(])/g,(m,ac,c,ar,r)=>ac+(ac?c:colName(colNum(c)+dc))+ar+(ar?r:+r+dr))).join('')}
function expandShared(w){for(const sh of Object.values(w)){const masters={};for(const [a,c]of Object.entries(sh))if(c.fa?.t==='shared'&&c.f)masters[c.fa.si]=[a,c.f];for(const[a,c]of Object.entries(sh))if(c.fa?.t==='shared'&&!c.f){let m=masters[c.fa.si];c.f=m?shiftFormula(m[1],m[0],a):'#UNRESOLVED_SHARED!';} }return w}
// Version 2: user-defined checks only. Arithmetic is parsed; workbook formulas are never executed as JavaScript.
function arithmetic(formula,read,referenceOnly=false){
 let s=formula.replace(/^=/,'').replace(/\$/g,''),p=0;
 function ws(){while(/\s/.test(s[p]||'')&&p<s.length)p++}
 function expr(){let a=term();ws();while(s[p]==='+'||s[p]==='-'){let op=s[p++],b=term();a=op==='+'?a+b:a-b;ws()}return a}
 function term(){let a=atom();ws();while(s[p]==='*'||s[p]==='/'){let op=s[p++],b=atom();a=op==='*'?a*b:a/b;ws()}return a}
 function atom(){ws();if(s[p]==='+'){p++;return atom()}if(s[p]==='-'){p++;return -atom()}if(s[p]==='('){p++;let v=expr();ws();if(s[p++]!==')')throw Error('syntax');return v}
  let f=s.slice(p).match(/^(ROUND|SUM|MINA|MIN)\s*\(/i);if(f){if(/^MINA?$/.test(f[1].toUpperCase())&&!referenceOnly)throw Error('unsupported');p+=f[0].length;const arg=()=>{ws();if(referenceOnly&&/^MINA?$/.test(f[1].toUpperCase())&&[',',';',')'].includes(s[p]))return 0;return expr()};let args=[arg()];ws();while(s[p]===','||s[p]===';'){p++;args.push(arg());ws()}if(s[p++]!==')')throw Error('syntax');return /^MINA?$/.test(f[1].toUpperCase())?Math.min(...args):f[1].toUpperCase()==='SUM'?args.reduce((a,b)=>a+b,0):Math.sign(args[0])*Math.round(Math.abs(args[0])*10**args[1]+1e-9)/10**args[1]}
  let r=s.slice(p).match(/^(?:'([^']+)'!|([A-Z_][A-Z_ ]*)!)?([A-Z]{1,3}\d+)/i);if(r){p+=r[0].length;ws();if(s[p]===':'){p++;let end=s.slice(p).match(/^([A-Z]{1,3})(\d+)/i),start=r[3].match(/^([A-Z]+)(\d+)/i);if(!end)throw Error('range');p+=end[0].length;let c1=colNum(start[1].toUpperCase()),c2=colNum(end[1].toUpperCase()),r1=+start[2],r2=+end[2];if(c2<c1||r2<r1||(c2-c1+1)*(r2-r1+1)>100000)throw Error('range');let sum=0;for(let row=r1;row<=r2;row++)for(let col=c1;col<=c2;col++)sum+=read(colName(col)+row,r[1]||r[2]||'');return sum}return read(r[3].toUpperCase(),r[1]||r[2]||'')}
  let n=s.slice(p).match(/^(?:\d+(?:\.\d*)?|\.\d+)(?:E[+-]?\d+)?/i);if(n){p+=n[0].length;return +n[0]}throw Error('unsupported');
 }let n=expr();ws();if(p!==s.length||!referenceOnly&&!Number.isFinite(n))throw Error('unsupported');return n;
}

function capacityEquivalent(formula, sheet, row, variables, expected, zeroVariables=[]) {
 const clean=p=>{for(const[k,v]of p)if(v===0)p.delete(k);if(p.size>256)throw Error('complex');return p};
 const plus=(a,b,sign=1)=>{let p=new Map(a);for(const[k,v]of b)p.set(k,(p.get(k)||0)+sign*v);return clean(p)};
 const times=(a,b)=>{let p=new Map();for(const[ka,va]of a)for(const[kb,vb]of b){const k=[...ka,...kb].sort().join('');p.set(k,(p.get(k)||0)+va*vb)}return clean(p)};
 const one=new Map([['',1]]),scalar=n=>[new Map(n?[['',n]]:[]),one];
 const combine=(a,b,op)=>op==='*'?[times(a[0],b[0]),times(a[1],b[1])]:op==='/'?[times(a[0],b[1]),times(a[1],b[0])]:[plus(times(a[0],b[1]),times(b[0],a[1]),op==='-'?-1:1),times(a[1],b[1])];
 function parse(text){let s=text.replace(/^=/,'').replace(/\$/g,''),p=0,refs=[];
  const ws=()=>{while(p<s.length&&/\s/.test(s[p]))p++};
  function expr(){let a=term();ws();while(['+','-'].includes(s[p])){let op=s[p++];a=combine(a,term(),op);ws()}return a}
  function term(){let a=atom();ws();while(['*','/'].includes(s[p])){let op=s[p++];a=combine(a,atom(),op);ws()}return a}
  function atom(){ws();if(s[p]==='+'){p++;return atom()}if(s[p]==='-'){p++;return combine(scalar(-1),atom(),'*')}if(s[p]==='('){p++;let a=expr();ws();if(s[p++]!==')')throw Error('syntax');return a}
   let m=s.slice(p).match(/^SUM\s*\(/i);if(m){p+=m[0].length;let a=expr();ws();while([',',';'].includes(s[p])){p++;a=combine(a,expr(),'+');ws()}if(s[p++]!==')')throw Error('syntax');return a}
   m=s.slice(p).match(/^(?:'([^']+)'!|([A-Z_][A-Z_ ]*)!)?([A-Z]{1,3})(\d+)/i);
   if(m){p+=m[0].length;let col=m[3].toUpperCase(),a=col+m[4];refs.push({s:m[1]||m[2]||sheet,a});if((m[1]||m[2]||sheet).toUpperCase()!==sheet||+m[4]!==row||!variables.includes(col))throw Error('reference');return zeroVariables.includes(col)?scalar(0):[new Map([[col,1]]),one]}
   m=s.slice(p).match(/^(?:\d+(?:\.\d*)?|\.\d+)(?:E[+-]?\d+)?/i);if(m){p+=m[0].length;return scalar(+m[0])}throw Error('unsupported');
  }const val=expr();ws();if(p!==s.length)throw Error(s[p]===':'?'reference':'unsupported');if(!val[1].size)throw Error('zero');return val;
 }
 try{const a=parse(formula),b=parse(expected);return{ok:plus(times(a[0],b[1]),times(b[0],a[1]),-1).size===0,reason:'structure'}}catch(e){return{ok:false,reason:e.message}}
}

/* Product capacity v27: SUMMARY AM=R-Q; BOM AK=matched AM/N;
   SUMMARY AN=MINIFS(BOM AK,BOM D,own E). No workbook writes. */
function capacityFormulaTools(){
 const normalize=f=>String(f||'').replace(/^\s*=\s*/,'').replace(/_xlfn\.|_xlws\./gi,'').replace(/\$/g,'').trim();
 function split(s,sep=','){let out=[],start=0,depth=0,quote='';for(let i=0;i<s.length;i++){const c=s[i];if(quote){if(c===quote){if(s[i+1]===quote)i++;else quote=''}continue}if(c==='"'||c==="'"){quote=c;continue}if(c==='(')depth++;if(c===')')depth--;if(depth<0)throw Error('syntax');if(depth===0&&(c===sep||sep===','&&c===';')){out.push(s.slice(start,i).trim());start=i+1}}if(quote||depth)throw Error('syntax');out.push(s.slice(start).trim());return out}
 function outer(s){s=s.trim();while(s[0]==='('&&s.at(-1)===')'){let depth=0,ends=false;for(let i=0;i<s.length;i++){if(s[i]==='(')depth++;if(s[i]===')')depth--;if(depth===0&&i<s.length-1){ends=true;break}}if(ends)break;s=s.slice(1,-1).trim()}return s}
 function call(s){s=outer(s);const m=s.match(/^([A-Z][A-Z0-9_.]*)\s*\(([\s\S]*)\)$/i);return m?{name:m[1].toUpperCase(),args:split(m[2])}:null}
 function reference(s,def){s=outer(s);const m=s.match(/^(?:'((?:[^']|'')+)'!|([A-Z_][A-Z0-9_ ]*)!)?([A-Z]{1,3})(\d+)?(?::([A-Z]{1,3})(\d+)?)?$/i);if(!m)return null;const sheet=(m[1]?.replace(/''/g,"'")||m[2]||def).toUpperCase(),left=m[3].toUpperCase(),right=(m[5]||m[3]).toUpperCase();if(!m[5]&&!m[4]||m[5]&&!!m[4]!==!!m[6])return null;const first=m[4]?+m[4]:1,last=m[5]?(m[6]?+m[6]:1048576):first;if(first<1||last<first||last>1048576||colNum(left)>colNum(right)||colNum(right)>16384)return null;return{s:sheet,left,right,first,last,a:left+first,single:!m[5]&&!!m[4]}}
 const isCell=(ref,s,c,r)=>ref?.single&&ref.s===s&&ref.left===c&&ref.first===r;
 const isColumn=(ref,s,c)=>ref&&ref.s===s&&ref.left===c&&ref.right===c;
 return{normalize,split,outer,call,reference,isCell,isColumn};
}

function validateMaximumChain(w,profile='AMO'){
 const S='SUMMARY LIQUIDATION',B='BOM LIST',sh=w[S]||{},bom=w[B]||{},issues=[],counts={am:0,ak:0,an:0},start=profile==='AMOGREEN'?5:6;
 const F=capacityFormulaTools(),val=(s,a)=>w[s]?.[a]?.v,blank=x=>x==null||String(x).trim()==='',key=x=>String(x??'').toUpperCase();
 const numeric=(s,a)=>{const c=w[s]?.[a];return c&&!blank(c.v)&&!['s','str','inlineStr','e'].includes(c.t)&&Number.isFinite(Number(c.v))?Number(c.v):NaN};
 const close=(a,b)=>Number.isFinite(a)&&Number.isFinite(b)&&Math.abs(a-b)<=Math.max(1e-6,Math.abs(b)*1e-10);
 const finite=x=>Number.isFinite(x)?x:null,cell=(s,a)=>({s,a});
 function rowIndex(s,col,first){const map=new Map();for(const[a,c]of Object.entries(w[s]||{})){const m=a.match(/^([A-Z]+)(\d+)$/);if(m&&m[1]===col&&+m[2]>=first&&!blank(c.v)){const k=key(c.v);if(!map.has(k))map.set(k,[]);map.get(k).push(+m[2])}}return map}
 const summaryIndex=rowIndex(S,'F',start),productIndex=rowIndex(B,'D',5),materialIndex=rowIndex(B,'E',5);
 const bomRows=[...new Set([...productIndex.values(),...materialIndex.values()].flat())].sort((a,b)=>a-b),am=new Map(),ak=new Map();
 const merged=(sh.mergedRanges||[]).map(range=>{const m=range.match(/^([A-Z]+)(\d+):([A-Z]+)(\d+)$/);return m?{range,anchor:m[1]+m[2],first:+m[2],last:+m[4],left:colNum(m[1]),right:colNum(m[3])}:null}).filter(m=>m&&m.left<=colNum('AN')&&m.right>=colNum('AN'));
 const mergeFor=a=>{const r=+a.match(/\d+$/)?.[0];return merged.find(m=>(/^AN/.test(a)||a===m.anchor)&&r>=m.first&&r<=m.last)};
 const targets=[...new Set(Object.keys(sh).filter(a=>/^AN\d+$/.test(a)).map(a=>mergeFor(a)?.anchor||a))].filter(a=>+a.match(/\d+$/)[0]>=start&&(sh[a]?.f||!blank(sh[a]?.v)));
 const targetIndex=new Map();for(const a of targets){const p=key(val(S,'E'+a.match(/\d+$/)[0]));if(!targetIndex.has(p))targetIndex.set(p,[]);targetIndex.get(p).push(a)}
 const refsUnique=refs=>[...new Map(refs.map(r=>[r.s+'!'+r.a,r])).values()];
 function base(stage,s,a,p,m,expected,formula,refs,detail={}){return{category:'d',scope:'core',s,a,r:+a.match(/\d+$/)[0],p:p??'',m:m??'',actual:val(s,a)??'',formula:w[s]?.[a]?.f||'',expected:finite(expected),expectedFormula:formula,refs:refsUnique(refs),capacityAudit:{stage,basis:'savedRQ',...detail}}}
 const add=(item,rule,level='error',extra={})=>issues.push({...item,rule,level,...extra});
 function compare(item,expected,savedMath,expectedMath){if(Number.isFinite(expected)&&!(blank(item.actual)&&!item.formula)&&!close(numeric(item.s,item.a),expected))add(item,'value','mismatch',{numericProof:{saved:savedMath||{expression:null,result:null},expected:{expression:expectedMath,result:expected}}})}
 function requiredFormula(item){const c=w[item.s]?.[item.a];if(c?.t==='e')add(item,'excelError');if(!c?.f){add(item,'capacityNoFormula');return false}if(c.f.includes('#REF!')){add(item,'broken');return false}return true}
 const pairRows=new Map();for(const r of bomRows){const p=val(B,'D'+r),m=val(B,'E'+r);if(blank(p)||blank(m))continue;const k=key(p)+'\u0000'+key(m);if(!pairRows.has(k))pairRows.set(k,[]);pairRows.get(k).push(r)}
 for(const rs of pairRows.values())if(rs.length>1){const r=rs[0],p=val(B,'D'+r),m=val(B,'E'+r);add(base('AK',B,'AK'+r,p,m,NaN,'',rs.flatMap(rr=>['D','E','N','AK'].map(c=>cell(B,c+rr))),{duplicateRows:rs}),'capacityBomDuplicate','review')}

 // AM expectations use saved R and Q, not cached AM. R source validation stays in c2.
 for(const rows of summaryIndex.values())for(const r of rows){counts.am++;const a='AM'+r,p=val(S,'E'+r),m=val(S,'F'+r),R=numeric(S,'R'+r),Q=numeric(S,'Q'+r),expected=R-Q;am.set(r,expected);
  const linkedBOM=materialIndex.get(key(m))||[],affected=[...new Set(linkedBOM.flatMap(br=>targetIndex.get(key(val(B,'D'+br)))||[]))];
  const refs=['E','F','R','Q','AM'].map(c=>cell(S,c+r));refs.push(...linkedBOM.map(br=>cell(B,'AK'+br)),...affected.map(a=>cell(S,a)));
  const expression=`(${R})-(${Q})`,item=base('AM',S,a,p,m,expected,`R${r}-Q${r}`,refs,{inputs:[{s:S,a:'R'+r,label:'R',value:finite(R)},{s:S,a:'Q'+r,label:'Q',value:finite(Q)}],expression,affected});
  let savedMath=null;if(requiredFormula(item)){
   const shape=capacityEquivalent(item.formula,S,r,['R','Q'],item.expectedFormula);if(!shape.ok)add(item,shape.reason==='unsupported'&&!/\bMIN(A)?\s*\(/i.test(item.formula)?'capacityUnsupported':'capacityAmFormula',shape.reason==='unsupported'&&!/\bMIN(A)?\s*\(/i.test(item.formula)?'review':'error');
   try{const n=arithmetic(item.formula,(a,s)=>numeric(s||S,a));savedMath={expression:item.formula.replace(/\$/g,'').replace(/'SUMMARY LIQUIDATION'!/gi,'').replace(/\b[A-Z]{1,3}\d+\b/g,a=>'('+numeric(S,a)+')'),result:n}}catch{}
  }
  if(!Number.isFinite(expected))add(item,'capacitySourceUnknown','review');else compare(item,expected,savedMath,expression);
 }

 function inspectAkFormula(item,r,sourceRows){
  const numeratorAndDenom=F.split(F.outer(F.normalize(item.formula)),'/');if(numeratorAndDenom.length!==2){add(item,'capacityUnsupported','review');return null}
  const [numerator,denominator]=numeratorAndDenom,den=F.reference(denominator,B);if(!F.isCell(den,B,'N',r))add(item,'capacityUsageReference');
  let source=null,lookup=F.call(numerator),lookupOK=false;
  if(lookup?.name==='XLOOKUP'){
   const a=lookup.args,k=F.reference(a[0]||'',B),lookupRange=F.reference(a[1]||'',B),returnRange=F.reference(a[2]||'',B);
   const modes=(a[4]===undefined||a[4]===''||a[4]==='0')&&(a[5]===undefined||a[5]===''||['1','-1'].includes(a[5]));
   if(a.length<3||a.length>6||!F.isCell(k,B,'E',r)||!F.isColumn(lookupRange,S,'F')||!F.isColumn(returnRange,S,'AM')||!modes){add(item,'capacityLookup');return null}
   if(lookupRange.first!==returnRange.first||lookupRange.last!==returnRange.last){add(item,'capacityRangeAlignment');return null}
   const inside=sourceRows.filter(rr=>rr>=lookupRange.first&&rr<=lookupRange.last);if(inside.length!==sourceRows.length||!inside.length){add(item,'capacityRange');return null}
   source=a[5]==='-1'?inside.at(-1):inside[0];lookupOK=true;
  }else if(lookup?.name==='VLOOKUP'){
   const a=lookup.args,k=F.reference(a[0]||'',B),range=F.reference(a[1]||'',B);
   if(a.length!==4||!F.isCell(k,B,'E',r)||!range||range.s!==S||range.left!=='F'||colNum(range.right)<colNum('AM')||Number(a[2])!==34||!['0','FALSE'].includes(a[3]?.toUpperCase())){add(item,'capacityLookup');return null}
   const inside=sourceRows.filter(rr=>rr>=range.first&&rr<=range.last);if(inside.length!==sourceRows.length||!inside.length){add(item,'capacityRange');return null}source=inside[0];lookupOK=true;
  }else{
   const direct=F.reference(numerator,B);if(direct?.single&&direct.s===S&&direct.left==='AM'){source=direct.first;lookupOK=sourceRows.includes(source);if(!lookupOK)add(item,'capacityLookup')}else{add(item,'capacityUnsupported','review');return null}
  }
  if(lookupOK&&source!=null&&den?.single){const numeratorValue=numeric(S,'AM'+source),denValue=numeric(den.s,den.a);if(Number.isFinite(numeratorValue)&&denValue>0)return{expression:`(${numeratorValue})/(${denValue})`,result:numeratorValue/denValue}}
  return null;
 }
 for(const r of bomRows){counts.ak++;const a='AK'+r,p=val(B,'D'+r),m=val(B,'E'+r),sourceRows=summaryIndex.get(key(m))||[],rate=numeric(B,'N'+r),source=sourceRows.length===1?sourceRows[0]:null;
  const available=source!=null?am.get(source):NaN,expected=rate>0?available/rate:NaN;ak.set(r,expected);
  const refs=['D','E','N','AK'].map(c=>cell(B,c+r));refs.push(...sourceRows.flatMap(rr=>['F','R','Q','AM'].map(c=>cell(S,c+rr))));const affected=targetIndex.get(key(p))||[];refs.push(...affected.map(a=>cell(S,a)));
  const expression=`(${available})/(${rate})`,item=base('AK',B,a,p,m,expected,source!=null?`'SUMMARY LIQUIDATION'!AM${source}/N${r}`:`XLOOKUP(E${r},'SUMMARY LIQUIDATION'!F:F,'SUMMARY LIQUIDATION'!AM:AM)/N${r}`,refs,{sourceRows,rate:finite(rate),available:finite(available),expression,affected,inputs:[{s:B,a:'N'+r,label:'N',value:finite(rate)},...sourceRows.map(rr=>({s:S,a:'AM'+rr,label:'AM',value:val(S,'AM'+rr),expected:finite(am.get(rr))}))]});
  if(blank(p))add(item,'capacityProductMissing');if(blank(m))add(item,'capacityMaterialMissing');
  if(!sourceRows.length)add(item,'capacityMaterialMissing');else if(sourceRows.length>1)add(item,'capacityMaterialDuplicate','review');
  if(bom['N'+r]?.f)add(item,'capacityUsageFormula');if(!Number.isFinite(rate)||rate<=0)add(item,'capacityUsage');
  let savedMath=null;if(requiredFormula(item))try{savedMath=inspectAkFormula(item,r,sourceRows)}catch{add(item,'capacityUnsupported','review')}
  if(!Number.isFinite(expected))add(item,'capacitySourceUnknown','review');else compare(item,expected,savedMath,expression);
 }
 const components=r=>{const m=val(B,'E'+r),rs=summaryIndex.get(key(m))||[],sr=rs.length===1?rs[0]:null;return{bomRow:r,material:m??'',sourceRows:rs,rate:finite(numeric(B,'N'+r)),stock:sr==null?null:finite(numeric(S,'R'+sr)),rma:sr==null?null:finite(numeric(S,'Q'+sr)),available:sr==null?null:finite(am.get(sr)),storedAK:val(B,'AK'+r)??'',expectedAK:finite(ak.get(r))}};
 // Keep AK findings visible at every dependent AN, even if AN happens to be zero.
 const akErrors=new Set(),akReviews=new Set();
 for(const i of issues)if(i.capacityAudit?.stage==='AK'){
  const rows=i.capacityAudit.duplicateRows||[i.r];
  for(const r of rows)(i.level==='review'?akReviews:akErrors).add(r);
 }
 for(const a of targets){counts.an++;const r=+a.match(/\d+$/)[0],p=val(S,'E'+r),brs=blank(p)?[]:productIndex.get(key(p))||[],parts=brs.map(components),values=brs.map(r=>ak.get(r)),expected=values.length&&values.every(Number.isFinite)?Math.min(...values):NaN,expression='MIN('+values.map(x=>'('+x+')').join(', ')+')';
  const cached=brs.map(br=>numeric(B,'AK'+br)),direct=brs.length&&cached.every(Number.isFinite)?Math.min(...cached):NaN;
  const directExpression='MIN('+cached.map(x=>'('+x+')').join(', ')+')';
  const badRows=brs.filter(br=>akErrors.has(br)||!Number.isFinite(numeric(B,'AK'+br))),reviewRows=brs.filter(br=>akReviews.has(br));
  const refs=[cell(S,'E'+r),...brs.flatMap(br=>['D','E','N','AK'].map(c=>cell(B,c+br))),...parts.flatMap(x=>x.sourceRows.flatMap(sr=>['F','R','Q','AM'].map(c=>cell(S,c+sr))))];
  const item=base('AN',S,a,p,'',expected,`MINIFS('BOM LIST'!AK:AK,'BOM LIST'!D:D,E${r})`,refs,{parts,expression,bottleneckRows:brs.filter(br=>close(ak.get(br),expected)),mergedRange:mergeFor(a)?.range||null,directMinimum:finite(direct),directExpression,directBottleneckRows:brs.filter(br=>close(numeric(B,'AK'+br),direct)),akErrorRows:badRows,akReviewRows:reviewRows});
  if(blank(p))add(item,'capacityProductMissing');else if(!brs.length)add(item,'capacityBomMissing');
  if(badRows.length)add(item,'capacityAkError');else if(reviewRows.length)add(item,'capacityAkReview','review');
  let savedMath=null;if(requiredFormula(item))try{
   const call=F.call(F.normalize(item.formula));let minRange,criteriaRange,productRef,parsed=false;
   if(call?.name==='MINIFS'){
    if(call.args.length!==3)add(item,'capacityAnCondition');
    else{minRange=F.reference(call.args[0],S);criteriaRange=F.reference(call.args[1],S);productRef=F.reference(call.args[2],S);parsed=true;}
   }else if(call?.name==='MIN'&&call.args.length===1&&F.call(call.args[0])?.name==='IF'){
    const fa=sh[a]?.fa,ar=fa?.ref?F.reference(fa.ref,S):null;
    if(fa?.t!=='array'||!ar||ar.a!==a||ar.s!==S||r<ar.first||r>ar.last||colNum(a.match(/^[A-Z]+/)[0])<colNum(ar.left)||colNum(a.match(/^[A-Z]+/)[0])>colNum(ar.right))add(item,'capacityArrayMissing');
    const inner=F.call(call.args[0]),args=inner.args;
    if(args.length<2||args.length>3)add(item,'capacityAnCondition');
    else{
     const falseArg=args[2]===undefined?undefined:F.outer(args[2]).toUpperCase();
     if(falseArg!==undefined&&!['FALSE','FALSE()','""'].includes(falseArg))add(item,'capacityArrayFalse');
     const condition=F.split(F.outer(args[0]),'=');minRange=F.reference(args[1],S);
     if(condition.length!==2)add(item,'capacityAnCondition');
     else{let l=F.reference(condition[0],S),rr=F.reference(condition[1],S);
      if(l?.single&&!rr?.single){productRef=l;criteriaRange=rr;}else{criteriaRange=l;productRef=rr;}parsed=true;
     }
    }
   }else add(item,/\bMIN(A)?\s*\(/i.test(item.formula)||/^\s*=?\s*\$?AM\$?\d+\s*$/i.test(item.formula)?'capacityOldMethod':'capacityUnsupported',/\bMIN(A)?\s*\(/i.test(item.formula)||/^\s*=?\s*\$?AM\$?\d+\s*$/i.test(item.formula)?'error':'review');
   if(parsed){
    if(!F.isColumn(minRange,B,'AK')||!F.isColumn(criteriaRange,B,'D'))add(item,'capacityAnRange');
    else if(minRange.first!==criteriaRange.first||minRange.last!==criteriaRange.last)add(item,'capacityRangeAlignment');
    else{
     const criteriaP=productRef?.single?val(productRef.s,productRef.a):null;
     const selected=blank(criteriaP)?[]:(productIndex.get(key(criteriaP))||[]).filter(br=>br>=criteriaRange.first&&br<=criteriaRange.last),saved=selected.map(br=>numeric(B,'AK'+br));
     if(saved.length&&saved.every(Number.isFinite))savedMath={expression:'MIN('+saved.map(n=>'('+n+')').join(', ')+')',result:Math.min(...saved)};
     if(brs.some(br=>br<criteriaRange.first||br>criteriaRange.last))add(item,'capacityRange');
    }
    if(!F.isCell(productRef,S,'E',r))add(item,'capacityAnCondition');
   }
  }catch{add(item,'capacityUnsupported','review')}
  // Direct comparison is independent of parsing the submitted formula.
  if(Number.isFinite(direct)){
   if(!close(numeric(S,a),direct))add({...item,expected:direct,expectedFormula:`MINIFS('BOM LIST'!AK:AK,'BOM LIST'!D:D,E${r})`,capacityAudit:{...item.capacityAudit,expression:directExpression}},'capacityAkMinimum','mismatch',{numericProof:{saved:savedMath||{expression:null,result:null},expected:{expression:directExpression,result:direct}}});
  }
  if(brs.length&&!Number.isFinite(expected))add(item,'capacitySourceUnknown','review');else compare(item,expected,savedMath,expression);
 }

 return{issues,counts};
}


root.ValidationCapacity={validateMaximumChain,expandShared};
if(typeof module!=="undefined")module.exports=root.ValidationCapacity;
})(globalThis);

