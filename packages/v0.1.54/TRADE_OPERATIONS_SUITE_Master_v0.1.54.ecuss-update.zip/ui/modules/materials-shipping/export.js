(function(root){'use strict';
const xml=s=>String(s??'').replace(/[\x00-\x08\x0B\x0C\x0E-\x1F]/g,'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&apos;'}[c]));
async function build(report){
 const zip=await JSZip.loadAsync(ShippingExportTemplate.base64,{base64:true}),st=ShippingExportTemplate.styles,rows=[];
 const numeric=v=>v&&typeof v==='object'&&'n' in v;
 const style=(v,short=false)=>short?(numeric(v)?(/^[-+]?\d+$/.test(String(v.n))?st.J:st.F):st.H):numeric(v)?(/^[-+]?\d+$/.test(String(v.n))?st.I:st.B):st.A;
 const cell=(ref,v,s)=>numeric(v)?'<c r="'+ref+'" s="'+s+'"><v>'+xml(v.n)+'</v></c>':'<c r="'+ref+'" s="'+s+'" t="inlineStr"><is><t xml:space="preserve">'+xml(v)+'</t></is></c>';
 function row(n,values,styles,height=30,cols=null){rows.push('<row r="'+n+'" ht="'+height+'" customHeight="1">'+values.map((v,i)=>cell((cols?.[i]||String.fromCharCode(65+i))+n,v,styles[i])).join('')+'</row>');}
 const productCols=['A','B','C','E','F','G','H','I'];
 row(1,report.productHeaders,Array(8).fill(st.D),42,productCols);
 const productHeight=Math.max(36,Math.ceil(String(report.product[0]).length/20)*15,Math.ceil(String(report.product[2]).length/28)*15);
 row(2,report.product,report.product.map((v,i)=>i===7?st.G:style(v)),productHeight,productCols);
 row(4,[report.section],[st.C],27);
 row(5,report.headers,report.headers.map((_,i)=>i===6?st.E:st.D),54);
 let n=6;for(const values of report.rows){const shortage=values[6]&&typeof values[6]==='object'&&Number(values[6].n)>0;row(n++,values,values.map((v,i)=>shortage?(i===6?(numeric(v)&&/^[-+]?\d+$/.test(String(v.n))?st.Q:st.P):i===9?st.R:numeric(v)?(/^[-+]?\d+$/.test(String(v.n))?st.O:st.N):st.M):(i===9?st.G:style(v,i===6))),Math.max(30,Math.ceil(String(values[0]).length/20)*15,Math.ceil(String(values[1]).length/30)*15));}
 const last=Math.max(5,n-1),widths=[22,34,14,20,22,22,22,22,22,22],merges=['C1:D1','C2:D2','I1:J1','I2:J2'];
 const worksheet='<?xml version="1.0" encoding="UTF-8" standalone="yes"?><worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetPr><pageSetUpPr fitToPage="1"/></sheetPr><dimension ref="A1:J'+last+'"/><sheetViews><sheetView workbookViewId="0" showGridLines="0"><pane ySplit="5" topLeftCell="A6" activePane="bottomLeft" state="frozen"/></sheetView></sheetViews><sheetFormatPr defaultRowHeight="24"/><cols>'+widths.map((w,i)=>'<col min="'+(i+1)+'" max="'+(i+1)+'" width="'+w+'" customWidth="1"/>').join('')+'</cols><sheetData>'+rows.join('')+'</sheetData>'+(last>5?'<autoFilter ref="A5:J'+last+'"/>':'')+'<mergeCells count="4">'+merges.map(x=>'<mergeCell ref="'+x+'"/>').join('')+'</mergeCells><pageMargins left="0.25" right="0.25" top="0.4" bottom="0.4" header="0.2" footer="0.2"/><pageSetup paperSize="9" orientation="landscape" fitToWidth="1" fitToHeight="0"/></worksheet>';
 zip.file('xl/worksheets/sheet1.xml',worksheet);
 return zip.generateAsync({type:'uint8array',compression:'DEFLATE'});
}
async function download(report,filename){const bytes=await build(report),url=URL.createObjectURL(new Blob([bytes],{type:'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'})),a=document.createElement('a');a.href=url;a.download=filename;document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),1000);}
root.ShippingExport={build,download};
})(globalThis);
