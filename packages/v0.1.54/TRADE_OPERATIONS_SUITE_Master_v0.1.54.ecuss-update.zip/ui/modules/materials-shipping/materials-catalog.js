/* Suite-owned read-only adapter. Cached OOXML values only; no formula evaluation. */
(function(root){'use strict';
const norm=s=>String(s??'').toUpperCase().replace(/[^A-Z0-9]/g,'');
const decode=s=>String(s??'').replace(/&(#x[\da-f]+|#\d+|amp|lt|gt|quot|apos);/gi,(_,x)=>x[0]==='#'?String.fromCodePoint(x[1].toLowerCase()==='x'?parseInt(x.slice(2),16):+x.slice(1)):({amp:'&',lt:'<',gt:'>',quot:'"',apos:"'"}[x]));
const attr=(s,k)=>decode((s.match(new RegExp('(?:^|\\s)'+k+'="([^"]*)"'))||[])[1]);
async function parse(bytes,key,info,Zip=root.JSZip){
 if(!['amo','agv'].includes(key))throw Error('법인 오류');root.StockDashboardReader.zipBounds(bytes);const zip=await Zip.loadAsync(bytes);
 async function read(path){const f=zip.file(path);if(!f)throw Error('필수 Excel 구성 누락: '+path);const s=await f.async('string');if(s.length>64000000||/<!DOCTYPE|<!ENTITY/i.test(s))throw Error('지원하지 않는 XML');return s.replace(/\r\n?/g,'\n');}
 const wb=await read('xl/workbook.xml'),rels=await read('xl/_rels/workbook.xml.rels');
 const strings=zip.file('xl/sharedStrings.xml')?[...(await read('xl/sharedStrings.xml')).matchAll(/<si(?:\s[^>]*)?>([\s\S]*?)<\/si>/g)].map(m=>[...m[1].matchAll(/<t(?:\s[^>]*)?>([\s\S]*?)<\/t>/g)].map(t=>decode(t[1])).join('')):[];
 const formats=new Map();let styles=[];
 if(zip.file('xl/styles.xml')){const xml=await read('xl/styles.xml');for(const m of xml.matchAll(/<numFmt\s([^>]*?)\/?\s*>/g))formats.set(attr(m[1],'numFmtId'),attr(m[1],'formatCode'));const x=(xml.match(/<cellXfs\b[^>]*>([\s\S]*?)<\/cellXfs>/)||[])[1]||'';styles=[...x.matchAll(/<xf\s([^>]*?)\/?\s*>/g)].map(m=>formats.get(attr(m[1],'numFmtId'))||'');}
 async function sheet(name,headers){
  const found=[...wb.matchAll(/<sheet\s([^>]*?)\/?\s*>/g)].filter(m=>norm(attr(m[1],'name'))===norm(name));if(found.length!==1)throw Error(name+' 시트 확인 필요');
  const id=attr(found[0][1],'r:id'),links=[...rels.matchAll(/<Relationship\s([^>]*?)\/?\s*>/g)].filter(m=>attr(m[1],'Id')===id);if(links.length!==1||attr(links[0][1],'TargetMode')==='External')throw Error('시트 연결 오류');
  const target=attr(links[0][1],'Target');if(target.includes('\\')||target.includes(':'))throw Error('시트 경로 오류');const parts=[];for(const p of (target.startsWith('/')?target.slice(1):'xl/'+target).split('/')){if(p==='..'){if(!parts.length)throw Error('시트 경로 오류');parts.pop();}else if(p&&p!=='.')parts.push(p);}const path=parts.join('/');if(!path.startsWith('xl/worksheets/'))throw Error('시트 경로 오류');
  const xml=await read(path),cells=new Map();let last=5;
  for(const m of xml.matchAll(/<c\b([^>]*?)(?:\/>|>([\s\S]*?)<\/c>)/g)){
   const a=attr(m[1],'r'),t=attr(m[1],'t'),body=m[2]||'';if(!/^[A-Z]{1,3}[1-9]\d{0,6}$/.test(a)||cells.has(a))throw Error('셀 주소 오류');const r=+a.replace(/^[A-Z]+/,'');if(r>100006)throw Error('행 수 초과');last=Math.max(last,r);
   let v=(body.match(/<v(?:\s[^>]*)?>([\s\S]*?)<\/v>/)||[])[1];v=v===undefined?'':decode(v);
   if(t==='s'){if(!/^\d+$/.test(v)||+v>=strings.length)throw Error('문자열 인덱스 오류');v=strings[+v];}
   if(t==='inlineStr')v=[...body.matchAll(/<t(?:\s[^>]*)?>([\s\S]*?)<\/t>/g)].map(x=>decode(x[1])).join('');
   const fmt=styles[+attr(m[1],'s')];cells.set(a,{v,t,fmt});
  }
  const get=(col,r,identifier=false)=>{const c=cells.get(col+r);if(!c||c.t==='e')return '';let v=c.v;if(identifier&&['','n'].includes(c.t)&&/^\d+$/.test(v)&&/^0{2,30}$/.test(c.fmt||''))v=v.padStart(c.fmt.length,'0');return v;};
  for(const [col,expected] of Object.entries(headers))if(!expected.some(e=>norm(get(col,4))===norm(e)))throw Error(name+' 양식 확인 필요: '+col+'4');
  const rows=[];for(let r=6;r<=last;r++){if(['TOTAL','GRANDTOTAL'].includes(norm(get('A',r))))break;rows.push(r);}return {get,rows};
 }
 const material=await sheet('Summary Liquidation',{A:['Item'],F:['Material Code'],G:['Material Name'],H:['Unit'],I:['HS CODE'],L:['Price']});
 // Handoff fixes data columns and start row, but does not require a literal row-4 product header.
 const product=await sheet('PRODUCT Trading team',{});
 const warehouse=await sheet('Product Warehouse',{});
 const byCode=new Map();for(const r of warehouse.rows){const code=warehouse.get('D',r,true);if(!code)continue;const a=byCode.get(code)||[];a.push({item:warehouse.get('A',r),unit:warehouse.get('F',r)});byCode.set(code,a);}
 const rows=[];let ambiguous=0;
 for(const r of material.rows){const g=c=>material.get(c,r,['F','I'].includes(c));if(!g('F'))continue;rows.push({type:'material',code:g('F'),name:g('G'),item:g('A'),unit:g('H'),hs:g('I'),price:g('L')||null,processing:null,contract:g('B'),liquidation:g('C'),source:'Summary Liquidation!'+r});}
 for(const r of product.rows){const g=c=>product.get(c,r,['D','I'].includes(c));if(!g('D'))continue;const matches=byCode.get(g('D'))||[],match=matches.length===1?matches[0]:null;if(matches.length>1)ambiguous++;rows.push({type:'product',code:g('D'),name:g('E'),item:match?.item||'',unit:match?.unit||'',hs:g('I'),price:g('K')||null,processing:g('J')||null,part:g('G'),customer:g('H'),contract:g('B'),liquidation:g('C'),source:'PRODUCT Trading team!'+r});}
 return {filename:info.finalName,sha256:info.finalHash,loaded:new Date().toISOString(),rows,ambiguous};
}
root.SuiteMaterialsCatalog={parse};if(typeof module!=='undefined')module.exports=root.SuiteMaterialsCatalog;
})(globalThis);
