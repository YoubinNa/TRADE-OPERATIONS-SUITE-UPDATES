(function(root){function zipBounds(bytes){
 if(bytes.length<22||bytes.length>50000000)throw Error('원본 파일 크기 오류');
 const v=new DataView(bytes.buffer,bytes.byteOffset,bytes.byteLength);let end=-1;
 for(let p=bytes.length-22;p>=Math.max(0,bytes.length-65557);p--)if(v.getUint32(p,true)===0x06054b50&&p+22+v.getUint16(p+20,true)===bytes.length){end=p;break;}
 if(end<0||v.getUint16(end+4,true)||v.getUint16(end+6,true))throw Error('지원하지 않는 ZIP');
 const n=v.getUint16(end+10,true);let p=v.getUint32(end+16,true),total=0;
 if(!n||n>10000||p+v.getUint32(end+12,true)!==end)throw Error('ZIP 목록 오류');
 for(let i=0;i<n;i++){
  if(p+46>end||v.getUint32(p,true)!==0x02014b50)throw Error('ZIP 항목 오류');
  const size=v.getUint32(p+24,true),flags=v.getUint16(p+8,true),method=v.getUint16(p+10,true);total+=size;
  if(flags&1||![0,8].includes(method)||size>64000000||total>256000000)throw Error('지원하지 않는 압축 크기/형식');
  p+=46+v.getUint16(p+28,true)+v.getUint16(p+30,true)+v.getUint16(p+32,true);
 }if(p!==end)throw Error('ZIP 목록 경계 오류');
}
root.StockDashboardReader={zipBounds};})(globalThis);