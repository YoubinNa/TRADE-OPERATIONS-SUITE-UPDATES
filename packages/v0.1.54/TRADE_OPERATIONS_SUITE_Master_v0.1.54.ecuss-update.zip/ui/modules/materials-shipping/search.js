(function(root){
 const normalize=(x,key)=>String(x??'').normalize('NFKC').toLocaleLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/đ/g,'d').trim().replace(key==='hs'?/[.\s-]+/g:/\s+/g,key==='hs'?'':' ');
 function rank(rows,queries){const active=Object.entries(queries).map(([k,q])=>[k,normalize(q,k)]).filter(([,q])=>q);if(!active.length)return rows.slice();
  return rows.map((row,i)=>{let score=0;for(const [key,q] of active){const s=normalize(row[key],key);if(s===q)score+=300;else if(s.startsWith(q))score+=200;else if(s.includes(q))score+=100;else return null;}return {row,i,score};}).filter(Boolean).sort((a,b)=>b.score-a.score||a.i-b.i).map(x=>x.row);
 }
 function rankAny(rows,query){const q=normalize(query);if(!q)return rows.slice();return rows.map((row,i)=>({row,i,score:Math.max(...['code','name'].map(key=>{const s=normalize(row[key]);return s===q?300:s.startsWith(q)?200:s.includes(q)?100:0;}))})).filter(x=>x.score>0).sort((a,b)=>b.score-a.score||a.i-b.i).map(x=>x.row);}
 root.ShippingSearch={rank,rankAny,normalize};if(typeof module!=='undefined')module.exports=root.ShippingSearch;
})(globalThis);
