/* Suite adapter: authenticated host storage, atomic version refresh, native Excel save. */
(()=>{'use strict';
const strings={ko:{current:'최신 버전 확인됨',checking:'최신 버전 확인 중…',loading:'자료 불러오는 중…',empty:'등록된 자료가 없습니다.',stale:'오프라인 · 마지막 저장 자료 사용 중',error:'이 PC에 저장된 자료가 없습니다. 인터넷 연결 후 한 번 자료를 불러와 주세요.',checked:'마지막 확인',refresh:'새로 확인',ambiguous:'제품코드 중복으로 ITEM·단위 확인이 필요한 항목',saved:'Excel 파일을 저장했습니다.',cancelled:'저장을 취소했습니다.',failed:'저장 결과를 확인하지 못했습니다.'},en:{current:'Latest version confirmed',checking:'Checking latest version…',loading:'Loading…',empty:'No registered file.',stale:'Offline · Using last saved data',error:'No saved data on this PC. Connect to the Internet and load data once.',checked:'Last checked',refresh:'Refresh',ambiguous:'Products requiring ITEM/unit review due to duplicate codes',saved:'Excel file saved.',cancelled:'Save cancelled.',failed:'Could not confirm the save result.'},vi:{current:'Đã xác nhận phiên bản mới nhất',checking:'Đang kiểm tra phiên bản mới nhất…',loading:'Đang tải…',empty:'Chưa có tệp được đăng ký.',stale:'Ngoại tuyến · Đang dùng dữ liệu đã lưu gần nhất',error:'Chưa có dữ liệu trên máy này. Hãy kết nối mạng và tải dữ liệu một lần.',checked:'Kiểm tra lần cuối',refresh:'Kiểm tra lại',ambiguous:'Sản phẩm cần kiểm tra ITEM/đơn vị do trùng mã',saved:'Đã lưu tệp Excel.',cancelled:'Đã hủy lưu.',failed:'Không xác nhận được kết quả lưu.'}};
const copy=()=>strings[ShippingI18n.lang]||strings.ko;
window.SuiteMaterialsSaveNotice=r=>r?.saved?copy().saved:r?.cancelled?copy().cancelled:copy().failed;
const bar=document.createElement('section');bar.id='suite-catalog-status';bar.className='panel';bar.setAttribute('aria-live','polite');
const title=document.createElement('strong'),detail=document.createElement('span'),warning=document.createElement('div'),refresh=document.createElement('button');
bar.style.cssText='display:flex;align-items:center;gap:14px;flex-wrap:wrap';detail.className='muted';warning.className='error';refresh.type='button';refresh.className='small';refresh.style.marginLeft='auto';bar.append(title,detail,warning,refresh);document.getElementById('view').before(bar);
if(!window.EcussDesktop){title.textContent=copy().error;refresh.disabled=true;return;}
let selectedCompany=null,active=false,event={state:'loading'},applied={};bar.style.display='none';
function render(){const t=copy();title.textContent=t[event.state]||t.error;bar.dataset.state=event.state;detail.textContent=window.SuiteMaterialsView?.().page==='catalog'&&event.snapshot?({ko:'자료 기준',en:'Data as of',vi:'Dữ liệu đến'}[ShippingI18n.lang]||'Data as of')+': '+new Intl.DateTimeFormat('sv-SE',{timeZone:'Asia/Seoul',dateStyle:'short',timeStyle:'medium'}).format(new Date(event.snapshot.info.validatedAt))+' (KST)':'';warning.textContent='';refresh.textContent=t.refresh;refresh.disabled=['loading','checking'].includes(event.state);bar.title=window.__ECUSS_SUITE__?.profile==='master'?(event.error||''):'';}
const provider=StockDashboardSync.nativeProvider({call:(path,payload)=>EcussDesktop.call(path.replace('/stock/dashboard/','/stock/materials/'),payload)},'catalog');
const sync=new StockDashboardSync.Sync(provider,BalanceCatalog.parse,e=>{event=e;if(e.state==='empty'){delete applied[e.key];MaterialsShippingCatalog.clear(e.key);window.MaterialsShippingSource?.clear(e.key);}else if(e.snapshot&&applied[e.key]!==(e.snapshot.info.finalHash+e.snapshot.info.catalogHash)){MaterialsShippingCatalog.set(e.key,{...e.snapshot.data,validatedAt:e.snapshot.info.validatedAt});applied[e.key]=(e.snapshot.info.finalHash+e.snapshot.info.catalogHash);}if(e.snapshot){MaterialsShippingCatalog.confirm(e.key,e.snapshot.info.validatedAt);window.MaterialsShippingSource?.receive(e.key,e.snapshot.data.shipping,e.snapshot.info);}render();});
refresh.addEventListener('click',()=>{if(active&&selectedCompany)sync.refresh();});
function checkPage(){const view=window.SuiteMaterialsView?.(),next=['catalog','shipping'].includes(view?.page)&&!!view.company;
 const entered=next&&(!active||view.company!==selectedCompany);active=next;selectedCompany=view?.company||null;bar.style.display=active?'flex':'none';
 if(entered&&!document.hidden)sync.select(selectedCompany);render();}
// The module's own click handler first commits the accepted company/page change.
document.addEventListener('click',()=>queueMicrotask(checkPage));
const visible=()=>{if(!document.hidden){checkPage();if(active)sync.select(selectedCompany);}};
document.addEventListener('visibilitychange',visible);
window.addEventListener('online',()=>{if(active&&selectedCompany)sync.refresh();});
const timer=setInterval(()=>{if(active&&!document.hidden)sync.refresh();},60000);
window.addEventListener('pagehide',()=>{clearInterval(timer);sync.dispose();document.removeEventListener('visibilitychange',visible);},{once:true});
ShippingExport.download=async(report,filename)=>{const bytes=await ShippingExport.build(report);let binary='';for(let i=0;i<bytes.length;i+=32768)binary+=String.fromCharCode(...bytes.subarray(i,i+32768));const r=await EcussDesktop.call('/stock/materials/export-xlsx',{filename,data:btoa(binary)});if(r.status!==200)throw Error(r.value?.message||copy().failed);return r.value;};
// Wait for explicit company selection before reading shared source data.
})();

