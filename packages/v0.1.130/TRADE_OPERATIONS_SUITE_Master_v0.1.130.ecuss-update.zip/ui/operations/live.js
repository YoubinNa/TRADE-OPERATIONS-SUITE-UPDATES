'use strict';
addTerms('새로고침|Refresh|Làm mới\n업데이트 · 설정|Updates and settings|Cập nhật và cài đặt\n설정을 저장하지 못했습니다.|Settings could not be saved.|Không lưu được cài đặt.\n업무를 열 수 없습니다.|Could not open the module.|Không mở được mô-đun.\n두 법인의 수출·물류비·재고와 검증 현황|Exports, logistics costs, inventory and checks across both companies|Xuất khẩu, chi phí logistics, tồn kho và kiểm tra của hai công ty');
const issueText = {
  waiting: ['자료 확인 중','Loading records','Đang tải dữ liệu'],
  empty: ['등록된 자료 없음','No records','Chưa có dữ liệu'],
  error: ['자료를 확인할 수 없습니다','Records unavailable','Không thể kiểm tra dữ liệu'],
  stale: ['마지막으로 확인한 자료','Last verified data','Dữ liệu xác nhận gần nhất']
};
const emptyRecord=()=>({state:'waiting',data:null});
const pair=()=>({amo:emptyRecord(),agv:emptyRecord()});
const live={trade:pair(),stock:pair(),cost:emptyRecord()};
const labelFor=record=>workL(...(issueText[record.state]||issueText.error));
const staleNote=record=>record.state==='stale'?'<small class="source-note">'+labelFor(record)+'</small>':'';
const panelMessage=record=>'<p class="source-note" role="status">'+labelFor(record)+'</p>';
const companyMessage=(co,record)=>'<div class="stock-line"><b>'+companies[co]+'</b>'+panelMessage(record)+'</div>';
function anchorDate(){
  const day=new Date();
  return String(day.getFullYear()).padStart(4,'0')+'-'+String(day.getMonth()+1).padStart(2,'0')+'-'+String(day.getDate()).padStart(2,'0');
}
function summarizeInventory(parsed){
  const items=new Map();
  let excess=0,short=0,missing=0;
  for(const row of parsed.rows){
    if(row.qty==null||row.amount==null){missing++;continue;}
    const qty=Number(row.qty),amount=Math.abs(Number(row.amount));
    if(!Number.isFinite(qty)||!Number.isFinite(amount)){missing++;continue;}
    if(!qty||!amount)continue;
    const name=String(row.item??'').trim(),item=items.get(name)||{item:name,excess:0,short:0,value:0};
    item.value+=amount;
    if(qty>0){item.excess+=amount;excess+=amount;}else{item.short+=amount;short+=amount;}
    items.set(name,item);
  }
  return {excess,short,missing,date:parsed.date,items:[...items.values()].sort((a,b)=>b.value-a.value||a.item.localeCompare(b.item,'en'))};
}
function redrawBoard(id){
  if(state.scene!=='home'||!host.isHome())return;
  const panel=main.querySelector('[data-widget="'+id+'"]');
  if(!panel)return;
  // Preserve period/help keyboard focus when a new company snapshot arrives.
  const focus=panel.contains(document.activeElement)?document.activeElement:null;
  const key=focus&&['data-export-period','data-info','data-open'].find(k=>focus.hasAttribute(k));
  const co=focus?.closest('[data-export-company]')?.dataset.exportCompany;
  const control=key?'['+key+'="'+CSS.escape(focus.getAttribute(key))+'"]':null;
  const template=document.createElement('template');template.innerHTML=widgetHtml(id);
  const next=template.content.firstElementChild;panel.replaceWith(next);
  if(control)(co?next.querySelector('[data-export-company="'+co+'"]'):next)?.querySelector(control)?.focus({preventScroll:true});
}
function projection(kind,target,id,parser){
  const bridge={call:(path,payload)=>host.call(path.replace('/stock/dashboard/','/home-board/'+kind+'/'),payload)};
  const provider=StockDashboardSync.nativeProvider(bridge,kind==='catalog'?'catalog':'dashboard');
  return new StockDashboardSync.Sync(provider,parser,result=>{
    const record=target[result.key];if(!record)return;
    record.data=result.snapshot?.data||null;
    record.state=['checking','loading'].includes(result.state)?'waiting':result.state;
    redrawBoard(id);
  });
}
async function readExport(bytes,co,info){
  const source=await DailyCatalog.open(bytes,co,info);
  const material=DailyCatalog.readTable(source.daily,'material'),product=DailyCatalog.readTable(source.daily,'product');
  return TradeReport.selectDirection({company:source.company,material,product},'Export');
}
const scripts=new Map(),syncs=new Map();
function loadScript(path){
  if(!scripts.has(path)){
    const script=document.createElement('script');script.src='../modules/'+path;
    scripts.set(path,new Promise((resolve,reject)=>{
      script.onload=resolve;script.onerror=()=>{scripts.delete(path);script.remove();reject(Error(path));};
      document.head.append(script);
    }));
  }
  return scripts.get(path);
}
async function loadProjections(shown){
  const trade='import-export-performance/';
  for(const id of ['imex','inventory']){
    if(!shown(id))continue;
    const isExport=id==='imex',records=isExport?live.trade:live.stock;
    try{
      if(!syncs.has(id)){
        const files=[trade+'vendor/jszip.min.js',trade+'stock-query-sync.js',isExport?trade+'daily-catalog.js':'stock-dashboard/reader.js'];
        await Promise.all(files.map(loadScript));
        syncs.set(id,projection(isExport?'catalog':'inventory',records,id,isExport?readExport:async(bytes,co,info)=>summarizeInventory(await StockDashboardReader.parse(bytes,co,info))));
      }
      // Both projections use the same native transfer session. Leave these reads serial.
      for(const co of ['amo','agv'])if(shown(id))await syncs.get(id).select(co);
    }catch{for(const record of Object.values(records))record.state=record.data?'stale':'error';redrawBoard(id);}
  }
}
async function loadCost(){
  try{
    const reply=await host.call('/home-board/logistics',null);
    if(reply.status!==200)throw Error('read');
    const snapshot=reply.value?.snapshot;
    if(!snapshot){live.cost={state:'empty',data:null};}
    else{
      const months=snapshot.data?.months;
      if(!Number.isInteger(snapshot.reportYear)||!Array.isArray(months)||!months.every(m=>Number.isInteger(m.month)&&m.month>=1&&m.month<=12&&Number.isFinite(m.cost)&&Number.isSafeInteger(m.cases)&&m.cases>=0))throw Error('invalid');
      if(new Set(months.map(m=>m.month)).size!==months.length)throw Error('duplicate month');
      // Match the logistics module's monthKRW: round the aggregated monthly VND cost once.
      const converted=months.map(m=>({...m,costKrw:Math.round(m.cost/20)})).sort((a,b)=>a.month-b.month);
      live.cost={state:months.length?'current':'empty',data:{year:snapshot.reportYear,months:converted}};
    }
  }catch{live.cost.state=live.cost.data?'stale':'error';}
  redrawBoard('logistics');
}
let loading=null,queued=false;
function loadHome(force=false){
  if(state.scene!=='home'||!host.isHome())return;
  if(loading){queued=true;return loading;}
  const shown=id=>state.scene==='home'&&host.isHome()&&savedLayout().some(w=>w.id===id&&w.visible);
  loading=(async()=>{
    if(shown('balanceStatus')||shown('customsStatus'))host.refreshStatus(force);
    await Promise.all([shown('logistics')&&loadCost(),loadProjections(shown)]);
  })().finally(()=>{loading=null;if(queued){queued=false;loadHome();}});
  return loading;
}
function verification(id){
  const balance=id==='balanceStatus',statuses=host.status(),mail=statuses.mail;
  const period=workL(['주간','월간'],['Weekly','Monthly'],['Tuần','Tháng']);
  const flag=(kind,status)=>'<span class="v-flag '+(status===true?'done':status===false?'waiting':'unknown')+'"><i></i>'+kind+(status===true?tr('완료'):status===false?tr('미완료'):status)+'</span>';
  const unknown=workL('확인 필요','Check status','Cần kiểm tra');
  const lines=[['AMO','AMOVINA'],['AMOGREEN','AMOGREEN VINA']].map(([co,name])=>{
    const row=statuses.balance?.find(r=>r.company===co);
    const labels=balance?flag('',row?.mark==='O'?true:row?.mark==='X'?false:row?.mark==='NA'?workL('해당 없음','N/A','Không áp dụng'):unknown):
      ['weekly','monthly'].map((k,i)=>{const item=mail?.rows?.find(r=>r.company===co&&r.reportKind===k);return flag(period[i]+' ',mail?.connection==='connected'&&typeof item?.completed==='boolean'?item.completed:unknown);}).join('');
    return '<div class="v-company"><span class="verification-company" data-entity="'+co+'">'+name+'</span>'+labels+'</div>';
  }).join('');
  const date=new Intl.DateTimeFormat(localeTags[state.lang],{timeZone:'Asia/Seoul',month:'short',day:'numeric'}).format(new Date());
  const subtitle=balance?workL('일일 검증 수행','Daily verification','Kiểm tra hằng ngày'):workL('확인 요청 메일 발송','Verification emails','Email yêu cầu xác nhận');
  return '<article class="panel verification widget-'+id+'" data-widget="'+id+'" data-panel-target="'+widgets[id].target+'" aria-labelledby="title-'+id+'">'+panelHead(id,date+' · '+subtitle)+'<div class="v-companies">'+lines+'</div></article>';
}
function widgetHtml(id){
  if(isVerification(id))return verification(id);
  if(id==='imex')return exportPanel();
  if(id==='inventory')return workInventoryPanel();
  if(id==='logistics')return workLogisticsPanel();
  if(id==='outputs'){
    const ids=['vn-kr-customs-translation','psr-rvc-lvc-calculator','monthly-report-consolidation'];
    return reviewPanel(id,panelHead(id,tr('통관·보고 산출물'))+'<div class="output-links">'+ids.map(k=>'<button data-open="'+k+'">'+escapeText(tr(findModule(k).title))+'</button>').join('')+'</div>');
  }
  const m=findModule(widgets[id].target);
  const latest=host.sessionSummary(widgets[id].target);
  return reviewPanel(id,panelHead(id,escapeText(tr(m.description)))+(latest?'<p class="module-result">'+escapeText(latest)+'</p>':'<p class="source-note">'+workL('모듈에서 결과를 확인하세요.','Open the module to view results.','Mở mô-đun để xem kết quả.')+'</p>'));
}
function info(id){
  dialog.dataset.infoPanel=id;
  const title=tr('월별 물류비 내역');
  const body=live.cost.data?table([workL('월','Month','Tháng'),'KRW',workL('처리 건수','Shipments','Số lô')],live.cost.data.months.map(m=>[monthShort(m.month),fmt(m.costKrw),fmt(m.cases)])):panelMessage(live.cost);
  openModal('info',modalHeader(title)+'<div class="info-body">'+body+'</div>','info-modal');
}

