const workSurfaces={
  'import-export-performance':{panels:'.panel,.item-menu',top:'.masthead'},
  'balance-ecuss':{panels:'.upload-card,.panel,.kpi,.modal-dialog',primary:'#analyze',drops:'.upload-card',top:'.top'},
  'balance-sheet-validation':{panels:'.upload,.coverage,.resulthead,.method,dialog',primary:'#run',drops:'.filelabel'},
  'stock-status-amovina':{panels:'.upload-group,.card,.ratebox,.review,.warehouse-sheets',primary:'#run',drops:'.dropzone',top:'header'},
  'stock-status-amogreen-vina':{panels:'.top-options,.card,.action-card,.gap-panel,.rules',primary:'#run',drops:'.file-row',top:'header'},
  'vn-kr-customs-translation':{panels:'.panel,.metric,.result-file,.file-box',primary:'#run,#select-original',drops:'#original-dropzone'},
  'customs-inspection-cost-comparison':{panels:'.panel,.kpi,.utm,.utm-highlight,.result-comparison,.summary,.verdict,.report-open',primary:'#calculate',top:'#ecuss-page-header'},
  'common-material-review':{panels:'.panel,.companybar,.modebar,.stat,.source-status,.mapping',primary:'#run,#applyMap',drops:'.drop'},
  'machine-information-validation':{panels:'.upload-panel,.upload-card,.panel,.editor-source,.review-source',primary:'#start-validation,#run',drops:'.dropzone',top:'#ecuss-page-header'},
  'shipping-freight-review':{panels:'.panel,.fx,.mode,.aside,.totalbox,.cargo,.statebar',primary:'#addRow',top:'.topbar'},
  'psr-rvc-lvc-calculator':{panels:'.psr-controls,.panel,.sheet,.card,.result-box',primary:'button.primary',top:'body>header'},
  'monthly-report-consolidation':{panels:'.panel,.sidebar,.common-rates,.rule-box,.period',primary:'#run',drops:'.drop',top:'.topbar'},
  'stock-dashboard':{panels:'.card,.panel,.source-download,.selection-summary',primary:'#refreshSource',top:'.topbar'},
  'materials-shipping':{panels:'.panel,.view,.corporations,.toolbar,.result-card,.kpi,.source-card,.message',primary:'[data-action="upload"]',top:'#ecuss-page-header'},
  'materials-info':{panels:'.panel,.view,.corporations,.toolbar,.result-card,.kpi,.source-card,.message',primary:'[data-action="upload"]',top:'#ecuss-page-header'},
  'vietnam-logistics-cost':{panels:'.filters,.logistics-toolbar,.card,.kpi,.insight,.reportbox,.processing-strip',primary:'.uploadLabel',top:'.logistics-header'},
  'stock-status-gap-revision':{panels:'.upload,.metrics>div,.toolbar,.table-wrap',primary:'#apply',drops:'label[for="file"]'},
  'container-stuffing-simulator':{panels:'.side,.container-section,.manifest,.scene-head,.dashboard,.counter,.scene-tools,.camera-tools',primary:'#generate,#optimize',top:'.app-head'},
  'validation-status':{panels:'dialog',primary:'main>button'},'mail-check-status':{panels:'dialog',primary:'main>button'}
};
function workStyleFor(id){
  const s=workSurfaces[id]||{};
  const css=(selectors,body)=>selectors?'html[data-work-theme] :is('+selectors+'){'+body+'}':'';
  return '@media screen{'+
    css(s.panels,'background:var(--ws-surface)!important;color:var(--ws-text)!important;border-color:var(--ws-line)!important;border-radius:12px;box-shadow:0 3px 14px var(--ws-shadow)!important;')+
    css(s.top,'background:var(--ws-header)!important;color:var(--ws-text)!important;border-color:var(--ws-line)!important;box-shadow:none!important;')+
    css(s.drops,'background:var(--ws-field)!important;border-color:var(--ws-edge)!important;')+
    css(s.primary,'background:var(--ws-cta)!important;color:var(--ws-oncta)!important;border-color:var(--ws-cta)!important;font-weight:700!important;')+'}';
}
