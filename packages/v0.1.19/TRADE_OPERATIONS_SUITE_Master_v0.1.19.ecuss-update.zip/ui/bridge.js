/* Host API v1. Local WebView2 messages only; no network fallback. */
(() => {
  'use strict';
  if (window !== window.top || !window.chrome?.webview || !window.__ECUSS_HOST_NONCE__) return;
  const pending = new Map();
  window.chrome.webview.addEventListener('message', event => {
    const message = event.data;
    if (message?.kind === 'work-access') { applyAccess(message.value); return; }
    if (!message || message.kind !== 'rpc-reply') return;
    const entry = pending.get(message.id);
    if (!entry) return;
    pending.delete(message.id);
    clearTimeout(entry.timer);
    entry.resolve(message);
  });
  function call(path, payload = null) {
    const id = Array.from(crypto.getRandomValues(new Uint8Array(16)), x => x.toString(16).padStart(2, '0')).join('');
    return new Promise((resolve, reject) => {
      // A native dialog may wait for user input; do not retry the operation.
      const timer = path.startsWith('/translation/') || ['/api/send','/api/prepare','/desktop/home','/updates/settings','/updates/download'].includes(path) ? null : setTimeout(() => {
        pending.delete(id); reject(new Error('The desktop connection did not respond.'));
      }, 60000);
      pending.set(id, { resolve, reject, timer });
      try { window.chrome.webview.postMessage({ kind: 'rpc', id, nonce: window.__ECUSS_HOST_NONCE__, path, payload: JSON.stringify(payload) }); }
      catch (error) { clearTimeout(timer); pending.delete(id); reject(error); }
    });
  }
  let access = window.__ECUSS_SUITE__?.access || {workBlocked:false,gateReason:'unverifiedAllowed'}, authorizing = false, accessError = false;
  const accessCopy = {
    ko:{title:'필수 업데이트 · 업무 실행 제한',detail:'최신 승인 버전을 적용해야 업무를 계속할 수 있습니다. 현재 결과는 HTML·Excel로 저장한 뒤 메인화면에서 업데이트하세요.',checking:'최신 버전 확인 중…',failure:'실행 허용 여부를 확인하지 못했습니다. 다시 시도해 주세요.',offline:'오프라인 · 설치된 지침으로 작업합니다. 연결되면 최신 버전을 다시 확인합니다.'},
    en:{title:'Required update · Work paused',detail:'Install the latest approved version to continue working. Save existing HTML/Excel results, then return to the main screen to update.',checking:'Checking the latest version…',failure:'Could not verify permission to start work. Please try again.',offline:'Offline · Using installed rules. Versions will be checked again when connected.'},
    vi:{title:'Bắt buộc cập nhật · Tạm dừng công việc',detail:'Cài bản mới nhất đã được duyệt để tiếp tục. Lưu kết quả HTML/Excel hiện có rồi về màn hình chính để cập nhật.',checking:'Đang kiểm tra phiên bản mới nhất…',failure:'Không xác nhận được quyền bắt đầu công việc. Vui lòng thử lại.',offline:'Ngoại tuyến · Dùng quy tắc đã cài. Kiểm tra lại phiên bản khi có mạng.'}
  };
  function renderAccess(){
    const banner=document.getElementById('ecuss-work-access');if(!banner)return;
    const t=accessCopy[document.documentElement.lang]||accessCopy.ko;
    const blocked=!!access.workBlocked;
    banner.hidden=!blocked&&!authorizing&&!accessError&&access.network!=='offline';
    banner.dataset.blocked=String(blocked);
    banner.textContent=authorizing?t.checking:accessError?t.failure:blocked?t.title+' — '+t.detail:t.offline;
    document.body.dataset.ecussWorkBlocked=String(blocked||authorizing);
    for(const el of document.querySelectorAll('#analyze,#run,#mail-preview-open')){
      if(blocked||authorizing)el.setAttribute('aria-disabled','true');else el.removeAttribute('aria-disabled');
    }
  }
  function applyAccess(next){
    if(!next || typeof next.workBlocked!=='boolean')return;
    access=next;renderAccess();window.EcussUpdateStatus?.accept(next);
  }
  async function authorizeWork(){
    if(authorizing)return false;authorizing=true;accessError=false;renderAccess();
    try{
      const r=await call('/desktop/authorize');
      if(r.status!==200||typeof r.value?.allowed!=='boolean')throw new Error('gate');
      applyAccess(r.value.access);return r.value.allowed===true;
    }catch{
      accessError=true;const banner=document.getElementById('ecuss-work-access');
      if(banner){banner.hidden=false;banner.textContent=(accessCopy[document.documentElement.lang]||accessCopy.ko).failure;}
      return false;
    }finally{authorizing=false;renderAccess();}
  }
  window.EcussDesktop = { call, authorizeWork };
  /* MASTER_TRANSPORT_BEGIN */
  const allowed = new Set(['/api/bootstrap', '/api/prepare', '/api/send']);
  window.fetch = async (input, init = {}) => {
    const url = new URL(typeof input === 'string' ? input : input.url, location.href);
    if (url.origin !== location.origin || (!allowed.has(url.pathname) && !/^\/download\/[0-9a-f]{32}\/(html|excel)$/.test(url.pathname)))
      throw new Error('This application does not make external requests.');
    const response = await call(url.pathname, init.body ? JSON.parse(init.body) : null);
    if (response.value?.binary) {
      const bytes = Uint8Array.from(atob(response.value.binary), c => c.charCodeAt(0));
      return new Response(bytes, { status: response.status, headers: { 'Content-Type': response.value.type } });
    }
    return new Response(JSON.stringify(response.value), { status: response.status, headers: { 'Content-Type': 'application/json' } });
  };
  /* MASTER_TRANSPORT_END */
  window.EcussDesktopState = () => ({
    busy: authorizing || !!window.EcussModuleState?.busy?.() || !!window.EcussMailBusy || !!document.querySelector('#analyze[data-desktop-running="true"]') ||
      (!!window.EcussModuleState?.hasResult() && !!document.querySelector('#download:disabled,#save-html:disabled')),
    hasWork: !!window.EcussModuleState?.hasWork?.() || !!window.EcussModuleState?.hasResult?.() || !!document.querySelector('.upload-card.ready') ||
      [...document.querySelectorAll('input[type="file"]')].some(x => x.files.length > 0)
  });
  let homeButton, homeNotice, homePending = false;
  const homeText = {
    ko: {home:'메인화면으로',busy:'진행 중인 작업이 끝난 뒤 다시 눌러 주세요.',error:'메인화면으로 돌아가지 못했습니다. 다시 시도하거나 상단의 업무 모듈을 이용하세요.'},
    en: {home:'Back to main screen',busy:'Wait for the current task to finish.',error:'Could not return to the main screen. Try again or use Work modules above.'},
    vi: {home:'Về màn hình chính',busy:'Chờ tác vụ hiện tại hoàn tất.',error:'Không thể về màn hình chính. Thử lại hoặc chọn Mô-đun công việc ở phía trên.'}
  };
  function homeCopy() { return homeText[document.documentElement.lang] || homeText.ko; }
  function installModuleNavigation() {
    if (!window.__ECUSS_DESKTOP_CONTEXT__?.moduleId || document.getElementById('ecuss-module-navigation')) return;
    const style=document.createElement('style');style.setAttribute('data-ecuss-desktop','');
    style.textContent='#ecuss-module-navigation{background:#123751;color:#fff;font-family:Segoe UI,Malgun Gothic,sans-serif}#ecuss-module-navigation .ecuss-nav-inner{max-width:1480px;margin:0 auto;padding:14px 28px;display:flex;align-items:center;gap:18px;flex-wrap:wrap}#ecuss-home-button{display:inline-flex;align-items:center;gap:9px;border:1px solid #91c4d2;border-radius:8px;background:#fff;color:#16475e;padding:10px 16px;font:600 14px Segoe UI,Malgun Gothic,sans-serif;cursor:pointer}#ecuss-home-button:hover{background:#e9f4f8}#ecuss-home-button:disabled{opacity:.65;cursor:wait}#ecuss-home-button:focus-visible{outline:3px solid #88e0ef;outline-offset:3px}#ecuss-home-notice{font-size:13px;color:#fff3d9;line-height:1.6}';
    document.head.append(style);
    const policyStyle=document.createElement('style');policyStyle.setAttribute('data-ecuss-desktop','');
    policyStyle.textContent='#ecuss-work-access{margin:0;padding:16px 28px;background:#fff4dc;color:#724d12;font:14px/1.65 Segoe UI,Malgun Gothic,sans-serif;border-bottom:1px solid #e8c987}#ecuss-work-access[data-blocked="true"]{background:#fff0ec;color:#9c3829;border-color:#e5b9af}body[data-ecuss-work-blocked="true"] #analyze,body[data-ecuss-work-blocked="true"] #mail-preview-open,body[data-ecuss-work-blocked="true"] .upload-card{opacity:.55;cursor:not-allowed}';
    document.head.append(policyStyle);
    const notice=document.createElement('section');notice.id='ecuss-work-access';notice.setAttribute('data-ecuss-desktop','');notice.setAttribute('role','alert');notice.hidden=true;document.body.prepend(notice);
    for(const name of ['click','drop','keydown']) document.addEventListener(name,event=>{
      if((access.workBlocked||authorizing)&&event.target.closest?.('#analyze,.upload-card,#mail-preview-open,#ecuss-mail-dialog,'+(window.EcussModuleUI?.workControls||'#run'))){
        if(name==='keydown'&&!['Enter',' '].includes(event.key))return;
        event.preventDefault();event.stopImmediatePropagation();renderAccess();
      }
    },true);
    const nav=document.createElement('nav');nav.id='ecuss-module-navigation';nav.setAttribute('data-ecuss-desktop','');
    const inner=document.createElement('div');inner.className='ecuss-nav-inner';
    homeButton=document.createElement('button');homeButton.type='button';homeButton.id='ecuss-home-button';
    const arrow=document.createElement('span');arrow.textContent='←';arrow.setAttribute('aria-hidden','true');
    const label=document.createElement('span');label.textContent=homeCopy().home;homeButton.append(arrow,label);
    homeNotice=document.createElement('span');homeNotice.id='ecuss-home-notice';homeNotice.setAttribute('role','status');homeNotice.setAttribute('aria-live','polite');
    inner.append(homeButton,homeNotice);nav.append(inner);
    const header=document.querySelector('body > header');if(header)header.before(nav);else document.body.prepend(nav);
    homeButton.addEventListener('click',async()=>{
      if(homePending)return;
      homeNotice.textContent='';
      if(window.EcussDesktopState().busy){homeNotice.textContent=homeCopy().busy;return;}
      homePending=true;homeButton.disabled=true;
      try{const response=await call('/desktop/home');if(response.status!==200)throw new Error(response.value?.message||homeCopy().error);}
      catch(error){homeNotice.textContent=homeCopy().error;}
      finally{homePending=false;homeButton.disabled=false;}
    });
  }
  function language() {
    const lang = document.documentElement.lang;
    renderAccess();
    if(homeButton){homeButton.lastElementChild.textContent=homeCopy().home;homeNotice.textContent='';}
    if (['ko', 'en', 'vi'].includes(lang)) call('/desktop/language', lang).catch(() => {});
  }
  window.addEventListener('load', () => {
    installModuleNavigation();
    language();
    new MutationObserver(language).observe(document.documentElement, { attributes: true, attributeFilter: ['lang'] });
    call('/desktop/ready').catch(() => {});
    if(window.__ECUSS_DESKTOP_CONTEXT__?.moduleId)call('/updates/check',false).then(r=>{if(r.status===200)applyAccess(r.value);}).catch(()=>{});
  }, { once: true });
})();

/* Shared presentation adapter. Existing module controls and business events are retained. */
(() => {
  'use strict';
  window.addEventListener('load', () => {
    if (!window.EcussDesktop || window.__VALIDATION_VIEWER__) return;
    const id=window.__ECUSS_DESKTOP_CONTEXT__?.moduleId;
    const module=window.__ECUSS_SUITE__?.modules?.find(m=>m.id===id);
    const nav=document.getElementById('ecuss-module-navigation');
    if(!module||!nav)return;
    let header=document.querySelector('body>header');
    if(!header&&id==='vn-kr-customs-translation'){
      const heading=document.querySelector('main>.heading');
      if(heading){header=document.createElement('header');heading.before(header);header.append(heading);nav.after(header);}
    }
    if(!header)return;
    document.body.classList.add('ecuss-module-ui');document.body.dataset.suiteCategory=module.category;
    header.id='ecuss-page-header';
    if(id==='stock-status-amovina'){
      const top=header.querySelector('.topbar'),left=top?.firstElementChild,date=header.querySelector('.datebox'),rate=header.querySelector('.ratebox:not(.datebox)');
      if(top&&left&&date&&rate){const options=document.createElement('div');options.className='top-options';options.append(date,rate);header.append(left,options);top.remove();}
    }else if(id==='stock-status-amogreen-vina'){
      const title=header.querySelector('.header-title');if(title)header.prepend(title);
    }
    const style=document.createElement('style');style.setAttribute('data-ecuss-desktop','');style.textContent="/* Desktop presentation only. Never included in shared result documents. */\nbody.ecuss-module-ui{--suite-accent:#285ea8;--suite-tint:#edf4ff;background:#f4f6fa;font-family:'Segoe UI','Malgun Gothic',sans-serif}\nbody.ecuss-module-ui[data-suite-category=translation]{--suite-accent:#7650a2;--suite-tint:#f5effc}\nbody.ecuss-module-ui[data-suite-category=inventory]{--suite-accent:#a65720;--suite-tint:#fff4e9}\nbody.ecuss-module-ui #ecuss-module-navigation{position:sticky;top:0;z-index:101;background:#14364b;border-bottom:1px solid #ffffff20}\nbody.ecuss-module-ui #ecuss-module-navigation .ecuss-nav-inner{max-width:1488px;padding:8px 24px;gap:12px;flex-wrap:nowrap}\nbody.ecuss-module-ui #ecuss-home-button{font-size:13px;padding:7px 12px;flex-shrink:0}\n#ecuss-category-label{color:#dce7ef;font-size:12px;font-weight:600;white-space:nowrap}\nbody.ecuss-module-ui #ecuss-page-header{position:sticky!important;top:var(--suite-nav-height,52px)!important;z-index:100;display:block!important;visibility:visible!important;background:#17394f;color:#fff;padding:16px max(24px,calc((100vw - 1440px)/2));margin:0;border-radius:0;border-bottom:3px solid var(--suite-accent);box-shadow:0 5px 12px #19354e16;max-height:55vh;overflow:auto}\nbody.ecuss-module-ui #ecuss-page-header h1{font:650 23px/1.35 'Segoe UI','Malgun Gothic',sans-serif;letter-spacing:-.4px;margin:0 0 6px;overflow-wrap:anywhere;color:#fff}\nbody.ecuss-module-ui #ecuss-page-header p{font-size:13px;line-height:1.5;color:#dce7ef;margin:0}\nbody.ecuss-module-ui #ecuss-page-header .top-inner,body.ecuss-module-ui #ecuss-page-header .heading{max-width:1440px;margin:0 auto;display:flex;gap:18px;align-items:center;justify-content:space-between}\nbody.ecuss-module-ui #ecuss-page-header .language-picker,body.ecuss-module-ui #ecuss-page-header .lang{margin:0;align-self:center;color:#dce7ef;flex-shrink:0}\nbody.ecuss-module-ui #ecuss-page-header select{background:#fff;color:#234056;max-width:100%;border-radius:8px;padding:7px 10px}\nbody.ecuss-module-ui #ecuss-page-header .eyebrow,body.ecuss-module-ui #ecuss-page-header .brand{font-size:10px;letter-spacing:1px;margin:0 0 5px;color:#c3d9e5}\nbody.ecuss-module-ui #ecuss-page-header .version,body.ecuss-module-ui #ecuss-page-header .pilot{font-size:11px;color:#dce7ef;margin-top:4px}\nbody.ecuss-module-ui #ecuss-page-header .header-title{display:flex;align-items:center;justify-content:space-between;gap:14px}\nbody.ecuss-module-ui #ecuss-page-header .top-options{display:flex;gap:16px;flex-wrap:wrap;margin:10px 0 0;justify-content:flex-start;align-items:flex-start}\nbody.ecuss-module-ui #ecuss-page-header .top-options .field,body.ecuss-module-ui #ecuss-page-header .ratebox{min-width:0;max-width:100%;background:#24495e;padding:8px 12px;border-radius:8px;margin:0;flex:0 1 auto}\nbody.ecuss-module-ui #ecuss-page-header .top-options small,body.ecuss-module-ui #ecuss-page-header .ratebox small{font-size:10px;color:#dce7ef}\nbody.ecuss-module-ui #ecuss-page-header input{max-width:100%;font-size:13px;padding:5px 8px}\nbody.ecuss-module-ui main,body.ecuss-module-ui .container{max-width:1488px;margin:0 auto;padding:24px 24px 48px}\nbody.ecuss-module-ui .panel,body.ecuss-module-ui .card,body.ecuss-module-ui .upload-card{border-radius:12px}\nbody.ecuss-module-ui .upload-card,body.ecuss-module-ui .dropzone,body.ecuss-module-ui [data-card],body.ecuss-module-ui .file-box{border-color:#c9d7e2;transition:background-color .12s,border-color .12s}\nbody.ecuss-module-ui .upload-card.ready,body.ecuss-module-ui .dropzone.selected,body.ecuss-module-ui .dropzone.has-file,body.ecuss-module-ui #dropzone[data-selected=true],body.ecuss-module-ui [data-card].selected,body.ecuss-module-ui .file-box[data-selected=true]{border:2px solid var(--suite-accent);background:var(--suite-tint)}\nbody.ecuss-module-ui .file-box.dragover,body.ecuss-module-ui .upload-card.dragover,body.ecuss-module-ui .upload-card.drag,body.ecuss-module-ui .dropzone.dragover,body.ecuss-module-ui .dropzone.drag-over,body.ecuss-module-ui [data-card].dragover{outline:3px solid var(--suite-accent);outline-offset:2px;background:var(--suite-tint)}\nbody.ecuss-module-ui .result-actions{top:var(--suite-header-bottom,150px);z-index:30}\nbody.ecuss-module-ui :is(#results,#result){scroll-margin-top:calc(var(--suite-header-bottom,150px) + 16px)}\n@media(max-width:700px){body.ecuss-module-ui #ecuss-module-navigation .ecuss-nav-inner{padding:8px 16px}#ecuss-home-notice{max-width:45vw;font-size:11px!important}body.ecuss-module-ui #ecuss-page-header{padding:12px 16px}body.ecuss-module-ui #ecuss-page-header h1{font-size:19px}body.ecuss-module-ui #ecuss-page-header .top-inner,body.ecuss-module-ui #ecuss-page-header .heading{flex-direction:row;flex-wrap:wrap;gap:8px}body.ecuss-module-ui #ecuss-page-header .top-options{gap:8px}body.ecuss-module-ui #ecuss-page-header .header-title{flex-wrap:wrap}body.ecuss-module-ui main,body.ecuss-module-ui .container{padding:18px 16px 36px}}\n@media print{body.ecuss-module-ui #ecuss-module-navigation{display:none}body.ecuss-module-ui #ecuss-page-header{position:static!important;max-height:none;overflow:visible}}\n\nbody.ecuss-module-ui #ecuss-page-header:has(>#lang){display:flex!important;justify-content:space-between;align-items:center;gap:16px;flex-wrap:wrap}\n\nbody.ecuss-module-ui #ecuss-page-header select.lang{color:#234056}\n";document.head.append(style);
    const category=document.createElement('span');category.id='ecuss-category-label';nav.querySelector('.ecuss-nav-inner').append(category);
    const categories={ko:{validation:'Balance Sheet 검증',translation:'문서 번역',inventory:'재고 취합'},en:{validation:'Balance Sheet validation',translation:'Document translation',inventory:'Stock consolidation'},vi:{validation:'Kiểm tra Balance Sheet',translation:'Dịch tài liệu',inventory:'Tổng hợp tồn kho'}};
    function labels(){const lang=document.documentElement.lang||'ko',name=module.name[lang]||module.name.ko;const h=header.querySelector('h1');if(h&&h.textContent!==name)h.textContent=name;document.title=name;category.textContent=(categories[lang]||categories.ko)[module.category]||'';}
    function measure(){const n=nav.getBoundingClientRect().height,h=header.getBoundingClientRect().height;document.body.style.setProperty('--suite-nav-height',n+'px');document.body.style.setProperty('--suite-header-bottom',(n+h)+'px');}
    if(id==='balance-sheet-validation'){const filename=document.getElementById('filename'),zone=document.getElementById('dropzone');const selected=()=>{zone.dataset.selected=String(!!window.EcussModuleState?.hasWork?.());};selected();new MutationObserver(selected).observe(filename,{childList:true,subtree:true,characterData:true});}
    labels();measure();new ResizeObserver(measure).observe(header);new ResizeObserver(measure).observe(nav);
    new MutationObserver(labels).observe(document.documentElement,{attributes:true,attributeFilter:['lang']});
    // Modules can render their own title again when language or result state changes.
    new MutationObserver(labels).observe(header.querySelector('h1'),{childList:true,subtree:true,characterData:true});
  },{once:true});
})();
