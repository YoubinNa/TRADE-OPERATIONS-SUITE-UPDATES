(function(){
'use strict';
const C=CommonMaterialCore,$=id=>document.getElementById(id),esc=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const langs={ko:0,en:1,vi:2},normalizeLang=l=>({kr:'ko',vn:'vi',ko:'ko',en:'en',vi:'vi'}[String(l||'').toLowerCase()]||'ko');
const state={lang:normalizeLang(new URLSearchParams(location.search).get('lang')),company:'',example:null,wb:null,filename:'',map:null,rows:null,saved:{},manual:{},pending:{},sourceCandidate:null,epoch:0,busy:false,excelSaving:false,detail:null,error:null,notice:null,dirty:false,reasonFilter:[],targets:[],activeTarget:null,nextTargetId:1,resultFile:''};
let reportLang=null;
const t=k=>CMText[k]?.[langs[reportLang||state.lang]]||k;
const source=()=>state.example?state.example.source:state.manual[state.company]||state.saved[state.company]||null;
const str=v=>v==null?'':String(v);
// A display alias only: preserve the received filename and source identity.
const sourceFilename=v=>str(v).replace(/balance-catalog/gi,'Balance Sheet');
function error(key,context=''){state.error=CMText[key]?key:'file_invalid';state.errorContext=context;$('error').textContent=(context?context+' · ':'')+t(state.error);$('error').classList.remove('hidden');}
function clearError(){state.error=null;state.errorContext='';$('error').classList.add('hidden');}
function invalidate(){state.rows=null;state.detail=null;state.reasonFilter=[];$('detail').close();$('resultArea').classList.add('hidden');$('empty').classList.remove('hidden');$('readyInfo').textContent='';updateRun();}
function setBusy(v){state.busy=v;document.querySelectorAll('.company-buttons button,#pickTarget,#pickSource,#sheet,#applyMap,#autoMap,#returnSummary,#reset,#sourceTarget,#removeTarget,#resultFile').forEach(e=>e.disabled=v);$('sheet').disabled=v||!state.wb;updateRun();$('readyInfo').textContent=v?t('working'):'';}
function date(v){if(!v)return t('unknownTime');const d=new Date(v);return isNaN(d)?t('unknownTime'):new Intl.DateTimeFormat({ko:'ko-KR',en:'en-GB',vi:'vi-VN'}[state.lang],{timeZone:'Asia/Seoul',dateStyle:'medium',timeStyle:'medium'}).format(d)+' (KST)';}
function showSource(){
 $('sourceActions').classList.toggle('hidden',!state.manual[state.company]||!!state.example);
 if(state.example){const s=source();$('sourceStatus').className='source-status manual';$('sourceStatus').innerHTML='<strong>'+t(s?'exampleSource':'exampleNoSource')+'</strong><p>'+t('exampleActive')+'</p>';for(const id of ['newSummary','sourceConfirm'])$(id).classList.add('hidden');$('returnSummary').disabled=true;return;}

 const s=source();$('sourceStatus').className='source-status '+(s?s.kind==='manual'?'manual':'saved':'waiting');
 $('sourceStatus').innerHTML=s?'<strong>'+t(s.kind==='manual'?'manual':'summary')+'</strong><p>'+esc(sourceFilename(s.filename))+'</p><p>'+t(s.kind==='manual'?'loadedTime':'sourceTime')+': '+esc(date(s.kind==='manual'?s.loadedAt:s.validatedAt))+'</p><p>'+t('allRows')+': '+s.bom.length.toLocaleString()+'</p>':'<strong>'+t('summary')+'</strong><p>'+t('sourceMissing')+'</p>';
 $('returnSummary').disabled=!state.manual[state.company]||state.busy;
 $('newSummary').classList.toggle('hidden',!state.pending[state.company]);
 $('sourceConfirm').classList.toggle('hidden',!state.sourceCandidate);
}
function labels(){
 CommonMaterialGuide.mount($('sourceGuideHost'),'source',t);
 document.documentElement.lang=state.lang;document.title=t('title');document.querySelectorAll('[data-i18n]').forEach(e=>e.textContent=t(e.dataset.i18n));
 document.querySelectorAll('[data-lang]').forEach(e=>{e.classList.toggle('active',e.dataset.lang===state.lang);e.setAttribute('aria-pressed',e.dataset.lang===state.lang);});
 $('search').placeholder=t('search');$('search').setAttribute('aria-label',t('search'));
 CommonMaterialReasonFilter.sync($('reasonFilter'),materialGroups(batchRows()),t,state.reasonFilter,materialGroups(state.rows||[]));
 if(!state.wb)$('sheet').innerHTML='<option>'+t('noneSheet')+'</option>';
 if(state.error)$('error').textContent=(state.errorContext?state.errorContext+' · ':'')+t(state.error);
 if(state.notice)$('fileNotice').textContent=t(state.notice);
 $('companyHint').classList.toggle('hidden',!!state.company);showSource();showLayout();showTargets();window.dispatchEvent(new Event("review-state"));if(state.rows)render();if(state.detail!==null)detail(state.detail);
}
function showLayout(){if(state.dirty)return;const s=state.wb?.Sheets[$('sheet').value];$('mapCode').closest('details').classList.toggle('hidden',!!state.map?.layout);$('bomLayout').innerHTML=s?CommonMaterialBOMUI.html(state.map,s,t):'';}
function setCompany(company){
 if(state.busy||company===state.company)return;
 state.example=null;state.dirty=false;state.targets=[];state.activeTarget=null;state.resultFile='';state.company=company;state.epoch++;state.wb=null;state.filename='';state.map=null;state.sourceCandidate=null;state.notice=null;
 $('targetFile').value='';$('sourceFile').value='';$('targetName').textContent='';$('sheet').innerHTML='<option>'+t('noneSheet')+'</option>';$('sheet').disabled=true;$('fileNotice').classList.add('hidden');clearError();invalidate();
 document.querySelectorAll('[data-company]').forEach(b=>{b.classList.toggle('active',b.dataset.company===company);b.setAttribute('aria-pressed',b.dataset.company===company);});labels();
}
function mapToInputs(m){const x=m||{code:2,name:3,spec:4,vnName:15,unit:6,price:8,hs:14,header:21};for(const [k,id] of [['code','Code'],['name','Name'],['spec','Spec'],['vnName','VnName'],['unit','Unit'],['price','Price'],['hs','Hs']])$('map'+id).value=x[k]>=0?XLSX.utils.encode_col(x[k]):'';$('mapHeader').value=x.header+1;}
function selectSheet(){
 clearError();state.dirty=false;invalidate();const s=state.wb.Sheets[$('sheet').value];state.map=C.detect(s);mapToInputs(state.map);showLayout();
 const co=C.companyOf(s);state.notice=!co?'company_unknown':null;$('fileNotice').classList.toggle('hidden',!state.notice);if(state.notice)$('fileNotice').textContent=t(state.notice);
 if(co&&co!==state.company){state.map=null;error('company_mismatch');}
 else if(!state.map)error('table_missing');
 saveActive();updateRun();
}
function active(){return state.targets.find(f=>f.id===state.activeTarget);}
function saveActive(){const f=active();if(f)Object.assign(f,{sheet:$('sheet').value,map:state.map,dirty:state.dirty,error:state.error||'',notice:state.notice});}
function updateRun(){const invalid=state.targets.some(f=>!f.map||f.dirty||f.error);$('run').disabled=state.busy||!state.company||!state.targets.length||invalid||state.dirty;$('sourceTarget').disabled=state.busy||state.dirty;$('removeTarget').disabled=state.busy||!state.targets.length;}
function targetEntry(wb,name){
 const ranked=wb.SheetNames.map(sheet=>({sheet,map:C.detect(wb.Sheets[sheet])})).sort((a,b)=>(b.map?.score||0)-(a.map?.score||0));
 if(!ranked.length)throw Error('table_missing');const {sheet,map}=ranked[0],co=C.companyOf(wb.Sheets[sheet]);
 if(co&&co!==state.company)throw Error('company_mismatch');
 return {id:state.nextTargetId++,name,wb,sheet,map,dirty:false,error:map?'':'table_missing',notice:co?null:'company_unknown'};
}
function showTargets(){
 $('sourceTarget').innerHTML=state.targets.map(f=>'<option value="'+f.id+'">'+esc(f.name.replace(/\.xlsx$/i,''))+'</option>').join('');$('sourceTarget').value=state.activeTarget||'';
 $('targetList').classList.toggle('hidden',!state.targets.length);
 $('targetName').textContent=state.targets.length===1?state.targets[0].name:state.targets.length?t('sourceFileCount')+': '+state.targets.length:'';
 const value=state.resultFile;$('resultFile').innerHTML='<option value="">'+t('sourceAllFiles')+'</option>'+state.targets.map(f=>'<option value="'+f.id+'">'+esc(f.name.replace(/\.xlsx$/i,''))+'</option>').join('');$('resultFile').value=value;
 $('resultFile').classList.toggle('hidden',state.targets.length<2);$('resultFile').setAttribute('aria-label',t('sourceResultFile'));updateRun();
}
function activateTarget(id){
 const f=state.targets.find(f=>f.id===Number(id));if(!f)return;
 state.activeTarget=f.id;state.wb=f.wb;state.filename=f.name;state.map=f.map;state.dirty=f.dirty;state.notice=f.notice;
 $('sheet').innerHTML=f.wb.SheetNames.map(name=>'<option value="'+esc(name)+'">'+esc(name)+'</option>').join('');$('sheet').value=f.sheet;$('sheet').disabled=state.busy;
 mapToInputs(f.map);clearError();if(f.error)error(f.error,f.name);$('fileNotice').classList.toggle('hidden',!state.notice);if(state.notice)$('fileNotice').textContent=t(state.notice);
 showLayout();showTargets();
}
function installTargets(files){
 state.example=null;state.epoch++;state.targets=files;state.resultFile='';state.dirty=false;invalidate();showSource();
 if(files.length)activateTarget(files[0].id);else{state.activeTarget=null;state.wb=null;state.filename='';state.map=null;$('sheet').innerHTML='<option>'+t('noneSheet')+'</option>';$('sheet').disabled=true;showLayout();showTargets();}
}
function loadWorkbook(wb,filename,example=false){const f=targetEntry(wb,filename);installTargets([f]);}
async function readWorkbook(file){
 if(window.CommonMaterialModule?.authorizeWork&&!await CommonMaterialModule.authorizeWork())throw Error('workDenied');
 if(!/\.xlsx$/i.test(file.name))throw Error('file_invalid');if(file.size>50*1024*1024)throw Error('too_large');
 const bytes=await file.arrayBuffer(),zip=await JSZip.loadAsync(bytes);let size=0;
 for(const f of Object.values(zip.files)){size+=f._data?.uncompressedSize||0;if(size>250*1024*1024)throw Error('too_large');}
 const wb=XLSX.read(bytes,{type:'array',cellNF:true,cellText:true,cellFormula:true,cellStyles:true,sheetStubs:true});
 // Surface conditional number formats instead of pretending the base format is the visible value.
 const parser=new DOMParser(),parse=s=>parser.parseFromString(s,'application/xml');
 const relfile=zip.file('xl/_rels/workbook.xml.rels'),bookfile=zip.file('xl/workbook.xml');
 if(relfile&&bookfile){
  const rel=parse(await relfile.async('string')),book=parse(await bookfile.async('string')),styles=zip.file('xl/styles.xml');
  const styleDoc=styles?parse(await styles.async('string')):null,dxfs=styleDoc?Array.from(styleDoc.getElementsByTagName('dxf')):[];
  const targets=new Map(Array.from(rel.getElementsByTagName('Relationship')).map(r=>[r.getAttribute('Id'),r.getAttribute('Target')]));
  for(const sh of book.getElementsByTagName('sheet')){
   const name=sh.getAttribute('name'),target=targets.get(sh.getAttribute('r:id'));if(!target||!wb.Sheets[name])continue;
   const path=target.startsWith('/')?target.slice(1):'xl/'+target.replace(/^\.\//,'');const entry=zip.file(path);if(!entry)continue;
   const xml=parse(await entry.async('string'));
   for(const cf of xml.getElementsByTagName('conditionalFormatting')){
    const rules=Array.from(cf.getElementsByTagName('cfRule'));
    if(!rules.some(r=>dxfs[Number(r.getAttribute('dxfId'))]?.getElementsByTagName('numFmt').length))continue;
    const ranges=(cf.getAttribute('sqref')||'').split(/\s+/).map(r=>{try{return XLSX.utils.decode_range(r);}catch{return null;}}).filter(Boolean);
    for(const address of Object.keys(wb.Sheets[name])){if(address.startsWith('!'))continue;const p=XLSX.utils.decode_cell(address);if(ranges.some(r=>r.s.r<=p.r&&r.e.r>=p.r&&r.s.c<=p.c&&r.e.c>=p.c))wb.Sheets[name][address].conditionalFormat=true;}
   }
  }
 }
 return wb;
}
async function targetFiles(input){
 const files=Array.from(input||[]);if(!state.company){error('chooseCompany');return;}if(!files.length||state.busy)return;
 if(files.length>20){error('sourceFileLimit');return;}
 if(new Set(files.map(f=>f.name.toLowerCase())).size!==files.length){error('sourceDuplicateName');return;}
 clearError();setBusy(true);const staged=[];let current='';
 try{
  for(const file of files){current=file.name;const wb=await readWorkbook(file);staged.push(targetEntry(wb,file.name));}
  installTargets(staged);
 }catch(e){error(e.message,current);}finally{setBusy(false);showSource();}
}
function installSource(s){state.manual[state.company]=s;state.sourceCandidate=null;invalidate();showSource();clearError();if(state.wb)$('readyInfo').textContent=t('sourceChanged');}
async function referenceFile(file){
 if(state.example)return error('endCaseFirst');
 if(!state.company){error('chooseCompany');return;}if(!file||state.busy)return;clearError();setBusy(true);state.sourceCandidate=null;
 try{
  const wb=await readWorkbook(file),s=C.sourceWorkbook(wb,state.company);s.kind='manual';s.filename=file.name;s.loadedAt=new Date().toISOString();
  const co=s.detectedCompany;
  if(!co)state.sourceCandidate=s;else installSource(s);
 }catch(e){error(e.message);}finally{setBusy(false);showSource();}
}
function receive(data,meta={}){
 const company={AMO:'AMO',AMOVINA:'AMO',AMOGREEN:'AGV',AGV:'AGV',AMOGREENVINA:'AGV'}[String(data?.company).toUpperCase()];
 if(!company)throw Error('source_invalid');const s=C.sourceJSON(data,company);s.kind='saved';s.filename=meta.filename||'';s.validatedAt=meta.validatedAt||data.validatedAt||null;s.hash=meta.hash||JSON.stringify(data.bom);
 const prior=state.saved[company];
 // A verified receipt supersedes any older pending summary, even if its hash
 // matches the saved source. Keep active/manual results for metadata-only updates.
 if(prior&&prior.hash===s.hash){prior.validatedAt=s.validatedAt;delete state.pending[company];showSource();if(state.rows&&state.company===company&&!state.manual[company])render();return;}
 if(prior&&state.company===company&&state.rows&&!state.manual[company]&&!state.example){state.pending[company]=s;showSource();return;}
 // Pending exists only while a different saved source protects an active result.
 state.saved[company]=s;delete state.pending[company];if(state.company===company){if(!state.manual[company]&&!state.example)invalidate();showSource();}
}
function run(){
 if(!state.company){error('chooseCompany');return;}if(state.busy||!state.targets.length)return;if(state.dirty)return error('bomApplyNeeded');clearError();
 let current='';try{
  const rows=[],ref=source();
  for(const f of state.targets){
   current=f.name;if(f.dirty)throw Error('bomApplyNeeded');if(!f.map)throw Error(f.error||'table_missing');
   const sheet=f.wb.Sheets[f.sheet],co=C.companyOf(sheet);if(co&&co!==state.company)throw Error('company_mismatch');
   const compared=C.compare(C.extract(sheet,f.map),ref);
   rows.push(...compared.map(r=>({...r,fileId:f.id,fileName:f.name,sheetName:f.sheet})));
  }
  state.rows=rows.sort((a,b)=>Number(!!b.issues.length)-Number(!!a.issues.length)||a.fileId-b.fileId||a.row-b.row);state.reasonFilter=[];state.resultFile='';$('search').value='';state.detail=null;$('detail').close();showTargets();render();
 }catch(e){invalidate();error(e.message,current);}
}
function batchRows(){return (state.rows||[]).map((r,i)=>({...r,i})).filter(r=>!state.resultFile||String(r.fileId)===state.resultFile);}
function searchedGroups(){const q=$('search').value.toLowerCase().trim();return materialGroups(batchRows()).filter(g=>!q||g.members.some(r=>(r.code+' '+r.name).toLowerCase().includes(q)));}
function filtered(){return searchedGroups().filter(g=>CommonMaterialOverview.matches(g.issues,state.reasonFilter)).flatMap(g=>g.members);}
function materialKey(r){return r.code&&!r.issues.includes('code_error')?'code:'+r.code:'row:'+r.fileId+':'+r.row;}
function materialGroups(rows){
 const groups=new Map();for(const r of rows){const key=materialKey(r);if(!groups.has(key))groups.set(key,[]);groups.get(key).push(r);}
 const join=(rs,k)=>[...new Set(rs.map(r=>str(r[k]).trim()||'—'))].join('\n');
 return [...groups.values()].map(members=>{const r={...members[0],members};
  for(const k of ['name','spec','vnName','unit','hs','raw','shown','format','formula'])r[k]=join(members,k);
  if(new Set(members.map(m=>C.unit(m.unit))).size>1)r.raw=[...new Set(members.map(m=>m.raw+' ['+(m.unit||'—')+']'))].join('\n');
  r.issues=[...new Set(members.flatMap(m=>m.issues))];r.duplicateRows=[...new Set(members.flatMap(m=>m.duplicateRows||[]))];
  r.matches=[...new Map(members.flatMap(m=>m.matches).map(m=>[JSON.stringify(m),m])).values()];
  r.row=members.map(m=>m.row).join(', ');r.priceCell=members.map(m=>m.priceCell).join('\n');r.role='';r.exampleExpected=[...new Set(members.flatMap(m=>m.exampleExpected||[]))];return r;
 });
}
function issueText(k,r){if(k==='hs_review')return CommonMaterialReasonFilter.describeHs(r.issues,t);return t(k)+(['code_duplicate','bom_duplicate'].includes(k)&&r.duplicateRows?.length?' · '+t('duplicateRows')+': '+r.duplicateRows.join(', '):'');}
function labelTables(scope=document){scope.querySelectorAll('table').forEach(table=>{const heads=[...table.querySelectorAll('thead th')].map(h=>h.textContent);table.querySelectorAll('tbody tr').forEach(row=>[...row.children].forEach((cell,i)=>{if(!cell.hasAttribute('colspan'))cell.dataset.label=heads[i]||'';}));});}
const RF=CommonMaterialReasonFilter;
function valueText(r,k){return str(k==='price'?(r.raw??r.price):r[k]).trim()||'—';}
function evidenceStatus(input,reference,field){
 const clean=v=>str(v).trim().normalize('NFC').replace(/\s+/g,' ');
 const a=clean(input[field]),b=clean(reference[field]);
 const target=state.targets.find(f=>f.id===input.fileId),cell=target?.wb?.Sheets[input.sheetName]?.[input[field+'Cell']];
 if(cell&&(cell.t==='e'||(cell.f&&cell.v==null)))return 'evidenceUnavailable';
 if(field==='price'){
  if(!C.unit(input.unit)||!C.unit(reference.unit)||C.number(input.price)===null||C.number(reference.price)===null)return 'evidenceUnavailable';
  if(C.unit(input.unit)!==C.unit(reference.unit))return 'evidenceUnitMismatch';
  return C.equal(C.number(input.price),C.number(reference.price))?'evidenceMatch':'evidenceMismatch';
 }
 if(!a||!b||(['name','spec','vnName'].includes(field)&&(a==='0'||b==='0')))return 'evidenceUnavailable';
 const same=field==='hs'?C.hs(a)===C.hs(b):field==='unit'?C.unit(a)===C.unit(b):a===b;
 return same?'evidenceMatch':'evidenceMismatch';
}
const evidenceLabel=b=>b.label+(b.statuses?.length?' · '+b.statuses.map(t).join(' / '):'');
function sourceEvidenceData(g,selection){
 const issues=RF.filterIssues(g.issues,selection),ref=source(),blocks=[];
 const fields=[...new Set(issues.flatMap(k=>k==='field_error'?['name','spec','vnName','unit','hs']:k==='combination'?['price','hs']:CommonMaterialExcel.issueFields(k)))].filter(k=>['code','name','spec','vnName','unit','hs','price'].includes(k));
 const reason=['internal','reference'].map(scope=>{const ks=issues.filter(k=>RF.scope(k)===scope);return ks.length?'['+t(scope==='internal'?'scopeInternal':'scopeReference')+']\n'+RF.displayIssues(ks).map(k=>issueText(k,{...g,issues:ks})).join('\n'):'';}).filter(Boolean).join('\n')||t('crossNoIssues');
 const strip=v=>str(v).replace(/\.xlsx$/i,''),refLoc=(m,f)=>{let pos=str(m.source||'');const column={code:'E',name:'F',spec:'G',hs:'H',vnName:'I',unit:'L',price:'M'}[f];if(ref?.kind==='manual'&&/^BOM[ _]LIST!\d+$/i.test(pos)&&column)pos=pos.replace(/!(\d+)$/,'!'+column+'$1');return pos||'—';};
 const records=(rs,f,reference)=>rs.map(m=>({reference,filename:strip(reference?sourceFilename(ref?.filename||t('summary')):m.fileName||state.filename),cell:reference?'':m[f+'Cell']||m.row,location:reference?refLoc(m,f):(m.sheetName||$('sheet').value)+'!'+(m[f+'Cell']||m.row),context:reference?[m.project,m.product].filter(Boolean).join(' · '):m.role?CommonMaterialBOMUI.context(m,t):''}));
 for(const f of fields){
  const keys=issues.filter(k=>(k==='combination'?['price','hs']:k==='field_error'?['name','spec','vnName','unit','hs']:CommonMaterialExcel.issueFields(k)).includes(f));
  const metadata=f==='price'&&keys.some(k=>/precision|display|format_unknown|conditional_format|formula_missing|price_error/.test(k));
  const compareRef=keys.some(k=>RF.scope(k)==='reference');
  for(const reference of compareRef?[false,true]:[false]){
   // Keep every source value/location for this code, including matches, so
   // reviewers can decide whether the input or the reference needs correction.
   const rows=reference?g.matches:g.members,buckets=new Map();
   for(const m of rows){const value=valueText(m,f)+(f==='price'?' ['+(m.unit||'—')+']':'')+(!reference&&metadata?'\n'+t('shown')+': '+(m.shown||'—')+'\n'+t('format')+': '+(m.format||'—')+(m.formula?'\n'+t('formula')+': '+m.formula:''):'');if(!buckets.has(value))buckets.set(value,[]);buckets.get(value).push(m);}
   const label=f==='price'?t(reference?'existingContractPrice':'newContractPrice'):t(reference?'excelReferenceLabel':'excelNewLabel')+' · '+t(f);
   for(const [value,rs] of buckets){
    const block={field:f,reference,label,value,records:records(rs,f,reference)};
    if(reference){
     const comparisons=new Map();
     for(const input of g.members){
      const statuses=[...new Set(rs.map(m=>evidenceStatus(input,m,f)))];
      for(const status of statuses){const inputValue=valueText(input,f)+(f==='price'?' ['+(input.unit||'—')+']':'');const key=JSON.stringify([status,inputValue]);if(!comparisons.has(key))comparisons.set(key,{status,value:inputValue,rows:[]});comparisons.get(key).rows.push(input);}
     }
     block.statuses=['evidenceMatch','evidenceMismatch','evidenceUnitMismatch','evidenceUnavailable'].filter(s=>[...comparisons.values()].some(c=>c.status===s));
     // A source value may match one input but differ from another. Identify
     // each input value/file/cell when the verdicts differ within this group.
     if(block.statuses.length>1)block.comparisons=[...comparisons.values()].map(c=>({field:f,label:t('evidenceComparedInput'),statuses:[c.status],value:c.value,records:records(c.rows,f,false)}));
    }
    blocks.push(block);
   }
   if(reference&&!rows.length)blocks.push({field:f,reference,label,value:t(ref?'scopeNotMatched':'waiting'),records:[]});
  }
 }
 if(!blocks.length)blocks.push({field:'crossFileShort',reference:false,label:t('crossFileShort'),value:issues.length?reason:t('crossNoIssues'),records:records(g.members,'code',false)});
 return {issues,reason,blocks,fileCount:new Set(g.members.map(m=>m.fileId)).size};
}
function sourceEvidence(data,collapsible){
 const fields=[...new Set(data.blocks.map(b=>b.field))];
 const blockHTML=b=>'<div class="cross-value'+(b.reference?' reference-value':'')+'"><strong class="hint">'+esc(b.label)+'</strong> '+(b.statuses||[]).map(s=>'<span class="comparison-status '+s+'">'+esc(t(s))+'</span>').join(' ')+'<div>'+esc(b.value).replace(/\n/g,'<br>')+'</div><div class="file-chips">'+b.records.map(r=>'<span class="file-chip" title="'+esc(r.filename+'\n'+r.location)+'">'+esc(r.filename)+(r.context?' · '+esc(r.context):'')+'<small>'+esc(r.location)+'</small></span>').join('')+'</div>'+(b.comparisons?.length?'<div class="comparison-inputs">'+b.comparisons.map(blockHTML).join('')+'</div>':'')+'</div>';
 return fields.map(field=>{const content=data.blocks.filter(b=>b.field===field).map(blockHTML).join('');return collapsible?'<details class="cross-evidence cross-fold" data-field="'+field+'"><summary>'+esc(t(field))+'</summary><div class="cross-fold-content">'+content+'</div></details>':'<section class="cross-evidence"><strong>'+esc(t(field))+'</strong>'+content+'</section>';}).join('');
}
function headingHTML(){return CommonMaterialOverview.isOverview(state.reasonFilter)?CommonMaterialOverview.headings(t):'<tr>'+['code','name','reason','crossEvidence','crossFileShort'].map(k=>'<th>'+t(k)+'</th>').join('')+'</tr>';}
function rowHTML(r){if(CommonMaterialOverview.isOverview(state.reasonFilter))return '<tr data-material="'+esc(r.code)+'">'+CommonMaterialOverview.cells(r.members,r.status,'<button class="small" data-detail="'+r.i+'">'+t('view')+'</button>',t)+'</tr>';
 const data=sourceEvidenceData(r,state.reasonFilter);
 return '<tr data-material="'+esc(r.code)+'"><td><strong>'+esc(r.code||'—')+'</strong><div><span class="badge '+r.status+'">'+t(r.status)+'</span></div><p class="'+(data.issues.length?'issue-text':'hint')+'">'+t(data.issues.length?'reviewNeeded':'crossNoIssues')+'</p></td><td>'+esc(r.name)+'</td><td class="issue-text">'+esc(data.reason).replace(/\n/g,'<br>')+'</td><td class="cross-evidence-cell">'+sourceEvidence(data,true)+'</td><td><div class="cross-file-labels">'+t('crossFileShort')+': '+data.fileCount+'</div><button data-detail="'+r.i+'">'+t('details')+'</button></td></tr>';
}
function outcome(){const common=state.rows.filter(r=>r.status==='common').length,unreadable=state.rows.some(r=>r.status==='unreadable');return !source()?'waiting':unreadable?'compareIncomplete':common?'compareDone':'noCommon';}
function render(){
 const opened=new Set([...$('results').querySelectorAll('details.cross-fold[open]')].map(d=>d.closest('tr').dataset.material+'|'+d.dataset.field));
 if(!state.rows)return;$('empty').classList.add('hidden');$('resultArea').classList.remove('hidden');
 const rows=batchRows(),groups=materialGroups(rows);state.reasonFilter=CommonMaterialReasonFilter.sync($('reasonFilter'),groups,t,state.reasonFilter,materialGroups(state.rows));$('countRows').textContent=groups.length;$('countCommon').textContent=source()?groups.filter(r=>r.status==='common').length:'—';$('countIssues').textContent=groups.filter(r=>r.issues.length).length;$('countDisplay').textContent=new Set(rows.map(r=>r.fileId)).size;
 const o=outcome();$('outcome').className='outcome '+(!source()||o==='compareIncomplete'?'pending':'');$('outcome').innerHTML='<p><strong>'+t('internalDone')+'</strong> · '+t('reviewMaterials')+' '+groups.filter(g=>g.members.some(r=>r.internalIssues.length)).length+'</p><p>'+t(o)+'</p>';
 $('results').classList.toggle('material-overview',CommonMaterialOverview.isOverview(state.reasonFilter));$('results').querySelector('thead').innerHTML=headingHTML();const f=materialGroups(filtered());$('results').querySelector('tbody').innerHTML=f.map(r=>rowHTML(r)).join('')||'<tr><td colspan="'+(CommonMaterialOverview.isOverview(state.reasonFilter)?9:5)+'">'+t('noData')+'</td></tr>';$('resultCount').textContent=t('materialCount')+': '+f.length+' / '+materialGroups(rows).length+' · '+t('crossRowsRead')+': '+filtered().length;
 $('results').querySelectorAll('details.cross-fold').forEach(d=>d.open=opened.has(d.closest('tr').dataset.material+'|'+d.dataset.field));labelTables();$('readyInfo').textContent=t('sourceFileCount')+': '+state.targets.length;
}
function detail(i){const original=state.rows?.[i];if(!original)return;const r=materialGroups(filtered()).find(g=>materialKey(g)===materialKey(original));if(!r){$('detail').close();state.detail=null;return;}state.detail=i;$('detailTitle').textContent=r.code+' · '+r.name;
 if(CommonMaterialOverview.isOverview(state.reasonFilter)){$('detailBody').innerHTML=CommonMaterialOverview.detail(r.members,t,m=>(m.fileName||state.filename).replace(/\.xlsx$/i,'')+'\n'+(m.sheetName||$('sheet').value)+'!'+m.row+'\n'+CommonMaterialBOMUI.context(m,t));labelTables($('detail'));if(!$('detail').open)$('detail').showModal();return;}
 const data=sourceEvidenceData(r,state.reasonFilter);$('detailBody').innerHTML='<p class="notice">'+esc(data.reason).replace(/\n/g,'<br>')+'</p>'+sourceEvidence(data,false)+'<details><summary>'+t('crossAllValues')+'</summary>'+CommonMaterialOverview.detail(r.members,t,m=>(m.fileName||state.filename).replace(/\.xlsx$/i,'')+'\n'+(m.sheetName||$('sheet').value)+'!'+m.row+'\n'+CommonMaterialBOMUI.context(m,t))+'</details>';labelTables($('detail'));if(!$('detail').open)$('detail').showModal();}
function reportSnapshot(lang){
 reportLang=lang;try{const groups=materialGroups(filtered()),overview=CommonMaterialOverview.isOverview(state.reasonFilter),ref=source();
 const details=groups.map(g=>{const data=sourceEvidenceData(g,state.reasonFilter),original=CommonMaterialOverview.detail(g.members,t,m=>(m.fileName||state.filename).replace(/\.xlsx$/i,'')+'\n'+(m.sheetName||$('sheet').value)+'!'+m.row+'\n'+CommonMaterialBOMUI.context(m,t));return {id:g.i,title:g.code+' · '+g.name,html:overview?original:'<p class="notice">'+esc(data.reason).replace(/\n/g,'<br>')+'</p>'+sourceEvidence(data,false)+'<details><summary>'+t('crossAllValues')+'</summary>'+original+'</details>'};});
 const table=$('results').cloneNode(false);table.innerHTML='<thead>'+headingHTML()+'</thead><tbody>'+groups.map(rowHTML).join('')+'</tbody>';
 return {title:t('exportTitle'),lang:state.lang,filename:'New-Liquidation-Result-'+state.company+'.html',table,details,meta:state.company+' · '+state.targets.filter(f=>!state.resultFile||String(f.id)===state.resultFile).map(f=>f.name.replace(/\.xlsx$/i,'')+' · '+f.sheet).join('\n')+'\n'+t('reference')+': '+(sourceFilename(ref?.filename)||t('sourceMissing'))+'\n'+t('materialCount')+': '+groups.length+' / '+materialGroups(state.rows).length+' · '+t('search')+': '+($('search').value||'—')+'\n'+t('reason')+': '+CommonMaterialReport.selectionLabel(state.reasonFilter,t)};
 }finally{reportLang=null;}
}
function exportReport(){if(state.rows)CommonMaterialReport.download({lang:state.lang,filename:'New-Liquidation-Result-'+state.company+'.html',build:reportSnapshot});}

function excelReport(selected){
 const groups=searchedGroups().filter(g=>RF.matches(g.issues,selected)).map(g=>({...g,issues:RF.filterIssues(g.issues,selected)}));
 const ref=source(),strip=v=>str(v).replace(/\.xlsx/ig,''),unique=xs=>[...new Set(xs)],rows=[],usedReferences=[];
 const compactLocations=records=>{const map=new Map();for(const r of records){const at=r.location.lastIndexOf('!'),sheet=at<0?'':r.location.slice(0,at),cell=at<0?r.location:r.location.slice(at+1),key=r.filename+'\n'+sheet;if(!map.has(key))map.set(key,[]);map.get(key).push(cell);}return [...map].map(([sheet,cells])=>(sheet?sheet+'!':'')+unique(cells).join(', ')).join('\n');};
 const fileText=records=>unique(records.map(r=>r.filename)).join('\n')+(records.some(r=>r.context&&!r.reference)?'\n'+unique(records.filter(r=>r.context&&!r.reference).map(r=>r.cell+' · '+r.context)).join('\n'):'');
 const width=v=>[...str(v)].reduce((n,c)=>n+(c.charCodeAt(0)>255?1.8:1),0),lines=(v,w)=>str(v).split('\n').reduce((n,l)=>n+Math.max(1,Math.ceil(width(l)/(w-2))),0);
 const brief=(values,w)=>{const out=[];let n=0;for(const v of values){const cost=lines(v,w);if(n+cost>18){out.push(t('excelDetailsBelow'));break;}out.push(v);n+=cost;}return out.join('\n');};
 for(const g of groups){
  const data=sourceEvidenceData(g,selected),blocks=data.blocks.flatMap(b=>[b,...(b.comparisons||[])]);if(blocks.some(b=>b.reference))usedReferences.push(...g.matches);
  const reasonText=data.reason,shortReason=brief(reasonText.split('\n'),33);if(shortReason!==reasonText)for(const k of RF.displayIssues(g.issues))blocks.push({label:t('reason'),value:issueText(k,g),records:[]});
  rows.push({kind:'summary',issues:!!g.issues.length,merges:[[3,6]],values:[(g.code||'—')+'\n'+t(g.status)+'\n'+t(g.issues.length?'reviewNeeded':'crossNoIssues'),g.name||t('crossBlank'),shortReason,[...new Set(blocks.map(b=>t(b.field)))].join(' · ')+'\n'+t('crossFileShort')+': '+data.fileCount]});
  rows.push({kind:'detailHeader',outline:1,merges:[[1,2],[3,5]],values:[t('field'),t('crossValue'),'',t('crossFilename'),'','',t('crossCell')]});
  let variant=0;
  for(const block of blocks){variant++;let chunk=[];const emit=()=>{rows.push({kind:'detail',outline:1,band:variant%2===1,variantStart:true,merges:[[1,2],[3,5]],values:[evidenceLabel(block),block.value,'',fileText(chunk)||'—','','',compactLocations(chunk)||'—']});chunk=[];};
   for(const record of block.records){const next=[...chunk,record];if(chunk.length&&(lines(fileText(next),66)>20||lines(compactLocations(next),44)>20))emit();chunk.push(record);}emit();
  }
  if(rows.length>200000)throw Error('excelTooLarge');
 }
 const keys=selected==null||selected==='all'?RF.entries(searchedGroups(),t).map(([k])=>k):selected;
 const fileIds=new Set(groups.flatMap(g=>g.members.map(m=>m.fileId)));const files=state.targets.filter(f=>fileIds.has(f.id)).map(f=>({values:[strip(f.name),f.sheet],issues:false}));
 if(usedReferences.length)files.push({values:[strip(sourceFilename(ref?.filename||t('summary'))),unique(usedReferences.map(m=>str(m.source).split('!')[0]).filter(Boolean)).join('\n')||'—'],issues:false});
 return {layout:'crossCompact',title:t('exportTitle'),summary:state.company+' · '+t('materialCount')+': '+groups.length+' · '+t('reviewMaterials')+': '+groups.filter(g=>g.issues.length).length+'\n'+t('exportSelection')+': '+keys.map(k=>t(k==='clean'?'crossNoIssues':k)).join(', '),sheets:[
 {name:t('crossMaterialSheet'),headers:[t('code'),t('name'),t('reason'),t('crossEvidence'),'','',''],headerMerges:[[3,6]],widths:[23,25,33,22,22,22,44],rows,outline:true,note:t('sourceExcelOutline'),empty:t('noData')},
 {name:t('crossFileList'),headers:['crossFilename','crossSelectedSheets'].map(t),widths:[76,48],rows:files,empty:''}
 ]};
}
async function exportExcel(){
 if(!state.rows||state.excelSaving)return;const selected=await CommonMaterialExcel.choose({t,items:searchedGroups(),availableItems:materialGroups(state.rows),initial:state.reasonFilter,count:keys=>searchedGroups().filter(r=>CommonMaterialExcel.includeRow(r.issues,keys)).length});if(!selected)return;state.excelSaving=true;$('exportExcel').disabled=true;$('exportExcel').textContent=t('excelWorking');clearError();
 try{const report=excelReport(selected),filename='New-Liquidation-Review-'+state.company+'-'+new Date().toISOString().slice(0,10)+'.xlsx',bytes=await CommonMaterialExcel.build(report);
 if(window.CommonMaterialModule.saveExcel){const r=await window.CommonMaterialModule.saveExcel(bytes,filename);if(!r?.saved&&!r?.cancelled)throw Error('excelFailed');$('readyInfo').textContent=t(r.cancelled?'excelCancelled':'excelSaved');}
 else{const url=URL.createObjectURL(new Blob([bytes],{type:'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'})),a=document.createElement('a');a.href=url;a.download=filename;a.click();setTimeout(()=>URL.revokeObjectURL(url),10000);$('readyInfo').textContent=t('excelSaved');}
 }catch(e){error(e.message==='excelTooLarge'?'excelTooLarge':'excelFailed');}finally{state.excelSaving=false;$('exportExcel').disabled=false;$('exportExcel').textContent=t('exportExcel');}
}
document.querySelectorAll('[data-company]').forEach(e=>e.onclick=()=>setCompany(e.dataset.company));
document.querySelectorAll('[data-lang]').forEach(e=>e.onclick=()=>{state.lang=e.dataset.lang;labels();});
$('pickTarget').onclick=()=>{if(!state.company)return error('chooseCompany');$('targetFile').click();};$('pickSource').onclick=()=>{if(!state.company)return error('chooseCompany');$('sourceFile').click();};
$('targetFile').onchange=e=>{targetFiles(e.target.files);e.target.value='';};$('sourceFile').onchange=e=>referenceFile(e.target.files[0]);
for(const [id,fn] of [['targetDrop',targetFiles],['sourceDrop',referenceFile]]){const d=$(id);d.ondragover=e=>{e.preventDefault();d.classList.add('over');};d.ondragleave=()=>d.classList.remove('over');d.ondrop=e=>{e.preventDefault();d.classList.remove('over');if(id==='targetDrop')fn(e.dataTransfer.files);else if(e.dataTransfer.files.length===1)fn(e.dataTransfer.files[0]);else error('file_invalid');};}
$('bomLayout').oninput=e=>{if(e.target.matches('[data-bom-field]')){state.dirty=true;saveActive();invalidate();$('run').disabled=true;$('bomLayout').querySelector('[data-bom-dirty]').textContent=t('bomApplyNeeded');}};
$('bomLayout').onclick=e=>{if(!e.target.closest('[data-bom-apply]'))return;try{state.map=CommonMaterialBOMUI.read($('bomLayout'),state.map,state.wb.Sheets[$('sheet').value]);state.dirty=false;clearError();saveActive();invalidate();showLayout();}catch(x){error(x.message);$('run').disabled=true;}};
$('sourceTarget').onchange=e=>{activateTarget(e.target.value);};$('removeTarget').onclick=()=>{if(state.busy)return;installTargets(state.targets.filter(f=>f.id!==state.activeTarget));clearError();};$('resultFile').onchange=e=>{state.resultFile=e.target.value;render();if(state.detail!==null)detail(state.detail);};
$('sheet').onchange=selectSheet;$('run').onclick=run;$('search').oninput=render;$('reasonFilter').onchange=e=>{state.reasonFilter=CommonMaterialReasonFilter.getValue($('reasonFilter'));render();if(state.detail!==null)detail(state.detail);};
document.querySelectorAll('.mapping-grid input[id^=map]').forEach(input=>input.oninput=()=>{if(!state.wb)return;state.dirty=true;saveActive();invalidate();});
$('applyMap').onclick=()=>{
 if(!state.wb)return;const m={},used=new Set();try{for(const [k,id] of [['code','Code'],['name','Name'],['spec','Spec'],['vnName','VnName'],['unit','Unit'],['price','Price'],['hs','Hs']]){const v=$('map'+id).value.trim().toUpperCase();if(!v&&['hs','unit','name','spec','vnName'].includes(k)){m[k]=-1;continue;}if(!/^[A-Z]{1,3}$/.test(v)||used.has(v))throw Error('mappingInvalid');used.add(v);m[k]=XLSX.utils.decode_col(v);if(m[k]>16383)throw Error('mappingInvalid');}m.header=Number($('mapHeader').value)-1;if(!Number.isInteger(m.header)||m.header<0||m.header>99999)throw Error('mappingInvalid');state.map=m;state.dirty=false;clearError();saveActive();invalidate();}catch(e){error(e.message);}
};
$('autoMap').onclick=()=>{if(state.wb)selectSheet();};
$('returnSummary').onclick=()=>{if(state.busy)return;delete state.manual[state.company];$('sourceFile').value='';clearError();if(state.pending[state.company]){state.saved[state.company]=state.pending[state.company];delete state.pending[state.company];}state.sourceCandidate=null;invalidate();showSource();};
$('applySource').onclick=()=>{if(state.sourceCandidate)installSource(state.sourceCandidate);};$('cancelSource').onclick=()=>{state.sourceCandidate=null;showSource();};
$('applyNew').onclick=()=>{if(!state.pending[state.company])return;state.saved[state.company]=state.pending[state.company];delete state.pending[state.company];invalidate();showSource();};
$('reset').onclick=()=>{state.targets=[];state.activeTarget=null;state.resultFile='';state.dirty=false;state.example=null;showSource();state.wb=null;state.map=null;state.filename='';state.notice=null;$('targetFile').value='';$('targetName').textContent='';$('sheet').disabled=true;$('sheet').innerHTML='<option>'+t('noneSheet')+'</option>';$('search').value='';$('fileNotice').classList.add('hidden');clearError();invalidate();showLayout();showTargets();};
$('results').onclick=e=>{const b=e.target.closest('[data-detail]');if(b)detail(Number(b.dataset.detail));};$('closeDetail').onclick=()=>{$('detail').close();state.detail=null;};$('detail').addEventListener('close',()=>{state.detail=null;});$('export').onclick=exportReport;$('exportExcel').onclick=exportExcel;
// Suite integration: trusted host code calls this API. No independent network or database writes.
window.CommonMaterialModule={receiveSource:receive,setLanguage(lang){state.lang=normalizeLang(lang);labels();},setCompany,clearSource(company){delete state.saved[company];delete state.pending[company];if(state.company===company&&!state.manual[company]&&!state.example)invalidate();showSource();},getState(){return state;},readWorkbook,loadWorkbook,run,excelReport};
window.EcussModuleI18n={languages:['ko','en','vi'],setLanguage:lang=>window.CommonMaterialModule.setLanguage(lang),getLanguage:()=>state.lang};
window.EcussModuleState={busy:()=>state.busy||state.excelSaving||!!window.CrossReview?.busy(),hasWork:()=>!!state.wb||!!window.CrossReview?.hasWork(),hasResult:()=>!!state.rows||!!window.CrossReview?.hasResult()};
labels();
})();

