/* Session-only workspace. Approved module documents remain mounted until explicitly closed. */
(()=>{
'use strict';
const suite=window.__ECUSS_SUITE__;if(!suite||!window.EcussDesktop)return;
const modules=new Map(suite.modules.map(m=>[m.id,m])),opened=new Map(),blobs=new Map();
const home=document.getElementById('home-content'),stage=document.getElementById('module-content'),tabs=document.getElementById('task-tabs');
const menu=document.getElementById('work-sidebar'),rail=document.getElementById('menu-rail'),pin=document.getElementById('menu-pin'),railPin=document.getElementById('rail-pin'),toggle=document.getElementById('menu-toggle'),shade=document.getElementById('menu-shade');
let active=null,pinned=true,visible=true,pending=false,refreshing=false;
const menuPreferences={home:true,module:false};
const text={ko:{home:'메인화면',menu:'업무 메뉴',tabs:'작업 탭',pin:'고정하기',pinned:'고정됨',hide:'숨기기',dashboard:'현황판',work:'업무 카테고리',tools:'업무 도구',hint:'모듈을 선택하면 작업 탭으로 열립니다.',guide:'탭으로 작업을 이어가세요',how:'왼쪽 메뉴에서 모듈 열기 → 상단 탭으로 바로 이동',keep:'이동 시 작업 유지 · ×는 해당 작업 종료',empty:'← 메뉴에서 모듈을 열면 이곳에 탭이 추가됩니다',close:'작업 종료',busy:'진행 중인 작업이 끝난 뒤 다시 시도해 주세요.',refreshing:'조회 정보 확인 중…',refreshed:'조회 정보 확인을 마쳤습니다.',error:'요청을 완료하지 못했습니다. 다시 시도해 주세요.'},en:{home:'Home',menu:'Work menu',tabs:'Work tabs',pin:'Pin menu',pinned:'Pinned',hide:'Hide',dashboard:'Dashboards',work:'Work categories',tools:'Work tools',hint:'Select a module to open a work tab.',guide:'Continue working across tabs',how:'Open from the menu → Switch using the tabs above',keep:'Switching preserves work · × closes the task',empty:'← Open a module from the menu to add a tab',close:'Close task',busy:'Wait for the current task to finish.',refreshing:'Checking status…',refreshed:'Status check complete.',error:'Could not complete the request. Please try again.'},vi:{home:'Màn hình chính',menu:'Menu công việc',tabs:'Thẻ công việc',pin:'Ghim menu',pinned:'Đã ghim',hide:'Ẩn',dashboard:'Bảng tổng quan',work:'Nhóm công việc',tools:'Công cụ công việc',hint:'Chọn mô-đun để mở thẻ công việc.',guide:'Tiếp tục công việc qua các thẻ',how:'Mở từ menu → Chuyển bằng các thẻ phía trên',keep:'Chuyển thẻ giữ công việc · × đóng công việc',empty:'← Chọn mô-đun từ menu để thêm thẻ',close:'Đóng công việc',busy:'Chờ tác vụ hiện tại hoàn tất.',refreshing:'Đang kiểm tra trạng thái…',refreshed:'Đã kiểm tra trạng thái.',error:'Không hoàn tất yêu cầu. Vui lòng thử lại.'}};
const copy=()=>text[document.documentElement.lang]||text.ko;
const name=id=>{const names=modules.get(id)?.name||window.EcussHome?.externalNames?.[id];return names?.[document.documentElement.lang]||names?.ko||id;};
const notice=document.createElement('span');notice.className='shell-notice';notice.setAttribute('role','status');document.querySelector('.task-shell').append(notice);
function menuRender(){menuPreferences[active?"module":"home"]=pinned;document.body.classList.toggle('menu-unpinned',!pinned);document.body.classList.toggle('menu-overlay',!pinned&&visible);rail.hidden=pinned;shade.hidden=pinned||!visible;menu.inert=!pinned&&!visible;toggle.setAttribute('aria-expanded',String(pinned||visible));pin.setAttribute('aria-pressed',String(pinned));pin.textContent=pinned?copy().pinned:copy().pin;railPin.title=railPin.ariaLabel=copy().pin;}
function hideMenu(){pinned=false;visible=false;menuRender();railPin.focus();}
railPin.onclick=()=>{pinned=visible=true;menuRender();pin.focus();};pin.onclick=()=>{pinned=!pinned;visible=true;menuRender();};document.getElementById('menu-hide').onclick=hideMenu;shade.onclick=hideMenu;toggle.onclick=()=>{if(pinned)hideMenu();else{visible=!visible;menuRender();}};
document.addEventListener('keydown',e=>{if(e.key==='Escape'&&!pinned&&visible)hideMenu();});
document.querySelectorAll('.review-heading').forEach(b=>b.onclick=()=>{const show=b.getAttribute('aria-expanded')!=='true';b.setAttribute('aria-expanded',String(show));document.getElementById(b.getAttribute('aria-controls')).hidden=!show;});
function identity(win){for(const[id,v]of opened)if(v.frame.contentWindow===win)return id;throw Error('Unregistered module document');}
function pageState(id){const v=opened.get(id);if(!v)return {hasWork:false,busy:false};try{const w=v.frame.contentWindow;if(!v.loaded||typeof w.EcussDesktopState!=='function')return {hasWork:true,busy:true};return w.EcussDesktopState();}catch{return {hasWork:true,busy:true};}}
function state(id=null){if(id)return pageState(id);const all=[...opened.keys()].map(pageState);return {busy:pending||refreshing||all.some(s=>s.busy),hasWork:all.some(s=>s.hasWork)};}
async function request(path,id){notice.textContent='';try{const r=await window.EcussDesktop.call(path,id);if(r.status!==200){notice.textContent=r.value?.busy?copy().busy:r.value?.message||copy().error;return false;}return r.value?.ok!==false;}catch{notice.textContent=copy().error;return false;}}
async function select(id){if(pending)return;pending=true;try{await request(id?'/desktop/open':'/desktop/home',id);}finally{pending=false;}}
function renderTabs(){document.getElementById('home-anchor').setAttribute('aria-pressed',String(!active));tabs.replaceChildren();for(const[id,v]of opened){const item=document.createElement('div');item.className='task-tab'+(active===id?' active':'');const b=document.createElement('button');b.className='activate';b.textContent=name(id);b.title=name(id);b.setAttribute('role','tab');b.setAttribute('aria-selected',String(active===id));b.onclick=()=>select(id);const close=document.createElement('button');close.className='close';close.textContent='×';close.title=copy().close+' · '+name(id);close.setAttribute('aria-label',close.title);close.onclick=()=>request('/desktop/close-tab',id);item.append(b,close);tabs.append(item);}if(!opened.size){const empty=document.createElement('span');empty.className='tab-empty';empty.textContent=copy().empty;tabs.append(empty);}document.querySelectorAll('[data-review-target]').forEach(n=>{n.setAttribute('aria-current',String(n.dataset.reviewTarget===active));n.dataset.open=String(opened.has(n.dataset.reviewTarget));});const selected=tabs.querySelector('.active');if(selected){const left=selected.offsetLeft;if(left<tabs.scrollLeft)tabs.scrollLeft=left;else if(left+selected.offsetWidth>tabs.scrollLeft+tabs.clientWidth)tabs.scrollLeft=left+selected.offsetWidth-tabs.clientWidth;}}
function activate(id){active=id;pinned=menuPreferences[id?'module':'home'];visible=pinned;menuRender();document.body.classList.toggle('module-mode',!!id);document.getElementById(id?'module-tab-slot':'home-tab-slot').append(document.querySelector('.task-shell'));home.hidden=!!id;stage.hidden=!id;for(const[k,v]of opened)v.frame.hidden=k!==id;if(!pinned){visible=false;menuRender();}renderTabs();}
function openApproved(id){if(id&&!opened.has(id)){const m=modules.get(id);if(!m)throw Error('Unknown module');const f=document.createElement('iframe');f.dataset.workspaceModule=id;f.title=name(id);f.hidden=true;const entry={frame:f,loaded:false};opened.set(id,entry);f.addEventListener('load',()=>{entry.loaded=true;renderTabs();});f.src=m.entry.substring(3);stage.querySelector('.module-viewport').append(f);}activate(id);}
function closeApproved(id){const v=opened.get(id);if(!v)return;v.frame.remove();opened.delete(id);for(const[url,owner]of blobs)if(owner===id)blobs.delete(url);activate(active===id?null:active);}
// Refresh is scoped to the screen that received the key. Never reload the workspace document.
async function refresh(){
 if(refreshing||pending)return false;
 const target=active;refreshing=true;
 try{
  if(target)return await request('/desktop/refresh-tab',target);
  notice.textContent=copy().refreshing;
  await Promise.all([window.EcussUpdateStatus?.refresh(),window.EcussRecords?.refresh(true),window.EcussStock?.refresh(),window.EcussMailChecks?.refresh(true)]);
  notice.textContent=copy().refreshed;return true;
 }catch{notice.textContent=copy().error;return false;}
 finally{refreshing=false;}
}
function refreshApproved(id){
 const entry=opened.get(id);if(!entry)return;
 const previous=entry.frame,next=previous.cloneNode(false);
 entry.loaded=false;entry.frame=next;
 next.addEventListener('load',()=>{entry.loaded=true;renderTabs();});
 for(const[url,owner]of blobs)if(owner===id)blobs.delete(url);
 previous.replaceWith(next); // Keep the tab position, active tab, sidebar and every other frame.
 renderTabs();
}
window.EcussWorkspace={bootstrapFrom(win){const id=identity(win),m=modules.get(id);if(win.location.href!==new URL(m.entry.substring(3),location.href).href)throw Error('Unexpected module URL');return {nonce:window.__ECUSS_HOST_NONCE__,module:window.__ECUSS_MODULE_CONTEXTS__[id],suite:{...suite,lang:document.documentElement.lang}};},openApproved,closeApproved,refreshApproved,refresh,state,language(lang){if(!text[lang])return;suite.lang=lang;if(document.documentElement.lang!==lang){const control=document.getElementById("language");control.value=lang;control.dispatchEvent(new Event("change"));}},registerBlob(win,url){blobs.set(url,identity(win));},downloadOwner:url=>blobs.get(url)||null,broadcastAccess(value){for(const v of opened.values()){try{v.frame.contentWindow.EcussApplyWorkAccess?.(value);}catch{}}},callFrom(win,path,payload){const id=identity(win);return window.EcussDesktop.call(path,payload,id);}};
window.EcussDesktopState=()=>state();
document.getElementById('home-anchor').onclick=()=>select(null);
document.getElementById('home-anchor').setAttribute('aria-keyshortcuts','Backspace Alt+ArrowLeft');
document.addEventListener('keydown',event=>{
 const backspace=event.key==='Backspace'&&!event.altKey,altLeft=event.key==='ArrowLeft'&&event.altKey;
 if(!active||(!backspace&&!altLeft)||event.ctrlKey||event.metaKey||event.shiftKey)return;
 const handled=event.defaultPrevented;if(altLeft)event.preventDefault();
 if(handled||event.isComposing||event.keyCode===229)return;
 const nodes=event.composedPath?.()||[event.target];
 if(nodes.some(el=>el?.closest?.('dialog,[role="dialog"]'))||document.querySelector('dialog[open],[role="dialog"][aria-modal="true"]:not([hidden])'))return;
 if(backspace&&nodes.some(el=>el?.isContentEditable||el?.closest?.('input,textarea,select,[contenteditable]:not([contenteditable="false"]),[role="textbox"],[role="combobox"],[role="spinbutton"]')))return;
 event.preventDefault();if(!event.repeat)select(null);
});
document.querySelectorAll('[data-review-target]').forEach(n=>n.onclick=()=>select(n.dataset.reviewTarget));
function labels(){const t=copy();toggle.textContent='☰ '+t.menu;document.getElementById('home-anchor').lastChild.textContent=t.home;document.querySelector('.menu-controls strong').textContent=t.menu;document.getElementById('menu-hide').textContent=t.hide;document.querySelector('.rail-label').textContent=t.menu;const headings=document.querySelectorAll('.review-heading');headings.forEach(heading=>{const key={'review-dash':'dashboard','review-tools':'tools','review-work':'work'}[heading.getAttribute('aria-controls')];heading.firstChild.textContent=t[key];});document.querySelectorAll('[data-review-target]').forEach(n=>n.querySelector('.nav-text').textContent=name(n.dataset.reviewTarget));menuRender();renderTabs();}
labels();new MutationObserver(labels).observe(document.documentElement,{attributes:true,attributeFilter:['lang']});
const shell=document.querySelector('.task-shell');function measure(){document.documentElement.style.setProperty('--shell-height',shell.getBoundingClientRect().height+'px');}new ResizeObserver(measure).observe(shell);measure();
})();

(()=>{
const groups=['dashboards','work-tools','work-categories'].map(id=>{
 const section=document.getElementById(id),head=section.querySelector('.section-head'),title=head.querySelector('h2');
 const body=document.createElement('div');body.id=id+'-body';body.className='category-body';
 [...section.children].filter(e=>e!==head).forEach(e=>body.append(e));section.append(body);
 const button=document.createElement('button');button.type='button';button.className='category-toggle';button.setAttribute('aria-controls',body.id);button.setAttribute('aria-expanded','true');
 const count=document.createElement('span');count.className='category-count';const label=document.createElement('span');label.className='category-action';
 const arrow=document.createElement('span');arrow.className='category-chevron';arrow.setAttribute('aria-hidden','true');arrow.textContent='⌃';
 title.append(count);button.append(title,label,arrow);head.prepend(button);const summary=head.querySelector('.summary');if(summary)summary.hidden=true;
 function refresh(){const lang=document.documentElement.lang,open=!body.hidden;count.textContent=body.querySelectorAll('.card').length;label.textContent=lang==='en'?(open?'Collapse':'Expand'):lang==='vi'?(open?'Thu gọn':'Mở rộng'):(open?'접기':'펼치기');button.setAttribute('aria-expanded',String(open));arrow.textContent=open?'⌃':'⌄';}
 button.onclick=()=>{body.hidden=!body.hidden;refresh();};refresh();return{section,head,button,title,count,body,refresh};
});
// Home translation updates title text and rerenders cards; restore the count after it finishes.
new MutationObserver(()=>groups.forEach(g=>{if(!g.title.contains(g.count))g.title.append(g.count);g.refresh();})).observe(document.documentElement,{attributes:true,attributeFilter:['lang']});
})();

(()=>{const panel=document.querySelector(".connection-panel"),details=document.getElementById("connection-settings");details.querySelector(".status-details").prepend(document.getElementById("github-status"));document.addEventListener("click",e=>{if(!panel.contains(e.target))details.open=false;});})();

