/* Suite home only. Four latest metadata slots; no business results or localStorage. */
(()=>{
'use strict';
if(!window.EcussDesktop||window.__ECUSS_DESKTOP_CONTEXT__?.moduleId)return;
const companies={AMO:'AMOVINA',AMOGREEN:'AMOGREEN VINA'},kinds=['weekly','monthly'];
const texts={
ko:{weekly:'주간',monthly:'월간',yes:'완료',no:'미완료',unknown:'확인 불가',pending:'동기화 대기',title:'메일 발송 요청 현황',time:'최근 수행',none:'수행 기록 없음',zone:'베트남 시각',close:'닫기',note:'Outlook 발송 요청 접수 기준'},
en:{weekly:'Weekly',monthly:'Monthly',yes:'Done',no:'Not done',unknown:'Unknown',pending:'Sync pending',title:'Mail request status',time:'Last performed',none:'No request recorded',zone:'Vietnam time',close:'Close',note:'Request accepted by Outlook'},
vi:{weekly:'Tuần',monthly:'Tháng',yes:'Xong',no:'Chưa',unknown:'Chưa rõ',pending:'Chờ đồng bộ',title:'Trạng thái yêu cầu gửi thư',time:'Thực hiện gần nhất',none:'Chưa có yêu cầu',zone:'Giờ Việt Nam',close:'Đóng',note:'Outlook đã nhận yêu cầu gửi thư'}};
const lang=()=>texts[document.documentElement.lang]||texts.ko;
let snapshot=null,fetching=null,initialized=false;
const element=(tag,cls,text)=>{const n=document.createElement(tag);if(cls)n.className=cls;if(text!=null)n.textContent=text;return n;};
const time=v=>{const d=new Date(v);return !v||!Number.isFinite(+d)?lang().none:new Intl.DateTimeFormat('en-GB',{timeZone:'Asia/Ho_Chi_Minh',year:'numeric',month:'2-digit',day:'2-digit',hour:'2-digit',minute:'2-digit',second:'2-digit',hour12:false}).format(d);};
const get=(c,k)=>snapshot?.rows?.find(r=>r.company===c&&r.reportKind===k);
function label(r){const t=lang();if(!snapshot||snapshot.connection!=='connected')return snapshot?.connection==='pending'?t.pending:t.unknown;return r?.completed===true?t.yes:r?.completed===false?t.no:t.unknown;}
function details(company,kind){
document.querySelector('.suite-mail-check-detail')?.remove();
const t=lang(),r=get(company,kind),d=element('dialog','suite-mail-check-detail');d.append(element('h2','',t.title));
if(company)d.append(element('p','',companies[company]+' · '+t[kind]+' · '+label(r)),element('p','',t.time+': '+time(r?.performedAt)));
else for(const c of Object.keys(companies))for(const k of kinds){const v=get(c,k);d.append(element('p','',companies[c]+' · '+t[k]+' · '+label(v)+' · '+time(v?.performedAt)));}
d.append(element('p','',t.zone+' · '+t.note));const close=element('button','',t.close);close.type='button';close.onclick=()=>d.close();d.append(close);d.addEventListener('close',()=>d.remove(),{once:true});document.body.append(d);d.showModal();
}
function render(){
const card=document.querySelector('[data-module-card="balance-ecuss"]');if(!card)return;
let panel=card.querySelector('.suite-mail-check');
if(!panel){card.style.containerType='inline-size';panel=element('div','suite-mail-check');panel.setAttribute('role','group');const anchor=card.querySelector('.card-actions')||card.querySelector('.open');if(!anchor)return;anchor.before(panel);}
let compact=card.querySelector('.suite-mail-check-small');if(!compact){compact=element('button','suite-mail-check-small');compact.type='button';compact.onclick=()=>details();card.append(compact);}
compact.replaceChildren();compact.setAttribute('aria-label',lang().title);
for(const k of kinds){const count=Object.keys(companies).filter(c=>get(c,k)?.completed===true).length;compact.append(element('span','',lang()[k]+' '+(snapshot?.connection==='connected'?count+'/2':snapshot?.connection==='pending'?'↻':'?')));}
panel.setAttribute('aria-label',lang().title);panel.replaceChildren();panel.append(element('span','suite-mail-check-corner',''));for(const k of kinds)panel.append(element('span','suite-mail-check-heading',lang()[k]));
for(const c of Object.keys(companies)){panel.append(element('span','suite-mail-check-company '+c,companies[c]));for(const k of kinds){const r=get(c,k),text=label(r),b=element('button','suite-mail-check-state');b.append(element('span','suite-mail-check-prefix',lang()[k]+' '),document.createTextNode(snapshot?.connection==='connected'?text:snapshot?.connection==='pending'?'↻':'?'));b.type='button';b.dataset.state=snapshot?.connection==='connected'&&typeof r?.completed==='boolean'?(r.completed?'complete':'incomplete'):'unknown';b.setAttribute('aria-label',companies[c]+' · '+lang()[k]+' · '+text+' · '+time(r?.performedAt));b.title=lang().time+': '+time(r?.performedAt)+' · '+lang().zone;b.onclick=()=>details(c,k);panel.append(b);}}
}
async function refresh(force=false){if(fetching)return fetching;fetching=(async()=>{try{const r=await EcussDesktop.call('/mail-check/status',force===true);if(r.status!==200||!Array.isArray(r.value?.rows))throw Error('unavailable');snapshot=r.value;}catch{snapshot={connection:'unavailable',rows:snapshot?.rows||[]};}finally{render();fetching=null;}})();return fetching;}
const style=element('style');style.textContent=`
.suite-mail-check{display:grid;grid-template-columns:minmax(0,1fr) max-content max-content;gap:3px 5px;width:100%;font-size:11px;line-height:16px;align-items:center;color:#52667d}
.suite-mail-check-heading{text-align:center;font-weight:600}.suite-mail-check-prefix{display:none}@container (min-width:285px){.suite-mail-check-heading,.suite-mail-check-corner{display:none}.suite-mail-check-prefix{display:inline}}
.suite-mail-check-company{font-weight:650;overflow-wrap:normal;word-break:normal;line-height:16px}.suite-mail-check-company.AMO{color:#b52d40}.suite-mail-check-company.AMOGREEN{color:#187347}
.suite-mail-check-state{font:inherit;line-height:16px;padding:1px 2px;border:0;border-radius:4px;background:transparent;white-space:nowrap;color:#8a611e;min-width:0;cursor:pointer}.suite-mail-check-state[data-state=complete]{color:#08783d}.suite-mail-check-state[data-state=incomplete]{color:#bd2525}.suite-mail-check-state:hover{background:#edf2ff}.suite-mail-check-state:focus-visible{outline:2px solid #527cbd;outline-offset:1px}
.suite-mail-check-small{display:none}@media(max-width:600px){.suite-mail-check{display:none}.suite-mail-check-small{display:flex;flex-direction:column;position:absolute;right:16px;bottom:10px;border:0;border-radius:5px;background:#f0f4ff;color:#4361a0;font:11px/16px Segoe UI,Malgun Gothic,sans-serif;padding:1px 7px;height:34px;cursor:pointer}}
.suite-mail-check-detail{max-width:min(480px,90vw);border:1px solid #c4d3dd;border-radius:12px;padding:24px;color:#26374e;background:#fff}.suite-mail-check-detail::backdrop{background:#12375188}.suite-mail-check-detail h2{font-size:16px}.suite-mail-check-detail p{font-size:13px;overflow-wrap:anywhere}.suite-mail-check-detail button{font:inherit;border:1px solid #dce5fa;border-radius:9px;background:#f0f4ff;color:#4361a0;padding:8px 12px}
@media(forced-colors:active){.suite-mail-check-state,.suite-mail-check-company{color:CanvasText!important}.suite-mail-check-state{border:1px solid ButtonText}.suite-mail-check-detail{background:Canvas;color:CanvasText}}
`;document.head.append(style);
function init(){if(initialized)return;initialized=true;const modules=document.getElementById('modules');if(modules)new MutationObserver(()=>{if(!document.querySelector('.suite-mail-check'))render();}).observe(modules,{childList:true,subtree:true});new MutationObserver(render).observe(document.documentElement,{attributes:true,attributeFilter:['lang']});render();refresh();setInterval(refresh,60000);window.addEventListener('focus',()=>refresh(true));}
window.EcussMailChecks={refresh};if(document.readyState==='complete')init();else window.addEventListener('load',init,{once:true});
})();
