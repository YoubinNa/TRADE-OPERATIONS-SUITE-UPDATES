const workSurfaces={
  'import-export-performance':{panels:'.panel,.item-menu',top:'.masthead'},
  'balance-ecuss':{panels:'.upload-card,.panel,.kpi,.modal-dialog',primary:'#analyze',drops:'.upload-card',top:'.top'},
  'balance-sheet-validation':{panels:'.upload,.coverage,.resulthead,.method,dialog',primary:'#run',drops:'.filelabel'},
  'stock-status-amovina':{panels:'.upload-group,.card,.ratebox,.review,.warehouse-sheets',primary:'#run',drops:'.dropzone',top:'header'},
  'stock-status-amogreen-vina':{panels:'.top-options,.card,.action-card,.gap-panel,.rules',primary:'#run',drops:'.file-row',top:'header'},
  'vn-kr-customs-translation':{panels:'.panel,.metric,.result-file,.file-box',primary:'#run,#select-original',drops:'#original-dropzone'},
  'customs-inspection-cost-comparison':{panels:'.panel,.kpi,.utm,.utm-highlight,.result-comparison,.summary,.verdict,.report-open',primary:'#calculate',top:'#ecuss-page-header'},
  'common-material-review':{panels:'.panel,.companybar,.modebar,.stat,.source-status,.mapping',primary:'#run,#applyMap',drops:'.drop'},
  'machine-information-validation':{panels:'.upload-panel,.upload-card,.panel,.editor-source,.review-source',primary:'#start-validation,#run',drops:'.dropzone',top:'#ecuss-page-header'},
  'shipping-freight-review':{panels:'.panel,.fx,.mode,.aside,.totalbox,.cargo,.statebar',primary:'#addRow',top:'.topbar'},
  'psr-rvc-lvc-calculator':{panels:'.panel,.sheet,.card,.result-box',primary:'button.primary',top:'body>header'},
  'monthly-report-consolidation':{panels:'.panel,.sidebar,.common-rates,.rule-box,.period',primary:'#run',drops:'.drop',top:'.topbar'},
  'stock-dashboard':{panels:'.card,.panel,.source-download,.selection-summary',primary:'#refreshSource'},
  'materials-shipping':{panels:'.panel,.view,.corporations,.toolbar,.result-card,.kpi,.source-card,.message',primary:'[data-action="upload"]',top:'#ecuss-page-header'},
  'materials-info':{panels:'.panel,.view,.corporations,.toolbar,.result-card,.kpi,.source-card,.message',primary:'[data-action="upload"]',top:'#ecuss-page-header'},
  'vietnam-logistics-cost':{panels:'.filters,.logistics-toolbar,.card,.kpi,.insight,.reportbox,.processing-strip',primary:'.uploadLabel',top:'.logistics-header'},
  'stock-status-gap-revision':{panels:'.upload,.metrics>div,.toolbar,.table-wrap',primary:'#apply',drops:'label[for="file"]'},
  'container-stuffing-simulator':{panels:'.side,.container-section,.manifest,.scene-head,.dashboard,.counter,.scene-tools,.camera-tools',primary:'#generate,#optimize',top:'.app-head'},
  'validation-status':{panels:'dialog',primary:'main>button'},'mail-check-status':{panels:'dialog',primary:'main>button'}
};
function workStyleFor(id){
  const s=workSurfaces[id]||{};
  const css=(selectors,body)=>selectors?'html[data-work-theme] :is('+selectors+'){'+body+'}':'';
  return '@media screen{'+
    css(s.panels,'background:var(--ws-surface)!important;color:var(--ws-text)!important;border-color:var(--ws-line)!important;border-radius:12px;box-shadow:0 3px 14px var(--ws-shadow)!important;')+
    css(s.top,'background:var(--ws-header)!important;color:var(--ws-text)!important;border-color:var(--ws-line)!important;box-shadow:none!important;')+
    css(s.drops,'background:var(--ws-field)!important;border-color:var(--ws-edge)!important;')+
    css(s.primary,'background:var(--ws-cta)!important;color:var(--ws-oncta)!important;border-color:var(--ws-cta)!important;font-weight:700!important;')+'}';
}

function prepareWorkGuidance(doc,id){
  if(id==='customs-inspection-cost-comparison'){
    const view=doc.defaultView,draw=view.drawReport;
    if(typeof draw!=='function'||doc.body.hasAttribute('data-inspection-renderer'))return;
    doc.body.setAttribute('data-inspection-renderer','');
    // The approved renderer reads the on-screen result colors synchronously for its white paper.
    view.drawReport=function(...args){
      doc.body.setAttribute('data-inspection-paper','');
      try{return draw.apply(this,args);}
      finally{doc.body.removeAttribute('data-inspection-paper');}
    };
    return;
  }
  if(id==='shipping-freight-review'){
    const heading=doc.querySelector('main .heading'),reset=doc.querySelector('.topbar #reset');
    if(heading&&reset)heading.append(reset);
    const summary=doc.querySelector('#originRateNote>summary');
    if(summary?.textContent==='계산 기준 및 검토본 안내')summary.textContent='운임 계산 기준';
    for(const node of doc.querySelectorAll('#originRateNote li>b,#productRateNote li')){
      const text=node.firstChild;
      if(text?.nodeType===3&&text.data.startsWith('검토본 임시 기준:'))text.data=text.data.replace('검토본 임시 기준:','잠정 계산 기준:');
    }
    return;
  }
  if(id!=='stock-status-amovina'&&id!=='monthly-report-consolidation')return;
  function translateGuide(){
    if(id==='stock-status-amovina'){
      const names={'검토본 31 UI 반영 사항':'언어와 화면 설정','Review 31 UI changes':'Language and display settings','Thay đổi giao diện bản xem xét 31':'Cài đặt ngôn ngữ và hiển thị'};
      for(const h of doc.querySelectorAll('#moduleHelp30 h3'))if(names[h.textContent])h.textContent=names[h.textContent];
    }else{
      const items=doc.querySelectorAll('#guide ol>li');
      for(const el of items){
        const text=el.firstChild;
        if(text?.nodeType!==3)continue;
        const clean=text.data.replace(/^이 검토본은 제공된/,'제공된').replace(/^This preview supports/,'This module supports').replace(/^Bản xem thử hỗ trợ/,'Mô-đun hỗ trợ');
        if(clean!==text.data)text.data=clean;
      }
      const note=doc.querySelector('#guide .guide>small')?.firstChild;
      if(note?.nodeType===3&&note.data.includes('docs/MODULE_UI_STANDARD_KO.md')&&note.data.includes('JSZip'))note.data=note.data.slice(note.data.indexOf('JSZip'));
    }
  }
  translateGuide();
  new MutationObserver(translateGuide).observe(doc.documentElement,{attributes:true,attributeFilter:['lang']});
}
