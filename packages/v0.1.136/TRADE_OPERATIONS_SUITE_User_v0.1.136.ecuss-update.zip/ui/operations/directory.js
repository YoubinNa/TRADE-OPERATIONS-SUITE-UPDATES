const directoryExtras = {
  'validation-status': {title:'밸런스 시트 검증 현황',description:'법인별 일일 밸런스 시트 검증 수행 여부를 확인합니다.',icon:'list-checks'},
  'mail-check-status': {title:'세관 자료 검증 현황',description:'주간·월간 세관 자료 확인 요청 메일의 발송 여부를 확인합니다.',icon:'file-check-2'},
  'vietnam-arrival-cargo': {title:'베트남 도착 화물 정보',description:'베트남 도착 화물 조회 페이지를 엽니다.',icon:'globe',url:'https://trade-scm-portal.pages.dev/'},
  'vietnam-processing-fees': {title:'베트남 법인 임가공비 현황',description:'베트남 법인의 임가공비 현황을 새 창에서 조회합니다.',icon:'globe',url:'https://vietnam-processing-dashboard.vercel.app/'}
};
const directorySections = {
  dashboards: [
    {id:'modules',name:'현황판 모듈',ids:getGroup('dashboards').ids},
    {id:'checks',name:'검증 현황',ids:['validation-status','mail-check-status']},
    {id:'external',name:'외부 현황판',ids:['vietnam-arrival-cargo','vietnam-processing-fees']}
  ],
  tools:[{id:'tools',name:'업무 도구',ids:getGroup('tools').ids}],
  categories:DATA.categoryGroups
};
function normalizedOrder(defaults, saved) {
  const known = Array.isArray(saved) ? saved.filter(id=>defaults.includes(id)) : [];
  return [...new Set([...known,...defaults])];
}
function orderKey() {return 'order.'+state.scene;}
function currentSections() {
  const saved=readPref(orderKey(),{})||{};
  return directorySections[state.scene].filter(s=>state.scene!=='categories'||state.category==='all'||s.id===state.category)
    .map(s=>({...s,ids:normalizedOrder(s.ids,saved[s.id])}));
}
function directoryEntry(id) {return findModule(id)||directoryExtras[id];}
function directoryRow(id, starred) {
  const m=directoryEntry(id), external=Boolean(m.url), module=Boolean(findModule(id))||external;
  const title=escapeText(tr(m.title)), detail=escapeText(tr(m.description));
  const launch='<span class="dir-icon">'+glyph(m.icon)+'</span><span class="dir-text"><b>'+title+'</b><small>'+detail+'</small></span><span class="dir-arrow">'+glyph(external?'external-link':'chevron-right')+'</span>';
  const target='<button class="dir-launch" data-open="'+id+'">'+launch+'</button>';
  const fav=module?'<button class="favorite-button'+(starred.has(id)?' filled':'')+'" data-fav="'+id+'" aria-pressed="'+starred.has(id)+'" aria-label="'+escapeText(tr('즐겨찾기')+' · '+tr(m.title))+'" title="'+tr('즐겨찾기')+'">'+glyph('star')+'</button>':'';
  return '<li class="dir-row" data-entry="'+id+'">'+target+fav+'</li>';
}
function directoryList(section, heading=true) {
  const starred=new Set(favorites()), title=escapeText(tr(section.name));
  return '<section class="directory-section" data-section="'+section.id+'" aria-label="'+title+'">'+(heading?'<div class="section-line"><h2>'+title+' <small>'+section.ids.length+'</small></h2></div>':'')+'<ul class="directory-list">'+section.ids.map(id=>directoryRow(id,starred)).join('')+'</ul></section>';
}
function renderDirectory() {
  const scene=state.scene, group=getGroup(scene);
  const descriptions={dashboards:'조회할 모듈을 선택하세요.',tools:'검토·계산·변환에 사용하는 도구',categories:'검증, 재고 취합과 월간 보고 업무'};
  const edit='<button class="button order-trigger" data-order-edit>'+glyph('layout-list')+tr('순서 편집')+'</button>';
  let content=dataHeading(tr(group.name),tr(descriptions[scene]),edit);
  if(scene==='categories'){
    const filters=[{id:'all',name:'전체 업무',ids:group.ids},...DATA.categoryGroups];
    content+='<div class="category-filters" role="group" aria-label="'+tr('업무 카테고리 선택')+'">'+filters.map(f=>'<button data-category="'+f.id+'" aria-pressed="'+(f.id===state.category)+'">'+escapeText(tr(f.name))+' <small>'+f.ids.length+'</small></button>').join('')+'</div>';
  }
  return content+currentSections().map(s=>directoryList(s,scene!=='tools')).join('');
}
function beginOrder() {
  const sections=state.scene==='favorites'?[{id:'favorites',name:'즐겨찾기',ids:favorites()}]:directorySections[state.scene]?currentSections():null;
  if(!sections)return;
  state.orderDraft=sections.map(s=>({...s,ids:s.ids.slice(),original:s.ids.slice()}));
  drawOrderEditor();
}
function drawOrderEditor() {
  const sections=state.orderDraft.map(s=>{
    const rows=s.ids.map((id,index)=>{
      const m=directoryEntry(id), name=escapeText(tr(m.title));
      const move=(direction,disabled,label,icon)=>'<button class="icon-button order-step" data-move="'+direction+'" '+(disabled?'disabled ':'')+'aria-label="'+escapeText(tr(label))+' · '+name+'" title="'+escapeText(tr(label))+'">'+glyph(icon)+'</button>';
      return '<li data-order-id="'+id+'" class="order-row"><span class="order-grip" draggable="true" title="'+escapeText(tr('끌어서 이동'))+'"><i aria-hidden="true"></i></span><span class="order-name">'+name+'</span>'+move('up',index===0,'위로 이동','arrow-up')+move('down',index===s.ids.length-1,'아래로 이동','arrow-down')+'</li>';
    }).join('');
    return '<section class="order-group" data-order-group="'+s.id+'"><h3>'+escapeText(tr(s.name))+'</h3><ol>'+rows+'</ol></section>';
  }).join('');
  const foot='<div class="dialog-foot"><button class="text-link" data-order-reset>'+glyph('refresh-cw')+tr('기본 순서')+'</button><span></span><button class="button secondary" data-close>'+tr('취소')+'</button><button class="button primary" data-order-save>'+glyph('check')+tr('순서 저장')+'</button></div>';
  openModal('order',modalHeader(tr('순서 편집'),tr('같은 분류 안에서 항목을 끌거나 화살표로 옮기세요.'))+'<div class="order-body">'+sections+'</div><div id="order-status" class="sr" role="status"></div>'+foot,'order-modal');
}
function focusOrder(id,direction,announce=true) {
  const row=dialog.querySelector('[data-order-id="'+id+'"]');
  if(!row)return;
  const button=row.querySelector('[data-move="'+direction+'"]:enabled')||row.querySelector('button:enabled');
  button?.focus({preventScroll:true});row.scrollIntoView({block:'nearest'});
  if(announce){
    const group=state.orderDraft.find(s=>s.ids.includes(id));
    dialog.querySelector('#order-status').textContent=tr(directoryEntry(id).title)+' · '+(group.ids.indexOf(id)+1)+' / '+group.ids.length;
  }
}
function moveOrder(id,groupId,to,direction) {
  const group=state.orderDraft?.find(s=>s.id===groupId);
  if(!group)return;
  const from=group.ids.indexOf(id);
  if(from<0||to<0||to>=group.ids.length||to===from)return;
  group.ids.splice(from,1);group.ids.splice(to,0,id);
  drawOrderEditor();focusOrder(id,direction);
}
function stepOrder(button) {
  const row=button.closest('[data-order-id]'), groupId=row.closest('[data-order-group]').dataset.orderGroup;
  const group=state.orderDraft.find(s=>s.id===groupId), id=row.dataset.orderId, direction=button.dataset.move;
  moveOrder(id,groupId,group.ids.indexOf(id)+(direction==='up'?-1:1),direction);
}
function resetOrder() {
  for(const section of state.orderDraft)section.ids=(state.scene==='favorites'?section.original:directorySections[state.scene].find(s=>s.id===section.id).ids).slice();
  drawOrderEditor();dialog.querySelector('[data-order-reset]').focus();
}
async function saveOrder() {
  if(state.scene==='favorites'){
    try{await host.orderFavorites(state.orderDraft[0].ids);closeModal();renderPage();}
    catch{toast(tr('설정을 저장하지 못했습니다.'));}
    return;
  }
  const prior=readPref(orderKey(),{}), updated=prior&&typeof prior==='object'&&!Array.isArray(prior)?{...prior}:{};
  for(const section of state.orderDraft){
    if(section.ids.some((id,i)=>id!==section.original[i]))updated[section.id]=section.ids.slice();
  }
  const ok=await writePref(orderKey(),updated);
  closeModal();renderPage();main.querySelector('[data-order-edit]')?.focus({preventScroll:true});
  toast(tr(ok?'모듈 순서를 저장했습니다.':'이 창에서 모듈 순서를 유지합니다.'));
}
function bindOrderDrag() {
  let source=null;
  const clear=()=>dialog.querySelectorAll('.drop-before,.drop-after,.being-dragged').forEach(e=>e.classList.remove('drop-before','drop-after','being-dragged'));
  function targetAt(e) {
    const row=e.target.closest('[data-order-id]');
    if(!source||!row||row.closest('[data-order-group]').dataset.orderGroup!==source.group||row.dataset.orderId===source.id)return null;
    const box=row.getBoundingClientRect();
    return {row,after:e.clientY>box.top+box.height/2};
  }
  dialog.addEventListener('dragstart',e=>{
    if(state.modal!=='order'||!e.target.closest('.order-grip'))return;
    const row=e.target.closest('[data-order-id]');
    source={id:row.dataset.orderId,group:row.closest('[data-order-group]').dataset.orderGroup};
    e.dataTransfer.effectAllowed='move';e.dataTransfer.setData('text/plain',source.id);
    e.dataTransfer.setDragImage(row,20,row.clientHeight/2);row.classList.add('being-dragged');
  });
  dialog.addEventListener('dragover',e=>{
    if(state.modal!=='order')return;
    dialog.querySelectorAll('.drop-before,.drop-after').forEach(r=>r.classList.remove('drop-before','drop-after'));
    const at=targetAt(e);if(!at)return;
    e.preventDefault();e.dataTransfer.dropEffect='move';at.row.classList.add(at.after?'drop-after':'drop-before');
  });
  dialog.addEventListener('drop',e=>{
    if(state.modal!=='order')return;
    const at=targetAt(e);
    if(at){
      e.preventDefault();
      const ids=state.orderDraft.find(s=>s.id===source.group).ids.filter(id=>id!==source.id);
      moveOrder(source.id,source.group,ids.indexOf(at.row.dataset.orderId)+(at.after?1:0),'down');
    }
    clear();source=null;
  });
  dialog.addEventListener('dragend',()=>{clear();source=null});
  dialog.addEventListener('close',()=>{source=null});
}
