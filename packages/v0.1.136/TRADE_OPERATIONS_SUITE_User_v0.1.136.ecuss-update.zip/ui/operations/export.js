const tradeColors=(()=>{
const itemHues = [278, 47, 151, 222, 98, 219, 187, 266, 8, 326, 127, 351,
    311, 202, 63, 243, 18, 84, 291, 170, 32, 12, 194];
const otherColor = '#798694';
  function itemColor(item) {
    // Hash only the ITEM so companies, dates and ranking order share the same color key.
    let hash = 2166136261;
    for (const char of item ?? '') hash = Math.imul(hash ^ char.codePointAt(0), 16777619);
    hash = hash >>> 0;
    const hue = itemHues[hash % itemHues.length] + (hash >>> 8) % 9 - 4;
    const saturation = 60 + (hash >>> 16) % 18;
    const lightness = (hue >= 205 && hue <= 300 ? 46 : 35) + (hash >>> 24) % 10;
    return `hsl(${hue}, ${saturation}%, ${lightness}%)`;
  }
return {item:itemColor,other:otherColor};})();
// The home area keeps its stable layout id so saved positions and visibility carry over.
const tradeModuleId='import-export-performance';
widgets.imex={name:'임가공 수출 실적',type:'법인별 임가공비',icon:'globe',target:tradeModuleId};
addTerms('임가공 수출 실적|Contract processing exports|Kết quả xuất khẩu gia công\n법인별 임가공비|Processing fees by company|Phí gia công theo công ty');
const exportPeriods=new Map();
const exportMode=()=>exportPeriods.get(state.user)||'month';
function exportFees(selected,range,company){
  const summary=TradeReport.summarize(selected,range),ranked=TradeReport.ranking(summary,'fee');
  if(ranked.sum===null)return {pending:true,buckets:[]};
  const format=units=>TradeReport.money(units,summary.scale).replaceAll(',','').replace(/^−/,'-');
  let rows=ranked.display;
  if(company==='agv'&&rows.length>3){
    // The module has already sorted fees and grouped all items below fifth place.
    const remaining=rows.slice(3).reduce((sum,row)=>sum+row.fee,0n);
    rows=[...rows.slice(0,3),{item:null,extraItems:true,fee:remaining}];
  }
  const buckets=rows.map(g=>({
    item:g.item,other:Boolean(g.extraItems),usd:format(g.fee),
    share:!ranked.negative&&ranked.sum>0n?Number(g.fee*1000000000000n/ranked.sum)/10000000000:0
  }));
  return {total:format(summary.total.fee),buckets,empty:buckets.length===0,comparable:!ranked.negative&&ranked.sum>0n};
}
function shareLabel(share){
  const format=new Intl.NumberFormat(localeTags[state.lang],{style:'percent',maximumFractionDigits:1});
  return share>0&&share<0.1?'< '+format.format(.001):format.format(share/100);
}
// The module places ITEM names at the midpoint of each slice. On the smaller home
// chart, move a name into the ring's interior when its slice cannot contain the text.
const feeLabelMeasure=document.createElement('canvas').getContext('2d');
feeLabelMeasure.font='700 14.5px system-ui, sans-serif';
function feeItemLines(name){
  const lines=[''];
  for(const ch of name){
    const last=lines.length-1;
    if(feeLabelMeasure.measureText(lines[last]+ch).width<=68){lines[last]+=ch;continue;}
    if(last===0){lines.push(ch);continue;}
    let tail=lines[last];
    while(tail&&feeLabelMeasure.measureText(tail+'…').width>68)tail=Array.from(tail).slice(0,-1).join('');
    lines[last]=tail+'…';break;
  }
  return lines.map(line=>({text:line.trim(),width:Math.max(1,feeLabelMeasure.measureText(line.trim()).width)}));
}
function feeRingLabels(slices,fixed=false){
  const placed=[],leaders=[],names=[];
  const radians=Math.PI/180;
  const point=(angle,r)=>({x:r*Math.sin(angle*radians),y:-r*Math.cos(angle*radians)});
  const overlaps=(a,b)=>Math.abs(a.x-b.x)<a.hw+b.hw+2&&Math.abs(a.y-b.y)<a.hh+b.hh+2;
  const center={x:0,y:0,hw:66,hh:29};
  // Six disjoint two-line slots around the total also fit five exceptionally long names.
  const slots=[[-40,-52],[40,-52],[0,-92],[-40,52],[40,52],[0,92]].map(([x,y])=>({x,y}));
  for(const {start,end,name,color} of slices){
    const mid=(start+end)*1.8, halfAngle=(end-start)*1.8;
    const lines=feeItemLines(name);
    const hw=Math.max(...lines.map(line=>line.width))/2+3.5,hh=lines.length*8.5+1;
    function choose(inside){
      if(inside&&halfAngle<10.8)return null;
      let best=null,bestCost=Infinity;
      // Spread compact callouts along the inside edge while keeping the center clear.
      const radii=inside?[94,89,99,83,78]:[58,66,48,75,87];
      for(const radius of radii){
        for(let delta=0;delta<=180;delta+=5){
          if(inside&&delta>halfAngle)break;
          const cost=delta+(inside?Math.abs(radius-94):Math.abs(radius-58))*.65;
          if(cost>=bestCost)continue;
          for(const offset of delta?[delta,-delta]:[0]){
            const {x,y}=point(mid+offset,radius),box={x,y,hw,hh};
            if(Math.hypot(Math.abs(x)+hw,Math.abs(y)+hh)>118||overlaps(box,center)||placed.some(p=>overlaps(box,p)))continue;
            if(inside){
              // A horizontal name can extend slightly into the hole; its center remains
              // on the colored slice and it must still clear the total and other names.
              if(Math.hypot(Math.max(0,Math.abs(x)-hw),Math.max(0,Math.abs(y)-hh))<47)continue;
              const corners=[[x-hw,y-hh],[x+hw,y-hh],[x-hw,y+hh],[x+hw,y+hh]];
              if(corners.some(([cx,cy])=>Math.hypot(cx,cy)>=72&&Math.abs(((Math.atan2(cx,-cy)/radians-mid+540)%360)-180)>halfAngle+3))continue;
            }
            best=box;bestCost=cost;break;
          }
        }
      }
      return best;
    }
    const direct=!fixed&&choose(true);
    let box=direct;
    if(fixed){
      const target=point(mid,95),distance=p=>Math.hypot(p.x-target.x,p.y-target.y);
      slots.sort((a,b)=>distance(a)-distance(b));
      box={...slots.shift(),hw,hh};
    }else if(!box){
      box=choose(false);
      if(!box)return feeRingLabels(slices,true);
    }
    placed.push(box);
    const {x,y}=box,round=v=>v.toFixed(2);
    if(!direct){
      const radius=99+(fixed?placed.length*2:0),anchor=point(mid,radius);
      const angleAtName=Math.atan2(x,-y)/radians;
      const bend=fixed?point(angleAtName,radius):anchor;
      const turn=(angleAtName-mid+540)%360-180;
      const arc=fixed&&Math.abs(turn)>.1?' A'+radius+' '+radius+' 0 0 '+(turn>0?1:0)+' '+round(bend.x)+' '+round(bend.y):'';
      const dx=bend.x-x,dy=bend.y-y;
      const edge=Math.min(hw/Math.max(.01,Math.abs(dx)),hh/Math.max(.01,Math.abs(dy)),1);
      leaders.push('<path d="M'+round(anchor.x)+' '+round(anchor.y)+arc+' L'+round(x+dx*edge)+' '+round(y+dy*edge)+'"/><circle cx="'+round(anchor.x)+'" cy="'+round(anchor.y)+'" r="2.3"/>');
    }
    const text=lines.map((line,i)=>'<text x="0" y="'+((i-(lines.length-1)/2)*17)+'" textLength="'+round(line.width)+'" lengthAdjust="spacingAndGlyphs">'+escapeText(line.text)+'</text>').join('');
    const badge=direct?'':'<rect x="-'+round(hw)+'" y="-'+round(hh)+'" width="'+round(hw*2)+'" height="'+round(hh*2)+'" rx="4" stroke="'+color+'"/>';
    names.push('<g class="fee-item-label '+(direct?'on-slice':'inset-label')+'" data-item="'+escapeText(name)+'" transform="translate('+round(x)+' '+round(y)+')">'+badge+text+'</g>');
  }
  return '<svg class="fee-labels" viewBox="-120 -120 240 240" aria-hidden="true"><g class="fee-leaders">'+leaders.join('')+'</g>'+names.join('')+'</svg>';
}
function feeDonut(group,nameOf,colorOf,company,total){
  const last=group.buckets.findLastIndex(b=>b.share>0);
  let end=0;
  const stops=[],slices=[];
  for(const [i,b] of group.buckets.entries()){
    if(b.share<=0)continue;
    const start=end;
    end=i===last?100:start+b.share;
    stops.push(colorOf(b)+' '+start+'% '+end+'%');
    if(!b.other)slices.push({start,end,name:nameOf(b),color:colorOf(b)});
  }
  const paint=stops.length?'conic-gradient('+stops.join(',')+')':'var(--ui-track)';
  const label=group.comparable?group.buckets.map(b=>nameOf(b)+' '+shareLabel(b.share)).join(', '):workL('비중 계산 불가','Shares unavailable','Không thể tính tỷ trọng');
  return '<div class="export-donut" role="img" aria-label="'+escapeText(company+' · '+group.total+' USD · '+label)+'" data-shares="'+group.buckets.map(b=>b.share).join(',')+'" style="--fee-ring:'+paint+'">'+feeRingLabels(slices)+'<div class="export-center"><span>'+workL('합계','Total','Tổng')+'</span>'+total+'</div></div>';
}
function exportPeriodText(mode){
  const range=TradeReport.bounds(mode,anchorDate()),locale=localeTags[state.lang];
  const date=key=>new Date(key+'T00:00:00Z');
  const formatter=new Intl.DateTimeFormat(locale,{timeZone:'UTC',year:'numeric',month:mode==='month'?'long':'short',...(mode==='week'?{day:'numeric'}:{})});
  return mode==='month'?formatter.format(date(range.from)):formatter.formatRange(date(range.from),date(range.to));
}
function exportComparison(mode){
  const range=TradeReport.bounds(mode,anchorDate());
  return ['amo','agv'].map(co=>{
    const record=live.trade[co];
    const group=record.data?exportFees(record.data,range,co):null;
    const itemName=b=>b.other?workL('그 외','Other','Còn lại'):b.item||workL('ITEM 미기재','Unspecified item','Chưa ghi ITEM');
    const usd=v=>new Intl.NumberFormat(localeTags[state.lang],{maximumFractionDigits:2}).format(v);
    const color=b=>b.other?tradeColors.other:tradeColors.item(b.item);
    const unit='<small class="currency-unit">USD</small>';
    const lines=(group?.buckets||[]).map(b=>{
      const name=escapeText(itemName(b));
      const share=group.comparable?shareLabel(b.share):'—';
      const tooltip=name+' · '+escapeText(share)+' · '+usd(b.usd)+' USD';
      return '<li title="'+tooltip+'"'+(b.other?' class="export-other"':'')+'><i style="background:'+color(b)+'" aria-hidden="true"></i><span>'+name+'</span><small class="export-share">'+escapeText(share)+'</small><b>'+usd(b.usd)+'</b>'+unit+'</li>';
    }).join('');
    const label=companies[co]+' · '+tr(widgets.imex.name)+' · '+exportPeriodText(mode);
    const heading='<h3><button type="button" class="export-open" data-open="'+tradeModuleId+'" aria-label="'+escapeText(label)+'">'+companies[co]+'</button></h3>';
    const totalText=group&&!group.pending?usd(group.total):'';
    const digits=totalText.replace(/\D/g,'').length;
    const amountEm=digits*.63+(totalText.length-digits)*.36;
    const total=totalText?'<strong class="export-total" data-total="'+group.total+'" style="--amount-em:'+amountEm+'"><span class="export-amount">'+escapeText(totalText)+'</span>'+unit+'</strong>':'';
    const result=!group?panelMessage(record):group.pending?'<p class="export-empty">'+workL('임가공비 자료 확인 필요','Processing fee data incomplete','Cần kiểm tra phí gia công')+'</p>':
      group.empty?total+'<p class="export-empty">'+workL('기간 내 수출 거래 없음','No exports in this period','Không có giao dịch xuất trong kỳ')+'</p>':
      feeDonut(group,itemName,color,companies[co],total)+'<ol class="export-ranks">'+lines+'</ol>';
    return '<section class="export-company" data-export-company="'+co+'" aria-label="'+companies[co]+'">'+heading+result+staleNote(record)+'</section>';
  }).join('');
}
function exportPanel(){
  const mode=exportMode(),group=workL('두 법인의 조회 기간','Reporting period for both companies','Kỳ báo cáo của hai công ty');
  const labels=workL(['월','주'],['Mo','Wk'],['Tháng','Tuần']);
  const types=workL(['월간','주간'],['Monthly','Weekly'],['Theo tháng','Theo tuần']);
  const buttons=['month','week'].map((key,i)=>'<button type="button" data-export-period="'+key+'" aria-label="'+types[i]+'" title="'+types[i]+'" aria-pressed="'+(key===mode)+'" aria-controls="export-comparison">'+labels[i]+'</button>').join('');
  const fee=workL('임가공비','Processing fees','Phí gia công');
  const controls='<div class="export-tools"><div class="export-switch" role="group" aria-label="'+group+'">'+buttons+'</div><time class="export-period-date">'+exportPeriodText(mode)+'</time></div>';
  const head=panelHead('imex',fee+' · USD',controls);
  return reviewPanel('imex',head+'<div class="export-comparison" id="export-comparison" aria-live="polite" aria-atomic="true">'+exportComparison(mode)+'</div>');
}
document.addEventListener('pointermove',event=>{
  const ring=event.target.closest('.export-donut');
  if(!ring)return;
  const box=ring.getBoundingClientRect(),radius=box.width/2;
  const x=(event.clientX-box.left-radius)/radius,y=(event.clientY-box.top-radius)/radius;
  const distance=Math.hypot(x,y);
  if(distance<.60||distance>1){ring.removeAttribute('title');return;}
  const pct=((Math.atan2(x,-y)/(2*Math.PI)+1)%1)*100;
  let end=0;
  const index=ring.dataset.shares.split(',').findIndex(value=>(end+=Number(value))>pct);
  const item=ring.parentElement.querySelectorAll('.export-ranks li')[index];
  if(item)ring.title=item.title;else ring.removeAttribute('title');
});
document.addEventListener('click',event=>{
  const button=event.target.closest('button[data-export-period]');
  if(!button)return;
  const mode=button.dataset.exportPeriod;
  if(!['month','week'].includes(mode)||mode===exportMode())return;
  exportPeriods.set(state.user,mode);
  const panel=button.closest('[data-widget="imex"]');
  panel.querySelectorAll('[data-export-period]').forEach(b=>b.setAttribute('aria-pressed',String(b.dataset.exportPeriod===mode)));
  panel.querySelector('.export-period-date').textContent=exportPeriodText(mode);
  panel.querySelector('.export-comparison').innerHTML=exportComparison(mode);
});
