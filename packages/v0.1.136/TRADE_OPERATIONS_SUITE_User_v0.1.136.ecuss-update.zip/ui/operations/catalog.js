const DATA = JSON.parse(document.querySelector('#payload').textContent);
const host=parent.OperationsWorkspace;
const suite=host.suite;
DATA.mods=DATA.mods.flatMap(meta=>{
  const m=suite.modules.find(row=>meta.id===row.id);
  return m?[{...meta,title:m.name.ko,names:m.name,description:m.description.ko,descriptions:m.description}]:[];
});
for(const group of [...DATA.groups,...DATA.categoryGroups])group.ids=group.ids.filter(id=>DATA.mods.some(m=>m.id===id));
const escapeText = value => String(value ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const fmt = (value,options) => Number(value).toLocaleString(localeTags[state.lang],options);
const extraGlyphs = {
  house:'<path d="m3 10 9-7 9 7v10a1 1 0 0 1-1 1h-5v-7H9v7H4a1 1 0 0 1-1-1z"/>',
  moon:'<path d="M20.5 14.1A8.3 8.3 0 0 1 9.9 3.5a8.7 8.7 0 1 0 10.6 10.6Z"/>',
  sun:'<circle cx="12" cy="12" r="4"/><path d="M12 2v2m0 16v2M2 12h2m16 0h2M5 5l1.5 1.5m11 11L19 19M5 19l1.5-1.5m11-11L19 5"/>'
};
const glyph = name => '<span class="glyph" aria-hidden="true">' + (DATA.icons[name] || (extraGlyphs[name]?'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round">'+extraGlyphs[name]+'</svg>':'')) + '</span>';
const findModule = id => DATA.mods.find(m => m.id === id);
const getGroup = id => DATA.groups.find(g => g.id === id);
const companies = {all:'전체 법인',amo:'AMOVINA',agv:'AMOGREEN VINA'};
const widgets = {
  imex:{name:'수출입 실적',type:'월별 비교 그래프',icon:'globe',target:'import-export-performance'},
  logistics:{name:'월별 물류비 현황',type:'비용 추이 그래프',icon:'truck',target:'vietnam-logistics-cost'},
  inventory:{name:'과부족 현황',type:'법인별 과잉·부족 금액',icon:'warehouse',target:'stock-dashboard'},
  balanceStatus:{name:'밸런스 시트 검증 현황',type:'법인별 일일 검증 수행',icon:'list-checks',target:'validation-status'},
  customsStatus:{name:'세관 자료 검증 현황',type:'주간·월간 확인 요청 메일 발송',icon:'file-check-2',target:'mail-check-status'},
  reconcile:{name:'세관 자료 대조',type:'검증 상태 도넛',icon:'file-check-2',target:'balance-ecuss'},
  container:{name:'컨테이너 적입 결과',type:'적입 수량 인포그래픽',icon:'container',target:'container-stuffing-simulator'},
  shipping:{name:'출하 가능 수량',type:'자재 소요량 인포그래픽',icon:'boxes',target:'materials-shipping'},
  inspection:{name:'세관 검수비용 비교',type:'비용 비교 그래프',icon:'coins',target:'customs-inspection-cost-comparison'},
  outputs:{name:'통관·보고 산출물',type:'업무별 결과 안내',icon:'file-output'}
};
const isVerification=id=>id==='balanceStatus'||id==='customsStatus';
const sceneWidgets = {
  home:{eligible:['imex','logistics','inventory','balanceStatus','customsStatus','reconcile','container','shipping','inspection','outputs'],on:['imex','logistics','inventory','balanceStatus','customsStatus']}
};
function panelHead(id,subtitle,control='') {
  const w=widgets[id];
  const titleText=escapeText(tr(w.name));
  const title=w.target?'<button type="button" class="panel-launch" data-open="'+w.target+'" aria-label="'+escapeText(tr('연결된 모듈 열기')+' · '+tr(w.name))+'">'+titleText+'</button>':titleText;
  return '<div class="panel-head"><div class="panel-heading"><div><h2 id="title-'+id+'">'+title+'</h2><p>'+subtitle+'</p></div></div>'+control+'</div>';
}
function infoButton(id,label) {
  return '<button class="chart-info" data-info="'+id+'" aria-label="'+label+'" title="'+label+'">'+glyph('circle-help')+'</button>';
}
function selectMenu(label, attr, options, value) {
  return '<label class="select-shell"><span class="sr">'+label+'</span><select '+attr+' aria-label="'+label+'">'+options.map(([key,name])=>'<option value="'+key+'"'+(String(key)===String(value)?' selected':'')+'>'+name+'</option>').join('')+'</select>'+glyph('chevron-down')+'</label>';
}
