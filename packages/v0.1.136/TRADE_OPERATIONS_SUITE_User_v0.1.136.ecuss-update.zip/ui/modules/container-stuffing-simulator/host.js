(() => {
  'use strict';
  const languages = ['ko', 'en', 'vi'];
  const suite = window.__ECUSS_SUITE__;
  if (!suite) return;
  const home = window === window.top ? null : window.top.document.documentElement;
  const current = () => home?.lang || suite.lang;

  // The approved entry reads this preference synchronously before creating the scene.
  try {
    if (languages.includes(current())) localStorage.setItem('amo.containerLoading.language', current());
  } catch { /* The load-time language adapter also works with storage disabled. */ }

  function setLanguage(lang) {
    const control = document.getElementById('language');
    if (!languages.includes(lang) || !control || control.value === lang && document.documentElement.lang === lang) return;
    control.value = lang;
    control.dispatchEvent(new Event('change', {bubbles: true}));
  }
  window.EcussModuleI18n = {languages, setLanguage};
  window.EcussModuleUI = {workControls: '.side, #viewport, #selection, #undo'};
  window.EcussModuleState = {
    busy: () => !!document.querySelector('.side')?.inert,
    hasResult: () => Number(document.getElementById('count-in')?.textContent) > 0,
    hasWork: () => document.getElementById('undo')?.disabled === false
  };
  if (home) {
    const observer = new MutationObserver(() => setLanguage(current()));
    observer.observe(home, {attributes: true, attributeFilter: ['lang']});
    window.addEventListener('pagehide', () => observer.disconnect(), {once: true});
  }
})();
