/* Keep model/product pairs attached to their original evidence locations. */
(function(root){'use strict';
const esc=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
function group(records){
 const groups=new Map();
 for(const r of records){const key=JSON.stringify([r.reference,r.filename,r.model||'',r.product||'',r.role||'']);
  if(!groups.has(key))groups.set(key,{...r,locations:[],records:[]});
  const g=groups.get(key);if(!g.locations.includes(r.location))g.locations.push(r.location);g.records.push(r);
 }return [...groups.values()];
}
function html(records,t){
 const groups=group(records);if(!groups.length)return '';
 const table=items=>'<table class="evidence-use-table"><thead><tr>'+['modelName','product','crossFilename','crossCell'].map(k=>'<th>'+esc(t(k))+'</th>').join('')+'</tr></thead><tbody>'+items.map(r=>'<tr>'+[r.model||t('evidenceNotProvided'),r.product||t('evidenceNotProvided'),r.filename+(r.role?'\n'+t('bom_'+r.role):''),r.locations.join('\n')].map((v,i)=>'<td data-label="'+esc(t(['modelName','product','crossFilename','crossCell'][i]))+'">'+esc(v).replace(/\n/g,'<br>')+'</td>').join('')+'</tr>').join('')+'</tbody></table>';
 const expand=t('evidenceExpand').replace('{total}',groups.length),collapse=t('evidenceCollapse');
 return '<div class="evidence-uses">'+table(groups)+(groups.length>5?'<button type="button" class="evidence-toggle" data-evidence-toggle data-expand="'+esc(expand)+'" data-collapse="'+esc(collapse)+'" aria-expanded="false">'+esc(expand)+'</button>':'')+'</div>';
}
// Also embedded in saved result HTML; keep this handler self-contained.
function handleToggle(event){
 const button=event.target.closest('[data-evidence-toggle]');if(!button)return false;
 const container=button.closest('.evidence-uses'),expanded=button.getAttribute('aria-expanded')!=='true';
 container.classList.toggle('expanded',expanded);button.setAttribute('aria-expanded',String(expanded));button.textContent=expanded?button.dataset.collapse:button.dataset.expand;
 return true;
}
document.addEventListener('click',handleToggle);
root.CommonMaterialEvidenceUses={group,html,handleToggle};
})(window);
