/* Suite catalogue view. The selected company's restored tables keep worksheet order. */
(function () {
  'use strict';
  const names = ['material', 'product'];
  const dates = ['DATE', 'PICK UP DATE'];
  const text = {
    ko: ['인보이스 조회', '시작일', '종료일', '거래 방향 · STATUS', '전체 고유 인보이스', 'ITEM별 건수', '인보이스 상세', '이 요약에는 일별 인보이스 자료가 없습니다.', '거래 방향 선택', '조회 기간을 확인해 주세요.', '해당 인보이스의 거래가 없습니다.'],
    en: ['Invoice lookup', 'From', 'Through', 'Direction · STATUS', 'Distinct invoices', 'Invoices by ITEM', 'Invoice details', 'Daily invoices are unavailable in this summary.', 'Select a direction', 'Check the date range.', 'No matching invoice rows.'],
    vi: ['Tra cứu hóa đơn', 'Từ ngày', 'Đến ngày', 'Chiều giao dịch · STATUS', 'Số hóa đơn riêng biệt', 'Số hóa đơn theo ITEM', 'Chi tiết hóa đơn', 'Bản tóm tắt này chưa có dữ liệu hóa đơn hằng ngày.', 'Chọn chiều giao dịch', 'Kiểm tra khoảng ngày.', 'Không có giao dịch cho hóa đơn này.'],
  };
  const el = (tag, value) => {
    const node = document.createElement(tag);
    if (value != null) node.textContent = value;
    return node;
  };

  // Excel numeric dates arrive as ISO dates or date-times. Preserve original text in detail.
  function calendarDay(value) {
    const date = String(value ?? '').trim();
    const iso = /^(\d{4})[-/](\d{1,2})[-/](\d{1,2})(?:$|[ T])/.exec(date);
    if (iso) return [iso[1], iso[2].padStart(2, '0'), iso[3].padStart(2, '0')].join('-');
    const dmy = /^(\d{1,2})\/(\d{1,2})\/(\d{4})$/.exec(date);
    return dmy && [dmy[3], dmy[2].padStart(2, '0'), dmy[1].padStart(2, '0')].join('-');
  }

  function grid(columns, rows) {
    const table = el('table'), header = table.createTHead().insertRow();
    for (const column of columns) header.append(el('th', column));
    const body = table.createTBody();
    for (const values of rows) {
      const row = body.insertRow();
      for (const value of values) row.insertCell().textContent = value ?? '';
    }
    const scroll = el('div');
    scroll.style.overflowX = 'auto';
    scroll.append(table);
    return scroll;
  }

  window.createInvoiceView = function (bar) {
    const panel = el('details'), title = el('summary'), filters = el('div');
    panel.id = 'suite-invoices';
    panel.className = 'panel';
    panel.hidden = true;
    filters.className = 'flex';
    filters.style.flexWrap = 'wrap';
    const from = el('input'), to = el('input'), status = el('select'), invoice = el('input');
    from.type = to.type = 'date';
    invoice.type = 'search';
    const choices = el('datalist');
    choices.id = 'suite-invoice-numbers';
    invoice.setAttribute('list', choices.id);
    const controls = [from, to, status, invoice], captions = controls.map((control, i) => {
      const label = el('label'), caption = el('span');
      control.id = 'suite-invoice-' + ['from', 'to', 'status', 'number'][i];
      label.append(caption, control);
      filters.append(label);
      return caption;
    });
    const total = el('p'), items = el('div'), detail = el('div');
    total.setAttribute('role', 'status');
    panel.append(title, filters, choices, total, items, detail);
    bar.after(panel);
    let company, source, tables, scoped;
    const labels = () => text[ShippingI18n.lang] || text.ko;
    function translate() {
      const t = labels();
      title.textContent = t[0];
      captions.forEach((caption, i) => { caption.textContent = t[[1, 2, 3, 6][i]]; });
      if (status.options.length) status.options[0].textContent = t[8];
    }
    function showDetail() {
      detail.replaceChildren();
      const selected = invoice.value.trim();
      if (!selected || !scoped) return;
      scoped.forEach(({columns, rows}, i) => {
        const index = columns.indexOf('INVOICE NO.');
        const matches = rows.filter(row => row[index]?.trim() === selected);
        if (matches.length) detail.append(el('h3', names[i].toUpperCase() + ' DAILY'), grid(columns, matches));
      });
      if (!detail.childElementCount) detail.textContent = labels()[10];
    }
    function filter() {
      scoped = null;
      total.textContent = '';
      items.replaceChildren();
      choices.replaceChildren();
      detail.replaceChildren();
      if (!panel.open || !company) return;
      if (!tables) { total.textContent = labels()[7]; return; }
      if (!status.value) return;
      if (from.value && to.value && from.value > to.value) { total.textContent = labels()[9]; return; }
      scoped = tables.map(({columns, rows}, i) => {
        const dateIndex = columns.indexOf(dates[i]), statusIndex = columns.indexOf('STATUS');
        return {columns, rows: rows.filter(row => {
          if (row[statusIndex] !== status.value) return false;
          if (!from.value && !to.value) return true;
          const day = calendarDay(row[dateIndex]);
          return day && (!from.value || day >= from.value) && (!to.value || day <= to.value);
        })};
      });
      const counts = DailyCatalog.invoiceCounts(...scoped);
      total.textContent = labels()[4] + ' · ' + counts.total;
      items.append(grid(['ITEM', labels()[5]], counts.byItem.map(x => [x.item, x.count])));
      const numbers = new Set();
      for (const {columns, rows} of scoped) {
        const index = columns.indexOf('INVOICE NO.');
        for (const row of rows) if (row[index]?.trim()) numbers.add(row[index].trim());
      }
      for (const number of numbers) choices.append(new Option(number, number));
      showDetail();
    }
    function load() {
      const selected = status.value;
      tables = null;
      status.replaceChildren(new Option(labels()[8], ''));
      if (panel.open && source) {
        const restored = names.map(name => source.readDaily(name));
        if (restored.every(table => table?.columns.includes('INVOICE NO.'))) {
          tables = restored;
          const statuses = new Set();
          for (const table of tables) {
            const index = table.columns.indexOf('STATUS');
            for (const row of table.rows) if (row[index]) statuses.add(row[index]);
          }
          for (const value of statuses) status.add(new Option(value, value));
          if (statuses.has(selected)) status.value = selected;
        }
      }
      for (const control of controls) control.disabled = !tables;
      filter();
    }
    for (const control of [from, to, status]) control.addEventListener('change', filter);
    invoice.addEventListener('input', showDetail);
    panel.addEventListener('toggle', load);
    window.addEventListener('ecuss-module-language-changed', () => { translate(); filter(); });
    translate();
    return {select(key, snapshot) {
      if (key === company && snapshot === source) return;
      if (key !== company) { invoice.value = status.value = ''; }
      company = key;
      source = snapshot;
      panel.hidden = !key;
      load();
    }};
  };
})();
