/* ITEM performance calculated from restored Balance Sheet DAILY tables. */
(() => {
  'use strict';

  const sources = ['material', 'product'];
  const dateHeaders = {material: 'DATE', product: 'PICK UP DATE'};
  const day = 86400000;
  const itemOrder = new Intl.Collator('ko', {numeric: true});
  const topItems = 5;

  async function restore(packet, company) {
    const catalog = await DailyCatalog.open(packet.bytes, company, packet.info);
    const tables = {};
    for (const name of sources) {
      tables[name] = DailyCatalog.readTable(catalog.daily, name);
      if (!tables[name]) return null;
    }
    return {...tables, company: catalog.company};
  }

  function dateKey(value) {
    const text = String(value ?? '').trim();
    const yearFirst = /^(\d{4})[-/](\d{1,2})[-/](\d{1,2})(?:$|[ T])/.exec(text);
    const match = yearFirst || /^(\d{1,2})\/(\d{1,2})\/(\d{4})$/.exec(text);
    if (!match) return null;
    const year = yearFirst ? match[1] : match[3], dayOfMonth = yearFirst ? match[3] : match[1];
    const iso = [year, match[2].padStart(2, '0'), dayOfMonth.padStart(2, '0')].join('-');
    const timestamp = Date.parse(iso + 'T00:00:00Z');
    return Number.isFinite(timestamp) && isoDay(timestamp) === iso ? iso : null;
  }

  function isoDay(timestamp) {
    return new Date(timestamp).toISOString().slice(0, 10);
  }

  function bounds(mode, anchor) {
    if (!dateKey(anchor)) return null;
    const year = anchor.slice(0, 4), month = anchor.slice(0, 7);
    if (mode === 'year') return {from: year + '-01-01', to: year + '-12-31'};
    if (mode === 'month') {
      const next = new Date(month + '-01T00:00:00Z');
      next.setUTCMonth(next.getUTCMonth() + 1);
      return {from: month + '-01', to: isoDay(next.getTime() - day)};
    }
    if (mode !== 'week') return null;
    const picked = new Date(anchor + 'T00:00:00Z');
    const monday = picked.getTime() - ((picked.getUTCDay() + 6) % 7) * day;
    return {from: isoDay(monday), to: isoDay(monday + 6 * day)};
  }

  // Compare the entire status. EXPORT RMA, IMPORT RMA and Ship-back have separate meanings.
  function selectDirection(tables, status) {
    const direction = status.trim().toUpperCase();
    if (direction !== 'IMPORT' && direction !== 'EXPORT') throw Error('Unknown trade direction');
    const result = {}, years = new Set();
    let latest = '', undated = 0;
    for (const name of sources) {
      const {columns, rows} = tables[name];
      const statusIndex = columns.indexOf('STATUS'), dateIndex = columns.indexOf(dateHeaders[name]);
      const entries = [];
      for (const row of rows) {
        if (row[statusIndex]?.trim().toUpperCase() !== direction) continue;
        const date = dateKey(row[dateIndex]);
        if (!date) { undated++; continue; }
        years.add(date.slice(0, 4));
        if (date > latest) latest = date;
        entries.push({row, date});
      }
      result[name] = {columns, entries};
    }
    return {tables: result, company: tables.company, direction, years: [...years].sort().reverse(), latest, undated};
  }

  // Preserve decimal precision through summation and ranking, including Excel scientific notation.
  function decimal(value) {
    const match = /^([+-]?)(\d*)(?:\.(\d*))?(?:e([+-]?\d+))?$/i.exec(String(value ?? '').trim());
    if (!match || (!match[2] && !match[3])) return null;
    const digits = match[2] + (match[3] || ''), exponent = Number(match[4] || 0);
    if (digits.length > 400 || Math.abs(exponent) > 324) return null;
    const scale = (match[3] || '').length - exponent;
    let units = BigInt(digits);
    if (match[1] === '-') units = -units;
    if (scale < 0) units *= 10n ** BigInt(-scale);
    return {units, scale: Math.max(0, scale)};
  }

  function roundMagnitude(magnitude, dropDigits) {
    if (dropDigits <= 0) return magnitude * 10n ** BigInt(-dropDigits);
    const divisor = 10n ** BigInt(dropDigits);
    return (magnitude + divisor / 2n) / divisor;
  }

  function money(units, scale, fractionDigits = 2) {
    const magnitude = units < 0n ? -units : units;
    const rounded = roundMagnitude(magnitude, scale - fractionDigits);
    const prefix = units < 0n && rounded > 0n ? '−' : '';
    if (fractionDigits === 0) return prefix + rounded.toLocaleString('en-US');
    const divisor = 10n ** BigInt(fractionDigits);
    return prefix + (rounded / divisor).toLocaleString('en-US') + '.' + String(rounded % divisor).padStart(fractionDigits, '0');
  }

  function detailNumber(value, kind) {
    const parsed = decimal(value);
    if (!parsed) return '—';
    const formatted = money(parsed.units, parsed.scale);
    return kind === 'quantity' ? formatted.replace(/\.00$/, '').replace(/(\.\d)0$/, '$1') : formatted;
  }

  function multiply(left, right) {
    if (!left || !right) return null;
    return {units: left.units * right.units, scale: left.scale + right.scale};
  }

  // Match AMOVINA's Excel ROUND(L*O,2) at half cents affected by numeric XML serialization.
  function hqAmount(quantity, price, company) {
    const value = multiply(quantity, price);
    if (!value || company !== 'AMO') return value;
    const sign = value.units < 0n ? -1n : 1n;
    const magnitude = sign * value.units;
    const excess = Math.max(0, magnitude.toString().length - 15);
    const excelProduct = roundMagnitude(magnitude, excess);
    return {units: sign * roundMagnitude(excelProduct, value.scale - excess - 2), scale: 2};
  }

  function summedUnits(value, scale) {
    return value ? value.units * 10n ** BigInt(scale - value.scale) : 0n;
  }

  function newGroup(item, hasInvoices) {
    return {item, rows: 0, invoices: hasInvoices ? 0 : null, amount: 0n, missingAmount: 0,
      fee: 0n, missingFee: 0};
  }

  function addLine(group, line, scale, feeApplies) {
    group.rows++;
    group.amount += summedUnits(line.amount, scale);
    if (line.amount === null) group.missingAmount++;
    group.fee += summedUnits(line.fee, scale);
    if (feeApplies && line.fee === null) group.missingFee++;
  }

  function summarize(selection, range) {
    const scoped = {};
    for (const name of sources) {
      const {columns, entries} = selection.tables[name];
      scoped[name] = {columns, rows: entries.filter(e => e.date >= range.from && e.date <= range.to).map(e => e.row)};
    }
    const counts = DailyCatalog.invoiceCounts(scoped.material, scoped.product);
    const groups = new Map(), lines = new Map(), exporting = selection.direction === 'EXPORT';
    const amountAt = scoped.material.columns.indexOf('AMOUNT (USD)');
    const pc = scoped.product.columns;
    const qtyAt = pc.indexOf("Q'TY"), hqAt = pc.indexOf('HQ U/PRICE (USD)'), feeAt = pc.indexOf('PROCESSING U/P (USD)');
    let scale = 0, missingQuantity = 0;
    for (const name of sources) {
      for (const row of scoped[name].rows) {
        let amount = null, fee = null;
        if (name === 'material') {
          amount = decimal(row[amountAt]);
        } else if (exporting) {
          const quantity = decimal(row[qtyAt]);
          if (quantity === null) missingQuantity++;
          amount = hqAmount(quantity, decimal(row[hqAt]), selection.company);
          fee = multiply(quantity, decimal(row[feeAt]));
        }
        lines.set(row, {amount, fee});
        scale = Math.max(scale, amount?.scale ?? 0, fee?.scale ?? 0);
      }
    }
    const total = newGroup(null, counts !== null);
    for (const name of sources) {
      const {columns, rows} = scoped[name], itemAt = columns.indexOf('ITEM');
      for (const row of rows) {
        const item = row[itemAt];
        if (!groups.has(item)) groups.set(item, newGroup(item, counts !== null));
        const line = lines.get(row), feeApplies = exporting && name === 'product';
        addLine(groups.get(item), line, scale, feeApplies);
        addLine(total, line, scale, feeApplies);
      }
    }
    if (counts) {
      total.invoices = counts.total;
      for (const entry of counts.byItem) groups.get(entry.item).invoices = entry.count;
    }
    return {scoped, groups: [...groups.values()], total, scale, lines, exporting, missingQuantity,
      blankInvoices: counts?.blankRows ?? null};
  }

  function ranking(summary, mode = 'amount') {
    const byCount = mode === 'count', byFee = summary.exporting && mode === 'fee';
    const metric = byCount ? 'invoices' : byFee ? 'fee' : 'amount';
    const complete = byCount ? summary.total.invoices !== null :
      summary.total[byFee ? 'missingFee' : 'missingAmount'] === 0;
    const sorted = [...summary.groups].sort((a, b) => {
      if (complete && a[metric] !== b[metric]) return a[metric] > b[metric] ? -1 : 1;
      return itemOrder.compare(a.item ?? '', b.item ?? '');
    });
    if (!complete) return {metric, display: sorted, sum: null, negative: false};
    const display = sorted.slice(0, topItems);
    if (sorted.length > topItems) {
      const other = newGroup(null, summary.total.invoices !== null);
      other.extraItems = sorted.length - topItems;
      for (const group of sorted.slice(topItems)) {
        other.rows += group.rows;
        other.amount += group.amount;
        other.missingAmount += group.missingAmount;
        other.fee += group.fee;
        other.missingFee += group.missingFee;
        if (other.invoices !== null) other.invoices += group.invoices;
      }
      display.push(other);
    }
    // A shared invoice contributes once to each ITEM it belongs to. The KPI stays distinct across all ITEMs.
    const sum = byCount ? BigInt(sorted.reduce((total, group) => total + group.invoices, 0)) : summary.total[metric];
    return {metric, display, sum, negative: !byCount && sorted.some(group => group[metric] < 0n)};
  }

  function detailFields(scoped, exporting) {
    const mixed = scoped[exporting ? 'material' : 'product'].rows.length > 0;
    const prefix = mixed ? '품목' : exporting ? '제품' : '자재';
    return {
      code: {label: prefix + ' 코드', material: 'MATERIAL CODE', product: 'PRODUCT CODE'},
      name: {label: mixed ? '품명' : prefix + '명', material: 'MATERIAL NAME', product: 'NAME'},
      country: {label: exporting ? '수입국' : '수출국', material: 'COUNTRY', product: 'COUNTRY'},
      partner: exporting ? {label: '수입자', product: 'CNEE'} : {label: '수출자', material: 'SUPPLIER'}
    };
  }

  function detailChoices(scoped, exporting, items) {
    const byCountry = new Map(), partners = new Set(), fields = detailFields(scoped, exporting);
    for (const name of sources) {
      const {columns, rows} = scoped[name], itemAt = columns.indexOf('ITEM');
      const countryAt = columns.indexOf(fields.country[name]), partnerAt = columns.indexOf(fields.partner[name]);
      for (const row of rows) {
        if (items?.size && !items.has(row[itemAt])) continue;
        const country = row[countryAt]?.trim() ?? '', partner = row[partnerAt]?.trim() ?? '';
        if (!byCountry.has(country)) byCountry.set(country, new Set());
        byCountry.get(country).add(partner);
        partners.add(partner);
      }
    }
    return {byCountry, partners};
  }

  // Match any selected ITEM and intersect it with the invoice and text criteria. Keep raw sheet order.
  function detailRows(scoped, source, number, filters = {}) {
    const result = [], invoice = number.trim(), query = (filters.query ?? '').trim().toLowerCase();
    const fields = detailFields(scoped, filters.exporting);
    const searchFields = filters.field && filters.field !== 'all' ? [fields[filters.field]] : Object.values(fields);
    for (const name of sources) {
      if (source !== 'all' && name !== source) continue;
      const {columns, rows} = scoped[name], invoiceAt = columns.indexOf('INVOICE NO.');
      const itemAt = columns.indexOf('ITEM');
      const countryAt = columns.indexOf(fields.country[name]), partnerAt = columns.indexOf(fields.partner[name]);
      const searchAt = searchFields.map(field => columns.indexOf(field?.[name])).filter(i => i >= 0);
      for (const row of rows) {
        if (invoice && row[invoiceAt]?.trim() !== invoice) continue;
        if (filters.items?.size && !filters.items.has(row[itemAt])) continue;
        if (filters.country !== undefined && (row[countryAt]?.trim() ?? '') !== filters.country) continue;
        if (filters.partner !== undefined && (row[partnerAt]?.trim() ?? '') !== filters.partner) continue;
        if (query && !searchAt.some(i => row[i]?.toLowerCase().includes(query))) continue;
        result.push({name, row});
      }
    }
    return result;
  }

  function detailStats(summary, details) {
    const tables = {};
    for (const name of sources) tables[name] = {columns: summary.scoped[name].columns, rows: []};
    const total = newGroup(null, summary.total.invoices !== null);
    for (const {name, row} of details) {
      tables[name].rows.push(row);
      addLine(total, summary.lines.get(row), summary.scale, summary.exporting && name === 'product');
    }
    const counts = DailyCatalog.invoiceCounts(tables.material, tables.product);
    total.invoices = counts?.total ?? null;
    return {total, byItem: counts?.byItem ?? null};
  }

  function detailTotals(summary, details) {
    return detailStats(summary, details).total;
  }

  function detailListing(summary, filters, mode) {
    const rows = detailRows(summary.scoped, 'all', '', {...filters, exporting: summary.exporting});
    const allRows = rows.length === summary.total.rows;
    const stats = allRows ? {total: summary.total} : detailStats(summary, rows);
    if (mode === 'count') {
      if (stats.total.invoices === null) return {rows, total: stats.total};
      const byItem = allRows ? summary.groups.map(g => ({item: g.item, count: g.invoices})) : stats.byItem;
      const ordered = [...byItem].sort((a, b) => b.count - a.count || itemOrder.compare(a.item ?? '', b.item ?? ''));
      const itemRows = new Map(ordered.map(g => [g.item, []]));
      const itemIndex = Object.fromEntries(sources.map(name => [name, summary.scoped[name].columns.indexOf('ITEM')]));
      for (const entry of rows) itemRows.get(entry.row[itemIndex[entry.name]]).push(entry);
      return {rows: [...itemRows.values()].flat(), total: stats.total};
    }
    const metric = summary.exporting && mode === 'fee' ? 'fee' : 'amount';
    const scored = rows.map(entry => {
      const value = summary.lines.get(entry.row)[metric];
      return {entry, units: value ? summedUnits(value, summary.scale) : null};
    });
    // Stable sorting retains the sheet order on ties; unavailable values follow all numeric values.
    scored.sort((a, b) => {
      if (a.units === b.units) return 0;
      if (a.units === null) return 1;
      if (b.units === null) return -1;
      return a.units > b.units ? -1 : 1;
    });
    return {rows: scored.map(s => s.entry), total: stats.total};
  }

  globalThis.TradeReport = {restore, bounds, selectDirection, summarize, ranking, money, detailNumber, detailFields, detailChoices, detailRows, detailTotals, detailListing};
})();
