(() => {
  'use strict';
  const el = id => document.getElementById(id);
  const make = tag => document.createElement(tag);
  const report = globalThis.TradeReport;
  const provider = globalThis.TradePerformanceSource;
  const names = {amo: 'AMOVINA', agv: 'AMOGREEN VINA'};
  const directions = {Import: '수입실적', Export: '수출실적'};
  const rankingOptions = {
    Export: [{mode: 'fee', label: '임가공비순'}, {mode: 'amount', label: '수출 금액순'}, {mode: 'count', label: '수출 건수순'}],
    Import: [{mode: 'amount', label: '수입 금액순'}, {mode: 'count', label: '수입 건수순'}]
  };
  const itemHues = [278, 47, 151, 222, 98, 219, 187, 266, 8, 326, 127, 351,
    311, 202, 63, 243, 18, 84, 291, 170, 32, 12, 194];
  const otherColor = '#798694';
  const sizes = new Intl.NumberFormat('ko-KR');
  const numeric = n => n === null ? '—' : sizes.format(n);
  const pageSize = 40;
  const numericTypes = new Set(['quantity', 'price', 'amount', 'fee']);
  const state = {company: 'amo', source: null, direction: 'Export', selection: null, period: 'month', anchor: '',
    generation: 0, summary: null, ranking: rankingOptions.Export[0].mode, selectedItems: new Set(),
    columns: [], details: [], page: 0};

  function itemColor(item) {
    // Hash only the ITEM so companies, dates and ranking order share the same color key.
    let hash = 2166136261;
    for (const char of item ?? '') hash = Math.imul(hash ^ char.codePointAt(0), 16777619);
    hash = hash >>> 0;
    const hue = itemHues[hash % itemHues.length] + (hash >>> 8) % 9 - 4;
    const saturation = 60 + (hash >>> 16) % 18;
    const lightness = (hue >= 205 && hue <= 300 ? 46 : 35) + (hash >>> 24) % 10;
    return `hsl(${hue}, ${saturation}%, ${lightness}%)`;
  }

  function detailColumns({exporting, scoped}, fields) {
    const columns = [
      {label: 'ITEM', material: 'ITEM', product: 'ITEM'},
      {label: '인보이스 번호', material: 'INVOICE NO.', product: 'INVOICE NO.'},
      {label: exporting ? '수출일' : '수입일', material: 'DATE', product: 'PICK UP DATE'},
      fields.code, {...fields.name, type: 'name'},
      {label: '수량', type: 'quantity', material: "Q'TY", product: "Q'TY"}
    ];
    if (!exporting || scoped.material.rows.length) {
      columns.push({label: '자재 단가 (USD)', type: 'price', material: 'U/PRICE (USD)'});
    }
    if (exporting) {
      columns.push({label: '가공 단가 (USD)', type: 'price', product: 'PROCESSING U/P (USD)'},
        {label: 'HQ 단가 (USD)', type: 'price', product: 'HQ U/PRICE (USD)'});
    }
    columns.push({label: (exporting ? '수출 금액' : '수입 금액') + ' (USD)', type: 'amount'});
    if (exporting) columns.push({label: '임가공비 (USD)', type: 'fee'});
    columns.push(fields.country, fields.partner);
    return columns;
  }

  function message(value) {
    el('prompt').textContent = value;
    el('prompt').hidden = !value;
  }
  function buttons(key, fn) {
    for (const b of document.querySelectorAll('[data-' + key + ']')) {
      b.addEventListener('click', () => fn(b.dataset[key]));
    }
  }
  function mark(key, value) {
    for (const b of document.querySelectorAll('[data-' + key + ']')) {
      b.setAttribute('aria-pressed', String(b.dataset[key] === value));
    }
  }
  function header(column) {
    const th = make('th');
    th.scope = 'col';
    th.textContent = column.label;
    if (numericTypes.has(column.type)) th.className = 'num';
    if (column.type === 'name') th.className = 'name-cell';
    th.title = [...new Set([column.material, column.product].filter(Boolean))].join(' / ');
    return th;
  }
  const sourceName = provider?.snapshot ? 'Supabase 검증 자료' : 'Balance Sheet 일별 거래';
  const kst = new Intl.DateTimeFormat('sv-SE', {dateStyle:'short', timeStyle:'medium', timeZone:'Asia/Seoul'});
  el('source-label').textContent = sourceName;

  function clearDetailFilters() {
    clearItems();
    el('item-picker').open = false;
    el('search-field').value = 'all';
    el('detail-search').value = '';
    el('detail-country').selectedIndex = 0;
    el('detail-partner').selectedIndex = 0;
    state.page = 0;
  }

  function updateItemCaption() {
    const selected = [...state.selectedItems].map(item => item || 'ITEM 미기재');
    const caption = el('item-caption');
    caption.textContent = selected.length > 1 ? selected.length + '개 선택' : selected[0] ?? '전체 ITEM';
    caption.title = selected.join(', ');
    el('items-all').disabled = !selected.length;
  }

  function clearItems() {
    state.selectedItems.clear();
    for (const box of el('item-options').querySelectorAll('input:checked')) box.checked = false;
    updateItemCaption();
  }

  function selectedChoice(select) {
    return select.selectedIndex > 0 ? select.value : undefined;
  }

  function fillChoices(select, values) {
    const previous = selectedChoice(select);
    const sorted = [...values].sort((a, b) => a.localeCompare(b, 'ko', {numeric: true}));
    select.replaceChildren(new Option('전체', ''), ...sorted.map(value => new Option(value || '미기재', value)));
    select.selectedIndex = sorted.indexOf(previous) + 1;
  }

  function refreshChoices() {
    const {scoped, exporting} = state.summary, country = el('detail-country'), partner = el('detail-partner');
    const {byCountry, partners} = report.detailChoices(scoped, exporting, state.selectedItems);
    fillChoices(country, byCountry.keys());
    const selected = selectedChoice(country);
    fillChoices(partner, selected === undefined ? partners : byCountry.get(selected));
  }

  function buildDetailFilters(fields) {
    el('country-label').textContent = fields.country.label;
    el('partner-label').textContent = fields.partner.label;
    el('search-field').replaceChildren(new Option('전체 항목', 'all'),
      ...Object.entries(fields).map(([key, column]) => new Option(column.label, key)));
    const items = state.summary.groups.map(group => group.item)
      .sort((a, b) => (a ?? '').localeCompare(b ?? '', 'ko', {numeric: true}));
    const labels = ['전체 ITEM', ...items.map(item => item || 'ITEM 미기재')];
    el('item-sizer').replaceChildren(...labels.map(text => {
      const span = make('span');
      span.textContent = text;
      return span;
    }));
    const options = items.map(item => {
      const label = make('label'), box = make('input');
      box.type = 'checkbox';
      box.addEventListener('change', () => {
        if (box.checked) state.selectedItems.add(item);
        else state.selectedItems.delete(item);
        updateItemCaption();
        refreshChoices();
        filterDetails();
      });
      label.append(box, item || 'ITEM 미기재');
      return label;
    });
    el('item-options').replaceChildren(...(options.length ? options : ['조회할 ITEM이 없습니다.']));
  }

  function buildRankingControls() {
    for (const [id, name] of [['ranking-options','ranking'], ['detail-ranking-options','detail-ranking']]) {
      const group = el(id);
      if (group.dataset.rankingDirection === state.direction) continue;
      group.dataset.rankingDirection = state.direction;
      for (const label of group.querySelectorAll('label')) label.remove();
      for (const option of rankingOptions[state.direction]) {
        const label = make('label'), radio = make('input'), caption = make('span');
        radio.type = 'radio';
        radio.name = name;
        radio.value = option.mode;
        radio.setAttribute('data-' + name, option.mode);
        caption.textContent = option.label;
        label.append(radio, caption);
        group.append(label);
      }
    }
  }

  async function selectCompany(company) {
    const request = ++state.generation;
    // Keep the chosen direction and dates when comparing the other company. Hide stale rows while loading.
    Object.assign(state, {company, source: null, selection: null, summary: null, details: []});
    mark('company', company);
    mark('direction', state.direction);
    mark('period', state.period);
    clearDetailFilters();
    el('source-label').textContent = sourceName;
    el('range-controls').hidden = true;
    el('results').hidden = true;
    if (!provider) { message('공유 요약 연결이 필요합니다.'); return; }
    message(names[company] + '의 일별 거래 요약을 읽는 중입니다.');
    try {
      // The Suite adapter supplies the selected company's read-only latest ZIP and metadata.
      const packet = await provider.load(company);
      if (request !== state.generation) return;
      if (!packet) { message('저장된 법인 요약이 없습니다.'); return; }
      const tables = await report.restore(packet, company);
      if (request !== state.generation) return;
      if (!tables) { message('이 요약에는 일별 거래 자료가 없습니다.'); return; }
      state.source = tables;
      if (packet.info.validatedAt) el('source-label').textContent = sourceName + ' · ' + kst.format(new Date(packet.info.validatedAt)) + ' KST';
      renderDirection();
    } catch {
      if (request === state.generation) message('법인 요약을 읽을 수 없습니다. 법인을 다시 선택해 주세요.');
    }
  }

  function selectDirection(direction) {
    if (state.direction !== direction) clearDetailFilters();
    state.direction = direction;
    state.ranking = rankingOptions[direction][0].mode;
    mark('direction', direction);
    if (state.source) renderDirection();
  }
  function renderDirection() {
    state.selection = report.selectDirection(state.source, state.direction);
    selectPeriod(state.period);
  }
  function niceDate(date) { return date.replaceAll('-', '.'); }
  function selectPeriod(period) {
    state.period = period;
    mark('period', period);
    if (!state.selection) return;
    state.anchor ||= state.selection.latest || kst.format(new Date()).slice(0, 10);
    el('range-controls').hidden = false;
    for (const name of ['year', 'month', 'week']) el(name + '-label').hidden = name !== period;
    const year = state.anchor.slice(0, 4);
    const years = [...new Set([...state.selection.years, year])].sort().reverse();
    el('year-value').replaceChildren(...years.map(y => new Option(y + '년', y)));
    el('year-value').value = year;
    el('month-value').value = state.anchor.slice(0, 7);
    el('week-value').value = state.anchor;
    renderPeriod();
  }
  function renderPeriod() {
    const range = report.bounds(state.period, state.anchor);
    if (!range) {
      el('range-caption').textContent = '';
      el('results').hidden = true;
      message('조회할 날짜를 입력해 주세요.');
      return;
    }
    message('');
    const dates = niceDate(range.from) + ' – ' + niceDate(range.to);
    el('range-caption').textContent = (state.period === 'week' ? '월요일 – 일요일  ·  ' : '') + dates + '  ·  원본 STATUS ' + state.selection.direction;
    el('scope').textContent = names[state.company] + '  /  ' + directions[state.direction] + '  /  ' + dates;
    state.summary = report.summarize(state.selection, range);
    const fields = report.detailFields(state.summary.scoped, state.summary.exporting);
    state.columns = detailColumns(state.summary, fields);
    buildDetailFilters(fields);
    buildRankingControls();
    el('detail-headings').replaceChildren(...state.columns.map(header));
    el('results').hidden = false;
    drawChart();
    clearDetailFilters();
    refreshChoices();
    filterDetails();
  }

  function addCell(tr, text, className) {
    const td = make('td');
    if (className) td.className = className;
    td.textContent = text;
    tr.append(td);
    return td;
  }
  function emptyRow(body, width, text) {
    const tr = make('tr'), td = addCell(tr, text, 'empty-cell');
    td.colSpan = width;
    body.append(tr);
  }

  function positionRingLabels() {
    const plot = el('ring-plot'), leaders = el('ring-leaders');
    leaders.replaceChildren();
    if (!plot.clientWidth) return;
    const cx = plot.clientWidth / 2, cy = plot.clientHeight / 2;
    const outer = el('ring').offsetWidth / 2;
    const inner = el('ring').querySelector('.ring-center').offsetWidth / 2;
    const middle = (inner + outer) / 2;
    const calloutX = outer + 15;
    plot.style.setProperty('--label-room', (cx - calloutX) + 'px');
    const sides = [[], []];
    for (const label of el('ring-labels').children) {
      label.className = 'ring-label';
      const start = Number(label.dataset.start), end = Number(label.dataset.end);
      const angle = (start + end) * Math.PI / 100 - Math.PI / 2;
      const dx = Math.cos(angle), dy = Math.sin(angle);
      const halfWidth = label.offsetWidth / 2 + 2, halfHeight = label.offsetHeight / 2 + 2;
      const x = middle * dx, y = middle * dy;
      // Check the nearest and farthest points of the label, and its clearance from adjacent slices.
      const near = Math.hypot(Math.max(0, Math.abs(x) - halfWidth), Math.max(0, Math.abs(y) - halfHeight));
      const far = Math.hypot(Math.abs(x) + halfWidth, Math.abs(y) + halfHeight);
      const halfArc = (end - start) * Math.PI / 100;
      const arcRoom = middle * Math.sin(Math.min(Math.PI / 2, halfArc));
      if (near >= inner && far <= outer && Math.hypot(halfWidth, halfHeight) <= arcRoom) {
        label.style.left = (cx + x) + 'px';
        label.style.top = (cy + y) + 'px';
      } else {
        const side = dx < 0 ? -1 : 1;
        label.classList.add(side < 0 ? 'callout-left' : 'callout-right');
        label.style.left = (cx + side * calloutX) + 'px';
        sides[side < 0 ? 0 : 1].push({label, side, x: cx + outer * dx, y: cy + outer * dy});
      }
    }
    // Keep angular order down each side, leaving space for every remaining label.
    for (const sideLabels of sides) {
      sideLabels.sort((a, b) => a.y - b.y);
      const gap = 4;
      let available = plot.clientHeight - sideLabels.reduce((sum, p) => sum + p.label.offsetHeight + gap, 0);
      let top = 0;
      for (const {label, side, x, y} of sideLabels) {
        const height = label.offsetHeight;
        const labelTop = Math.max(top, Math.min(y - height / 2, available));
        const labelY = labelTop + height / 2;
        label.style.top = labelY + 'px';
        top = labelTop + height + gap;
        available += height + gap;
        const line = document.createElementNS('http://www.w3.org/2000/svg', 'polyline');
        line.setAttribute('points', [[x, y], [cx + side * (outer + 3), y], [cx + side * (calloutX - 3), labelY]].join(' '));
        line.setAttribute('stroke', label.style.getPropertyValue('--slice-color'));
        leaders.append(line);
      }
    }
  }

  function drawRing(slices, caption) {
    const ring = el('ring');
    const stops = slices.map(s => s.color + ' ' + s.start + '% ' + s.end + '%');
    ring.style.background = stops.length ? 'conic-gradient(' + stops.join(', ') + ')' : '';
    const labels = slices.map(slice => {
      const label = make('div');
      label.dataset.start = slice.start;
      label.dataset.end = slice.end;
      label.style.setProperty('--slice-color', slice.color);
      label.textContent = slice.item;
      label.title = slice.item + ' · ' + slice.share;
      return label;
    });
    el('ring-labels').replaceChildren(...labels);
    ring.setAttribute('aria-label', [caption, ...labels.map(label => label.title)].join('. '));
    positionRingLabels();
  }
  function drawChart() {
    const summary = state.summary, mode = state.ranking, ranked = report.ranking(summary, mode);
    const direction = summary.exporting ? '수출' : '수입', label = direction + ' 금액';
    const byCount = ranked.metric === 'invoices', byFee = ranked.metric === 'fee';
    const basis = byCount ? direction + ' 건수' : byFee ? '임가공비' : label;
    const pending = summary.missingQuantity ? '수량 미제공' : '자료 확인 필요';
    const hasChart = ranked.sum !== null && ranked.sum > 0n && !ranked.negative;
    const amount = group => group.missingAmount ? '—' : report.money(group.amount, summary.scale);
    const fee = group => group.missingFee ? '—' : report.money(group.fee, summary.scale);
    el('unique-stat').textContent = summary.total.invoices === null ? '미제공' : numeric(summary.total.invoices) + '건';
    el('amount-stat').textContent = amount(summary.total);
    if (summary.total.missingAmount) el('amount-stat').textContent = pending;
    el('fee-stat-row').hidden = !summary.exporting;
    el('fee-stat').textContent = summary.exporting ? (summary.total.missingFee ? pending : fee(summary.total)) : '';
    el('amount-stat').classList.toggle('unavailable', !!summary.total.missingAmount);
    el('fee-stat').classList.toggle('unavailable', !!summary.total.missingFee);
    el('rank-fee').hidden = !summary.exporting;
    el('rank-amount').textContent = label + ' (USD)';
    for (const option of document.querySelectorAll('.ranking-options input')) {
      option.checked = option.value === mode;
    }
    el('rank-share').textContent = (byCount ? '건수' : byFee ? '임가공비' : '금액') + ' 비중';
    const ringCaption = byCount ? 'ITEM별 건수 합계' : basis + ' (USD)';
    el('ring-caption').textContent = ringCaption;
    const ringValue = ranked.sum === null ? '집계 대기' : byCount ? numeric(ranked.sum) + '건' : report.money(ranked.sum, summary.scale, 0);
    const centerValue = el('ring-value');
    centerValue.textContent = ringValue;
    centerValue.style.setProperty('--value-length', ringValue.length);
    centerValue.classList.toggle('long', ringValue.length > 9);
    el('rank-title').textContent = ranked.sum === null ? 'ITEM별 내역' : 'ITEM TOP 5';
    el('sort-note').textContent = ranked.sum === null ? basis + ' 순위 대기 · ITEM명순' : basis + '순';
    const notes = [];
    if (summary.missingQuantity) notes.push('제품 거래 수량이 요약에 없어 수출 금액과 임가공비 집계를 보류했습니다.');
    if (summary.total.missingAmount && !summary.missingQuantity) notes.push('금액 산출에 필요한 값이 없는 거래가 있어 총 금액과 금액 순위는 집계 대기입니다.');
    if (summary.exporting && summary.total.missingFee && !summary.missingQuantity) notes.push('임가공비를 계산할 수 없는 제품 거래가 있습니다.');
    if (summary.blankInvoices) notes.push('인보이스 번호가 빈 ' + numeric(summary.blankInvoices) + '행은 상세에 포함합니다.');
    if (summary.total.invoices === null) notes.push('이 요약은 인보이스 열을 제공하지 않습니다.');
    if (state.selection.undated) notes.push('날짜를 확인할 수 없는 해당 방향 거래 ' + numeric(state.selection.undated) + '행은 기간 집계에서 제외했습니다.');
    if (ranked.negative) notes.push('음수인 ITEM이 있어 ' + basis + ' 비중을 표시할 수 없습니다.');
    el('data-note').textContent = notes.join(' ');
    el('data-note').hidden = !notes.length;
    const body = el('rank-body'), slices = [];
    body.replaceChildren();
    let cumulative = 0n;
    for (const group of ranked.display) {
      const itemName = group.extraItems ? '기타' : (group.item || 'ITEM 미기재');
      const color = group.extraItems ? otherColor : itemColor(group.item);
      const value = hasChart ? BigInt(group[ranked.metric]) : 0n;
      const ratio = hasChart ? Number(value * 1000000n / ranked.sum) / 10000 : null;
      if (hasChart && value > 0n) {
        const start = Number(cumulative * 1000000n / ranked.sum) / 10000;
        cumulative += value;
        const end = Number(cumulative * 1000000n / ranked.sum) / 10000;
        slices.push({color, start, end, item: itemName, share: ratio.toFixed(1) + '%'});
      }
      const tr = make('tr'), th = make('th'), dot = make('span');
      th.scope = 'row';
      dot.className = 'dot';
      if (hasChart) {
        dot.style.background = color;
        th.append(dot);
      }
      th.append(itemName);
      if (group.extraItems) {
        tr.className = 'other-row';
        const info = make('span');
        info.className = 'secondary';
        info.textContent = group.extraItems + '개 ITEM 합계';
        th.append(info);
      }
      tr.append(th);
      const share = addCell(tr, ''), wrap = make('div'), track = make('span'), bar = make('span');
      wrap.className = 'share-cell';
      if (ratio !== null) {
        track.className = 'track';
        bar.className = 'bar';
        bar.style.width = ratio + '%';
        bar.style.background = color;
        track.append(bar);
        wrap.append(track, ratio.toFixed(1) + '%');
      } else wrap.textContent = '—';
      share.append(wrap);
      addCell(tr, amount(group), 'num');
      if (summary.exporting) addCell(tr, fee(group), 'num');
      addCell(tr, numeric(group.invoices), 'num');
      body.append(tr);
    }
    if (!ranked.display.length) emptyRow(body, summary.exporting ? 5 : 4, '선택한 기간과 방향에 해당하는 거래가 없습니다.');
    drawRing(slices, ringCaption + ' ' + ringValue);
  }

  function filterDetails() {
    const summary = state.summary, mode = state.ranking;
    const query = el('detail-search').value, field = el('search-field').value;
    const searchLabel = el('search-field').selectedOptions[0].textContent;
    el('detail-search').placeholder = field === 'all' ?
      (summary.exporting ? '코드·품명·수입국·수입자' : '코드·품명·수출국·수출자') : searchLabel + ' 입력';
    const country = selectedChoice(el('detail-country')), partner = selectedChoice(el('detail-partner'));
    const {rows, total} = report.detailListing(summary, {items: state.selectedItems, field, query, country, partner}, mode);
    state.details = rows;
    const unit = mode === 'fee' ? '임가공비' : summary.exporting ? '수출 금액' : '수입 금액';
    el('detail-order-note').textContent = mode === 'count' ?
      (total.invoices === null ? '건수 미제공 · 원본 순서' : 'ITEM별 고유 건수 내림차순 · 같은 ITEM은 원본 순서') :
      '거래별 ' + unit + ' 내림차순 · 동률은 원본 순서';
    el('detail-invoices').textContent = total.invoices === null ? '미제공' : numeric(total.invoices) + '건';
    el('detail-amount').textContent = total.missingAmount ? '미제공' : report.money(total.amount, summary.scale);
    el('detail-fee-group').hidden = !summary.exporting;
    el('detail-fee').textContent = total.missingFee ? '미제공' : report.money(total.fee, summary.scale);
    el('detail-reset').disabled = !state.selectedItems.size && country === undefined && partner === undefined && field === 'all' && !query;
    state.page = 0;
    drawDetails();
  }
  function detailValue(column, raw, line) {
    switch (column.type) {
      case 'price':
      case 'quantity': return report.detailNumber(raw, column.type);
      case 'amount':
      case 'fee': {
        const value = line[column.type];
        return value ? report.money(value.units, value.scale) : '—';
      }
      default: return raw ?? '—';
    }
  }
  function drawDetails() {
    const body = el('detail-body'), start = state.page * pageSize;
    const end = Math.min(start + pageSize, state.details.length);
    body.replaceChildren();
    const columns = state.columns;
    const indexes = {};
    for (const name of ['material', 'product']) {
      indexes[name] = columns.map(col => state.summary.scoped[name].columns.indexOf(col[name]));
    }
    for (const {name, row} of state.details.slice(start, end)) {
      const tr = make('tr'), line = state.summary.lines.get(row);
      columns.forEach((column, i) => {
        const value = detailValue(column, row[indexes[name][i]], line);
        if (column.type === 'name') {
          const td = addCell(tr, '', 'name-cell'), text = make('span');
          text.className = 'name-value';
          text.textContent = value;
          td.append(text);
        } else addCell(tr, value, numericTypes.has(column.type) ? 'num' : '');
      });
      body.append(tr);
    }
    if (!state.details.length) emptyRow(body, columns.length, '조회 조건에 해당하는 거래가 없습니다.');
    el('detail-count').textContent = state.details.length ?
      numeric(start + 1) + '–' + numeric(end) + ' / 전체 ' + numeric(state.details.length) + '행' : '전체 0행';
    el('prev').disabled = !state.page;
    el('next').disabled = end >= state.details.length;
    document.querySelector('.details-scroll').scrollTop = 0;
  }

  buttons('company', selectCompany);
  buttons('direction', selectDirection);
  buttons('period', selectPeriod);
  for (const group of document.querySelectorAll('.ranking-options')) {
    group.addEventListener('change', e => {
      state.ranking = e.target.value;
      drawChart();
      filterDetails();
    });
  }
  for (const [id, suffix] of [['year-value','-01-01'], ['month-value','-01'], ['week-value','']]) {
    el(id).addEventListener('input', e => {
      state.anchor = e.target.value ? e.target.value + suffix : '';
      renderPeriod();
    });
  }
  const picker = el('item-picker');
  picker.addEventListener('keydown', e => {
    if (e.key === 'Escape' && picker.open) {
      picker.open = false;
      picker.querySelector('summary').focus();
    }
  });
  document.addEventListener('click', e => {
    if (picker.open && !picker.contains(e.target)) picker.open = false;
  });
  picker.addEventListener('focusout', e => {
    if (e.relatedTarget && !picker.contains(e.relatedTarget)) picker.open = false;
  });
  el('items-all').addEventListener('click', () => {
    clearItems();
    refreshChoices();
    picker.open = false;
    picker.querySelector('summary').focus();
    filterDetails();
  });
  el('detail-reset').addEventListener('click', () => { clearDetailFilters(); refreshChoices(); filterDetails(); });
  el('detail-country').addEventListener('change', () => { refreshChoices(); filterDetails(); });
  el('detail-partner').addEventListener('change', filterDetails);
  el('search-field').addEventListener('change', filterDetails);
  el('detail-search').addEventListener('input', filterDetails);
  el('prev').addEventListener('click', () => { state.page--; drawDetails(); });
  el('next').addEventListener('click', () => { state.page++; drawDetails(); });
  new ResizeObserver(positionRingLabels).observe(el('ring-plot'));
  selectCompany(state.company);
})();
