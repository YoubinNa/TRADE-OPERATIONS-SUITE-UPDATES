/* Supply the approved report with a verified Balance Sheet catalogue through the native app. */
(() => {
  'use strict';
  const bridge = {
    call(path, payload) {
      return EcussDesktop.call(path.replace('/stock/dashboard/', '/stock/materials/'), payload);
    }
  };
  const provider = StockDashboardSync.nativeProvider(bridge, 'catalog');
  let result;
  const sync = new StockDashboardSync.Sync(provider, async (bytes, company, info) => {
    await DailyCatalog.open(bytes, company, info);
    return {bytes};
  }, update => { result = update; });

  const note = document.createElement('span');
  note.hidden = true;
  note.setAttribute('role', 'status');
  note.className = 'source-label';
  document.getElementById('source-label').after(note);
  const offline = {ko: '오프라인 · 마지막 저장 자료', en: 'Offline · Last saved data', vi: 'Ngoại tuyến · Dữ liệu đã lưu'};
  let latest = 0;
  let pending = Promise.resolve();
  function load(company) {
    const request = ++latest;
    note.hidden = true;
    // The native module has one transfer session. Finish and release it before switching companies.
    const task = pending.then(async () => {
      await sync.select(company);
      const {key, state, snapshot, error} = result;
      if (key !== company) throw Error('Unexpected catalogue company');
      if (state === 'empty') return null;
      if (!snapshot || !['current', 'stale'].includes(state)) throw Error(error || 'Catalogue unavailable');
      if (request === latest && state === 'stale') {
        note.textContent = offline[document.documentElement.lang] || offline.ko;
        note.hidden = false;
      }
      return {bytes: snapshot.data.bytes, info: snapshot.info};
    });
    pending = task.catch(() => {});
    return task;
  }
  window.TradePerformanceSource = {load};
})();
