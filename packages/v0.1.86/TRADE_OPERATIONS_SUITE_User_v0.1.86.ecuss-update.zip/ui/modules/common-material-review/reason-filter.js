(function(root){'use strict';
const selected=value=>value==null||value==='all'?'all':Array.isArray(value)?value:[value];
const withinKey=key=>/^(masterDiff_|bomDiff_|internal_)(name|spec|vnName|unit|hs|price)$/.test(key)?'within_'+key.split('_').at(-1):key;
const isHs=key=>/(^|_)hs(_|$)/.test(key);
const canonical=key=>isHs(key)?'hs_review':withinKey(key);
const hsDetails=issues=>[...new Set(issues.filter(isHs).map(withinKey))];
const describeHs=(issues,t)=>t('hs_review')+': '+hsDetails(issues).map(t).join(' · ');
const displayIssues=issues=>[...new Set(issues.map(canonical))];
const scope=key=>/^(source_|(?:name|spec|vnName|hs|price)_(?:difference|partial)$|unit_difference$|combination$)/.test(key)?'reference':'internal';
const matches=(issues,value)=>{const keys=selected(value),shown=displayIssues(issues);return keys==='all'||keys.some(key=>key==='clean'?!issues.length:shown.includes(canonical(key)));};
const filterIssues=(issues,value)=>{const keys=selected(value);return keys==='all'?[...issues]:issues.filter(key=>keys.map(canonical).includes(canonical(key)));};
const getValue=el=>el.value??'all';
function entries(items,t){const counts=new Map();for(const item of items)for(const key of displayIssues(item.issues))counts.set(key,(counts.get(key)||0)+1);return [['clean',t('crossNoIssues'),items.filter(x=>!x.issues.length).length],...[...counts].map(([key,n])=>[key,t(key),n])];}
function sync(el,items,t,value='all'){
 const choices=entries(items,t);
 const allKeys=choices.map(([key])=>key),requested=selected(value),keys=requested==='all'?allKeys:[...new Set(requested.map(canonical))].filter(key=>allKeys.includes(key));
 const all=keys.length===allKeys.length,focused=el.contains(document.activeElement)?document.activeElement.dataset.reason:null;
 el.value=all?'all':keys;el._reasonKeys=allKeys;
 if(!el._reasonBound){el._reasonBound=true;el.addEventListener('change',e=>{
  const input=e.target.closest('input[data-reason]');if(!input)return;
  if(input.dataset.reason==='all'){el.querySelectorAll('input[data-reason]').forEach(x=>x.checked=input.checked);el.value=input.checked?'all':[];}
  else{const checked=[...el.querySelectorAll('input[data-reason]:checked')].map(x=>x.dataset.reason).filter(k=>k!=='all');el.value=checked.length===el._reasonKeys.length?'all':checked;}
  update(el,t);
 },true);el.addEventListener('keydown',e=>{if(e.key==='Escape'){el.open=false;el.querySelector('summary')?.focus();e.stopPropagation();}});}
 // Change handlers use the latest language, including after a language switch.
 el._reasonText=t;
 el.replaceChildren();const summary=document.createElement('summary');el.append(summary);
 const list=document.createElement('div');list.className='reason-check-list';list.setAttribute('role','group');list.setAttribute('aria-label',t('reason'));el.append(list);
 for(const [key,label,n] of [['all',t('allReasons'),items.length],...choices]){const row=document.createElement('label'),input=document.createElement('input'),text=document.createElement('span');input.type='checkbox';input.dataset.reason=key;input.checked=key==='all'?all:keys.includes(key);text.textContent=label+' ('+n+')';row.append(input,text);if(key==='all')row.className='reason-check-all';list.append(row);}
 update(el,t);if(focused)el.querySelectorAll('input[data-reason]').forEach(input=>{if(input.dataset.reason===focused)input.focus({preventScroll:true});});return el.value;
}
function update(el,t){t=el._reasonText||t;const value=selected(el.value),all=value==='all',master=el.querySelector('input[data-reason="all"]');if(master){master.checked=all;master.indeterminate=!all&&value.length>0;}
 const labels={ko:['선택한 사유','선택한 사유 없음'],en:['Selected reasons','No reasons selected'],vi:['Lý do đã chọn','Chưa chọn lý do']},lang=document.documentElement.lang,words=labels[lang]||labels.ko;
 el.querySelector('summary').textContent=all?t('allReasons'):value.length?words[0]+' ('+value.length+')':words[1];
}
document.addEventListener('click',e=>document.querySelectorAll('details.reason-filter[open]').forEach(el=>{if(!e.composedPath().includes(el))el.open=false;}));
root.CommonMaterialReasonFilter={matches,sync,getValue,filterIssues,canonical,displayIssues,scope,isHs,hsDetails,describeHs,entries};
})(window);
