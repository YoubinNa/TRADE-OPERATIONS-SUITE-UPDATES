window.CMText={
 exportExcel:['Excel 저장','Save Excel','Lưu Excel'],excelWorking:['Excel 파일 준비 중…','Preparing Excel…','Đang tạo Excel…'],excelSaved:['Excel 저장을 요청했습니다.','Excel save requested.','Đã yêu cầu lưu Excel.'],excelCancelled:['Excel 저장을 취소했습니다.','Excel save cancelled.','Đã hủy lưu Excel.'],excelFailed:['Excel 파일을 저장하지 못했습니다. 다시 시도하세요.','Could not save Excel. Please try again.','Không lưu được Excel. Vui lòng thử lại.'],excelTooLarge:['Excel 출력 한도를 초과했습니다. 검토 범위를 나누어 저장하세요.','Excel output exceeds its limits. Split the review range.','Vượt giới hạn Excel. Hãy chia phạm vi kiểm tra.'],
 excelReview:['검토 결과','Review results','Kết quả kiểm tra'],excelReference:['기존 원천 상세','Reference details','Chi tiết nguồn'],excelNote:['전체 검토 결과의 저장본 · 단가·코드·HS CODE(VN)는 정확한 원문 보존을 위해 텍스트로 저장합니다.','Full review snapshot · Prices, codes and HS CODE(VN) are stored as text to preserve exact original values.','Bản lưu toàn bộ kết quả · Giá, mã và HS CODE(VN) được lưu dạng văn bản để giữ nguyên giá trị.'],

 exampleTitle:['유형별 가상 예시','Synthetic examples by type','Ví dụ giả lập theo loại'],
 exampleHint:['법인을 선택하고 예시를 불러오세요. 가상 수책과 가상 비교 원천으로 검토하며 실제 저장 자료는 변경하지 않습니다.','Select a company and load a case. Synthetic workbooks and references do not change saved business data.','Chọn công ty và tải ví dụ. Tệp và nguồn giả lập không thay đổi dữ liệu nghiệp vụ đã lưu.'],
 loadCase:['예시 불러오기','Load example','Tải ví dụ'],endCase:['예시 종료','Exit examples','Thoát ví dụ'],
 exampleActive:['가상 예시 검토 중 · 실제 업무자료 아님','SYNTHETIC EXAMPLE · Not business data','ĐANG XEM VÍ DỤ GIẢ LẬP · Không phải dữ liệu nghiệp vụ'],
 exampleSource:['가상 비교 원천','Synthetic reference','Nguồn đối chiếu giả lập'],exampleNoSource:['비교 원천이 없는 상황의 예시','Example with no reference available','Ví dụ chưa có nguồn đối chiếu'],
 exampleGoal:['예시 확인 포인트','Expected review points','Điểm cần kiểm tra trong ví dụ'],endCaseFirst:['예시를 종료한 뒤 실제 비교 원천을 불러오세요.','Exit examples before loading a business reference.','Thoát ví dụ trước khi tải nguồn nghiệp vụ.'],
 ex_normal:['01 정상 및 경계값','01 Normal and boundary cases','01 Bình thường và giá trị biên'],
 ex_missing:['02 입력 누락·HS CODE(VN) 형식','02 Missing inputs and HS CODE(VN) format','02 Thiếu dữ liệu và định dạng HS CODE(VN)'],
 ex_price:['03 단가 표시·7자리·비정상값','03 Price display, 7+ decimals and invalid values','03 Hiển thị giá, từ 7 chữ số và giá không hợp lệ'],
 ex_duplicate:['04 자재코드 중복·내부 혼재','04 Duplicate codes and internal inconsistencies','04 Mã trùng và dữ liệu nội bộ khác nhau'],
 ex_difference:['05 공용자재 불일치','05 Common material differences','05 Vật tư dùng chung không khớp'],
 ex_partial:['06 일부 일치·단가/HS CODE(VN) 조합','06 Partial matches and price/HS CODE(VN) combinations','06 Khớp một phần và tổ hợp giá/HS CODE(VN)'],
 ex_reference:['07 기존 원천 누락·값 확인','07 Missing or invalid reference values','07 Nguồn thiếu hoặc không hợp lệ'],
 ex_cells:['08 셀·수식·표시 형식 오류','08 Cell, formula and format issues','08 Lỗi ô, công thức và định dạng'],
 ex_waiting:['09 원천 없음·자체 검증','09 No reference; internal review','09 Chưa có nguồn; kiểm tra nội bộ'],
 ex_noCommon:['10 공용자재 없음·자체 검증','10 No common materials; internal review','10 Không có vật tư dùng chung; kiểm tra nội bộ'],

 field_error:['검증 항목의 셀 오류 또는 수식 계산 결과 누락','Field cell error or missing formula result','Ô dữ liệu có lỗi hoặc thiếu kết quả công thức'],
 spec:['규격','Specification','Quy cách'],vnName:['베트남어명','Vietnamese name','Tên tiếng Việt'],field:['검증 항목','Field','Hạng mục kiểm tra'],newValue:['신규수책 값','New workbook value','Giá trị trong phụ lục mới'],existingValues:['기존 원천 값','Existing reference values','Giá trị dữ liệu nguồn'],
 name_missing:['자재명 미입력','Material name missing','Thiếu tên vật tư'],spec_missing:['규격 미입력','Specification missing','Thiếu quy cách'],vnName_missing:['베트남어명 미입력 또는 0','Vietnamese name missing or zero','Tên tiếng Việt bị thiếu hoặc bằng 0'],
 source_name_missing:['기존 원천 자재명 누락','Reference material name missing','Thiếu tên vật tư trong nguồn'],source_spec_missing:['기존 원천 규격 누락 · 요약 갱신 필요 여부 확인','Reference specification missing · check whether summary needs updating','Thiếu quy cách nguồn · kiểm tra nhu cầu cập nhật tóm tắt'],source_vnName_missing:['기존 원천 베트남어명 누락 · 요약 갱신 필요 여부 확인','Reference Vietnamese name missing · check whether summary needs updating','Thiếu tên tiếng Việt nguồn · kiểm tra nhu cầu cập nhật tóm tắt'],
 name_difference:['기존 원천과 자재명 불일치','Material name differs from reference','Tên vật tư không khớp nguồn'],name_partial:['기존 자재명 일부 일치 · 다른 이름 존재','Matches some reference names; other names exist','Khớp một phần tên nguồn; có tên khác'],spec_difference:['기존 원천과 규격 불일치','Specification differs from reference','Quy cách không khớp nguồn'],spec_partial:['기존 규격 일부 일치 · 다른 규격 존재','Matches some reference specifications; others exist','Khớp một phần quy cách nguồn; có quy cách khác'],vnName_difference:['기존 원천과 베트남어명 불일치','Vietnamese name differs from reference','Tên tiếng Việt không khớp nguồn'],vnName_partial:['기존 베트남어명 일부 일치 · 다른 이름 존재','Matches some reference Vietnamese names; others exist','Khớp một phần tên tiếng Việt nguồn; có tên khác'],
 title:['신규수책검토','New Liquidation Review','Kiểm tra phụ lục mới'],
 subtitle:['신규수책 BOM을 기존 원재료와 비교하고, 파일 내부의 확인 사항을 살펴봅니다.','Compare the new BOM with existing materials and review issues within the file.','Đối chiếu BOM mới với vật tư hiện có và kiểm tra các điểm cần xác nhận trong tệp.'],
 tools:['업무 도구','Work tools','Công cụ nghiệp vụ'],
 crossCell:['시트 · 셀 위치','Sheet · cell','Trang tính · ô'],
 exportOther:['기타 셀 오류·조합 확인','Other cell / combination checks','Kiểm tra lỗi ô / tổ hợp khác'],
 exportSelectTitle:['Excel 추출 항목 선택','Select Excel export checks','Chọn mục kiểm tra để xuất Excel'],
 exportSelectHint:['선택한 검증항목의 확인 사유와 비교 내용만 추출합니다. 파일명과 셀 위치는 같은 순서로 표시합니다.','Export only the selected check reasons and comparison details. Filenames and cell locations appear in the same order.','Chỉ xuất lý do và nội dung so sánh của các mục đã chọn. Tên tệp và vị trí ô được hiển thị theo cùng thứ tự.'],
 exportSelectAll:['전체 선택','Select all','Chọn tất cả'],exportSelectNone:['전체 해제','Clear all','Bỏ chọn tất cả'],
 exportSelectedCount:['추출 대상','Selected results','Kết quả được chọn'],exportSelection:['추출 항목','Exported checks','Mục đã xuất'],
 crossExcelOutline:['기본값: 전체 펼침 · 왼쪽 −로 상세 접기 · 1: 전체 접기 / 2: 전체 펼치기','All details expanded by default · Use − to collapse · 1: collapse all / 2: expand all','Mặc định mở rộng tất cả · Nhấn − để thu gọn · 1: thu gọn / 2: mở rộng tất cả'],
 company:['법인 선택','Select company','Chọn công ty'],companyHint:['검토할 법인을 먼저 선택하세요.','Select the company to begin.','Chọn công ty trước khi kiểm tra.'],
 target:['신규수책 자료','New Liquidation workbook','Tệp phụ lục mới'],targetHint:['Excel 파일을 끌어 놓거나 파일을 선택하세요.','Drop an Excel file here or choose a file.','Kéo thả tệp Excel hoặc chọn tệp.'],choose:['파일 선택','Choose file','Chọn tệp'],
 sheet:['검증 대상 시트','Worksheet to review','Trang tính cần kiểm tra'],noneSheet:['파일을 먼저 불러오세요','Load a workbook first','Vui lòng tải tệp trước'],
 samples:['첨부 샘플로 살펴보기','Explore the supplied samples','Xem các mẫu đã cung cấp'],sampleNote:['샘플은 원재료 표만 포함하며, 기존 비교 원천은 포함하지 않습니다.','Samples contain the material table only, without an existing reference dataset.','Mẫu chỉ gồm bảng vật tư, không bao gồm dữ liệu đối chiếu hiện có.'],
 reference:['비교 원천','Reference data','Dữ liệu đối chiếu'],summary:['저장된 검증 요약','Saved validation summary','Dữ liệu tóm tắt kiểm tra đã lưu'],manual:['직접 업로드한 Balance Sheet','Uploaded Balance Sheet','Balance Sheet tải lên trực tiếp'],
 sourceMissing:['저장된 요약 미연결 · 공용자재 대조 대기','Saved summary unavailable · common material comparison pending','Chưa có dữ liệu tóm tắt · chờ đối chiếu vật tư dùng chung'],
 sourceHint:['프로그램에서는 법인별 저장 요약을 기본으로 사용합니다. 이 단독 검토본에서는 아래에 Balance Sheet를 넣어 비교할 수 있습니다.','The program uses the company’s saved summary by default. In this standalone draft, load a Balance Sheet below to compare.','Chương trình mặc định dùng dữ liệu tóm tắt đã lưu theo công ty. Với bản xem thử độc lập này, hãy tải Balance Sheet bên dưới để đối chiếu.'],
 override:['최신 Balance Sheet로 검토하기 (선택)','Use a newer Balance Sheet (optional)','Dùng Balance Sheet mới hơn (tùy chọn)'],
 overrideHint:['여기에 끌어 놓거나 선택 · 이번 검토에 우선 적용','Drop or choose a file · takes priority for this review','Kéo thả hoặc chọn tệp · ưu tiên cho lần kiểm tra này'],
 returnSummary:['저장된 요약으로 돌아가기','Return to saved summary','Quay về dữ liệu tóm tắt đã lưu'],
 sourceTime:['자료 기준','Reference time','Thời điểm dữ liệu'],loadedTime:['파일을 불러온 시각','File loaded at','Thời điểm tải tệp'],unknownTime:['검증 시각 미제공','Validation time not provided','Chưa có thời điểm kiểm tra'],
 sourceCompanyConfirm:['이 Balance Sheet의 법인을 파일에서 확정할 수 없습니다. 선택한 법인의 파일인지 확인 후 적용하세요.','The company cannot be confirmed from this Balance Sheet. Confirm it belongs to the selected company before applying.','Không xác định được công ty từ Balance Sheet. Xác nhận tệp thuộc công ty đã chọn trước khi áp dụng.'],
 applySource:['선택한 법인 원천으로 적용','Use for selected company','Áp dụng cho công ty đã chọn'],cancel:['취소','Cancel','Hủy'],
 mapping:['읽기 위치 확인 / 조정','Inspect / adjust column mapping','Kiểm tra / điều chỉnh vị trí đọc'],
 code:['자재코드','Material code','Mã vật tư'],name:['MATERIAL NAME (자재명)','MATERIAL NAME','MATERIAL NAME (Tên vật tư)'],unit:['단위','Unit','Đơn vị'],price:['자재단가','Unit price','Đơn giá vật tư'],hs:['HS CODE(VN)','HS CODE(VN)','HS CODE(VN)'],
 header:['제목 행 번호','Header row number','Số dòng tiêu đề'],applyMap:['읽기 위치 적용','Apply mapping','Áp dụng vị trí đọc'],autoMap:['자동 찾기','Auto-detect','Tự động tìm'],
 run:['검토 실행','Run review','Thực hiện kiểm tra'],rerun:['다시 검토','Run again','Kiểm tra lại'],reset:['신규수책 초기화','Clear new workbook','Xóa tệp phụ lục mới'],
 empty:['법인과 신규수책 자료를 선택하면 검토를 시작할 수 있습니다.','Select a company and a new workbook to start reviewing.','Chọn công ty và tệp phụ lục mới để bắt đầu kiểm tra.'],
 help:['검토 기준','Review rules','Quy tắc kiểm tra'],rules:['수책 원재료 목록에서 동일 자재코드는 한 번만 허용하며 중복된 모든 행을 확인 대상으로 표시합니다. 전체 자재코드가 일치하면 공용자재로 분류합니다. 단위가 다른 단가는 직접 비교하지 않습니다. 표시 단가와 실제 단가의 차이, 또는 어느 쪽이든 소수점 이하 7자리 이상이면 확인 대상으로 안내합니다. 표시값은 끝자리 0을 포함합니다. 여러 확인 사유는 원본 행 하나에 함께 표시합니다. 파일 내부 검토와 공용자재 대조 상태는 별도로 표시합니다.','Each material code may appear only once in the Liquidation material list; all duplicate rows are flagged. An exact full-code match identifies a common material. Prices with different units are not directly compared. Review flags apply when displayed and stored prices differ, or either has 7 or more decimal places. Displayed trailing zeros count. Multiple reasons appear together in one original row. Internal checks and reference comparison are reported separately.','Mỗi mã vật tư chỉ được xuất hiện một lần trong danh sách vật tư của phụ lục; tất cả dòng trùng đều cần xác nhận. Mã vật tư đầy đủ trùng khớp được xác định là vật tư dùng chung. Không so sánh trực tiếp đơn giá khác đơn vị. Yêu cầu xác nhận khi giá hiển thị khác giá đã lưu, hoặc một trong hai có từ 7 chữ số thập phân trở lên. Tính cả số 0 cuối giá hiển thị. Các lý do được gộp trên cùng dòng gốc. Kiểm tra nội bộ và đối chiếu nguồn được báo cáo riêng.'],
 allRows:['원재료 행','Material rows','Dòng vật tư'],commonRows:['공용자재 행','Common material rows','Dòng vật tư dùng chung'],issueRows:['확인 대상 행','Rows to review','Dòng cần xác nhận'],displayRows:['단가 표시 차이','Price display differences','Chênh lệch giá hiển thị'],
 waiting:['대조 대기','Comparison pending','Chờ đối chiếu'],common:['공용자재','Common material','Vật tư dùng chung'],new:['공용자재 아님','Not common','Không phải vật tư dùng chung'],unreadable:['코드 확인 필요','Code needs review','Cần xác nhận mã'],
 internalDone:['파일 내부 검토 완료','Internal file review complete','Đã kiểm tra nội bộ tệp'],compareDone:['공용자재 대조 완료','Common material comparison complete','Đã đối chiếu vật tư dùng chung'],noCommon:['특이사항 없음(공용자재 없음)','No common materials found','Không có vật tư dùng chung'],compareIncomplete:['코드 확인 필요 · 대조 미완료','Code needs review · comparison incomplete','Cần xác nhận mã · đối chiếu chưa hoàn tất'],
 newContractPrice:['신규수책 단가','New Liquidation price','Đơn giá phụ lục mới'],existingContractPrice:['기존수책 단가','Existing Liquidation price','Đơn giá phụ lục hiện có'],allReasons:['모든 확인 사유','All review reasons','Tất cả lý do xác nhận'],
 search:['자재코드 또는 자재명 검색','Search material code or name','Tìm mã hoặc tên vật tư'],filter:['표시 대상','Show','Hiển thị'],all:['전체','All','Tất cả'],issues:['확인 대상','Needs review','Cần xác nhận'],displayFilter:['단가 표시 차이','Display differences','Chênh lệch hiển thị'],unitFilter:['단위 확인','Unit checks','Kiểm tra đơn vị'],
 row:['행 / 셀','Row / cell','Dòng / ô'],classification:['공용 여부','Common status','Trạng thái dùng chung'],shown:['표시 단가','Displayed price','Giá hiển thị'],actual:['실제 저장 단가','Stored price','Giá trị giá đã lưu'],reason:['확인 사유','Review reason','Lý do xác nhận'],details:['비교 상세','Details','Chi tiết'],view:['보기','View','Xem'],ok:['확인 사항 없음','No issues found','Không có điểm cần xác nhận'],
 resultCount:['표시 행','Visible rows','Dòng hiển thị'],close:['닫기','Close','Đóng'],existing:['기존 원천의 모든 일치 행','All matching reference rows','Tất cả dòng trùng trong dữ liệu nguồn'],project:['프로젝트','Project','Dự án'],product:['제품코드','Product code','Mã sản phẩm'],location:['원본 위치','Source location','Vị trí nguồn'],format:['Excel 표시 형식','Excel number format','Định dạng số Excel'],formula:['셀 수식','Cell formula','Công thức ô'],
 noMatches:['일치하는 기존 원천 행이 없습니다.','No matching reference rows.','Không có dòng nguồn trùng khớp.'],working:['파일을 읽는 중입니다…','Reading the file…','Đang đọc tệp…'],sourceChanged:['비교 원천 변경 · 검토를 다시 실행하세요.','Reference changed · run the review again.','Dữ liệu đối chiếu đã thay đổi · vui lòng kiểm tra lại.'],
 code_duplicate:['자재코드 중복 · 수책 내 1회만 허용','Duplicate material code · only one entry allowed per Liquidation','Mã vật tư trùng · chỉ được xuất hiện một lần trong phụ lục'],duplicateRows:['중복 원본 행','Duplicate source rows','Các dòng gốc bị trùng'],
 code_missing:['자재코드 미입력','Material code missing','Thiếu mã vật tư'],code_error:['자재코드 셀 오류','Material code cell error','Lỗi ô mã vật tư'],price_missing:['자재단가 미입력','Unit price missing','Thiếu đơn giá vật tư'],price_invalid:['단가를 숫자로 읽을 수 없음','Price is not numeric','Không đọc được đơn giá dạng số'],price_nonpositive:['0 또는 음수 단가 확인','Check zero or negative price','Xác nhận đơn giá bằng 0 hoặc âm'],price_error:['단가 셀 수식 오류','Price cell formula error','Lỗi công thức ô đơn giá'],formula_missing:['단가 수식 계산 결과 없음','Price formula has no cached result','Công thức đơn giá chưa có kết quả đã lưu'],
 unit_missing:['수량단위 미입력','Unit missing','Thiếu đơn vị tính'],hs_missing:['HS CODE(VN) 미입력','HS CODE(VN) missing','Thiếu HS CODE(VN)'],hs_format:['베트남 HS CODE(VN) 형식 확인','Check Vietnamese HS CODE(VN) format','Kiểm tra định dạng HS CODE(VN) Việt Nam'],
 stored_precision:['실제 저장 단가 소수점 7자리 이상','Stored price has 7+ decimal places','Giá đã lưu có từ 7 chữ số thập phân'],display_precision:['표시 단가 소수점 7자리 이상','Displayed price has 7+ decimal places','Giá hiển thị có từ 7 chữ số thập phân'],
 display_difference:['표시 단가와 실제 저장 단가 차이','Displayed and stored prices differ','Giá hiển thị khác giá trị đã lưu'],format_unknown:['단가 표시 형식 추가 확인 필요','Price format needs further checking','Cần kiểm tra thêm định dạng đơn giá'],conditional_format:['조건부 표시 형식 확인 필요','Conditional number format needs checking','Cần kiểm tra định dạng số có điều kiện'],
 internal_name:['파일 내부 동일 코드의 자재명 차이','Same code has different material names in this file','Cùng mã có tên vật tư khác nhau trong tệp'],
 internal_unit:['파일 내부 동일 코드의 단위 혼재','Same code has mixed units in this file','Cùng mã có nhiều đơn vị trong tệp'],internal_price:['파일 내부 동일 코드의 단가 차이','Same code has different prices in this file','Cùng mã có đơn giá khác nhau trong tệp'],internal_hs:['파일 내부 동일 코드의 HS CODE(VN) 차이','Same code has different HS CODE(VN)s in this file','Cùng mã có HS CODE(VN) khác nhau trong tệp'],
 source_unit_missing:['기존 원천 단위 누락','Reference unit missing','Thiếu đơn vị trong nguồn'],source_price_missing:['기존 원천 단가 누락 또는 읽기 불가','Reference price missing or unreadable','Đơn giá nguồn bị thiếu hoặc không đọc được'],source_hs_missing:['기존 원천 HS CODE(VN) 누락','Reference HS CODE(VN) missing','Thiếu HS CODE(VN) trong nguồn'],source_hs_format:['기존 원천 HS CODE(VN) 형식 확인','Check reference HS CODE(VN) format','Kiểm tra định dạng HS CODE(VN) nguồn'],
 unit_difference:['기존 원천과 단위 차이 · 해당 단가 비교 보류','Reference unit differs · corresponding price comparison deferred','Khác đơn vị nguồn · chưa so sánh đơn giá tương ứng'],price_difference:['기존 원천과 단가 불일치','Price differs from reference','Đơn giá không khớp nguồn'],price_partial:['기존 단가 일부 일치 · 다른 단가 존재','Matches some reference prices; other prices exist','Khớp một phần đơn giá nguồn; có đơn giá khác'],hs_difference:['기존 원천과 HS CODE(VN) 불일치','HS CODE(VN) differs from reference','HS CODE(VN) không khớp nguồn'],hs_partial:['기존 HS CODE(VN) 일부 일치 · 다른 HS CODE(VN) 존재','Matches some reference HS CODE(VN)s; others exist','Khớp một phần HS CODE(VN) nguồn; có HS CODE(VN) khác'],combination:['단가·HS CODE(VN)가 같은 기존 행에서 함께 일치하지 않음','Price and HS CODE(VN) do not match together in one reference row','Đơn giá và HS CODE(VN) không cùng khớp trên một dòng nguồn'],
 table_missing:['원재료 표를 찾지 못했습니다. 시트와 읽기 위치를 확인하세요.','Material table not found. Check the sheet and mapping.','Không tìm thấy bảng vật tư. Kiểm tra trang tính và vị trí đọc.'],rows_missing:['선택 범위에 읽을 원재료 행이 없습니다.','No material rows found in the selected range.','Không có dòng vật tư trong phạm vi đã chọn.'],too_large:['파일 또는 표가 처리 범위를 초과합니다.','The file or table exceeds the processing limit.','Tệp hoặc bảng vượt giới hạn xử lý.'],source_invalid:['비교 원천의 형식 또는 필수 항목을 확인하세요.','Check reference format and required fields.','Kiểm tra định dạng và trường bắt buộc của dữ liệu nguồn.'],source_formula:['기존 원천에 셀 오류 또는 수식 계산 결과 누락이 있습니다.','Reference contains cell errors or missing formula results.','Nguồn có lỗi ô hoặc thiếu kết quả công thức.'],company_mismatch:['선택한 법인과 파일의 법인이 다릅니다.','The selected company differs from the file.','Công ty đã chọn khác công ty trong tệp.'],company_unknown:['파일의 법인을 자동 확인하지 못했습니다. 선택한 법인 기준으로 검토합니다.','Could not identify the file’s company. Reviewing for the selected company.','Không tự xác định được công ty trong tệp. Kiểm tra theo công ty đã chọn.'],file_invalid:['읽을 수 없는 파일입니다. .xlsx 파일인지 확인하세요.','Cannot read this file. Please use an .xlsx workbook.','Không đọc được tệp. Vui lòng sử dụng tệp .xlsx.'],
 summaryImport:['저장 요약 불러오기 (.json)','Load saved summary (.json)','Tải dữ liệu tóm tắt (.json)'],pendingSummary:['새 저장 요약이 도착했습니다. 적용하면 현재 결과를 다시 검토해야 합니다.','A new saved summary is available. Applying it requires a new review.','Có dữ liệu tóm tắt mới. Sau khi áp dụng cần kiểm tra lại.'],applyNew:['새 요약 적용','Apply new summary','Áp dụng tóm tắt mới'],
 export:['검토 결과 저장 (HTML)','Save review results (HTML)','Lưu kết quả kiểm tra (HTML)'],exportTitle:['신규수책검토 결과','New Liquidation review results','Kết quả kiểm tra phụ lục mới'],
 noData:['표시할 항목이 없습니다.','No rows to display.','Không có dòng để hiển thị.'],chooseCompany:['법인을 먼저 선택하세요.','Select a company first.','Vui lòng chọn công ty trước.'],mappingInvalid:['열 문자는 서로 다르게 지정하고 제목 행은 1 이상으로 입력하세요.','Use distinct column letters and a header row of at least 1.','Dùng ký tự cột khác nhau và số dòng tiêu đề từ 1 trở lên.']
};

Object.assign(CMText,{
modeSource:['원천자료 대조','Reference comparison','Đối chiếu dữ liệu nguồn'],modeCross:['신규수책 간 교차 검증','Cross-file review','Đối chiếu phụ lục mới'],
crossHint:["동일 법인 파일 2~20개 · 총 250 MB 이하", "2–20 files from the same company · up to 250 MB total", "2–20 tệp cùng công ty · tổng dung lượng tối đa 250 MB"],
crossAdd:['파일 추가 / 드래그 드롭 (최대 20개)','Add / drop files (up to 20)','Thêm / thả tệp (tối đa 20)'],crossCount:['신규수책 파일은 2~20개가 필요합니다.','Select 2–20 Liquidation files.','Chọn 2–20 tệp phụ lục.'],crossLimit:['최대 20개, 전체 파일 용량 250MB까지 추가할 수 있습니다.','Up to 20 files and 250 MB in total.','Tối đa 20 tệp và tổng dung lượng 250 MB.'],crossRemove:['제거','Remove','Xóa'],crossFile:['파일 / 시트 / 행','File / sheet / row','Tệp / trang / dòng'],
crossShared:['파일 간 공용','Shared across files','Dùng chung giữa tệp'],crossUnique:['다른 파일에 없음','No other file match','Không có ở tệp khác'],crossDone:['신규수책 간 교차 검증 완료 · 원천자료 미사용','Cross-file review complete · no reference catalog used','Đã đối chiếu các phụ lục · không dùng nguồn'],crossOther:['다른 신규수책의 동일 코드','Same code in other Liquidations','Cùng mã trong phụ lục khác'],crossExample:['교차 검증 예시 3개 파일','Load 3 example files','Tải 3 tệp ví dụ'],crossUnknown:['법인을 자동 확인하지 못했습니다. 선택 법인으로 검토할지 확인해 주세요.','Company could not be detected. Confirm the selected company.','Không nhận diện được công ty. Xác nhận công ty đã chọn.'],crossConfirm:['선택 법인 자료임을 확인','Confirm selected company','Xác nhận đúng công ty'],crossBlocked:['모든 파일의 시트·열 설정 및 법인을 확인하거나, 읽을 수 없는 파일을 제거해 주세요.','Check sheets, columns and companies for all files, or remove unreadable files.','Kiểm tra trang, cột và công ty của mọi tệp, hoặc xóa tệp không đọc được.'],
crossPriceUnit:['단위가 달라 단가 차이는 단위와 함께 확인 필요','Units differ; review price differences together with units','Đơn vị khác nhau; kiểm tra giá cùng đơn vị'],crossSynthetic:['가상 예시 파일 · 실제 업무자료 아님','Synthetic examples · not business records','Tệp ví dụ giả lập · không phải dữ liệu thực'],crossResult:['교차 검증 결과','Cross-file results','Kết quả đối chiếu'],crossFiles:['업로드 파일','Uploaded files','Tệp đã tải'],crossDuplicates:['동일한 파일을 중복 추가하지 않았습니다.','An identical file was not added again.','Không thêm lại tệp giống hệt.'],crossMapping:['열 설정 (열 문자, 첫 행은 헤더 행)','Columns (letters; header row number)','Cột (chữ cái; số dòng tiêu đề)']
});
for(const k of ['name','spec','vnName','hs','unit','price']){
CMText['crossDiff_'+k]=['신규수책 간 '+CMText[k][0]+' 불일치','Across files: '+CMText[k][1]+' differs','Giữa các tệp: '+CMText[k][2]+' khác nhau'];
CMText['crossMissing_'+k]=['다른 신규수책의 '+CMText[k][0]+' 누락','Other Liquidation: missing '+CMText[k][1],'Phụ lục khác thiếu '+CMText[k][2]];
}

CMText.crossCompareSheet=['파일 간 비교 상세','Cross-file details','Chi tiết đối chiếu tệp'];

CMText.workDenied=['프로그램의 작업 승인 상태를 확인해 주세요.','Check the program work authorization.','Kiểm tra quyền thực hiện trong chương trình.'];

CMText.crossOrigin=['검토 파일 / 시트 / 행','Reviewed file / sheet / row','Tệp kiểm tra / trang / dòng'];
CMText.crossPeer=['비교 파일 / 시트 / 행','Compared file / sheet / row','Tệp đối chiếu / trang / dòng'];

CMText.subtitle=['원천자료 대조와 신규수책 간 교차 검증을 한곳에서 진행합니다.','Review against reference data or compare new Liquidation files.','Đối chiếu dữ liệu nguồn hoặc so sánh các phụ lục mới.'];

Object.assign(CMText,{
 materialCount:['자재','Materials','Vật tư'],reviewMaterials:['확인 대상 자재','Materials to review','Vật tư cần kiểm tra'],reviewNeeded:['확인 필요','Review needed','Cần kiểm tra'],
 crossEvidence:['항목별 값 · 해당 파일','Values by field · files','Giá trị theo mục · tệp'],crossFileShort:['해당 파일','Files','Tệp liên quan'],crossFileId:['파일 ID','File ID','ID tệp'],crossFilename:['파일명','Filename','Tên tệp'],crossFileList:['파일 목록','File list','Danh sách tệp'],
 crossMaterialSheet:['자재별 결과','Material results','Kết quả theo vật tư'],crossDifferenceSheet:['불일치 비교','Differences','So sánh khác biệt'],crossValue:['입력값','Value','Giá trị'],crossLocation:['파일명 · 셀','Filename · cell','Tên tệp · ô'],crossInternal:['파일 자체 확인','Within-file checks','Kiểm tra nội bộ tệp'],crossAllValues:['파일별 전체 값','All values by file','Toàn bộ giá trị theo tệp'],
 crossGroupedHint:['동일 자재는 한 행으로 표시합니다. 값이 같은 파일을 묶었으며, 서로 다른 값 그룹 간 확인이 필요합니다.','One row per material. Files with equal values are grouped; review differences between value groups.','Mỗi vật tư một dòng. Các tệp có cùng giá trị được nhóm lại; kiểm tra các nhóm có giá trị khác nhau.'],
 crossBlank:['(공란)','(blank)','(trống)'],crossNoIssues:['특이사항 없음','No issues','Không có vấn đề'],crossNoDifference:['파일 간 불일치 없음','No cross-file differences','Không có khác biệt giữa các tệp'],crossRowsRead:['읽은 자재 행','Material rows read','Dòng vật tư đã đọc'],
 crossFileSettings:['업로드 파일 · 시트 설정','Uploaded files · sheet settings','Tệp đã tải · chọn trang'],crossSelectedSheets:['선택 시트','Selected sheet','Trang đã chọn']
});

CMText.crossStatus=['검토 상태','Review status','Trạng thái kiểm tra'];

Object.assign(CMText,{
bomDetected:['다중 BOM 양식 감지','Multi-product BOM detected','Đã nhận diện BOM nhiều sản phẩm'],
bomProducts:['완제품','Products','Thành phẩm'],bomRows:['BOM 행','BOM rows','Dòng BOM'],
bom_master:['자재목록','Material master','Danh sách vật tư'],bom_bom:['제품별 BOM','Product BOM','BOM sản phẩm'],bom_products:['완제품목록','Product list','Danh sách thành phẩm'],
bomSettings:['구간별 읽기 설정 확인 / 수정','Review / edit section mapping','Xem / sửa phạm vi đọc'],
bomSettingsHint:['행 번호는 제목을 제외한 데이터 범위입니다. 열 문자를 확인한 뒤 설정을 적용하세요. 병합된 제품명은 해당 병합 범위 안에서만 이어 읽습니다.','Row numbers define data ranges excluding headers. Check column letters and apply. Merged products are carried only within the actual merged range.','Số dòng là phạm vi dữ liệu, không gồm tiêu đề. Kiểm tra ký tự cột rồi áp dụng. Chỉ điền sản phẩm trong phạm vi ô gộp thực tế.'],
bomStart:['시작 행','First data row','Dòng bắt đầu'],bomEnd:['끝 행','Last data row','Dòng kết thúc'],bomConsumption:['소요량','Consumption','Định mức'],bomScope:['구분 · 완제품 · 프로젝트','Section · product · project','Phần · sản phẩm · dự án'],bomEvidence:['동일 자재의 자재목록 · 제품별 BOM 비교','Same material across master and product BOMs','So sánh cùng vật tư trong danh sách và BOM'],
bomApplyNeeded:['변경한 구간 설정을 적용한 뒤 다시 검증하세요.','Apply the changed mapping before reviewing again.','Áp dụng phạm vi đã sửa trước khi kiểm tra lại.'],
bom_layout_invalid:['데이터 범위와 열 설정을 확인하세요. 구간이 겹치거나 필수 열이 누락되었습니다.','Check data ranges and columns: overlapping sections or missing required columns.','Kiểm tra phạm vi và cột: phạm vi chồng lấn hoặc thiếu cột bắt buộc.'],
bom_code_ambiguous:['자재코드 열이 여러 개입니다. 자재목록의 코드 열을 지정하고 설정을 적용하세요.','Multiple material code columns: select the master code column and apply.','Có nhiều cột mã vật tư: chọn cột mã của danh sách rồi áp dụng.'],
bom_product_missing:['BOM 완제품 미입력','BOM product missing','Thiếu thành phẩm trong BOM'],bom_product_unlisted:['완제품목록에 없는 BOM 제품','BOM product is absent from product list','Thành phẩm BOM không có trong danh sách'],bom_product_without_rows:['완제품목록에 BOM 행이 없는 제품이 있습니다. 구간 설정을 확인하세요.','A listed product has no BOM rows. Check section ranges.','Có thành phẩm không có dòng BOM. Kiểm tra phạm vi.'],
bom_duplicate:['같은 완제품 내 자재코드 중복','Duplicate material within the same product','Mã vật tư lặp trong cùng thành phẩm'],bom_master_missing:['자재목록에 없는 BOM 자재','BOM material absent from master','Vật tư BOM không có trong danh sách'],bom_unused:['BOM에서 사용하지 않은 목록 자재','Master material unused in BOMs','Vật tư danh sách chưa dùng trong BOM'],
crossHint:["동일 법인 파일 2~20개 · 총 250 MB 이하", "2–20 files from the same company · up to 250 MB total", "2–20 tệp cùng công ty · tổng dung lượng tối đa 250 MB"],
crossCount:['개별 BOM은 2~20개, 다중 BOM은 1~20개 파일을 선택하세요.','Select 2–20 individual BOMs or 1–20 files including a multi-product BOM.','Chọn 2–20 BOM đơn hoặc 1–20 tệp có BOM nhiều sản phẩm.'],
crossGroupedHint:['동일 자재는 한 행으로 표시합니다. 같은 값을 묶고 파일명·제품·시트/셀 위치를 함께 표시합니다.','One row per material. Equal values are grouped with files, products and sheet/cell locations.','Mỗi vật tư một dòng. Nhóm cùng giá trị kèm tệp, sản phẩm và vị trí trang/ô.']
});
for(const k of ['name','spec','vnName','unit','hs','price']){
 CMText['masterDiff_'+k]=['자재목록·BOM 간 '+CMText[k][0]+' 차이 존재','Master / BOM: '+CMText[k][1]+' differences exist','Danh sách / BOM: có khác biệt '+CMText[k][2]];
 CMText['bomDiff_'+k]=['제품별 BOM 간 '+CMText[k][0]+' 차이 존재','Across product BOMs: '+CMText[k][1]+' differences exist','Giữa BOM sản phẩm: có khác biệt '+CMText[k][2]];
}
CMText.rules=CMText.rules.map((v,i)=>[
 '다중 BOM은 자재목록과 제품별 BOM을 구분합니다. 다른 제품에서 동일 자재를 사용하는 것은 정상이며, 같은 제품 내 중복은 확인 대상입니다. 제품별 소요량 차이는 오류로 처리하지 않습니다. ',
 'Multi-product BOMs separate the material master from each product BOM. Reuse across products is valid; duplicates within a product require review. Different consumption by product is not an error. ',
 'BOM nhiều sản phẩm tách danh sách vật tư và BOM từng sản phẩm. Dùng chung giữa sản phẩm là hợp lệ; lặp trong cùng sản phẩm cần kiểm tra. Khác định mức theo sản phẩm không phải lỗi. '
][i]+v);

CMText.masterDiff_price=['신규수책 내 자재목록과 BOM의 단가가 다름','Within the new Liquidation: material list and BOM prices differ','Trong phụ lục mới: đơn giá danh sách vật tư khác BOM'];
CMText.bomDiff_price=['신규수책 내 제품별 BOM의 동일 자재 단가가 다름','Within the new Liquidation: the same material has different prices across product BOMs','Trong phụ lục mới: cùng vật tư có đơn giá khác nhau giữa BOM sản phẩm'];

CMText.sourceLocations=['곳','locations','vị trí'];
CMText.sourceOccurrences=['신규수책의 해당 자재 입력 위치','Occurrences of this material in the new Liquidation','Vị trí vật tư này trong phụ lục mới'];

Object.assign(CMText,{
 scopeInternal:['신규수책 내부 비교','Within the new Liquidation','So sánh trong phụ lục mới'],scopeReference:['기준자료 대조','Against reference data','Đối chiếu dữ liệu chuẩn'],
 scopeNewValues:['신규수책 입력값','New Liquidation values','Giá trị phụ lục mới'],scopeReferenceValues:['기준자료 입력값','Reference values','Giá trị dữ liệu chuẩn'],
 scopeMaster:['자재목록 ↔ 제품 BOM','Material list ↔ product BOM','Danh sách vật tư ↔ BOM sản phẩm'],scopeProducts:['제품 BOM ↔ 제품 BOM','Product BOM ↔ product BOM','BOM sản phẩm ↔ BOM sản phẩm'],scopeRepeated:['동일 자재의 입력행 간 비교','Across occurrences of the same material','Giữa các dòng của cùng vật tư'],
 scopeInternalHint:['신규수책 안에서 같은 자재의 입력값이 일관되는지 확인합니다.','Checks consistency of the same material within the new Liquidation.','Kiểm tra tính nhất quán của cùng vật tư trong phụ lục mới.'],
 scopeReferenceHint:['신규수책 입력값을 기준 밸런스시트의 동일 자재와 대조합니다.','Compares new Liquidation values against the same material in the reference Balance Sheet.','Đối chiếu giá trị phụ lục mới với cùng vật tư trong Balance Sheet chuẩn.'],
 scopeNotSelected:['선택하지 않음','Not selected','Chưa chọn'],scopeNotMatched:['기준자료에 해당 코드 없음','Code not found in reference','Không có mã này trong nguồn'],scopeConsistent:['확인된 차이 없음','No differences flagged','Chưa ghi nhận khác biệt'],
 scopeVariants:['입력값 종류','Distinct values','Số giá trị khác nhau'],scopeAffected:['불일치 입력 위치','Mismatching locations','Vị trí không khớp'],scopeEvidence:['입력값 및 원본 위치','Values and original locations','Giá trị và vị trí gốc']
});
for(const k of ['name','spec','vnName','unit','hs','price'])CMText['within_'+k]=['신규수책 내부 '+(k==='price'?'단가':CMText[k][0])+' 불일치','Within new Liquidation: '+CMText[k][1]+' mismatch','Trong phụ lục mới: '+CMText[k][2]+' không khớp'];
CMText.price_difference=['기준자료 대비 단가 불일치','Price differs from reference data','Đơn giá không khớp dữ liệu chuẩn'];

CMText.crossCount=['교차 검증은 신규수책 파일 2~20개가 필요합니다.','Cross-file review requires 2–20 new Liquidation files.','Đối chiếu giữa tệp cần 2–20 tệp phụ lục mới.'];
CMText.crossHint=['동일 법인의 신규수책 파일 2~20개를 비교합니다. 개별 BOM과 다중 BOM을 함께 사용할 수 있습니다. 파일 1개의 내부 비교는 원천자료 대조 화면에서 확인하세요.','Compare 2–20 new Liquidation files for one company. Individual and multi-product BOMs can be mixed. Use Reference comparison for checks within a single file.','So sánh 2–20 tệp phụ lục mới của cùng công ty. Có thể kết hợp BOM đơn và BOM nhiều sản phẩm. Kiểm tra trong một tệp tại Đối chiếu dữ liệu nguồn.'];

Object.assign(CMText,{
 hs_review:['HS CODE(VN) 확인 필요','HS CODE(VN) review required','Cần kiểm tra HS CODE(VN)'],
 hs_format:['신규수책 HS CODE(VN) 형식 확인 (숫자 8자리)','New Liquidation HS CODE(VN): check 8-digit format','HS CODE(VN) phụ lục mới: kiểm tra định dạng 8 chữ số'],
 hs_difference:['기준자료 대비 HS CODE(VN) 값 불일치','HS CODE(VN) value differs from reference data','Giá trị HS CODE(VN) không khớp dữ liệu chuẩn'],
 hs_partial:['기준자료 HS CODE(VN) 일부 일치 · 다른 값 존재','HS CODE(VN) matches some reference values; other values exist','HS CODE(VN) khớp một phần nguồn; có giá trị khác'],
 source_hs_format:['기준자료 HS CODE(VN) 형식 확인 (숫자 8자리)','Reference HS CODE(VN): check 8-digit format','HS CODE(VN) nguồn: kiểm tra định dạng 8 chữ số']
});

Object.assign(CMText,{
 exportSelectTitle:['Excel 저장 · 확인 사유 선택','Excel export · Select review reasons','Xuất Excel · Chọn lý do kiểm tra'],
 exportSelectHint:['화면과 동일한 확인 사유입니다. 현재 체크 상태를 가져오며, 선택한 사유와 해당 비교 근거만 저장합니다.','Uses the same review reasons and current selection as the screen. Exports selected reasons and their evidence only.','Dùng cùng lý do và lựa chọn hiện tại trên màn hình. Chỉ xuất lý do đã chọn và căn cứ liên quan.'],
 exportSelectedCount:['추출 대상 자재','Materials to export','Vật tư được xuất'],exportSelection:['선택한 확인 사유','Selected review reasons','Lý do kiểm tra đã chọn'],
 excelMaterialSummary:['자재별 검토 요약','Material review summary','Tổng hợp kiểm tra vật tư'],excelEvidence:['비교 근거','Comparison evidence','Căn cứ đối chiếu'],
 excelNewLocation:['신규수책 파일 · 시트/셀','New Liquidation file · sheet/cell','Tệp phụ lục mới · trang/ô'],excelRefLocation:['기준자료 파일 · 시트/셀','Reference file · sheet/cell','Tệp nguồn · trang/ô'],
 excelGroupedNote:['자재코드별 한 행 · 선택한 확인 사유만 표시 · 값과 위치가 많은 항목은 비교 근거 시트에 모두 기재합니다.','One row per material code · Selected reasons only · Full values and locations are retained in Comparison evidence.','Mỗi mã vật tư một dòng · Chỉ lý do đã chọn · Đầy đủ giá trị và vị trí tại Căn cứ đối chiếu.'],
 excelMoreEvidence:['… 전체 내용은 비교 근거 시트 참조','… See Comparison evidence for full details','… Xem đầy đủ tại Căn cứ đối chiếu'],
 excelContext:['비교 참고값','Comparison context','Giá trị tham chiếu để so sánh']
});

Object.assign(CMText,{
 excelNewLabel:['신규수책','New Liquidation','Phụ lục mới'],excelReferenceLabel:['기준자료','Reference data','Dữ liệu chuẩn'],
 excelDetailsBelow:['… 전체 내용은 바로 아래 상세행 참조','… See detail rows immediately below','… Xem đầy đủ ở các dòng chi tiết bên dưới'],
 sourceExcelOutline:['자재별 요약 바로 아래에 입력값·파일명·시트/셀을 표시합니다. 기본은 모두 펼침이며, Excel의 1/2 또는 −/+ 버튼으로 상세를 접고 펼칠 수 있습니다.','Values, files and sheet/cell locations appear directly below each material summary. Details are expanded by default; use Excel 1/2 or −/+ controls to collapse or expand.','Giá trị, tên tệp và trang/ô nằm ngay dưới tổng hợp từng vật tư. Mặc định mở toàn bộ; dùng nút 1/2 hoặc −/+ trong Excel để thu gọn/mở rộng.']
});

CMText.reportNoReasons=['선택한 사유 없음','No reasons selected','Chưa chọn lý do'];
