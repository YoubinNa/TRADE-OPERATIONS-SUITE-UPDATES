/* Suite-owned read-only catalog, permissions and lifecycle adapter for approved 1.0.0. */
(function(){'use strict';
if(!window.EcussDesktop||!window.StockDashboardSync)return;
const M=CommonMaterialModule;
const copy={ko:{loading:'요약 자료 불러오는 중',checking:'최신 요약 확인 중',current:'최신 요약 확인 완료',empty:'저장된 요약 없음',stale:'연결 확인 실패 · 마지막 저장 요약 사용',error:'요약 연결 실패 · 원천 대조 대기',refresh:'다시 확인'},en:{loading:'Loading catalog',checking:'Checking latest catalog',current:'Latest catalog confirmed',empty:'No saved catalog',stale:'Connection unavailable · using saved catalog',error:'Catalog unavailable · comparison pending',refresh:'Refresh'},vi:{loading:'Đang tải dữ liệu',checking:'Đang kiểm tra dữ liệu mới nhất',current:'Đã xác nhận dữ liệu mới nhất',empty:'Chưa có dữ liệu lưu',stale:'Mất kết nối · dùng dữ liệu đã lưu',error:'Chưa có dữ liệu · chờ đối chiếu',refresh:'Kiểm tra lại'}};
const bar=document.createElement('div');bar.id='suite-common-material-status';bar.className='source-status';bar.setAttribute('aria-live','polite');const title=document.createElement('span'),button=document.createElement('button');button.type='button';button.className='small';button.style.marginLeft='12px';bar.append(title,button);document.getElementById('sourceMode').prepend(bar);
let status='empty',key=null,disposed=false;
const text=()=>{const t=copy[EcussModuleI18n.getLanguage()]||copy.ko;title.textContent=t[status]||t.error;button.textContent=t.refresh;button.disabled=['loading','checking'].includes(status);bar.hidden=!M.getState().company;};
async function parse(bytes,key,info){if(info.sourceKind!=='balance'||info.company!==(key==='amo'?'AMO':'AMOGREEN'))throw Error('source_invalid');const zip=await JSZip.loadAsync(bytes),files=Object.values(zip.files).filter(f=>!f.dir);if(files.length!==1||files[0].name!=='catalog.json'||files[0]._data?.uncompressedSize>16000000)throw Error('source_invalid');const json=await files[0].async('string');if(json.length>16000000)throw Error('source_invalid');const data=CommonMaterialCore.sourceJSON(JSON.parse(json),key==='amo'?'AMO':'AGV');return {...data,validatedAt:info.validatedAt};}
const provider=StockDashboardSync.nativeProvider({call:(path,payload)=>EcussDesktop.call(path.replace('/stock/dashboard/','/stock/materials/'),payload)},'catalog');
const sync=new StockDashboardSync.Sync(provider,parse,event=>{status=event.state;const company=event.key==='amo'?'AMO':'AGV';if(status==='empty')M.clearSource(company);else if(event.snapshot)M.receiveSource(event.snapshot.data,{filename:event.snapshot.info.finalName,validatedAt:event.snapshot.info.validatedAt,hash:event.snapshot.contentHash});text();});
function active(){return !!M.getState().company&&!window.CrossReview?.getState().mode&&!document.hidden;}
function select(){if(disposed)return;text();if(!active())return;const next=M.getState().company==='AMO'?'amo':'agv';if(next!==key){key=next;sync.select(key);}}
button.onclick=()=>{if(active())sync.refresh();};
const click=()=>queueMicrotask(select),visible=()=>{if(active()){select();sync.refresh();}};
document.addEventListener('click',click);window.addEventListener('review-state',select);document.addEventListener('visibilitychange',visible);window.addEventListener('online',visible);
const timer=setInterval(()=>{if(active())sync.refresh();},60000);
window.addEventListener('pagehide',()=>{disposed=true;clearInterval(timer);sync.dispose();document.removeEventListener('click',click);window.removeEventListener('review-state',select);document.removeEventListener('visibilitychange',visible);window.removeEventListener('online',visible);},{once:true});
M.saveExcel=async(bytes,filename)=>{let binary='';for(let i=0;i<bytes.length;i+=32768)binary+=String.fromCharCode(...bytes.subarray(i,i+32768));const result=await EcussDesktop.call('/stock/materials/export-xlsx',{filename,data:btoa(binary)});if(result.status!==200)throw Error('excelFailed');return result.value;};
M.authorizeWork=()=>EcussDesktop.authorizeWork?EcussDesktop.authorizeWork():Promise.resolve(false);
if(window.__ECUSS_SUITE__?.lang)M.setLanguage(window.__ECUSS_SUITE__.lang);
window.addEventListener('load',()=>{if(document.getElementById('ecuss-language-toolbar'))document.querySelector('.lang')?.classList.add('ecuss-source-language');},{once:true});
window.EcussModuleUI={workControls:'#run,#crossRun,#pickTarget,#pickSource,#crossPick,.drop,#summaryFile'};
const stateAPI=window.EcussModuleState;window.EcussModuleState={...stateAPI,hasWork:()=>stateAPI.hasWork()||!!M.getState().sourceCandidate||Object.keys(M.getState().manual).length>0};
window.CommonMaterialSuite={refresh:()=>sync.refresh(),parse,dispose:()=>sync.dispose()};text();
})();
