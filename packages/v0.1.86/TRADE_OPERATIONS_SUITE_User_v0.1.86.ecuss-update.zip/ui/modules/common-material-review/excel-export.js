/* Runtime XLSX output populated from the Artifact Tool-authored style template. */
(function(root){'use strict';
const xml=v=>String(v??'').replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F]/g,'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
const col=i=>String.fromCharCode(65+i);

function issueFields(key){
 if(['bom_duplicate','bom_master_missing','bom_unused'].includes(key))return ['code'];
 if(key==='crossPriceUnit')return ['price','unit'];
 if(/price|precision|display|format_unknown|formula_missing/i.test(key))return ['price'];
 const field=['code','name','spec','vnName','hs','unit'].find(f=>new RegExp('(^|_)'+f+'(_|$)').test(key));
 return [field||'exportOther'];
}
const filterIssues=(issues,selected)=>root.CommonMaterialReasonFilter.filterIssues(issues,selected);
const includeRow=(issues,selected)=>root.CommonMaterialReasonFilter.matches(issues,selected);
function choose({t,items,count,initial='all'}){
 return new Promise(resolve=>{
  const dialog=document.createElement('dialog');dialog.id='excelOptions';dialog.className='excel-options';
  const choices=root.CommonMaterialReasonFilter.entries(items,t),keys=initial==null||initial==='all'?'all':initial.map(root.CommonMaterialReasonFilter.canonical);
  dialog.innerHTML='<div class="dialogtop"><h2>'+t('exportSelectTitle')+'</h2><button data-cancel>'+t('cancel')+'</button></div><p class="hint">'+t('exportSelectHint')+'</p><div class="actions"><button data-all>'+t('exportSelectAll')+'</button><button data-none>'+t('exportSelectNone')+'</button></div><fieldset class="excel-checks"><legend>'+t('reason')+'</legend>'+choices.map(([key,label,n])=>'<label><input type="checkbox" value="'+key+'" '+(keys==='all'||keys.includes(key)?'checked':'')+'> '+label+' <small>('+n+')</small></label>').join('')+'</fieldset><p data-count role="status"></p><button data-confirm class="primary">'+t('exportExcel')+'</button>';
  const selected=()=>[...dialog.querySelectorAll('input:checked')].map(e=>e.value);
  const update=()=>{const n=count(selected());dialog.querySelector('[data-count]').textContent=t('exportSelectedCount')+': '+n;dialog.querySelector('[data-confirm]').disabled=!n;};
  let result=null;dialog.onclose=()=>{dialog.remove();resolve(result);};dialog.oncancel=()=>{result=null;};
  dialog.querySelector('[data-cancel]').onclick=()=>dialog.close();dialog.querySelector('[data-confirm]').onclick=()=>{result=selected();dialog.close();};
  for(const [key,checked] of [['all',true],['none',false]])dialog.querySelector('[data-'+key+']').onclick=()=>{dialog.querySelectorAll('input').forEach(e=>e.checked=checked);update();};
  dialog.onchange=update;document.body.appendChild(dialog);update();dialog.showModal();
 });
}
function cell(address,value,style){const v=String(value??'');if(v.length>32767)throw Error('excelTooLarge');return '<x:c r="'+address+'" s="'+style+'" t="inlineStr"><x:is><x:t xml:space="preserve">'+xml(v)+'</x:t></x:is></x:c>';}
const textWidth=s=>[...String(s)].reduce((n,c)=>n+(c.charCodeAt(0)>255?1.8:1),0);
function height(values,widths){return Math.min(409,Math.max(32,...values.map((v,i)=>String(v??'').split('\n').reduce((n,line)=>n+Math.max(1,Math.ceil(textWidth(line)/Math.max(2,widths[i]-2))),0)*14+10)));}
async function build(report){
 if(['crossCompact','sourceGrouped'].includes(report.layout))return buildCompact(report);
 const zip=await JSZip.loadAsync(CMExcelTemplate.base64,{base64:true});
 const sheets=[{name:report.sheetNames[0],headers:report.headers,rows:report.rows,indices:report.columnIndices,widths:report.widths||[5,17,16,12,18,5,9,11,16,10,27]},
 {name:report.sheetNames[1],headers:report.referenceHeaders,rows:report.referenceRows,indices:report.referenceColumnIndices,widths:report.referenceWidths||[5,17,12,16,17,12,20,6,10,16,24]}];
 for(let i=0;i<sheets.length;i++){
  const data=sheets[i],path='xl/worksheets/sheet'+(i+1)+'.xml';let sheet=await zip.file(path).async('string');
  const styles=CMExcelTemplate.styles[i],cols=data.headers.length,end=col(cols-1),styleCol=c=>col(data.indices?.[c]??c);const last=Math.max(8,data.rows.length+7);if(last>1048576)throw Error('excelTooLarge');
  const meta=[report.title,report.target,report.reference,report.summary,report.note];
  let body='<x:row r="1" ht="9" customHeight="1"/>';
  meta.forEach((v,j)=>{const r=j+2;body+='<x:row r="'+r+'" ht="'+(r===2?29:height([v],[data.widths.reduce((a,b)=>a+b,0)]))+'" customHeight="1">'+cell('A'+r,v,styles['A'+r])+'</x:row>';});
  body+='<x:row r="7" ht="34" customHeight="1">'+data.headers.map((v,c)=>cell(col(c)+'7',v,styles[styleCol(c)+'7'])).join('')+'</x:row>';
  const rows=data.rows.length?data.rows:[{values:[report.emptyReference],issues:false}];
  rows.forEach((r,j)=>{const n=j+8,values=Array.from({length:cols},(_,c)=>r.values[c]??'');body+='<x:row r="'+n+'" ht="'+height(values,data.widths)+'" customHeight="1">'+values.map((v,c)=>cell(col(c)+n,v,styles[styleCol(c)+(r.highlights?.includes(c)?10:r.issues?9:8)])).join('')+'</x:row>';});
  sheet=sheet.replace(/<x:sheetData>[\s\S]*?<\/x:sheetData>/,'<x:sheetData>'+body+'</x:sheetData>');
  sheet=sheet.replace(/<x:cols>[\s\S]*?<\/x:cols>/,'<x:cols>'+data.widths.map((w,c)=>'<x:col min="'+(c+1)+'" max="'+(c+1)+'" width="'+w+'" customWidth="1"/>').join('')+'</x:cols>');
  sheet=sheet.replace('<x:sheetView ','<x:sheetView zoomScale="85" zoomScaleNormal="85" ');
  sheet=sheet.replace('</x:sheetPr>','<x:pageSetUpPr fitToPage="1"/></x:sheetPr>');
  sheet=sheet.replace(/<x:mergeCells[\s\S]*?<\/x:mergeCells>/,'<x:mergeCells count="5">'+[2,3,4,5,6].map(r=>'<x:mergeCell ref="A'+r+':'+end+r+'"/>').join('')+'</x:mergeCells>');
  sheet=sheet.replace('</x:sheetData>','</x:sheetData><x:autoFilter ref="A7:'+end+last+'"/>');
  // pageMargins is a singleton. The style template already contains one.
  // Replace its print layout instead of appending a second pageMargins (Excel repair).
  sheet=sheet.replace(/<x:pageMargins\b[^>]*\/>/g,'').replace(/<x:pageSetup\b[^>]*\/>/g,'');
  sheet=sheet.replace('</x:worksheet>','<x:pageMargins left="0.25" right="0.25" top="0.35" bottom="0.35" header="0.15" footer="0.15"/><x:pageSetup paperSize="9" orientation="landscape" fitToWidth="1" fitToHeight="0"/></x:worksheet>');
  for(const tag of ['sheetData','sheetViews','autoFilter','mergeCells','pageMargins','pageSetup']){
   if((sheet.match(new RegExp('<x:'+tag+'\\b','g'))||[]).length!==1)throw Error('excelFailed');
  }
  zip.file(path,sheet);
 }
 let workbook=await zip.file('xl/workbook.xml').async('string');
 workbook=workbook.replace('name="Review"','name="'+xml(sheets[0].name)+'"').replace('name="Reference"','name="'+xml(sheets[1].name)+'"');
 workbook=workbook.replace('</x:workbook>','<x:definedNames>'+sheets.map((s,i)=>'<x:definedName name="_xlnm.Print_Titles" localSheetId="'+i+'">'+xml("'"+s.name.replace(/'/g,"''")+"'!$1:$7")+'</x:definedName>').join('')+'</x:definedNames></x:workbook>');
 zip.file('xl/workbook.xml',workbook);
 return zip.generateAsync({type:'uint8array',compression:'DEFLATE'});
}
async function buildCompact(report){
 const zip=await JSZip.loadAsync(CMCrossExcelTemplate.base64,{base64:true}),sheets=report.sheets;
 for(let i=0;i<sheets.length;i++){
  const data=sheets[i],path='xl/worksheets/sheet'+(i+1)+'.xml',styles=CMCrossExcelTemplate.styles[data.templateSheet??i],cols=data.headers.length,end=col(cols-1);
  let sheet=await JSZip.loadAsync(CMCrossExcelTemplate.base64,{base64:true}).then(z=>z.file('xl/worksheets/sheet'+((data.templateSheet??i)+1)+'.xml').async('string'));const rows=data.rows.length?data.rows:[{values:[data.empty],issues:false}],last=rows.length+4;
  if(last>1048576)throw Error('excelTooLarge');
  let body='<x:row r="1" ht="8" customHeight="1"/>';
  body+='<x:row r="2" ht="30" customHeight="1">'+cell('A2',data.name,styles.A2)+'</x:row>';
  const subtitle=report.summary+(data.note?'\n'+data.note:'');
  body+='<x:row r="3" ht="'+height([subtitle],[data.widths.reduce((n,w)=>n+w,0)])+'" customHeight="1">'+cell('A3',subtitle,styles.A3)+'</x:row>';
  body+='<x:row r="4" ht="32" customHeight="1">'+data.headers.map((v,c)=>cell(col(c)+'4',v,styles[col(c)+'4'])).join('')+'</x:row>';
  const merges=['A2:'+end+'2','A3:'+end+'3',...(data.headerMerges||[]).map(([a,b])=>col(a)+'4:'+col(b)+'4')];
  rows.forEach((r,j)=>{const n=j+5,values=Array.from({length:cols},(_,c)=>r.values[c]??''),widths=[...data.widths];
   for(const [a,b] of r.merges||[]){merges.push(col(a)+n+':'+col(b)+n);widths[a]=data.widths.slice(a,b+1).reduce((x,y)=>x+y,0);}
   const styleRow=r.kind==='summary'?(r.issues?10:9):r.kind==='detailHeader'?8:r.band?7:5;
   const attrs=(r.outline?' outlineLevel="'+r.outline+'"':'')+(r.collapsed?' collapsed="1"':'');
   body+='<x:row r="'+n+'" ht="'+height(values,widths)+'" customHeight="1"'+attrs+'>'+values.map((v,c)=>cell(col(c)+n,v,styles[col(c)+(r.kind==='material'?(r.issues&&c===2?10:r.band?7:5):styleRow)])).join('')+'</x:row>';
  });
  sheet=sheet.replace(/<x:sheetData>[\s\S]*?<\/x:sheetData>/,'<x:sheetData>'+body+'</x:sheetData>');
  sheet=sheet.replace(/<x:cols>[\s\S]*?<\/x:cols>/,'<x:cols>'+data.widths.map((w,c)=>'<x:col min="'+(c+1)+'" max="'+(c+1)+'" width="'+w+'" customWidth="1"/>').join('')+'</x:cols>');
  sheet=sheet.replace(/<x:mergeCells[\s\S]*?<\/x:mergeCells>/,'<x:mergeCells count="'+merges.length+'">'+merges.map(ref=>'<x:mergeCell ref="'+ref+'"/>').join('')+'</x:mergeCells>');
  sheet=sheet.replace('<x:sheetView ','<x:sheetView zoomScale="85" zoomScaleNormal="85" ');
  sheet=sheet.replace('</x:sheetPr>',(data.outline?'<x:outlinePr summaryBelow="0" showOutlineSymbols="1"/>':'')+'<x:pageSetUpPr fitToPage="1"/></x:sheetPr>');
  if(data.outline)sheet=sheet.replace('<x:sheetFormatPr ','<x:sheetFormatPr outlineLevelRow="1" ');
  // Filtering or sorting a mixed summary/detail range separates material groups.
  if(!data.outline)sheet=sheet.replace('</x:sheetData>','</x:sheetData><x:autoFilter ref="A4:'+end+last+'"/>');
  sheet=sheet.replace(/<x:pageMargins\b[^>]*\/>/g,'').replace(/<x:pageSetup\b[^>]*\/>/g,'');
  sheet=sheet.replace('</x:worksheet>','<x:pageMargins left="0.25" right="0.25" top="0.35" bottom="0.35" header="0.15" footer="0.15"/><x:pageSetup paperSize="9" orientation="landscape" fitToWidth="1" fitToHeight="0"/></x:worksheet>');
  for(const tag of ['sheetData','sheetViews','mergeCells','pageMargins','pageSetup'])if((sheet.match(new RegExp('<x:'+tag+'\\b','g'))||[]).length!==1)throw Error('excelFailed');
  zip.file(path,sheet);
 }
 let workbook=await zip.file('xl/workbook.xml').async('string'),idx=0;
 workbook=workbook.replace(/(<x:sheet\b[^>]*\bname=")[^"]+("[^>]*\/?>)/g,(_,a,b)=>a+xml(sheets[idx++].name)+b);
 workbook=workbook.replace('</x:workbook>','<x:definedNames>'+sheets.map((s,i)=>'<x:definedName name="_xlnm.Print_Titles" localSheetId="'+i+'">'+xml("'"+s.name.replace(/'/g,"''")+"'!$1:$4")+'</x:definedName><x:definedName name="_xlnm.Print_Area" localSheetId="'+i+'">'+xml("'"+s.name.replace(/'/g,"''")+"'!$A$1:$"+col(s.headers.length-1)+'$'+Math.max(5,s.rows.length+4))+'</x:definedName>').join('')+'</x:definedNames></x:workbook>');
 zip.file('xl/workbook.xml',workbook);return zip.generateAsync({type:'uint8array',compression:'DEFLATE'});
}

root.CommonMaterialExcel={build,choose,filterIssues,includeRow,issueFields};
})(typeof window!=='undefined'?window:globalThis);
