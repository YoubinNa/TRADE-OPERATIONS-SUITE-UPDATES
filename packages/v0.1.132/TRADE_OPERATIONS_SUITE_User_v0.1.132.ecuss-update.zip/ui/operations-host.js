/* The native workspace owns module identities, access checks, work tabs, and file dialogs. */
(() => {
  'use strict';
  const suite=window.__ECUSS_SUITE__,desktop=window.EcussDesktop;
  if(!suite||!desktop)return;
  const frame=document.createElement('iframe');
  frame.id='operations-home';
  frame.title='Trade Operations';
  const call=(path,payload)=>desktop.call(path,payload);
  let theme=suite.homeTheme==='light'?'light':'dark',reading='large',pendingRoute=null,routeObserver=null,returnScene='home';
  const skinUrl=new URL('operations/native.css',location.href).href;
  const child=()=>frame.contentWindow;
  const language=()=>document.documentElement.lang||suite.lang||'ko';
  const local=(ko,en,vi)=>({ko,en,vi}[language()]||ko);
  const isHome=()=>!document.body.classList.contains('module-mode');
  const feedback=message=>{const node=document.querySelector('.shell-notice');if(node)node.textContent=message;};
  const ready=(async()=>{
    let saved=window.__ECUSS_HOME_PREFERENCES__;
    if(!saved){
      const reply=await call('/desktop/home-preferences/load',null).catch(()=>null);
      if(reply?.status===200)saved=reply.value;
    }
    const values={};
    for(const [key,value] of Object.entries(saved||{})){try{values[key]=JSON.parse(value);}catch{}}
    return values;
  })();
  async function savePreference(key,value){
    const result=await call('/desktop/home-preferences/change',{key,value:JSON.stringify(value)});
    if(result.status!==200)throw Error('preference');
  }
  function moduleSkin(doc,id){
    if(!doc?.head||doc.URL==='about:blank')return;
    doc.documentElement.dataset.workTheme=theme;
    doc.documentElement.dataset.workSize=reading;
    doc.documentElement.dataset.workModule=id;
    if(!doc.getElementById('operations-skin')){
      const owner=doc.defaultView.frameElement,link=doc.createElement('link');
      owner.dataset.skinPending='';
      doc.documentElement.dataset.workStarting='';
      const reveal=()=>{
        if(owner.contentDocument!==doc)return;
        doc.documentElement.getBoundingClientRect();
        owner.removeAttribute('data-skin-pending');
        doc.defaultView.requestAnimationFrame(()=>doc.documentElement.removeAttribute('data-work-starting'));
      };
      link.id='operations-skin';link.rel='stylesheet';link.href=skinUrl;link.onload=reveal;
      link.onerror=()=>{reveal();feedback(local('모듈 테마를 불러올 수 없습니다.','Module appearance could not be loaded.','Không thể tải giao diện mô-đun.'));};
      const style=doc.createElement('style');style.textContent=workStyleFor(id);
      doc.head.append(link,style);
    }
    if(id==='psr-rvc-lvc-calculator')for(const nested of doc.querySelectorAll('iframe')){
      try{if(nested.contentDocument?.URL!=='about:blank')moduleSkin(nested.contentDocument,'psr-sheet');}catch{}
    }
  }
  function appearance(next,size){
    theme=next==='light'?'light':'dark';reading=size==='standard'?'standard':'large';
    document.documentElement.dataset.operationsTheme=theme;
    for(const f of document.querySelectorAll('iframe[data-workspace-module]'))moduleSkin(f.contentDocument,f.dataset.workspaceModule);
  }
  function status(){return {balance:window.EcussRecords?.snapshot?.(),mail:window.EcussMailChecks?.snapshot?.()};}
  function statusChanged(id){child()?.redrawBoard?.(id);}
  function refreshStatus(force){
    window.EcussRecords?.refresh(force);window.EcussMailChecks?.refresh(force);
  }
  function settings(){
    const panel=document.querySelector('.connection-panel');
    if(!panel||panel.closest('dialog'))return;
    const placeholder=document.createComment('connection-panel');panel.before(placeholder);
    const dialog=document.createElement('dialog');dialog.className='operations-settings';
    const close=document.createElement('button');close.textContent=local('닫기','Close','Đóng');close.onclick=()=>dialog.close();
    dialog.append(panel,close);document.body.append(dialog);
    dialog.addEventListener('close',()=>{placeholder.replaceWith(panel);dialog.remove();frame.focus();},{once:true});
    dialog.showModal();
  }
  function applyRoute(){
    if(!pendingRoute||isHome())return;
    const {id,route}=pendingRoute;
    const f=document.querySelector('iframe[data-workspace-module="'+id+'"]:not([hidden])'),doc=f?.contentDocument;
    if(!doc||doc.readyState!=='complete')return;
    const {company,period,anchor}=route;
    if(id==='stock-dashboard'){
      const co=doc.getElementById(company);if(co){pendingRoute=null;co.click();}
      return;
    }
    const co=doc.querySelector('[data-company="'+company+'"]'),results=doc.getElementById('results');
    if(!co||!results)return;
    const switchCompany=co.getAttribute('aria-pressed')!=='true';
    if(switchCompany||results.hidden){
      if(routeObserver)return;
      routeObserver=new MutationObserver(applyRoute);routeObserver.observe(results,{attributes:true,attributeFilter:['hidden']});
      if(switchCompany)co.click();
      return;
    }
    routeObserver?.disconnect();routeObserver=null;pendingRoute=null;
    doc.querySelector('[data-direction="Export"]')?.click();
    doc.querySelector('[data-period="'+period+'"]')?.click();
    const input=doc.getElementById(period+'-value');
    if(input){input.value=period==='month'?anchor.slice(0,7):anchor;input.dispatchEvent(new f.contentWindow.Event('input',{bubbles:true}));}
    const fee=doc.querySelector('#ranking-options input[value="fee"]');if(fee&&!fee.checked)fee.click();
  }
  function cancelRoute(){pendingRoute=null;routeObserver?.disconnect();routeObserver=null;}
  async function open(id,route){
    if(id==='validation-status'||id==='mail-check-status'){
      (id==='validation-status'?window.EcussRecords:window.EcussMailChecks)?.show();return;
    }
    cancelRoute();
    if(route&&['stock-dashboard','import-export-performance'].includes(id)&&['amo','agv'].includes(route.company))pendingRoute={id,route};
    const result=await call('/desktop/open',id);
    if(result.status!==200||result.value?.ok===false){cancelRoute();if(result.value?.access)window.EcussUpdateStatus?.accept(result.value.access);throw Error('open');}
    applyRoute();
  }
  function sessionSummary(id){
    const selectors={'balance-ecuss':'.result-summary,.kpi','container-stuffing-simulator':'.counter','materials-shipping':'.stat','customs-inspection-cost-comparison':'.verdict'};
    const doc=document.querySelector('iframe[data-workspace-module="'+id+'"]')?.contentDocument;
    if(!doc||!selectors[id])return '';
    return [...doc.querySelectorAll(selectors[id])].filter(n=>!n.closest('[hidden]')).map(n=>n.textContent.trim()).filter(Boolean).slice(0,3).join(' · ').slice(0,300);
  }
  function selectModule(id,showHome){
    child()?.setModuleNavigation?.(id);
    if(id){syncModuleLanguage(document.querySelector('iframe[data-workspace-module="'+id+'"]'));applyRoute();return;}
    cancelRoute();
    if(showHome)child()?.navigate?.(returnScene);
  }
  async function backTo(scene){
    returnScene=scene;
    try{const result=await call('/desktop/home',null);if(result.status!==200||!result.value?.ok)throw Error('home');}
    finally{returnScene='home';}
  }
  function measureSidebar(width){
    document.documentElement.style.setProperty('--suite-sidebar',width+'px');
  }
  function measureTabs(){
    const height=document.getElementById('home-tab-slot').getBoundingClientRect().height;
    document.documentElement.style.setProperty('--suite-tabs',height+'px');
    frame.contentDocument?.documentElement?.style.setProperty('--suite-tabs',height+'px');
  }
  function present(source){
    if(source!==frame.contentWindow||!document.body.hasAttribute('data-home-starting'))return;
    measureTabs();
    document.body.classList.add('operations-enabled');
    document.body.removeAttribute('data-home-starting');
    document.dispatchEvent(new Event('ecuss-operations-ready'));
    window.EcussFavorites?.ready.then(()=>child()?.refreshFavoriteView?.());
  }
  const favorites=()=>window.EcussFavorites?.ids()||[];
  function readBoard(path,payload){
    if(path!=='/home-board/logistics'&&!/^\/home-board\/(catalog|inventory)\/(status|restore|start|chunk|confirm|commit|release|forget)$/.test(path))throw Error('Unsupported dashboard read');
    return call(path,payload);
  }
  const toolbar=document.getElementById('workspace-controls');
  const toolsDialog=document.createElement('dialog');
  toolsDialog.className='workspace-tools';toolsDialog.id='workspace-tools';
  toolsDialog.setAttribute('aria-labelledby','workspace-tools-title');
  document.body.append(toolsDialog);
  let zoom=suite.zoomPercent||100;
  const labels={
    search:['업무 또는 자료 검색','Search tools or data','Tìm công cụ hoặc dữ liệu'],
    favorites:['즐겨찾기','Favorites','Yêu thích'],tools:['프로그램 도구','Program tools','Công cụ'],
    menu:['업무 탐색','Navigation','Điều hướng'],reading:['텍스트 크기','Text size','Cỡ chữ'],
    standard:['기본','Standard','Chuẩn'],large:['크게','Large','Lớn'],close:['닫기','Close','Đóng'],
    smaller:['축소','Zoom out','Thu nhỏ'],larger:['확대','Zoom in','Phóng to'],reset:['100% 복원','Reset to 100%','Đặt lại 100%'],
    refresh:['현황판 새로고침 (F5)','Refresh dashboard (F5)','Làm mới bảng tổng quan (F5)'],
    update:['업데이트·복구','Update and recovery','Cập nhật và phục hồi'],log:['진단 기록','Diagnostics','Nhật ký'],
    storage:['저장소 인증','Storage sign-in','Đăng nhập lưu trữ']
  };
  const label=key=>local(...labels[key]);
  const icon=key=>child()?.toolbarGlyph?.(key)||'';
  function button(action,body,attrs=''){
    const name=label(action);
    return '<button type="button" data-action="'+action+'" aria-label="'+name+'" title="'+name+'" '+attrs+'>'+body+'</button>';
  }
  function displayControls(){
    return '<div class="display-group zoom-controls">'+button('smaller','−',zoom<=50?'disabled':'')+button('reset',zoom+'%')+button('larger','+',zoom>=200?'disabled':'')+'</div>'+
      '<div class="display-group size-controls" role="group" aria-label="'+label('reading')+'"><small>'+label('reading')+'</small>'+
      ['standard','large'].map(k=>button(k,label(k),'aria-pressed="'+(reading===k)+'"')).join('')+'</div>';
  }
  function syncToolbar(){
    if(!toolbar)return;
    const focus=toolbar.contains(document.activeElement)?document.activeElement.dataset.action:null;
    toolbar.innerHTML=button('menu',icon('menu'),'class="workspace-menu"')+
      button('search',icon('search')+'<span>'+label('search')+'</span><kbd>Ctrl K</kbd>','class="workspace-search" data-search-open')+
      button('favorites',icon('star'))+displayControls()+button('tools','<span>'+label('tools')+'</span>'+icon('settings-2'),'aria-haspopup="dialog"');
    if(focus)toolbar.querySelector('[data-action="'+focus+'"]')?.focus({preventScroll:true});
  }
  function showTools(){
    const active=document.querySelector('iframe[data-workspace-module]:not([hidden])')?.dataset.workspaceModule;
    const module=suite.modules.find(m=>m.id===active);
    const collapsed=['search','favorites'].filter(key=>!toolbar.querySelector('[data-action="'+key+'"]').getClientRects().length);
    toolsDialog.toggleAttribute('data-display-controls',!toolbar.querySelector('.display-group').getClientRects().length);
    const actions=[...collapsed,...(child()?.isDashboardVisible?.()?['refresh']:[]),'update',...(suite.mailEnabled?['log']:[]),...(suite.profile==='master'?['storage']:[])];
    toolsDialog.innerHTML='<div class="tools-heading"><h2 id="workspace-tools-title">'+label('tools')+'</h2>'+button('close','×')+'</div>'+
      '<div class="tools-list">'+actions.map(a=>button(a,label(a))).join('')+'</div><div class="tools-display">'+displayControls()+'</div><p class="tool-version"></p>';
    toolsDialog.querySelector('.tool-version').textContent='App '+suite.appVersion+(module&&suite.mailEnabled?' · '+module.name[language()]+' '+module.version+' · Rules '+module.rulesVersion:'');
    if(!toolsDialog.open)toolsDialog.showModal();
  }
  async function toolbarClick(event){
    const action=event.target.closest('[data-action]')?.dataset.action;
    if(!action)return;
    const reply=async(path,value)=>{const r=await call(path,value);if(r?.status!==200)throw Error('toolbar');return r.value;};
    try{
      if(action==='tools'){showTools();return;}
      if(action==='close'){toolsDialog.close();return;}
      if(action==='standard'||action==='large'){
        await savePreference('textSize',action);window.OperationsWorkspace.textSize(action);
      }else if(['smaller','larger','reset'].includes(action)){
        const result=await reply('/desktop/display-zoom',action==='reset'?0:action==='larger'?1:-1);
        zoom=result.zoom;syncToolbar();
      }else{
        if(toolsDialog.open)toolsDialog.close();
        if(action==='menu'){if(!isHome())await backTo('home');child()?.showNav?.();}
        else if(action==='search')child()?.beginSearch?.();
        else if(action==='favorites')child()?.toggleFavorites?.();
        else if(action==='refresh')await window.EcussWorkspace.refresh();
        else if(action==='update')await reply('/desktop/update',null);
        else if(action==='log')await reply('/desktop/log',null);
        else if(action==='storage')await reply('/desktop/storage-signin',null);
      }
      if(toolsDialog.open){
        showTools();toolsDialog.querySelector('[data-action="'+action+'"]')?.focus();
      }
    }catch{feedback(local('요청을 완료하지 못했습니다.','The request could not be completed.','Không thể hoàn tất yêu cầu.'));}
  }
  toolbar.addEventListener('click',toolbarClick);
  toolsDialog.addEventListener('click',toolbarClick);
  document.addEventListener('keydown',event=>{
    if(event.key==='Escape'&&!event.repeat&&!event.isComposing&&!event.defaultPrevented&&!document.querySelector('dialog[open]')&&child()?.closeFavorites?.())event.preventDefault();
  });
  async function returnFromFavorites(moduleId){
    if(moduleId&&[...document.querySelectorAll('iframe[data-workspace-module]')].some(f=>f.dataset.workspaceModule===moduleId))await open(moduleId);
    const star=toolbar.querySelector('[data-action=favorites]');
    (star?.getClientRects().length?star:toolbar.querySelector('[data-action=tools]'))?.focus({preventScroll:true});
  }

  window.OperationsWorkspace={syncToolbar,zoomChanged(percent){zoom=percent;syncToolbar();},refreshBoards(){return child()?.loadHome?.(true,true);},suite,ready,call:readBoard,settings,open,favorites,savePreference,language,isHome,status,statusChanged,refreshStatus,appearance,sessionSummary,
    prepareModule:moduleSkin,selectModule,backTo,measureSidebar,present,returnFromFavorites,
    async favorite(id){await window.EcussFavorites.ready;const ids=favorites();if(!await window.EcussFavorites.save(ids.includes(id)?ids.filter(x=>x!==id):[...ids,id]))throw Error('favorites');},
    async orderFavorites(ids){if(!await window.EcussFavorites.save(ids))throw Error('favorites');},
    setLanguage(lang){window.EcussWorkspace.language(lang);},
    textSize(size){reading=size;child()?.syncPreferences?.({textSize:size});appearance(theme,size);}
  };
  const languageRetries=new WeakMap();
  function syncModuleLanguage(moduleFrame){
    if(!moduleFrame)return;
    clearTimeout(languageRetries.get(moduleFrame));languageRetries.delete(moduleFrame);
    const target=moduleFrame.contentWindow,lang=language();
    if(!moduleFrame.isConnected||!target?.EcussLanguage||target.document.documentElement.lang===lang)return;
    // A running import, export or print can temporarily lock the module's language.
    // Re-read the workspace selection after the guard clears, without reloading the tab.
    const locked=target.EcussDesktopState?.().busy||target.document.querySelector(':is(#language,#language-select,#lang,#suite-tool-language):disabled');
    if(locked){languageRetries.set(moduleFrame,setTimeout(()=>syncModuleLanguage(moduleFrame),350));return;}
    target.EcussLanguage.setLanguage(lang);
  }
  new MutationObserver(()=>{
    child()?.changeHomeLanguage?.();
    document.querySelectorAll('iframe[data-workspace-module]').forEach(syncModuleLanguage);
  }).observe(document.documentElement,{attributes:true,attributeFilter:['lang']});
  new ResizeObserver(measureTabs).observe(document.getElementById('home-tab-slot'));
  document.addEventListener('load',event=>{
    const f=event.target;
    if(f.tagName!=='IFRAME'||!f.dataset.workspaceModule)return;
    moduleSkin(f.contentDocument,f.dataset.workspaceModule);syncModuleLanguage(f);applyRoute();
    prepareWorkGuidance(f.contentDocument,f.dataset.workspaceModule);
    f.contentDocument.addEventListener('click',e=>{if(e.isTrusted&&e.target.closest('[data-company],[data-direction],[data-period]'))cancelRoute();},true);
    if(f.dataset.workspaceModule==='psr-rvc-lvc-calculator')f.contentDocument.addEventListener('load',e=>{if(e.target.tagName==='IFRAME')moduleSkin(e.target.contentDocument,'psr-sheet');},true);
  },true);
  const startupMessage=document.getElementById('home-startup-message');
  const retry=document.getElementById('home-startup-retry');
  function showLoadError(){
    startupMessage.textContent=local('홈 화면을 열지 못했습니다.','The home screen could not be opened.','Không thể mở trang chủ.');
    retry.textContent=local('다시 시도','Retry','Thử lại');
    retry.hidden=false;
  }
  function loadFrame(){
    retry.hidden=true;
    startupMessage.textContent='TRADE OPERATIONS SUITE · '+local('화면 준비 중…','Preparing the application…','Đang chuẩn bị chương trình…');
    frame.src='operations/index.html';
  }
  retry.addEventListener('click',loadFrame);
  frame.addEventListener('error',showLoadError);
  frame.addEventListener('load',async()=>{
    try{
      const rendered=frame.contentWindow.operationsHomeRendered;
      if(!rendered)throw Error('Home renderer unavailable');
      await rendered;
      present(frame.contentWindow);
    }catch{showLoadError();}
  });
  loadFrame();
  document.getElementById('home-content').prepend(frame);
})();
