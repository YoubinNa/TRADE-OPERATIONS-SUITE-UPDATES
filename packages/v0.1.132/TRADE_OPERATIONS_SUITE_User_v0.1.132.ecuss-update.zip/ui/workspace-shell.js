/* Session-only workspace. Approved module documents remain mounted until explicitly closed. */
(()=>{
'use strict';
const suite=window.__ECUSS_SUITE__;if(!suite||!window.EcussDesktop)return;
const modules=new Map(suite.modules.map(m=>[m.id,m])),opened=new Map(),blobs=new Map();
const stage=document.getElementById('module-content'),tabs=document.getElementById('task-tabs');
const languageGroup=document.getElementById('suite-language'),homeButton=document.getElementById('home-anchor');
let active=null,pending=false,refreshing=false;
const text={
 ko:{home:'홈 화면',tabs:'열린 모듈',close:'작업 종료',busy:'진행 중인 작업이 끝난 뒤 다시 시도해 주세요.',refreshing:'조회 정보 확인 중…',refreshed:'조회 정보 확인을 마쳤습니다.',error:'요청을 완료하지 못했습니다. 다시 시도해 주세요.'},
 en:{home:'Home',tabs:'Open modules',close:'Close task',busy:'Wait for the current task to finish.',refreshing:'Checking status…',refreshed:'Status check complete.',error:'Could not complete the request. Please try again.'},
 vi:{home:'Trang chủ',tabs:'Mô-đun đang mở',close:'Đóng công việc',busy:'Chờ tác vụ hiện tại hoàn tất.',refreshing:'Đang kiểm tra trạng thái…',refreshed:'Đã kiểm tra trạng thái.',error:'Không hoàn tất yêu cầu. Vui lòng thử lại.'}
};
const copy=()=>text[document.documentElement.lang]||text.ko;
const name=id=>{const names=modules.get(id)?.name||window.EcussHome?.externalNames?.[id]||window.EcussHome?.statusNames?.[id];return names?.[document.documentElement.lang]||names?.ko||id;};
const notice=document.createElement('span');notice.className='shell-notice';notice.setAttribute('role','status');document.querySelector('.task-shell').append(notice);
function identity(win){for(const[id,v]of opened)if(v.frame.contentWindow===win)return id;throw Error('Unregistered module document');}
function pageState(id){const v=opened.get(id);if(!v)return {hasWork:false,busy:false};try{const w=v.frame.contentWindow;if(!v.loaded||typeof w.EcussDesktopState!=='function')return {hasWork:true,busy:true};return w.EcussDesktopState();}catch{return {hasWork:true,busy:true};}}
function state(id=null){if(id)return pageState(id);const all=[...opened.keys()].map(pageState);return {busy:pending||refreshing||all.some(s=>s.busy),hasWork:all.some(s=>s.hasWork)};}
async function request(path,id){notice.textContent='';try{const r=await window.EcussDesktop.call(path,id);if(r.status!==200){notice.textContent=r.value?.busy?copy().busy:r.value?.message||copy().error;return false;}return r.value?.ok!==false;}catch{notice.textContent=copy().error;return false;}}
async function select(id){if(pending)return;pending=true;try{await request(id?'/desktop/open':'/desktop/home',id);}finally{pending=false;}}
function renderTabs(){
 homeButton.setAttribute('aria-pressed',String(!active));
 tabs.replaceChildren();
 for(const id of opened.keys()){
  const item=document.createElement('div');item.className='task-tab'+(active===id?' active':'');
  const button=document.createElement('button');button.className='activate';button.textContent=button.title=name(id);
  button.setAttribute('role','tab');button.setAttribute('aria-selected',String(active===id));button.onclick=()=>select(id);
  const close=document.createElement('button');close.className='close';close.textContent='×';close.title=copy().close+' · '+name(id);
  close.setAttribute('aria-label',close.title);close.onclick=()=>request('/desktop/close-tab',id);
  item.append(button,close);tabs.append(item);
 }
 tabs.querySelector('.task-tab.active')?.scrollIntoView({block:'nearest',inline:'nearest'});
}
function activate(id,showHome=false){
 const wasModule=!!active;
 active=id;document.body.classList.toggle('module-mode',!!id);
 stage.hidden=!id;
 for(const [key,entry] of opened)entry.frame.hidden=key!==id;
 renderTabs();
 window.OperationsWorkspace?.selectModule(id,showHome||wasModule);
}
function openApproved(id){if(id&&!opened.has(id)){const m=modules.get(id);if(!m)throw Error('Unknown module');const f=document.createElement('iframe');f.dataset.workspaceModule=id;f.title=name(id);f.hidden=true;f.dataset.skinPending='';const entry={frame:f,loaded:false};opened.set(id,entry);f.addEventListener('load',()=>{entry.loaded=true;renderTabs();});f.src=m.entry.substring(3);stage.querySelector('.module-viewport').append(f);}activate(id,!id);}
function closeApproved(id){const v=opened.get(id);if(!v)return;v.frame.remove();opened.delete(id);for(const[url,owner]of blobs)if(owner===id)blobs.delete(url);activate(active===id?null:active);}
// Refresh is scoped to the screen that received the key. Never reload the workspace document.
async function refresh(){
 if(refreshing||pending)return false;
 const target=active;refreshing=true;
 try{
  if(target)return await request('/desktop/refresh-tab',target);
  notice.textContent=copy().refreshing;
  await Promise.all([window.OperationsWorkspace?.refreshBoards(),window.EcussUpdateStatus?.refresh(),window.EcussRecords?.refresh(true),window.EcussStock?.refresh(),window.EcussMailChecks?.refresh(true)]);
  notice.textContent=copy().refreshed;return true;
 }catch{notice.textContent=copy().error;return false;}
 finally{refreshing=false;}
}
function refreshApproved(id){
 const entry=opened.get(id);if(!entry)return;
 const previous=entry.frame,next=previous.cloneNode(false);
 entry.loaded=false;entry.frame=next;next.dataset.skinPending='';
 next.addEventListener('load',()=>{entry.loaded=true;renderTabs();});
 for(const[url,owner]of blobs)if(owner===id)blobs.delete(url);
 previous.replaceWith(next); // Keep the tab position, active tab, sidebar and every other frame.
 renderTabs();
}
window.EcussWorkspace={bootstrapFrom(win){const id=identity(win),m=modules.get(id);if(win.location.href!==new URL(m.entry.substring(3),location.href).href)throw Error('Unexpected module URL');return {nonce:window.__ECUSS_HOST_NONCE__,module:window.__ECUSS_MODULE_CONTEXTS__[id],suite:{...suite,lang:document.documentElement.lang}};},openApproved,closeApproved,refreshApproved,refresh,state,language(lang){if(!Object.hasOwn(text,lang))return;suite.lang=lang;if(document.documentElement.lang!==lang){const control=document.getElementById("language");control.value=lang;control.dispatchEvent(new Event("change"));}},registerBlob(win,url){blobs.set(url,identity(win));},downloadOwner:url=>blobs.get(url)||null,broadcastAccess(value){for(const v of opened.values()){try{v.frame.contentWindow.EcussApplyWorkAccess?.(value);}catch{}}},callFrom(win,path,payload){
 const id=identity(win);
 // Older module adapters acknowledge the language they inherited from the shell.
 if(path==='/desktop/language')return Promise.resolve({status:200,value:{ok:true}});
 return window.EcussDesktop.call(path,payload,id);
}};
window.EcussDesktopState=()=>state();
languageGroup.addEventListener('click',event=>{
 const button=event.target.closest('button[data-shell-lang]');
 if(button)window.EcussWorkspace.language(button.dataset.shellLang);
});
document.getElementById('home-anchor').onclick=()=>select(null);
document.getElementById('home-anchor').setAttribute('aria-keyshortcuts','Backspace Alt+ArrowLeft');
document.addEventListener('keydown',event=>{
 const backspace=event.key==='Backspace'&&!event.altKey,altLeft=event.key==='ArrowLeft'&&event.altKey;
 if(!active||(!backspace&&!altLeft)||event.ctrlKey||event.metaKey||event.shiftKey)return;
 const handled=event.defaultPrevented;if(altLeft)event.preventDefault();
 if(handled||event.isComposing||event.keyCode===229)return;
 const nodes=event.composedPath?.()||[event.target];
 if(nodes.some(el=>el?.closest?.('dialog,[role="dialog"]'))||document.querySelector('dialog[open],[role="dialog"][aria-modal="true"]:not([hidden])'))return;
 if(backspace&&nodes.some(el=>el?.isContentEditable||el?.closest?.('input,textarea,select,[contenteditable]:not([contenteditable="false"]),[role="textbox"],[role="combobox"],[role="spinbutton"]')))return;
 event.preventDefault();if(!event.repeat)select(null);
});
document.querySelectorAll('[data-review-target]').forEach(n=>n.onclick=()=>select(n.dataset.reviewTarget));
document.querySelectorAll('[data-review-status]').forEach(n=>n.onclick=async()=>{if(await request('/desktop/home',null)){if(n.dataset.reviewStatus==='validation-status')window.EcussRecords?.show();else window.EcussMailChecks?.show();}});
function labels(){
 const t=copy(),lang=document.documentElement.lang;
 homeButton.lastChild.textContent=t.home;homeButton.title=t.home;tabs.setAttribute('aria-label',t.tabs);
 languageGroup.setAttribute('aria-label',({en:'Display language',vi:'Ngôn ngữ hiển thị'})[lang]||'표시 언어');
 for(const button of languageGroup.children)button.setAttribute('aria-pressed',String(button.dataset.shellLang===lang));
 renderTabs();
}
labels();new MutationObserver(labels).observe(document.documentElement,{attributes:true,attributeFilter:['lang']});
})();

(()=>{
const groups=['dashboards','work-tools','work-categories'].map(id=>{
 const section=document.getElementById(id),head=section.querySelector('.section-head'),title=head.querySelector('h2');
 const body=document.createElement('div');body.id=id+'-body';body.className='category-body';
 [...section.children].filter(e=>e!==head).forEach(e=>body.append(e));section.append(body);
 const button=document.createElement('button');button.type='button';button.className='category-toggle';button.setAttribute('aria-controls',body.id);button.setAttribute('aria-expanded','true');
 const count=document.createElement('span');count.className='category-count';const label=document.createElement('span');label.className='category-action';
 const arrow=document.createElement('span');arrow.className='category-chevron';arrow.setAttribute('aria-hidden','true');arrow.textContent='⌃';
 title.append(count);button.append(title,label,arrow);head.prepend(button);const summary=head.querySelector('.summary');if(summary)summary.hidden=true;
 function refresh(){const lang=document.documentElement.lang,open=!body.hidden;count.textContent=body.querySelectorAll('.card').length;label.textContent=lang==='en'?(open?'Collapse':'Expand'):lang==='vi'?(open?'Thu gọn':'Mở rộng'):(open?'접기':'펼치기');button.setAttribute('aria-expanded',String(open));arrow.textContent=open?'⌃':'⌄';}
 button.onclick=()=>{body.hidden=!body.hidden;refresh();};refresh();return{section,head,button,title,count,body,refresh};
});
// Home translation updates title text and rerenders cards; restore the count after it finishes.
new MutationObserver(()=>groups.forEach(g=>{if(!g.title.contains(g.count))g.title.append(g.count);g.refresh();})).observe(document.documentElement,{attributes:true,attributeFilter:['lang']});
})();

(()=>{const panel=document.querySelector(".connection-panel"),details=document.getElementById("connection-settings");details.querySelector(".status-details").prepend(document.getElementById("github-status"));document.addEventListener("click",e=>{if(!panel.contains(e.target))details.open=false;});})();


