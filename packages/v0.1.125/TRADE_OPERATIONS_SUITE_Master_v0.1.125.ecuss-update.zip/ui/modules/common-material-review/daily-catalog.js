/* Read-only access to the company catalogue shared by dashboards. */
(function (root) {
  'use strict';

  const headers = {
    material: ['MATERIAL CODE', 'MATERIAL NAME', "Q'TY", 'U/PRICE (USD)', 'AMOUNT (USD)', 'ITEM', 'DATE', 'SUPPLIER', 'COUNTRY', 'STATUS', 'INVOICE NO.'],
    product: ['PICK UP DATE', 'CNEE', 'COUNTRY', 'PRODUCT CODE', 'NAME', 'STATUS', 'PROCESSING U/P (USD)', 'HQ U/PRICE (USD)', 'ITEM', 'INVOICE NO.'],
  };
  const codeHeader = {material: 'MATERIAL CODE', product: 'PRODUCT CODE'};
  const cellValue = value => value === null || typeof value === 'string';
  const maxSheetRows = 1048576;

  function check(ok) {
    if (!ok) throw Error('daily_catalog_invalid');
  }

  // Use first occurrence order. Different values attached to the same code remain separate.
  function groupRows(codes) {
    const groups = new Map();
    for (let row = 0; row < codes.length; row++) {
      const code = codes[row];
      if (!groups.has(code)) groups.set(code, []);
      groups.get(code).push(row);
    }
    return [...groups.values()];
  }

  function vectorValues(vector, length) {
    if (Array.isArray(vector)) {
      check(vector.length === length && vector.every(cellValue));
      return vector;
    }
    check(vector && typeof vector === 'object');
    const dictionary = vector.dictionary;
    if (dictionary !== undefined) {
      check(Array.isArray(dictionary) && dictionary.length <= length && dictionary.every(cellValue));
    }
    const valueOf = value => {
      if (dictionary === undefined) {
        check(cellValue(value));
        return value;
      }
      check(Number.isInteger(value) && value >= 0 && value < dictionary.length);
      return dictionary[value];
    };
    if (Array.isArray(vector.indices)) {
      check(dictionary && vector.indices.length === length);
      return vector.indices.map(valueOf);
    }
    const runs = vector.runs;
    check(Array.isArray(runs) && runs.length % 2 === 0);
    const values = new Array(length);
    let start = 0;
    for (let i = 0; i < runs.length; i += 2) {
      const count = runs[i];
      check(Number.isSafeInteger(count) && count > 0 && count <= length - start);
      values.fill(valueOf(runs[i + 1]), start, start + count);
      start += count;
    }
    check(start === length);
    return values;
  }

  function restoreColumn(vector, groups, length) {
    if (vector?.byCode) {
      check(Array.isArray(vector.byCode) && vector.byCode.length === groups.length && vector.byCode.every(cellValue));
      const values = new Array(length);
      groups.forEach((positions, index) => {
        for (const row of positions) values[row] = vector.byCode[index];
      });
      const exceptions = vector.exceptions ?? [];
      check(Array.isArray(exceptions) && exceptions.length % 2 === 0);
      let previous = -1;
      for (let i = 0; i < exceptions.length; i += 2) {
        const row = exceptions[i];
        check(Number.isSafeInteger(row) && row > previous && row < length && cellValue(exceptions[i + 1]));
        values[row] = exceptions[i + 1];
        previous = row;
      }
      return values;
    }
    if (vector?.grouped) {
      const grouped = vectorValues(vector.grouped, length);
      const values = new Array(length);
      let i = 0;
      for (const positions of groups) for (const row of positions) values[row] = grouped[i++];
      return values;
    }
    return vectorValues(vector, length);
  }

  function readTable(daily, name) {
    check(Object.hasOwn(headers, name));
    if (daily === undefined) return null;
    const table = daily?.[name], expected = headers[name], columns = table?.columns;
    // The first DAILY format predates invoice numbers. Its headers describe the fields available.
    check(Array.isArray(columns) && (columns.length === expected.length || columns.length === expected.length - 1) &&
      columns.every((label, i) => label === expected[i]));
    if (daily.schema === 1) {
      check(Array.isArray(table.rows) && table.rows.length <= maxSheetRows && table.rows.every(
        row => Array.isArray(row) && row.length === columns.length && row.every(cellValue)));
      return {columns: [...columns], rows: table.rows.map(row => [...row])};
    }
    const length = table.length;
    check(daily.schema === 2 && Number.isSafeInteger(length) && length >= 0 && length <= maxSheetRows &&
      Array.isArray(table.vectors) && table.vectors.length === columns.length);
    const codeIndex = columns.indexOf(codeHeader[name]);
    const codes = vectorValues(table.vectors[codeIndex], length);
    const groups = groupRows(codes);
    const rows = Array.from({length}, () => new Array(columns.length));
    for (let i = 0; i < columns.length; i++) {
      const values = i === codeIndex ? codes : restoreColumn(table.vectors[i], groups, length);
      for (let r = 0; r < length; r++) rows[r][i] = values[r];
    }
    return {columns: [...columns], rows};
  }

  // Pass rows already filtered to the same company, period and direction.
  function invoiceCounts(...tables) {
    if (!tables.length) return null;
    const all = new Set(), perItem = new Map();
    let blankRows = 0;
    for (const table of tables) {
      if (!table) return null;
      const item = table.columns.indexOf('ITEM'), invoice = table.columns.indexOf('INVOICE NO.');
      if (item < 0 || invoice < 0) return null;
      for (const row of table.rows) {
        const value = row[invoice]?.trim();
        const key = row[item];
        if (!perItem.has(key)) perItem.set(key, new Set());
        if (value) {
          perItem.get(key).add(value);
          all.add(value);
        } else {
          blankRows++;
        }
      }
    }
    return {total: all.size, byItem: [...perItem].map(([item, set]) => ({item, count: set.size})), blankRows};
  }

  async function open(bytes, key, info, Zip = root.JSZip) {
    const company = {amo: 'AMO', agv: 'AMOGREEN', AMO: 'AMO', AMOGREEN: 'AMOGREEN'}[key];
    check(company && info?.sourceKind === 'balance' && info.company === company);
    const zip = await Zip.loadAsync(bytes);
    const file = zip.file('catalog.json');
    check(file && Object.keys(zip.files).length === 1 && file._data.uncompressedSize <= 16000000);
    const payload = await file.async('uint8array');
    check(payload.byteLength <= 16000000);
    const source = JSON.parse(new TextDecoder('utf-8', {fatal: true}).decode(payload));
    check(source?.schema === 1 && source.company === company);
    return source;
  }

  // Existing views clone their display data. Keep the lazy reader out of those copies.
  function attach(view, daily) {
    Object.defineProperty(view, 'readDaily', {value: name => readTable(daily, name)});
    return view;
  }

  async function parse(bytes, key, info) {
    const source = await open(bytes, key, info);
    return attach(root.BalanceCatalog.expand(source, info), source.daily);
  }

  root.DailyCatalog = {headers, codeHeader, groupRows, readTable, invoiceCounts, open, attach, parse};
})(globalThis);
