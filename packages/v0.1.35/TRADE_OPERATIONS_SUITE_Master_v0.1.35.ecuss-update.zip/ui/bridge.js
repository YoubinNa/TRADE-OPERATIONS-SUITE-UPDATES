/* Host API v1. Local WebView2 messages only; no network fallback. */
(() => {
  'use strict';
  if (window !== window.top || !window.chrome?.webview || !window.__ECUSS_HOST_NONCE__) return;
  const pending = new Map();
  window.chrome.webview.addEventListener('message', event => {
    const message = event.data;
    if (message?.kind === 'work-access') { applyAccess(message.value); return; }
    if (!message || message.kind !== 'rpc-reply') return;
    const entry = pending.get(message.id);
    if (!entry) return;
    pending.delete(message.id);
    clearTimeout(entry.timer);
    entry.resolve(message);
  });
  function call(path, payload = null) {
    const id = Array.from(crypto.getRandomValues(new Uint8Array(16)), x => x.toString(16).padStart(2, '0')).join('');
    return new Promise((resolve, reject) => {
      // A native dialog may wait for user input; do not retry the operation.
      const timer = path.startsWith('/translation/') || ['/api/send','/api/prepare','/desktop/home','/updates/settings','/updates/download'].includes(path) ? null : setTimeout(() => {
        pending.delete(id); reject(new Error('The desktop connection did not respond.'));
      }, 60000);
      pending.set(id, { resolve, reject, timer });
      try { window.chrome.webview.postMessage({ kind: 'rpc', id, nonce: window.__ECUSS_HOST_NONCE__, path, payload: JSON.stringify(payload) }); }
      catch (error) { clearTimeout(timer); pending.delete(id); reject(error); }
    });
  }
  let access = window.__ECUSS_SUITE__?.access || {workBlocked:false,gateReason:'unverifiedAllowed'}, authorizing = false, accessError = false;
  const accessCopy = {
    ko:{title:'필수 업데이트 · 업무 실행 제한',detail:'최신 승인 버전을 적용해야 업무를 계속할 수 있습니다. 현재 결과는 HTML·Excel로 저장한 뒤 메인화면에서 업데이트하세요.',checking:'최신 버전 확인 중…',failure:'실행 허용 여부를 확인하지 못했습니다. 다시 시도해 주세요.',offline:'오프라인 · 설치된 지침으로 작업합니다. 연결되면 최신 버전을 다시 확인합니다.'},
    en:{title:'Required update · Work paused',detail:'Install the latest approved version to continue working. Save existing HTML/Excel results, then return to the main screen to update.',checking:'Checking the latest version…',failure:'Could not verify permission to start work. Please try again.',offline:'Offline · Using installed rules. Versions will be checked again when connected.'},
    vi:{title:'Bắt buộc cập nhật · Tạm dừng công việc',detail:'Cài bản mới nhất đã được duyệt để tiếp tục. Lưu kết quả HTML/Excel hiện có rồi về màn hình chính để cập nhật.',checking:'Đang kiểm tra phiên bản mới nhất…',failure:'Không xác nhận được quyền bắt đầu công việc. Vui lòng thử lại.',offline:'Ngoại tuyến · Dùng quy tắc đã cài. Kiểm tra lại phiên bản khi có mạng.'}
  };
  function renderAccess(){
    const banner=document.getElementById('ecuss-work-access');if(!banner)return;
    const t=accessCopy[document.documentElement.lang]||accessCopy.ko;
    const blocked=!!access.workBlocked;
    banner.hidden=!blocked&&!authorizing&&!accessError&&access.network!=='offline';
    banner.dataset.blocked=String(blocked);
    banner.textContent=authorizing?t.checking:accessError?t.failure:blocked?t.title+' — '+t.detail:t.offline;
    document.body.dataset.ecussWorkBlocked=String(blocked||authorizing);
    for(const el of document.querySelectorAll('#analyze,#run,#mail-preview-open')){
      if(blocked||authorizing)el.setAttribute('aria-disabled','true');else el.removeAttribute('aria-disabled');
    }
  }
  function applyAccess(next){
    if(!next || typeof next.workBlocked!=='boolean')return;
    access=next;renderAccess();window.EcussUpdateStatus?.accept(next);
  }
  async function authorizeWork(){
    if(authorizing)return false;authorizing=true;accessError=false;renderAccess();
    try{
      const r=await call('/desktop/authorize');
      if(r.status!==200||typeof r.value?.allowed!=='boolean')throw new Error('gate');
      applyAccess(r.value.access);return r.value.allowed===true;
    }catch{
      accessError=true;const banner=document.getElementById('ecuss-work-access');
      if(banner){banner.hidden=false;banner.textContent=(accessCopy[document.documentElement.lang]||accessCopy.ko).failure;}
      return false;
    }finally{authorizing=false;renderAccess();}
  }
  window.EcussDesktop = { call, authorizeWork };
  /* MASTER_TRANSPORT_BEGIN */
  const allowed = new Set(['/api/bootstrap', '/api/prepare', '/api/send']);
  window.fetch = async (input, init = {}) => {
    const url = new URL(typeof input === 'string' ? input : input.url, location.href);
    if (url.origin !== location.origin || (!allowed.has(url.pathname) && !/^\/download\/[0-9a-f]{32}\/(html|excel)$/.test(url.pathname)))
      throw new Error('This application does not make external requests.');
    const response = await call(url.pathname, init.body ? JSON.parse(init.body) : null);
    if (response.value?.binary) {
      const bytes = Uint8Array.from(atob(response.value.binary), c => c.charCodeAt(0));
      return new Response(bytes, { status: response.status, headers: { 'Content-Type': response.value.type } });
    }
    return new Response(JSON.stringify(response.value), { status: response.status, headers: { 'Content-Type': 'application/json' } });
  };
  /* MASTER_TRANSPORT_END */
  window.EcussDesktopState = () => ({
    busy: authorizing || !!window.EcussModuleState?.busy?.() || !!window.EcussMailBusy || !!document.querySelector('#analyze[data-desktop-running="true"]') ||
      (!!window.EcussModuleState?.hasResult() && !!document.querySelector('#download:disabled,#save-html:disabled')),
    hasWork: !!window.EcussModuleState?.hasWork?.() || !!window.EcussModuleState?.hasResult?.() || !!document.querySelector('.upload-card.ready') ||
      [...document.querySelectorAll('input[type="file"]')].some(x => x.files.length > 0)
  });
  let homeButton, homeNotice, homePending = false;
  const homeText = {
    ko: {home:'메인화면으로',busy:'진행 중인 작업이 끝난 뒤 다시 눌러 주세요.',error:'메인화면으로 돌아가지 못했습니다. 다시 시도하거나 상단의 업무 모듈을 이용하세요.'},
    en: {home:'Back to main screen',busy:'Wait for the current task to finish.',error:'Could not return to the main screen. Try again or use Work modules above.'},
    vi: {home:'Về màn hình chính',busy:'Chờ tác vụ hiện tại hoàn tất.',error:'Không thể về màn hình chính. Thử lại hoặc chọn Mô-đun công việc ở phía trên.'}
  };
  function homeCopy() { return homeText[document.documentElement.lang] || homeText.ko; }
  function installModuleNavigation() {
    if (!window.__ECUSS_DESKTOP_CONTEXT__?.moduleId || document.getElementById('ecuss-module-navigation')) return;
    const style=document.createElement('style');style.setAttribute('data-ecuss-desktop','');
    style.textContent='#ecuss-module-navigation{background:#123751;color:#fff;font-family:Segoe UI,Malgun Gothic,sans-serif}#ecuss-module-navigation .ecuss-nav-inner{max-width:1480px;margin:0 auto;padding:14px 28px;display:flex;align-items:center;gap:18px;flex-wrap:wrap}#ecuss-home-button{display:inline-flex;align-items:center;gap:9px;border:1px solid #91c4d2;border-radius:8px;background:#fff;color:#16475e;padding:10px 16px;font:600 14px Segoe UI,Malgun Gothic,sans-serif;cursor:pointer}#ecuss-home-button:hover{background:#e9f4f8}#ecuss-home-button:disabled{opacity:.65;cursor:wait}#ecuss-home-button:focus-visible{outline:3px solid #88e0ef;outline-offset:3px}#ecuss-home-notice{font-size:13px;color:#fff3d9;line-height:1.6}';
    document.head.append(style);
    const policyStyle=document.createElement('style');policyStyle.setAttribute('data-ecuss-desktop','');
    policyStyle.textContent='#ecuss-work-access{margin:0;padding:16px 28px;background:#fff4dc;color:#724d12;font:14px/1.65 Segoe UI,Malgun Gothic,sans-serif;border-bottom:1px solid #e8c987}#ecuss-work-access[data-blocked="true"]{background:#fff0ec;color:#9c3829;border-color:#e5b9af}body[data-ecuss-work-blocked="true"] #analyze,body[data-ecuss-work-blocked="true"] #mail-preview-open,body[data-ecuss-work-blocked="true"] .upload-card{opacity:.55;cursor:not-allowed}';
    document.head.append(policyStyle);
    const notice=document.createElement('section');notice.id='ecuss-work-access';notice.setAttribute('data-ecuss-desktop','');notice.setAttribute('role','alert');notice.hidden=true;document.body.prepend(notice);
    for(const name of ['click','drop','keydown']) document.addEventListener(name,event=>{
      if((access.workBlocked||authorizing)&&event.target.closest?.('#analyze,.upload-card,#mail-preview-open,#ecuss-mail-dialog,'+(window.EcussModuleUI?.workControls||'#run'))){
        if(name==='keydown'&&!['Enter',' '].includes(event.key))return;
        event.preventDefault();event.stopImmediatePropagation();renderAccess();
      }
    },true);
    const nav=document.createElement('nav');nav.id='ecuss-module-navigation';nav.setAttribute('data-ecuss-desktop','');
    const inner=document.createElement('div');inner.className='ecuss-nav-inner';
    homeButton=document.createElement('button');homeButton.type='button';homeButton.id='ecuss-home-button';
    const arrow=document.createElement('span');arrow.textContent='←';arrow.setAttribute('aria-hidden','true');
    const label=document.createElement('span');label.textContent=homeCopy().home;homeButton.append(arrow,label);
    homeNotice=document.createElement('span');homeNotice.id='ecuss-home-notice';homeNotice.setAttribute('role','status');homeNotice.setAttribute('aria-live','polite');
    inner.append(homeButton,homeNotice);nav.append(inner);
    const header=document.querySelector('body > header');if(header)header.before(nav);else document.body.prepend(nav);
    homeButton.addEventListener('click',async()=>{
      if(homePending)return;
      homeNotice.textContent='';
      if(window.EcussDesktopState().busy){homeNotice.textContent=homeCopy().busy;return;}
      homePending=true;homeButton.disabled=true;
      try{const response=await call('/desktop/home');if(response.status!==200)throw new Error(response.value?.message||homeCopy().error);}
      catch(error){homeNotice.textContent=homeCopy().error;}
      finally{homePending=false;homeButton.disabled=false;}
    });
  }
  // Bind each same-origin document: keyboard events inside PSR frames do not bubble to the host page.
  const homeDocuments=new WeakSet();
  function bindHomeShortcut(doc){
    if(homeDocuments.has(doc))return;homeDocuments.add(doc);
    doc.addEventListener('keydown',event=>{
      const backspace=event.key==='Backspace'&&!event.altKey;
      const altLeft=event.key==='ArrowLeft'&&event.altKey;
      if((!backspace&&!altLeft)||event.ctrlKey||event.metaKey||event.shiftKey)return;
      if(!homeButton)return;
      // Consume browser Back even while guarded, so history cannot bypass the work confirmation.
      const handled=event.defaultPrevented;
      if(altLeft)event.preventDefault();
      if(handled||event.isComposing||event.keyCode===229)return;
      const nodes=event.composedPath?.()||[event.target];
      if(nodes.some(el=>el?.closest?.('dialog,[role="dialog"]')))return;
      if(doc.querySelector('dialog[open], [role="dialog"][aria-modal="true"]:not([hidden])'))return;
      if(backspace&&nodes.some(el=>el?.isContentEditable||el?.closest?.('input,textarea,select,[contenteditable]:not([contenteditable="false"]),[role="textbox"],[role="combobox"],[role="spinbutton"]')))return;
      event.preventDefault();
      if(!event.repeat&&!homePending)homeButton.click();
    });
    for(const frame of doc.querySelectorAll('iframe')){
      const bind=()=>{try{if(frame.contentDocument)bindHomeShortcut(frame.contentDocument);}catch{}};
      frame.addEventListener('load',bind);bind();
    }
  }
  function language() {
    const lang = document.documentElement.lang;
    renderAccess();
    if(homeButton){homeButton.lastElementChild.textContent=homeCopy().home;homeNotice.textContent='';}
    if (['ko', 'en', 'vi'].includes(lang)) call('/desktop/language', lang).catch(() => {});
  }
  window.addEventListener('load', () => {
    installModuleNavigation();
    if(homeButton){homeButton.setAttribute("aria-keyshortcuts","Backspace Alt+ArrowLeft");bindHomeShortcut(document);}
    language();
    new MutationObserver(language).observe(document.documentElement, { attributes: true, attributeFilter: ['lang'] });
    call('/desktop/ready').catch(() => {});
    if(window.__ECUSS_DESKTOP_CONTEXT__?.moduleId)call('/updates/check',false).then(r=>{if(r.status===200)applyAccess(r.value);}).catch(()=>{});
  }, { once: true });
})();


/* Shared presentation adapter. Existing module controls and business events are retained. */
(() => {
  'use strict';
  window.addEventListener('load', () => {
    if (!window.EcussDesktop || window.__VALIDATION_VIEWER__) return;
    const id=window.__ECUSS_DESKTOP_CONTEXT__?.moduleId;
    const module=window.__ECUSS_SUITE__?.modules?.find(m=>m.id===id);
    const nav=document.getElementById('ecuss-module-navigation');
    if(!module||!nav)return;
    let header=document.querySelector('body>header');
    if(!header&&id==='vn-kr-customs-translation'){
      const heading=document.querySelector('main>.heading');
      if(heading){header=document.createElement('header');heading.before(header);header.append(heading);nav.after(header);}
    }
    if(!header)return;
    document.body.classList.add('ecuss-module-ui');document.body.dataset.suiteCategory=module.category;
    header.id='ecuss-page-header';
    if(id==='stock-status-amovina'){
      const top=header.querySelector('.topbar'),left=top?.firstElementChild,date=header.querySelector('.datebox'),rate=header.querySelector('.ratebox:not(.datebox)');
      if(top&&left&&date&&rate){const options=document.createElement('div');options.className='top-options';options.append(date,rate);header.append(left,options);top.remove();}
    }else if(id==='stock-status-amogreen-vina'){
      const title=header.querySelector('.header-title');if(title)header.prepend(title);
    }
    const style=document.createElement('style');style.setAttribute('data-ecuss-desktop','');style.textContent="/* Desktop presentation only. Never included in shared result documents. */\nbody.ecuss-module-ui{--suite-accent:#0866d9;--suite-tint:#edf4ff;background:#f5f6fa;font-family:'Segoe UI Variable','Segoe UI','Malgun Gothic',sans-serif}\nbody.ecuss-module-ui[data-suite-category=translation]{--suite-accent:#7650a2;--suite-tint:#f5effc}\nbody.ecuss-module-ui[data-suite-category=inventory]{--suite-accent:#a65720;--suite-tint:#fff4e9}\nbody.ecuss-module-ui #ecuss-module-navigation{position:sticky;top:0;z-index:101;background:#f9fafded;color:#425c7b;backdrop-filter:blur(20px);border-bottom:1px solid #e1e6ef}\nbody.ecuss-module-ui #ecuss-module-navigation .ecuss-nav-inner{max-width:1488px;padding:8px 24px;gap:12px;flex-wrap:nowrap}\nbody.ecuss-module-ui #ecuss-home-button{font-size:13px;padding:7px 12px;flex-shrink:0}\n#ecuss-category-label{color:#65768d;font-size:12px;font-weight:600;white-space:nowrap}\nbody.ecuss-module-ui #ecuss-page-header{position:sticky!important;top:var(--suite-nav-height,52px)!important;z-index:100;display:block!important;visibility:visible!important;background:#ffffffed;backdrop-filter:blur(20px);color:#202b3b;padding:22px max(24px,calc((100vw - 1440px)/2));margin:0;border-radius:0;border-bottom:1px solid #dfe5ef;box-shadow:0 5px 12px #19354e16;max-height:55vh;overflow:auto}\nbody.ecuss-module-ui #ecuss-page-header h1{font:650 25px/1.35 'Segoe UI Variable','Segoe UI','Malgun Gothic',sans-serif;letter-spacing:-.4px;margin:0 0 6px;overflow-wrap:anywhere;color:#202b3b}\nbody.ecuss-module-ui #ecuss-page-header p{font-size:13px;line-height:1.5;color:#65768d;margin:0}\nbody.ecuss-module-ui #ecuss-page-header .top-inner,body.ecuss-module-ui #ecuss-page-header .heading{max-width:1440px;margin:0 auto;display:flex;gap:18px;align-items:center;justify-content:space-between}\nbody.ecuss-module-ui #ecuss-page-header .language-picker,body.ecuss-module-ui #ecuss-page-header .lang{margin:0;align-self:center;color:#65768d;flex-shrink:0}\nbody.ecuss-module-ui #ecuss-page-header select{background:#fff;color:#234056;max-width:100%;border-radius:8px;padding:7px 10px}\nbody.ecuss-module-ui #ecuss-page-header .eyebrow,body.ecuss-module-ui #ecuss-page-header .brand{font-size:10px;letter-spacing:1px;margin:0 0 5px;color:#6d7e94}\nbody.ecuss-module-ui #ecuss-page-header .version,body.ecuss-module-ui #ecuss-page-header .pilot{font-size:11px;color:#65768d;margin-top:4px}\nbody.ecuss-module-ui #ecuss-page-header .header-title{display:flex;align-items:center;justify-content:space-between;gap:14px}\nbody.ecuss-module-ui #ecuss-page-header .top-options{display:flex;gap:16px;flex-wrap:wrap;margin:10px 0 0;justify-content:flex-start;align-items:flex-start}\nbody.ecuss-module-ui #ecuss-page-header .top-options .field,body.ecuss-module-ui #ecuss-page-header .ratebox{min-width:0;max-width:100%;color:#405878;background:#eef2f8;padding:8px 12px;border-radius:8px;margin:0;flex:0 1 auto}\nbody.ecuss-module-ui #ecuss-page-header .top-options small,body.ecuss-module-ui #ecuss-page-header .ratebox small{font-size:10px;color:#65768d}\nbody.ecuss-module-ui #ecuss-page-header input{max-width:100%;font-size:13px;padding:5px 8px}\nbody.ecuss-module-ui main,body.ecuss-module-ui .container{max-width:1488px;margin:0 auto;padding:24px 24px 48px}\nbody.ecuss-module-ui .panel,body.ecuss-module-ui .card,body.ecuss-module-ui .upload-card{border-radius:18px;border-color:#e0e6ee;box-shadow:0 5px 20px #24364b05}\nbody.ecuss-module-ui .upload-card,body.ecuss-module-ui .dropzone,body.ecuss-module-ui [data-card],body.ecuss-module-ui .file-box{border-color:#c9d7e2;transition:background-color .12s,border-color .12s}\nbody.ecuss-module-ui .upload-card.ready,body.ecuss-module-ui .dropzone.selected,body.ecuss-module-ui .dropzone.has-file,body.ecuss-module-ui #dropzone[data-selected=true],body.ecuss-module-ui [data-card].selected,body.ecuss-module-ui .file-box[data-selected=true]{border:2px solid var(--suite-accent);background:var(--suite-tint)}\nbody.ecuss-module-ui .file-box.dragover,body.ecuss-module-ui .upload-card.dragover,body.ecuss-module-ui .upload-card.drag,body.ecuss-module-ui .dropzone.dragover,body.ecuss-module-ui .dropzone.drag-over,body.ecuss-module-ui [data-card].dragover{outline:3px solid var(--suite-accent);outline-offset:2px;background:var(--suite-tint)}\nbody.ecuss-module-ui .result-actions{top:var(--suite-header-bottom,150px);z-index:30}\nbody.ecuss-module-ui :is(#results,#result){scroll-margin-top:calc(var(--suite-header-bottom,150px) + 16px)}\n@media(max-width:700px){body.ecuss-module-ui #ecuss-module-navigation .ecuss-nav-inner{padding:8px 16px}#ecuss-home-notice{max-width:45vw;font-size:11px!important}body.ecuss-module-ui #ecuss-page-header{padding:12px 16px}body.ecuss-module-ui #ecuss-page-header h1{font-size:19px}body.ecuss-module-ui #ecuss-page-header .top-inner,body.ecuss-module-ui #ecuss-page-header .heading{flex-direction:row;flex-wrap:wrap;gap:8px}body.ecuss-module-ui #ecuss-page-header .top-options{gap:8px}body.ecuss-module-ui #ecuss-page-header .header-title{flex-wrap:wrap}body.ecuss-module-ui main,body.ecuss-module-ui .container{padding:18px 16px 36px}}\n@media print{body.ecuss-module-ui #ecuss-module-navigation{display:none}body.ecuss-module-ui #ecuss-page-header{position:static!important;max-height:none;overflow:visible}}\n\nbody.ecuss-module-ui #ecuss-page-header:has(>#lang){display:flex!important;justify-content:space-between;align-items:center;gap:16px;flex-wrap:wrap}\n\nbody.ecuss-module-ui #ecuss-page-header select.lang{color:#234056}\n\nbody.ecuss-module-ui #ecuss-home-button{color:#315374;background:#fff;border:1px solid #dce3ed;border-radius:10px}\nbody.ecuss-module-ui button,body.ecuss-module-ui select{border-radius:10px}body.ecuss-module-ui button{font-family:inherit}body.ecuss-module-ui :is(button,input,select):focus-visible{outline:3px solid #2278e6;outline-offset:3px}\nbody.ecuss-module-ui #ecuss-page-header input{background:#fff;color:#293b54;border:1px solid #dce3ed;border-radius:7px}body.ecuss-module-ui .result-actions{background:#ffffffed;backdrop-filter:blur(16px);border-color:#e0e6ee}\n/* A single vertical scroller leaves the mail sheet header and actions visible. */\nbody.ecuss-module-ui #ecuss-mail-dialog{overflow:hidden;border-radius:22px;border:1px solid #ffffffa0;color:#26354b;background:#f4f6fa;box-shadow:0 25px 90px #172b4650}body.ecuss-module-ui #ecuss-mail-dialog[open]{display:flex;flex-direction:column}body.ecuss-module-ui #ecuss-mail-dialog::backdrop{background:#1c2d4666;backdrop-filter:blur(6px)}body.ecuss-module-ui #ecuss-mail-dialog .em-head,body.ecuss-module-ui #ecuss-mail-dialog .em-foot{position:static;flex:0 0 auto;padding:17px 24px;background:#ffffffef;border-color:#e1e6ef}body.ecuss-module-ui #ecuss-mail-dialog h2{font-size:21px;letter-spacing:-.5px}body.ecuss-module-ui #ecuss-mail-dialog .em-content{flex:1 1 auto;min-height:0;overflow:auto;padding:20px 24px;scrollbar-gutter:stable}body.ecuss-module-ui #ecuss-mail-dialog .em-card{border:1px solid #e0e6ee;border-radius:15px;padding:20px}body.ecuss-module-ui #ecuss-mail-dialog .em-choice{background:#f6f8fb;border:1px solid #e1e6ef;border-radius:9px;color:#566880}body.ecuss-module-ui #ecuss-mail-dialog .em-choice:has(input:checked){color:#285583;border-color:#b9d0ef;background:#eef5ff}body.ecuss-module-ui #ecuss-mail-dialog input[type=checkbox]{accent-color:#0866d9}body.ecuss-module-ui #ecuss-mail-dialog select,body.ecuss-module-ui #ecuss-mail-dialog .em-quiet{border-color:#dce3ed;border-radius:9px;background:#f8fafc;color:#3b577a}body.ecuss-module-ui #ecuss-mail-dialog #em-subject{display:block;width:100%;min-width:0;font:600 14px/1.6 'Segoe UI','Malgun Gothic',sans-serif;padding:11px 13px;border:1px solid #b8c9df;border-radius:10px;color:#233b5b;background:#fff}body.ecuss-module-ui #ecuss-mail-dialog #em-subject:disabled{color:#7d8796;background:#f3f5f8}body.ecuss-module-ui #ecuss-mail-dialog #em-send{background:#0866d9;border-radius:11px;padding:12px 25px}body.ecuss-module-ui #ecuss-mail-dialog #em-send:disabled{background:#9caabe;color:#fff}body.ecuss-module-ui #ecuss-mail-dialog #em-viewport{max-height:none;min-height:0;overflow-x:auto;overflow-y:hidden}body.ecuss-module-ui #ecuss-mail-dialog #em-count{font-size:13px}body.ecuss-module-ui #ecuss-mail-dialog .em-note{font-size:11px;line-height:1.7;color:#687c94}body.ecuss-module-ui #ecuss-mail-dialog .em-preview-title{flex-wrap:wrap;font-size:13px}body.ecuss-module-ui #ecuss-mail-dialog .em-file{border-radius:8px;background:#f0f5fc;border-color:#dbe5f2}\n@media(max-width:700px){body.ecuss-module-ui #ecuss-category-label{font-size:10px;white-space:normal}body.ecuss-module-ui #ecuss-mail-dialog .em-head,body.ecuss-module-ui #ecuss-mail-dialog .em-content,body.ecuss-module-ui #ecuss-mail-dialog .em-foot{padding:12px 14px}body.ecuss-module-ui #ecuss-mail-dialog .em-card{padding:14px}body.ecuss-module-ui #ecuss-mail-dialog .em-foot .em-note{margin:4px 0}body.ecuss-module-ui #ecuss-mail-dialog .em-head .em-note{display:none}}\n@media(prefers-reduced-motion:reduce){body.ecuss-module-ui *{transition:none!important;scroll-behavior:auto!important}}\n\nbody.ecuss-module-ui #ecuss-home-notice{color:#975527}\n\nbody.ecuss-module-ui #ecuss-page-header .version{background:#eef2f8;color:#61738d;border-radius:20px;padding:6px 12px}\n\n/* Glass Workspace: shared navigation materials; document content keeps an opaque reading surface. */\nbody.ecuss-module-ui{--suite-accent:#4260da;--suite-tint:#eff3ff;background:radial-gradient(ellipse at 0 0,#e9edfc 0,transparent 48%),#f4f6fb;color:#253148}\nbody.ecuss-module-ui #ecuss-module-navigation{background:#eef2fbdc;border-bottom-color:#e0e6f2;backdrop-filter:blur(24px)}\nbody.ecuss-module-ui #ecuss-page-header{background:#f9faffea;box-shadow:0 6px 20px #34436808;border-bottom-color:#e0e6f2;backdrop-filter:blur(24px)}\nbody.ecuss-module-ui #ecuss-home-button{border-color:#d8e2f4;background:#ffffffc9;color:#4c649b;border-radius:12px}\nbody.ecuss-module-ui .panel,body.ecuss-module-ui .card,body.ecuss-module-ui .upload-card{border-radius:20px;border-color:#e0e6f1;box-shadow:0 8px 26px #34436806}\nbody.ecuss-module-ui #ecuss-page-header .top-options .field,body.ecuss-module-ui #ecuss-page-header .ratebox{background:#eaf0fa9c;border:1px solid #dfe7f5;border-radius:11px}\nbody.ecuss-module-ui #ecuss-mail-dialog{background:#f3f5fb;border-color:#e1e7f2;box-shadow:0 30px 100px #26344e45}\nbody.ecuss-module-ui #ecuss-mail-dialog .em-head,body.ecuss-module-ui #ecuss-mail-dialog .em-foot{background:#f6f8ffed;backdrop-filter:blur(22px)}\nbody.ecuss-module-ui #ecuss-mail-dialog #em-send{background:#4260da}\nbody.ecuss-module-ui dialog::backdrop{background:#26344e66;backdrop-filter:blur(7px)}\n@media(forced-colors:active){body.ecuss-module-ui,body.ecuss-module-ui #ecuss-page-header,body.ecuss-module-ui #ecuss-module-navigation,body.ecuss-module-ui #ecuss-mail-dialog,body.ecuss-module-ui #ecuss-mail-dialog .em-head,body.ecuss-module-ui #ecuss-mail-dialog .em-foot{background:Canvas;color:CanvasText;backdrop-filter:none}body.ecuss-module-ui #ecuss-page-header h1,body.ecuss-module-ui #ecuss-page-header p{color:CanvasText}body.ecuss-module-ui #ecuss-home-button{border:1px solid ButtonText;color:ButtonText;background:ButtonFace}}\n\nbody.ecuss-module-ui #report-dialog{border:1px solid #e1e7f2;border-radius:22px;background:#f3f5fb;box-shadow:0 30px 100px #26344e45;overflow:hidden}body.ecuss-module-ui #report-dialog .report-toolbar{background:#f6f8ffed;border-bottom:1px solid #dfe5f1;color:#354868;gap:14px}body.ecuss-module-ui #report-dialog #close-report{border:1px solid #d8e2f4;border-radius:10px;background:white;color:#4c649b;padding:8px 13px}\n";document.head.append(style);
    const category=document.createElement('span');category.id='ecuss-category-label';nav.querySelector('.ecuss-nav-inner').append(category);
    const categories={ko:{validation:'Balance Sheet 검증',translation:'문서 번역',inventory:'재고 취합',tools:'업무 도구'},en:{validation:'Balance Sheet validation',translation:'Document translation',inventory:'Stock consolidation',tools:'Work tools'},vi:{validation:'Kiểm tra Balance Sheet',translation:'Dịch tài liệu',inventory:'Tổng hợp tồn kho',tools:'Công cụ công việc'}};
    function labels(){const lang=document.documentElement.lang||'ko',name=module.name[lang]||module.name.ko;const h=header.querySelector('h1');if(h&&h.textContent!==name)h.textContent=name;document.title=name;category.textContent=(categories[lang]||categories.ko)[module.category]||'';}
    function measure(){const n=nav.getBoundingClientRect().height,h=header.getBoundingClientRect().height;document.body.style.setProperty('--suite-nav-height',n+'px');document.body.style.setProperty('--suite-header-bottom',(n+h)+'px');}
    if(id==='balance-sheet-validation'){const filename=document.getElementById('filename'),zone=document.getElementById('dropzone');const selected=()=>{zone.dataset.selected=String(!!window.EcussModuleState?.hasWork?.());};selected();new MutationObserver(selected).observe(filename,{childList:true,subtree:true,characterData:true});}
    labels();measure();new ResizeObserver(measure).observe(header);new ResizeObserver(measure).observe(nav);
    new MutationObserver(labels).observe(document.documentElement,{attributes:true,attributeFilter:['lang']});
    // Modules can render their own title again when language or result state changes.
    new MutationObserver(labels).observe(header.querySelector('h1'),{childList:true,subtree:true,characterData:true});
  },{once:true});
})();
