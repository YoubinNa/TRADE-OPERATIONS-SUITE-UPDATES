/* Suite home only. Four latest metadata slots; no business results or localStorage. */
(()=>{
'use strict';
if(!window.EcussDesktop||window.__ECUSS_DESKTOP_CONTEXT__?.moduleId)return;
const companies={AMO:'AMOVINA',AMOGREEN:'AMOGREEN VINA'},kinds=['weekly','monthly'];
const texts={
ko:{weekly:'주간',monthly:'월간',yes:'완료',no:'미완료',unknown:'확인 불가',pending:'동기화 대기',title:'확인 요청 메일 발송 현황',time:'최근 수행',none:'수행 기록 없음',zone:'한국 시각 (KST)',close:'닫기',note:'Outlook 발송 요청 접수 기준',html:'첨부된 공유용 HTML 열기',missing:'보관된 첨부 HTML 없음',opening:'여는 중…',opened:'공유용 HTML을 열었습니다.',error:'파일을 열 수 없습니다. 새로고침 후 다시 확인하세요.',retry:'새로고침'},
en:{weekly:'Weekly',monthly:'Monthly',yes:'Done',no:'Not done',unknown:'Unknown',pending:'Sync pending',title:'Review request mail status',time:'Last performed',none:'No request recorded',zone:'Korea time (KST)',close:'Close',note:'Request accepted by Outlook',html:'Open attached shared HTML',missing:'No stored HTML attachment',opening:'Opening…',opened:'Shared HTML opened.',error:'Unable to open. Refresh and try again.',retry:'Refresh'},
vi:{weekly:'Tuần',monthly:'Tháng',yes:'Xong',no:'Chưa',unknown:'Chưa rõ',pending:'Chờ đồng bộ',title:'Trạng thái gửi thư yêu cầu xác nhận',time:'Thực hiện gần nhất',none:'Chưa có yêu cầu',zone:'Giờ Hàn Quốc (KST)',close:'Đóng',note:'Outlook đã nhận yêu cầu gửi thư',html:'Mở HTML chia sẻ đính kèm',missing:'Chưa lưu tệp HTML',opening:'Đang mở…',opened:'Đã mở HTML chia sẻ.',error:'Không mở được. Làm mới và thử lại.',retry:'Làm mới'}};
const lang=()=>texts[document.documentElement.lang]||texts.ko;
let snapshot=null,fetching=null,forcedRefresh=null,initialized=false;
const element=(tag,cls,text)=>{const n=document.createElement(tag);if(cls)n.className=cls;if(text!=null)n.textContent=text;return n;};
const koreaTime=new Intl.DateTimeFormat('en-GB',{timeZone:'Asia/Seoul',year:'numeric',month:'2-digit',day:'2-digit',hour:'2-digit',minute:'2-digit',second:'2-digit',hourCycle:'h23'});
const time=v=>{
 if(!v)return lang().none;
 const d=new Date(v);if(!Number.isFinite(+d))return lang().none;
 const p=Object.fromEntries(koreaTime.formatToParts(d).map(x=>[x.type,x.value]));
 return p.year+'/'+p.month+'/'+p.day+' '+p.hour+':'+p.minute+':'+p.second;
};
const get=(c,k)=>snapshot?.rows?.find(r=>r.company===c&&r.reportKind===k);
function label(r){const t=lang();if(!snapshot||snapshot.connection!=='connected')return snapshot?.connection==='pending'?t.pending:t.unknown;return r?.completed===true?t.yes:r?.completed===false?t.no:t.unknown;}
function state(r){return snapshot?.connection==='pending'?'pending':snapshot?.connection==='connected'&&typeof r?.completed==='boolean'?(r.completed?'complete':'incomplete'):'unknown';}
function dot(){const d=element('span','suite-mail-check-dot');d.setAttribute('aria-hidden','true');return d;}
const openings=new Set();
function details(){
document.querySelector('.suite-mail-check-detail')?.remove();
const t=lang(),d=element('dialog','suite-mail-check-detail'),heading=element('h2','',t.title);heading.id='suite-mail-check-title';d.setAttribute('aria-labelledby',heading.id);d.append(heading);
for(const c of Object.keys(companies)){
 const section=element('section','suite-mail-check-detail-company');section.dataset.company=c;
 section.append(element('h3','suite-mail-check-company '+c,companies[c]));
 for(const k of kinds){
  const r=get(c,k),row=element('div','suite-mail-check-detail-row'),status=element('span','suite-mail-check-status');row.dataset.kind=k;status.dataset.state=state(r);status.append(dot(),document.createTextNode(label(r)));
  row.append(element('strong','',t[k]),status,element('p','',t.time+': '+time(r?.performedAt)));
  const open=element('button','suite-mail-report-open',t.html),feedback=element('p','suite-mail-report-feedback');open.type='button';feedback.setAttribute('role','status');
  const key=c+':'+k;open.disabled=!r?.report||openings.has(key);open.setAttribute('aria-label',companies[c]+' · '+t[k]+' · '+t.html);
  if(!r?.report)feedback.textContent=t.missing;
  open.onclick=async()=>{if(openings.has(key))return;openings.add(key);open.disabled=true;feedback.textContent=lang().opening;
   try{const result=await EcussDesktop.call('/mail-check/open',{company:c,reportKind:k,performedAt:r.performedAt});if(result.status!==200)throw Error('open');feedback.textContent=lang().opened;}
   catch{feedback.textContent=lang().error;}finally{openings.delete(key);open.disabled=false;}
  };row.append(open,feedback);section.append(row);
 }

 d.append(section);
}
d.append(element('p','',t.zone+' · '+t.note));const close=element('button','',t.close);close.type='button';close.onclick=()=>d.close();d.append(close);const retry=element('button','suite-mail-check-retry',t.retry);retry.type='button';retry.onclick=async()=>{retry.disabled=true;await refresh(true);if(d.open)details();};d.append(retry);d.addEventListener('close',()=>d.remove(),{once:true});document.body.append(d);d.showModal();
}
function render(){
const card=document.querySelector('[data-status-card="mail-check-status"]');if(!card)return;
let panel=card.querySelector('.suite-mail-check');
if(!panel){card.style.containerType='inline-size';panel=element('div','suite-mail-check');panel.setAttribute('role','group');card.querySelector('[data-status-body]').append(panel);}
panel.setAttribute('aria-label',lang().title);panel.replaceChildren();panel.append(element('span','suite-mail-check-corner',''));for(const k of kinds)panel.append(element('span','suite-mail-check-heading',lang()[k]));
for(const c of Object.keys(companies)){panel.append(element('span','suite-mail-check-company '+c,companies[c]));for(const k of kinds){const r=get(c,k),text=label(r),b=element('span','suite-mail-check-state');const indicator=element('span','suite-mail-check-indicator');indicator.append(dot(),document.createTextNode(snapshot?.connection==='connected'?text:snapshot?.connection==='pending'?'↻':'?'));b.append(element('span','suite-mail-check-prefix',lang()[k]+' '),indicator);b.dataset.state=state(r);b.setAttribute('aria-label',companies[c]+' · '+lang()[k]+' · '+text+' · '+time(r?.performedAt));b.title=lang().time+': '+time(r?.performedAt)+' · '+lang().zone;panel.append(b);}}
}
async function refresh(force=false){if(fetching){if(!force)return fetching;if(!forcedRefresh)forcedRefresh=fetching.then(()=>{forcedRefresh=null;return refresh(true);});return forcedRefresh;}fetching=(async()=>{try{const r=await EcussDesktop.call('/mail-check/status',force===true);if(r.status!==200||!Array.isArray(r.value?.rows))throw Error('unavailable');snapshot=r.value;}catch{snapshot={connection:'unavailable',rows:snapshot?.rows||[]};}finally{render();fetching=null;}})();return fetching;}
const style=element('style');style.textContent=`
.suite-mail-check{display:grid;grid-template-columns:minmax(0,1fr) max-content max-content;gap:3px 5px;width:100%;font-size:11px;line-height:16px;align-items:center;color:#52667d}
.suite-mail-check-heading{text-align:center;font-weight:600}.suite-mail-check-prefix{display:none}@container (min-width:285px){.suite-mail-check-heading,.suite-mail-check-corner{display:none}.suite-mail-check-prefix{display:inline}}
.suite-mail-check-company{font-weight:650;overflow-wrap:normal;word-break:normal;line-height:16px}.suite-mail-check-company.AMO{color:#b52d40}.suite-mail-check-company.AMOGREEN{color:#187347}
.suite-mail-check-state{display:inline-flex;align-items:center;justify-content:center;gap:4px;font:inherit;line-height:16px;padding:1px 2px;border:0;border-radius:4px;background:transparent;white-space:nowrap;color:#64748b;min-width:0;cursor:pointer}.suite-mail-check-dot{display:inline-block;width:7px;height:7px;border-radius:50%;background:currentColor;flex-shrink:0}.suite-mail-check-state[data-state=complete],.suite-mail-check-status[data-state=complete]{color:#08783d}.suite-mail-check-state[data-state=incomplete],.suite-mail-check-status[data-state=incomplete]{color:#bd2525}.suite-mail-check-state[data-state=pending],.suite-mail-check-status[data-state=pending]{color:#a35c00}.suite-mail-check-state:hover{background:#edf2ff}.suite-mail-check-state:focus-visible{outline:2px solid #527cbd;outline-offset:1px}

.suite-mail-check-detail{width:min(900px,92vw);max-width:900px;max-height:88vh;overflow:auto;border:1px solid #c4d3dd;border-radius:12px;padding:24px;color:#26374e;background:#fff}.suite-mail-check-detail::backdrop{background:#12375188}.suite-mail-check-detail h2{font-size:20px;margin:0 0 12px}.suite-mail-check-detail p{font-size:13px;overflow-wrap:anywhere}.suite-mail-check-detail button{font:inherit;border:1px solid #dce5fa;border-radius:9px;background:#f0f4ff;color:#4361a0;padding:8px 12px}
.suite-mail-check-detail-company{border-top:1px solid #dde5eb;margin-top:15px;padding-top:12px}.suite-mail-check-detail-company h3{font-size:16px;margin:0 0 8px}.suite-mail-check-detail-row{display:grid;grid-template-columns:1fr auto;align-items:center;gap:4px 20px;padding:7px 0;font-size:13px}.suite-mail-check-detail-row p{grid-column:1/-1;margin:0;color:#52667d;font-variant-numeric:tabular-nums}.suite-mail-check-status{display:inline-flex;align-items:center;gap:5px;color:#64748b}
.suite-mail-report-open{justify-self:start;grid-column:1/-1;cursor:pointer}.suite-mail-check-detail button:disabled{opacity:.5;cursor:default}.suite-mail-check-detail button+button{margin-left:8px}.suite-mail-check-detail-row{padding:12px 0}.suite-mail-report-feedback:empty{display:none}
@media(forced-colors:active){.suite-mail-check-state,.suite-mail-check-company{color:CanvasText!important}.suite-mail-check-state{border:1px solid ButtonText}.suite-mail-check-detail{background:Canvas;color:CanvasText}}
`;document.head.append(style);
function init(){if(initialized)return;initialized=true;const modules=document.getElementById('dashboard-grid');if(modules)new MutationObserver(()=>{if(!document.querySelector('.suite-mail-check'))render();}).observe(modules,{childList:true,subtree:true});new MutationObserver(render).observe(document.documentElement,{attributes:true,attributeFilter:['lang']});render();refresh();setInterval(refresh,60000);window.addEventListener('focus',()=>refresh(true));}
window.EcussMailChecks={refresh,show:details};if(document.readyState==='complete')init();else window.addEventListener('load',init,{once:true});
})();



