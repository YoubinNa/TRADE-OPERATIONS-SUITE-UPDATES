/* Host API v1. Local WebView2 messages only; no network fallback. */
(() => {
  'use strict';
  const framed=window!==window.top;
  if(framed&&!window.__ECUSS_HOST_NONCE__){
    try{
      const context=window.top.EcussWorkspace.bootstrapFrom(window);
      window.__ECUSS_HOST_NONCE__=context.nonce;
      window.__ECUSS_DESKTOP_CONTEXT__=context.module;
      window.__ECUSS_SUITE__=context.suite;
    }catch{return;}
  }
  if (!window.__ECUSS_HOST_NONCE__) return;
  if(!framed&&!window.chrome?.webview)return;
  const pending = new Map();
  if(!framed)window.chrome.webview.addEventListener('message', event => {
    const message = event.data;
    if (message?.kind === 'work-access') { applyAccess(message.value);window.EcussWorkspace?.broadcastAccess(message.value); return; }
    if (!message || message.kind !== 'rpc-reply') return;
    const entry = pending.get(message.id);
    if (!entry) return;
    pending.delete(message.id);
    clearTimeout(entry.timer);
    entry.resolve(message);
  });
  let activeCalls=0;
  function call(path, payload = null, moduleId = null) {
    if(framed){
      // Lifecycle requests inspect the page state themselves; do not count the
      // request being inspected as an in-flight business operation.
      const track=!['/desktop/home','/desktop/update','/desktop/close-tab','/desktop/refresh-tab','/desktop/ready','/desktop/language','/desktop/drag-hover'].includes(path);
      if(track)activeCalls++;
      try{return Promise.resolve(window.top.EcussWorkspace.callFrom(window,path,payload)).finally(()=>{if(track)activeCalls--;});}
      catch(error){if(track)activeCalls--;throw error;}
    }
    const id = Array.from(crypto.getRandomValues(new Uint8Array(16)), x => x.toString(16).padStart(2, '0')).join('');
    return new Promise((resolve, reject) => {
      // Native record reads may outlast the UI timer while waiting for sync/network
      // or opening the isolated WebView. Keep the original request until its reply;
      // never retry it or report a false failure while the host is still working.
      const timer = path.startsWith('/stock/') || path.startsWith('/translation/') || path.startsWith('/mail-check/') || ['/records/status','/records/open','/records/html','/api/send','/api/prepare','/desktop/home','/desktop/close-tab','/desktop/refresh-tab','/updates/settings','/updates/download'].includes(path) ? null : setTimeout(() => {
        pending.delete(id); reject(new Error('The desktop connection did not respond.'));
      }, 60000);
      pending.set(id, { resolve, reject, timer });
      try { window.chrome.webview.postMessage({ kind: 'rpc', id, nonce: window.__ECUSS_HOST_NONCE__, moduleId, path, payload: JSON.stringify(payload) }); }
      catch (error) { clearTimeout(timer); pending.delete(id); reject(error); }
    });
  }
  let access = window.__ECUSS_SUITE__?.access || {workBlocked:false,gateReason:'unverifiedAllowed'}, authorizing = false, accessError = false;
  const accessCopy = {
    ko:{title:'필수 업데이트 · 업무 실행 제한',detail:'최신 승인 버전을 적용해야 업무를 계속할 수 있습니다. 현재 결과는 HTML·Excel로 저장한 뒤 메인화면에서 업데이트하세요.',checking:'최신 버전 확인 중…',failure:'실행 허용 여부를 확인하지 못했습니다. 다시 시도해 주세요.',offline:'오프라인 · 설치된 지침으로 작업합니다. 연결되면 최신 버전을 다시 확인합니다.'},
    en:{title:'Required update · Work paused',detail:'Install the latest approved version to continue working. Save existing HTML/Excel results, then return to the main screen to update.',checking:'Checking the latest version…',failure:'Could not verify permission to start work. Please try again.',offline:'Offline · Using installed rules. Versions will be checked again when connected.'},
    vi:{title:'Bắt buộc cập nhật · Tạm dừng công việc',detail:'Cài bản mới nhất đã được duyệt để tiếp tục. Lưu kết quả HTML/Excel hiện có rồi về màn hình chính để cập nhật.',checking:'Đang kiểm tra phiên bản mới nhất…',failure:'Không xác nhận được quyền bắt đầu công việc. Vui lòng thử lại.',offline:'Ngoại tuyến · Dùng quy tắc đã cài. Kiểm tra lại phiên bản khi có mạng.'}
  };
  function renderAccess(){
    const banner=document.getElementById('ecuss-work-access');if(!banner)return;
    const t=accessCopy[document.documentElement.lang]||accessCopy.ko;
    const blocked=!!access.workBlocked;
    banner.hidden=!blocked&&!authorizing&&!accessError&&access.network!=='offline';
    banner.dataset.blocked=String(blocked);
    banner.textContent=authorizing?t.checking:accessError?t.failure:blocked?t.title+' — '+t.detail:t.offline;
    document.body.dataset.ecussWorkBlocked=String(blocked||authorizing);
    for(const el of document.querySelectorAll('#analyze,#run,#mail-preview-open')){
      if(blocked||authorizing)el.setAttribute('aria-disabled','true');else el.removeAttribute('aria-disabled');
    }
  }
  function applyAccess(next){
    if(!next || typeof next.workBlocked!=='boolean')return;
    access=next;renderAccess();window.EcussUpdateStatus?.accept(next);
  }
  async function authorizeWork(){
    if(authorizing)return false;authorizing=true;accessError=false;renderAccess();
    try{
      const r=await call('/desktop/authorize');
      if(r.status!==200||typeof r.value?.allowed!=='boolean')throw new Error('gate');
      applyAccess(r.value.access);return r.value.allowed===true;
    }catch{
      accessError=true;const banner=document.getElementById('ecuss-work-access');
      if(banner){banner.hidden=false;banner.textContent=(accessCopy[document.documentElement.lang]||accessCopy.ko).failure;}
      return false;
    }finally{authorizing=false;renderAccess();}
  }
  window.EcussDesktop = { call, authorizeWork };
  window.EcussApplyWorkAccess=applyAccess;
  window.fetch = async () => { throw new Error('External requests are disabled.'); };
  window.EcussDesktopState = () => ({
    busy: activeCalls>0 || authorizing || !!window.EcussStockSharing || !!window.EcussModuleState?.busy?.() || !!document.querySelector('#analyze[data-desktop-running="true"]') ||
      (!!window.EcussModuleState?.hasResult() && !!document.querySelector('#download:disabled,#save-html:disabled')),
    hasWork: !!window.EcussModuleState?.hasWork?.() || !!window.EcussModuleState?.hasResult?.() || !!document.querySelector('.upload-card.ready') ||
      [...document.querySelectorAll('input[type="file"]')].some(x => x.files.length > 0)
  });
  let edited=false;
  const tracked=new WeakSet();
  function track(doc){if(tracked.has(doc))return;tracked.add(doc);for(const name of ['input','change'])doc.addEventListener(name,event=>{if(!event.target.closest?.('#ecuss-language-toolbar,.ecuss-source-language'))edited=true;},true);const win=doc.defaultView;if(win&&framed){const create=win.URL.createObjectURL.bind(win.URL);win.URL.createObjectURL=value=>{const url=create(value);window.top.EcussWorkspace.registerBlob(window,url);return url;};}for(const f of doc.querySelectorAll('iframe')){const bind=()=>{try{if(f.contentDocument)track(f.contentDocument);}catch{}};f.addEventListener('load',bind);bind();}}
  const originalState=window.EcussDesktopState;
  window.EcussDesktopState=()=>{const state=originalState();return {...state,hasWork:state.hasWork||edited};};
  let homeButton, homeNotice, homePending = false;
  const homeText = {
    ko: {home:'메인화면으로',busy:'진행 중인 작업이 끝난 뒤 다시 눌러 주세요.',error:'메인화면으로 돌아가지 못했습니다. 다시 시도하거나 상단의 업무 모듈을 이용하세요.'},
    en: {home:'Back to main screen',busy:'Wait for the current task to finish.',error:'Could not return to the main screen. Try again or use Work modules above.'},
    vi: {home:'Về màn hình chính',busy:'Chờ tác vụ hiện tại hoàn tất.',error:'Không thể về màn hình chính. Thử lại hoặc chọn Mô-đun công việc ở phía trên.'}
  };
  function homeCopy() { return homeText[document.documentElement.lang] || homeText.ko; }
  function installModuleNavigation() {
    if (!window.__ECUSS_DESKTOP_CONTEXT__?.moduleId || document.getElementById('ecuss-module-navigation')) return;
    const style=document.createElement('style');style.setAttribute('data-ecuss-desktop','');
    style.textContent='#ecuss-module-navigation[hidden]{display:none!important}#ecuss-module-navigation{background:#123751;color:#fff;font-family:Segoe UI,Malgun Gothic,sans-serif}#ecuss-module-navigation .ecuss-nav-inner{max-width:1480px;margin:0 auto;padding:14px 28px;display:flex;align-items:center;gap:18px;flex-wrap:wrap}#ecuss-home-button{display:inline-flex;align-items:center;gap:9px;border:1px solid #91c4d2;border-radius:8px;background:#fff;color:#16475e;padding:10px 16px;font:600 14px Segoe UI,Malgun Gothic,sans-serif;cursor:pointer}#ecuss-home-button:hover{background:#e9f4f8}#ecuss-home-button:disabled{opacity:.65;cursor:wait}#ecuss-home-button:focus-visible{outline:3px solid #88e0ef;outline-offset:3px}#ecuss-home-notice{font-size:13px;color:#fff3d9;line-height:1.6}';
    document.head.append(style);
    const policyStyle=document.createElement('style');policyStyle.setAttribute('data-ecuss-desktop','');
    policyStyle.textContent='#ecuss-work-access{margin:0;padding:16px 28px;background:#fff4dc;color:#724d12;font:14px/1.65 Segoe UI,Malgun Gothic,sans-serif;border-bottom:1px solid #e8c987}#ecuss-work-access[data-blocked="true"]{background:#fff0ec;color:#9c3829;border-color:#e5b9af}body[data-ecuss-work-blocked="true"] #analyze,body[data-ecuss-work-blocked="true"] #mail-preview-open,body[data-ecuss-work-blocked="true"] .upload-card{opacity:.55;cursor:not-allowed}';
    document.head.append(policyStyle);
    const notice=document.createElement('section');notice.id='ecuss-work-access';notice.setAttribute('data-ecuss-desktop','');notice.setAttribute('role','alert');notice.hidden=true;document.body.prepend(notice);
    for(const name of ['click','drop','keydown']) document.addEventListener(name,event=>{
      if((access.workBlocked||authorizing)&&event.target.closest?.('#analyze,.upload-card,#mail-preview-open,#ecuss-mail-dialog,'+(window.EcussModuleUI?.workControls||'#run'))){
        if(name==='keydown'&&!['Enter',' '].includes(event.key))return;
        event.preventDefault();event.stopImmediatePropagation();renderAccess();
      }
    },true);
    const nav=document.createElement('nav');nav.id='ecuss-module-navigation';nav.setAttribute('data-ecuss-desktop','');
    const inner=document.createElement('div');inner.className='ecuss-nav-inner';
    homeButton=document.createElement('button');homeButton.type='button';homeButton.id='ecuss-home-button';
    const arrow=document.createElement('span');arrow.textContent='←';arrow.setAttribute('aria-hidden','true');
    const label=document.createElement('span');label.textContent=homeCopy().home;homeButton.append(arrow,label);
    homeNotice=document.createElement('span');homeNotice.id='ecuss-home-notice';homeNotice.setAttribute('role','status');homeNotice.setAttribute('aria-live','polite');
    inner.append(homeButton,homeNotice);nav.append(inner);if(framed)nav.hidden=true;
    const header=document.querySelector('body > header');if(header)header.before(nav);else document.body.prepend(nav);
    homeButton.addEventListener('click',async()=>{
      if(homePending)return;
      homeNotice.textContent='';
      if(!framed&&window.EcussDesktopState().busy){homeNotice.textContent=homeCopy().busy;return;}
      homePending=true;homeButton.disabled=true;
      try{const response=await call('/desktop/home');if(response.status!==200)throw new Error(response.value?.message||homeCopy().error);}
      catch(error){homeNotice.textContent=homeCopy().error;}
      finally{homePending=false;homeButton.disabled=false;}
    });
  }
  // Bind each same-origin document: keyboard events inside PSR frames do not bubble to the host page.
  const homeDocuments=new WeakSet();
  function bindHomeShortcut(doc){
    if(homeDocuments.has(doc))return;homeDocuments.add(doc);
    doc.addEventListener('keydown',event=>{
      const backspace=event.key==='Backspace'&&!event.altKey;
      const altLeft=event.key==='ArrowLeft'&&event.altKey;
      if((!backspace&&!altLeft)||event.ctrlKey||event.metaKey||event.shiftKey)return;
      if(!homeButton)return;
      // Consume browser Back even while guarded, so history cannot bypass the work confirmation.
      const handled=event.defaultPrevented;
      if(altLeft)event.preventDefault();
      if(handled||event.isComposing||event.keyCode===229)return;
      const nodes=event.composedPath?.()||[event.target];
      if(nodes.some(el=>el?.closest?.('dialog,[role="dialog"]')))return;
      if(doc.querySelector('dialog[open], [role="dialog"][aria-modal="true"]:not([hidden])'))return;
      if(backspace&&nodes.some(el=>el?.isContentEditable||el?.closest?.('input,textarea,select,[contenteditable]:not([contenteditable="false"]),[role="textbox"],[role="combobox"],[role="spinbutton"]')))return;
      event.preventDefault();
      if(!event.repeat&&!homePending)homeButton.click();
    });
    for(const frame of doc.querySelectorAll('iframe')){
      const bind=()=>{try{if(frame.contentDocument)bindHomeShortcut(frame.contentDocument);}catch{}};
      frame.addEventListener('load',bind);bind();
    }
  }
  // Inherit the visible home selection before reporting this module's language.
  // Native bootstrap can precede a later home selection while the frame is loading.
  function inheritLanguage() {
    if (!window.__ECUSS_DESKTOP_CONTEXT__?.moduleId) return;
    const suite=window.__ECUSS_SUITE__,id=window.__ECUSS_DESKTOP_CONTEXT__.moduleId;
    let desired=suite?.lang;
    if(framed){try{desired=window.top.document.documentElement.lang;}catch{}}
    if(!['ko','en','vi'].includes(desired))desired='ko';
    if(suite)suite.lang=desired;
    window.EcussLanguage.setLanguage(desired,{initial:true});
  }

  function language() {
    const lang = document.documentElement.lang;
    renderAccess();
    if(homeButton){homeButton.lastElementChild.textContent=homeCopy().home;homeNotice.textContent='';}
    if (['ko', 'en', 'vi'].includes(lang)) call('/desktop/language', lang).catch(() => {});
  }
  window.addEventListener('load', () => {
    inheritLanguage();
    // Initial language inheritance is setup, not an unsaved user edit.
    track(document);
    installModuleNavigation();
    if(homeButton){homeButton.setAttribute("aria-keyshortcuts","Backspace Alt+ArrowLeft");bindHomeShortcut(document);}
    language();
    new MutationObserver(language).observe(document.documentElement, { attributes: true, attributeFilter: ['lang'] });
    call('/desktop/ready').catch(() => {});
    if(window.__ECUSS_DESKTOP_CONTEXT__?.moduleId)call('/updates/check',false).then(r=>{if(r.status===200)applyAccess(r.value);}).catch(()=>{});
  }, { once: true });
})();




/* Suite-only drag presentation. Original module drop handlers own file validation/import. */
(() => {
  'use strict';
  if (!window.EcussDesktop || window.__VALIDATION_VIEWER__ || window.EcussDragUpload) return;
  const selector = '.upload-card,.dropzone,.drop-zone,.drop[data-file],#dropzone,#original-dropzone,#targetDrop,#sourceDrop,#crossDrop,#excelPanel,[data-drop]';
  const documents = new WeakSet(), frames = new WeakSet();
  const copy = {ko:'여기에 파일을 놓으세요',en:'Drop files here',vi:'Thả tệp vào đây'};
  let zone = null, badge = null, currentDoc = null, lastOver = 0, lastSent = 0, engaged = false;
  function send(phase) { try { window.EcussDesktop.call('/desktop/drag-hover',{phase}).catch(() => {}); } catch {} }
  function clearHighlight() { if(zone)zone.classList.remove('ecuss-drop-active');zone=null;if(badge)badge.remove();badge=null; }
  function reset() { clearHighlight();currentDoc=null;lastOver=lastSent=0;if(engaged)send('end');engaged=false; }
  function available(doc) {
    if (window.EcussDesktopState?.().busy || document.body?.dataset.ecussWorkBlocked==='true') return false;
    try {
      for(let w=doc.defaultView;w&&w!==w.top;w=w.parent)if(!w.frameElement?.getClientRects().length)return false;
      return !doc.hidden && !doc.querySelector('dialog[open],[role="dialog"][aria-modal="true"]:not([hidden])');
    } catch { return false; }
  }
  function highlight(next,doc) {
    if(next===zone)return;
    clearHighlight();if(!next)return;zone=next;zone.classList.add('ecuss-drop-active');
    badge=doc.createElement('div');badge.className='ecuss-drop-hint';badge.dataset.ecussDesktop='';badge.setAttribute('role','status');
    badge.textContent=copy[document.documentElement.lang]||copy.ko;doc.body.append(badge);
    const r=zone.getBoundingClientRect();badge.style.left=Math.max(8,Math.min(r.left+8,doc.documentElement.clientWidth-badge.offsetWidth-8))+'px';badge.style.top=Math.max(8,Math.min(r.top+8,doc.documentElement.clientHeight-badge.offsetHeight-8))+'px';
  }
  function uploadTarget(e) {
    const next=e.target.closest?.(selector),inputs=next?[...next.querySelectorAll('input[type=file]')]:[];
    return next&&!next.closest('[inert],[aria-disabled="true"]')&&(!inputs.length||inputs.some(x=>!x.disabled))?next:null;
  }
  function drop(e,doc) {
    if(e.isTrusted&&e.dataTransfer?.files?.length&&available(doc)&&uploadTarget(e))send('drop');
    reset();
  }
  function over(e,doc) {
    if(!e.isTrusted||!Array.from(e.dataTransfer?.types||[]).includes('Files'))return;
    if(!available(doc)){reset();return;}
    highlight(uploadTarget(e),doc);currentDoc=doc;lastOver=Date.now();
    // Observe only. Do not preventDefault, replace FileLists, focus inputs or run imports.
    if(!engaged||lastOver-lastSent>=100){engaged=true;lastSent=lastOver;send('over');}
  }
  function bind(doc) {
    if(!doc?.body||documents.has(doc))return;documents.add(doc);
    const style=doc.createElement('style');style.dataset.ecussDesktop='';style.textContent='.ecuss-drop-active{outline:3px solid #4260da!important;outline-offset:2px;background-color:#eaf0ff!important;box-shadow:0 0 0 5px #4260da22!important}.ecuss-drop-hint{position:fixed;z-index:2147483647;pointer-events:none;padding:7px 12px;border-radius:8px;background:#2446a8;color:white;font:600 13px/1.4 "Segoe UI","Malgun Gothic",sans-serif;box-shadow:0 3px 12px #0002}';doc.head.append(style);
    for(const name of ['dragenter','dragover'])doc.addEventListener(name,e=>over(e,doc),true);
    doc.addEventListener('dragleave',e=>{if(e.isTrusted&&currentDoc===doc&&!e.relatedTarget){const seen=lastOver;setTimeout(()=>{if(lastOver===seen&&currentDoc===doc)reset();},0);}},true);
    doc.addEventListener('drop',e=>drop(e,doc),true);
    doc.addEventListener('dragend',reset,true);
    doc.addEventListener('keydown',e=>{if(e.key==='Escape')reset();},true);
    doc.addEventListener('visibilitychange',()=>{if(doc.hidden)reset();});doc.defaultView.addEventListener('pagehide',reset);
    function scan(){for(const frame of doc.querySelectorAll('iframe')){if(frame.hasAttribute('data-workspace-module')||frames.has(frame))continue;frames.add(frame);const apply=()=>{try{bind(frame.contentDocument);}catch{}};frame.addEventListener('load',apply);apply();}}
    scan();new MutationObserver(scan).observe(doc.body,{childList:true,subtree:true});
  }
  // The top workspace installs its own adapter; module adapters cover their PSR srcdoc children.
  window.EcussDragUpload={reset};
  if(document.readyState==='complete')bind(document);else window.addEventListener('load',()=>bind(document),{once:true});
  setInterval(()=>{if(engaged&&(Date.now()-lastOver>900||!currentDoc||!available(currentDoc)))reset();},100);
})();

/* Integration UI only: company IDs and the approved validation engine stay unchanged. */
(() => {
  'use strict';
  if (!window.EcussDesktop) return;
  const companies={AMO:'AMOVINA',AMOGREEN:'AMOGREEN VINA'};
  const copy={
    ko:{title:'검증 수행 현황',unknown:'확인 불가',notConfigured:'연결 미설정',checking:'확인 중',pending:'동기화 대기',connected:'동기화 완료',unavailable:'연결 확인 필요',unread:'기록을 불러오지 못했습니다',retry:'다시 확인',authentication:'연결 인증 갱신 필요',authHelp:'기록 저장소의 연결 인증을 갱신해야 합니다. Master에게 알려 주세요.',cached:'마지막 저장 결과입니다. 최신 상태는 연결 복구 후 확인할 수 있습니다.',cachedDownload:'마지막 저장 HTML 다운로드',NA:'수행 대상 아님',none:'완료 기록 없음',view:'최신 기록·결과',html:'공유용 HTML 열기',download:'최신 검증 결과 HTML 다운로드',close:'닫기',started:'시작',completed:'완료',incomplete:'미완료',profile:'실행 구분',state:'최근 실행 상태',running:'진행 중',failed:'실패',interrupted:'중단',done:'완료',error:'기록을 저장·조회하지 못했습니다. 검증 결과는 그대로 사용할 수 있습니다.',zone:'베트남 시각 · 월~토 · 회사별 매일 1회',saving:'검증 결과 동기화 중'},
    en:{title:'Validation status',unknown:'Unavailable',notConfigured:'Not connected',checking:'Checking',pending:'Sync pending',connected:'Synced',unavailable:'Check connection',unread:'Could not load the record',retry:'Check again',authentication:'Connection renewal required',authHelp:'The records connection needs renewed credentials. Contact the Master.',cached:'Last saved result. Reconnect to verify the latest status.',cachedDownload:'Download last saved HTML',NA:'Not required',none:'No completed record',view:'Latest record / result',html:'Open shared HTML',download:'Download latest validation HTML',close:'Close',started:'Started',completed:'Completed',incomplete:'Incomplete',profile:'Profile',state:'Latest attempt',running:'Running',failed:'Failed',interrupted:'Interrupted',done:'Completed',error:'Could not save/read the record. Your validation result remains available.',zone:'Vietnam time · Mon–Sat · Once daily per company',saving:'Synchronizing validation result'},
    vi:{title:'Trạng thái kiểm tra',unknown:'Không xác định',notConfigured:'Chưa kết nối',checking:'Đang kiểm tra',pending:'Chờ đồng bộ',connected:'Đã đồng bộ',unavailable:'Cần kiểm tra kết nối',unread:'Không tải được bản ghi',retry:'Kiểm tra lại',authentication:'Cần gia hạn xác thực',authHelp:'Cần cập nhật xác thực kết nối bản ghi. Vui lòng báo Master.',cached:'Kết quả đã lưu gần nhất. Kết nối lại để xác nhận trạng thái mới nhất.',cachedDownload:'Tải HTML đã lưu gần nhất',NA:'Không yêu cầu',none:'Chưa có lần hoàn tất',view:'Bản ghi / kết quả mới nhất',html:'Mở HTML chia sẻ',download:'Tải HTML kết quả kiểm tra mới nhất',close:'Đóng',started:'Bắt đầu',completed:'Hoàn tất',incomplete:'Chưa hoàn tất',profile:'Vai trò',state:'Lần chạy mới nhất',running:'Đang chạy',failed:'Thất bại',interrupted:'Gián đoạn',done:'Hoàn tất',error:'Không lưu/đọc được bản ghi. Kết quả kiểm tra vẫn sử dụng được.',zone:'Giờ Việt Nam · Thứ 2–7 · Mỗi công ty một lần/ngày',saving:'Đang đồng bộ kết quả'}
  };
  Object.assign(copy.ko,{beginError:'검증 시작 기록을 저장하지 못했습니다. 검증은 계속 사용할 수 있습니다.',saveError:'검증 완료 기록을 저장하지 못했습니다. 현재 검증 결과는 그대로 사용할 수 있습니다.',buildError:'공유용 HTML을 준비하지 못했습니다. 현재 검증 결과는 그대로 사용할 수 있습니다.',openError:'공유용 HTML을 열지 못했습니다. 잠시 후 다시 시도해 주세요.',downloadError:'검증 결과 HTML을 가져오지 못했습니다. 잠시 후 다시 시도해 주세요.',opening:'공유용 HTML을 여는 중입니다…',downloading:'검증 결과 HTML을 가져오는 중입니다…',opened:'공유용 HTML을 열었습니다.'});
  Object.assign(copy.en,{beginError:'Could not save the start record. Validation can continue.',saveError:'Could not save the completion record. Your current validation result remains available.',buildError:'Could not prepare shared HTML. Your current validation result remains available.',openError:'Could not open shared HTML. Please try again.',downloadError:'Could not retrieve validation HTML. Please try again.',opening:'Opening shared HTML…',downloading:'Retrieving validation HTML…',opened:'Shared HTML opened.'});
  Object.assign(copy.vi,{beginError:'Không lưu được bản ghi bắt đầu. Vẫn có thể tiếp tục kiểm tra.',saveError:'Không lưu được bản ghi hoàn tất. Kết quả kiểm tra hiện tại vẫn sử dụng được.',buildError:'Không chuẩn bị được HTML chia sẻ. Kết quả hiện tại vẫn sử dụng được.',openError:'Không mở được HTML chia sẻ. Vui lòng thử lại.',downloadError:'Không lấy được HTML kết quả. Vui lòng thử lại.',opening:'Đang mở HTML chia sẻ…',downloading:'Đang lấy HTML kết quả…',opened:'Đã mở HTML chia sẻ.'});
  const t=()=>copy[document.documentElement.lang]||copy.ko;
  const el=(tag,text,cls)=>{const x=document.createElement(tag);if(text)x.textContent=text;if(cls)x.className=cls;return x;};
  function time(value,short=false){if(!value)return '—';const d=new Date(value);if(Number.isNaN(d.getTime()))return '—';return new Intl.DateTimeFormat('en-GB',{timeZone:'Asia/Ho_Chi_Minh',...(short?{hour:'2-digit',minute:'2-digit'}:{dateStyle:'short',timeStyle:'medium'}),hour12:false}).format(d);}
  const inModule=()=>window.__ECUSS_DESKTOP_CONTEXT__?.moduleId==='balance-sheet-validation';
  let rows=[],fetching=false,notice,activeCompany,catalogWarning=false;
  const opening=new Map();
  function message(text){if(!notice){notice=el('p','','ecuss-record-notice');notice.dataset.ecussDesktop='';notice.setAttribute('role','status');(document.getElementById('dropzone')||document.body).append(notice);}notice.textContent=text+(catalogWarning?" · "+({ko:"기본정보·출하 요약을 갱신하지 못했습니다. 기존 자료를 유지합니다.",en:"Catalogue/shipment summary not updated; previous data retained.",vi:"Chưa cập nhật dữ liệu cơ bản/xuất hàng; giữ dữ liệu trước."}[document.documentElement.lang]||"Catalogue not updated."):"");}
  async function rpc(path,payload){const r=await EcussDesktop.call(path,payload);if(r.status!==200)throw new Error('records');return r.value;}
  window.EcussRecords={refresh,show,
    async begin(company){activeCompany=company;try{const r=await rpc('/records/begin',company);message(t().running+' · '+companies[company]);return {runId:r.runId,company};}catch{message(t().beginError);return null;}},
    async complete(run,build,catalogFactory){if(!run)return;let html;try{html=await build();}catch{await this.fail(run);message(t().buildError);return;}try{message(t().saving);let catalog=null;catalogWarning=false;try{catalog=catalogFactory?await catalogFactory():null;}catch{catalogWarning=true;}const saved=await rpc('/records/finish',{...run,state:'completed',html,catalog});catalogWarning=catalogWarning||saved.catalogState==='invalid';message(t().pending);refresh();}catch{message(t().saveError);}},
    async fail(run){if(!run)return;try{await rpc('/records/finish',{...run,state:'failed'});message(t().failed+' · '+t().pending);refresh();}catch{message(t().saveError);}}
  };
  const style=el('style');style.dataset.ecussDesktop='';style.textContent=`
.ecuss-record-footer{grid-column:2;width:100%;box-sizing:border-box;align-self:stretch;justify-self:stretch;display:flex;align-items:center;justify-content:space-between;gap:12px;flex-wrap:wrap;min-width:0}.ecuss-record-footer>.open{flex-shrink:0;margin:0}.ecuss-records{display:flex;flex-direction:column;gap:8px;margin-left:auto;max-width:100%;font-size:11px}.ecuss-record-row{display:flex;align-items:center;gap:14px;justify-content:space-between;min-width:0}.ecuss-record-summary{display:flex;align-items:center;gap:7px;white-space:nowrap}.ecuss-record-company{font-weight:650}.ecuss-record-row[data-company=AMO] .ecuss-record-company{color:#b52d40}.ecuss-record-row[data-company=AMOGREEN] .ecuss-record-company{color:#187347}.ecuss-record-status{display:inline-flex;align-items:center;gap:5px;font-weight:650;color:#64748b}.ecuss-record-dot{width:7px;height:7px;border-radius:50%;background:currentColor;flex-shrink:0}.ecuss-record-row[data-mark=O] .ecuss-record-status{color:#08783d}.ecuss-record-row[data-mark=X] .ecuss-record-status{color:#bd2525}.ecuss-record-row[data-connection=unavailable] .ecuss-record-status{color:#a35c00}.ecuss-record-time{font-variant-numeric:tabular-nums;color:#52667d}.ecuss-record-sync{font-size:10px;color:#735e26}.ecuss-records>button.ecuss-record-row{box-sizing:border-box;max-width:100%;min-height:36px;border:1px solid #aebbd0;background:#fff;padding:8px 11px;text-align:left;color:inherit;font:inherit;cursor:pointer;border-radius:10px;transition:background .15s,border-color .15s}.ecuss-records>button.ecuss-record-row .ecuss-record-summary{white-space:normal;flex-wrap:wrap}.ecuss-records>button.ecuss-record-row:hover{background:#edf2ff;border-color:#5276cf}.ecuss-records>button.ecuss-record-row:active{background:#e1e9fc}.ecuss-records>button.ecuss-record-row:focus-visible{outline:2px solid #5276cf;outline-offset:3px}
.ecuss-records-module{margin:0 0 16px;padding:20px 24px;border:1px solid #e1e7f2;border-radius:18px;background:#fff;color:#26374e}.ecuss-records-module header{display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:10px;padding:0;margin:0 0 14px;background:none;border:0;position:static}.ecuss-records-module h2{font-size:15px;margin:0}.ecuss-records-module header p{font-size:11px;color:#64748b;margin:5px 0 0}.ecuss-records-module .ecuss-records{margin:0;font-size:13px;gap:10px}.ecuss-records-module .ecuss-record-row{padding:10px 0;border-top:1px solid #edf0f5;flex-wrap:wrap}.ecuss-record-download,.ecuss-record-details,.ecuss-record-dialog button{padding:8px 12px;border:1px solid #dce5fa;border-radius:9px;background:#f0f4ff;color:#4361a0;font-size:12px;cursor:pointer}.ecuss-record-download:disabled{opacity:.5;cursor:default}.ecuss-record-dialog{max-width:700px;width:90%;border:1px solid #c4d3dd;border-radius:12px;padding:24px}.ecuss-record-dialog::backdrop{background:#12375188}.ecuss-record-dialog section{border-top:1px solid #dde5eb;margin-top:15px;padding-top:15px}.ecuss-record-notice{font-size:12px;margin:8px 0 0;color:#52667d}@media(max-width:500px){.ecuss-record-footer{grid-column:1/-1}.ecuss-records-module{padding:16px}.ecuss-records-module .ecuss-record-summary{gap:5px;font-size:12px}}`;
  document.head.append(style);
  async function download(company,button){
    button.disabled=true;message(t().downloading);
    try{
      const result=await rpc('/records/html',company);
      if(typeof result.html!=='string'||!result.html)throw new Error('empty result');
      const url=URL.createObjectURL(new Blob([result.html],{type:'text/html;charset=utf-8'}));
      const link=el('a');link.href=url;link.download=companies[company].replaceAll(' ','_')+'_latest_validation.html';document.body.append(link);link.click();link.remove();message('');setTimeout(()=>URL.revokeObjectURL(url),60000);
    }catch{message(t().downloadError);}finally{button.disabled=false;}
  }
  function summary(r){
    const result=el('span','','ecuss-record-summary'),status=el('span','','ecuss-record-status');
    const label=r.mark==='O'?t().completed:r.mark==='X'?t().incomplete:r.mark==='NA'?t().NA:(r.errorCode==='authentication'?t().authentication:t()[r.connection]||t().unknown);
    const dot=el('span','','ecuss-record-dot');dot.setAttribute('aria-hidden','true');status.append(dot,el('span',label));
    result.append(el('span',companies[r.company],'ecuss-record-company'),status);
    if(r.mark==='O'&&r.latest)result.append(el('time',time(r.latest.completedAt,true),'ecuss-record-time'));
    if(r.connection==='pending')result.append(el('span',r.errorCode==='authentication'?t().authentication:t().pending,'ecuss-record-sync'));
    return result;
  }
  function emptyText(r){
    if(r.errorCode==='authentication')return t().authHelp;
    return r.connection==='connected'?t().none:r.connection==='checking'?t().checking:r.connection==='notConfigured'?t().notConfigured:t().unread;
  }
  function fill(panel,module){
    panel.replaceChildren();
    for(const company of Object.keys(companies)){
      const r=rows.find(x=>x.company===company)||{company,mark:'?',connection:'checking'};
      const row=el('div','','ecuss-record-row');row.dataset.mark=r.mark;row.dataset.connection=r.connection;row.dataset.company=company;
      const description=summary(r);
      row.title=companies[company]+' · '+t().zone+' · '+(r.latest?t().completed+': '+time(r.latest.completedAt):emptyText(r));
      row.append(description);
      if(module){const b=el('button',r.connection==='unavailable'?t().cachedDownload:t().download,'ecuss-record-download');b.type='button';b.dataset.company=company;b.disabled=!r.hasHtml;b.title=row.title;b.setAttribute('aria-label',companies[company]+' · '+b.textContent);b.onclick=()=>download(company,b);row.append(b);}
      else{row.setAttribute('aria-label',description.textContent);}
      if(module)panel.append(row);
      else{const line=el('div','','ecuss-record-home-row'),label=description.querySelector('.ecuss-record-company');line.dataset.company=company;line.append(label,row);panel.append(line);}
    }
  }
  function render(){
    if(inModule()){
      const drop=document.getElementById('dropzone');if(!drop)return;
      let block=document.querySelector('.ecuss-records-module');
      if(!block){block=el('section','','ecuss-records-module');block.dataset.ecussDesktop='';drop.before(block);}
      let panel=block.querySelector('.ecuss-records');
      if(!panel){const header=el('header'),heading=el('div');heading.append(el('h2'),el('p'));const b=el('button','','ecuss-record-details');b.type='button';b.onclick=show;header.append(heading,b);panel=el('div','','ecuss-records');panel.setAttribute('aria-live','polite');block.append(header,panel);}
      block.querySelector('h2').textContent=t().title;block.querySelector('header p').textContent=t().zone;block.querySelector('.ecuss-record-details').textContent=t().view;fill(panel,true);return;
    }
    const card=document.querySelector('[data-status-card="validation-status"]');if(!card)return;
    let panel=card.querySelector('.ecuss-records');
    if(!panel){panel=el('div','','ecuss-records');panel.setAttribute('aria-live','polite');card.querySelector('[data-status-body]').append(panel);}
    fill(panel,false);
  }
  function details(d){
    for(const s of d.querySelectorAll('section'))s.remove();
    const close=d.querySelector('.ecuss-record-close');
    for(const company of Object.keys(companies)){const r=rows.find(x=>x.company===company)||{company,mark:'?',connection:'checking'},s=el('section');
      const row=el('div','','ecuss-record-row');row.dataset.mark=r.mark;row.dataset.connection=r.connection;row.dataset.company=r.company;row.append(summary(r));s.append(row);
      if(r.latest)s.append(el('p',t().profile+': '+r.latest.profile),el('p',t().started+': '+time(r.latest.startedAt)),el('p',t().completed+': '+time(r.latest.completedAt)));else s.append(el('p',emptyText(r)));
      if(r.latest&&r.connection==='unavailable'){s.append(el('p',t().cached));if(r.errorCode==='authentication')s.append(el('p',t().authHelp));}
      if(r.attempt)s.append(el('p',t().state+': '+(r.attempt.state==='completed'?t().done:t()[r.attempt.state]||r.attempt.state)+' · '+time(r.attempt.completedAt||r.attempt.startedAt)));
      const state=opening.get(r.company),b=el('button',t().html);
      b.disabled=!r.hasHtml||state==='opening';
      b.onclick=async()=>{
        if(opening.get(r.company)==='opening')return;
        opening.set(r.company,'opening');details(d);
        try{await rpc('/records/open',r.company);opening.set(r.company,'opened');}
        catch{opening.set(r.company,'openError');}
        finally{const current=document.querySelector('.ecuss-record-dialog[open]');if(current)details(current);}
      };
      s.append(b);
      if(state){const feedback=el('p',t()[state],'ecuss-record-open-feedback');feedback.setAttribute('role','status');s.append(feedback);}
      d.insertBefore(s,close);
    }
  }
  function show(){
    document.querySelector('.ecuss-record-dialog')?.remove();const d=el('dialog','','ecuss-record-dialog');d.append(el('h2',t().title),el('p',t().zone));
    const close=el('button',t().close,'ecuss-record-close');close.onclick=()=>d.close();d.append(close);
    const retry=el('button',t().retry,'ecuss-record-retry');retry.onclick=async()=>{retry.disabled=true;try{await refresh(true);}finally{retry.disabled=false;}};d.append(retry);
    details(d);document.body.append(d);d.showModal();
  }
  function refresh(force=false){if(fetching)return fetching;fetching=(async()=>{try{rows=await rpc('/records/status',force===true);}catch{rows=Object.keys(companies).map(company=>({company,mark:'?',connection:'unavailable'}));}finally{fetching=false;render();const dialog=document.querySelector('.ecuss-record-dialog[open]');if(dialog)details(dialog);if(notice&&activeCompany){const r=rows.find(x=>x.company===activeCompany);if(r)message(companies[activeCompany]+' · '+(t()[r.connection]||t().unknown)+(r.catalogPending?' · '+({ko:'기본정보·출하 요약 전송 대기',en:'Catalogue sync pending',vi:'Chờ đồng bộ dữ liệu cơ bản'}[document.documentElement.lang]||'Catalogue sync pending'):''));}}})();return fetching;}
  window.addEventListener('load',()=>{
    const module=window.__ECUSS_DESKTOP_CONTEXT__?.moduleId;if(module&&!inModule())return;
    if(!module){const modules=document.getElementById('dashboard-grid');if(modules)new MutationObserver(()=>{if(!document.querySelector('.ecuss-records'))render();}).observe(modules,{childList:true,subtree:true});}
    new MutationObserver(render).observe(document.documentElement,{attributes:true,attributeFilter:['lang']});
    render();refresh();setInterval(refresh,60000);window.addEventListener('focus',refresh);
  },{once:true});
})();





/* Suite integration only: capture approved module outputs without recalculation. */
(() => {
  'use strict';
  if (!window.EcussDesktop) return;
  const companies = {AMO:'AMOVINA', AMOGREEN:'AMOGREEN VINA'};
  const modules = {AMO:'stock-status-amovina', AMOGREEN:'stock-status-amogreen-vina'};
  const company = Object.keys(modules).find(c => modules[c] === window.__ECUSS_DESKTOP_CONTEXT__?.moduleId);
  const master = window.__ECUSS_SUITE__?.profile === 'master';
  const texts = {
    ko:{localFile:'마지막 저장 파일',localGap:'마지막 저장 현황판',lastChecked:'마지막 확인',file:'최신 파일',gap:'과부족 현황판',none:'미등록',waiting:'승인 대기',unknown:'확인 불가',title:'최신 취합 파일·과부족 공유',year:'년',month:'월',version:'버전',register:'현재 최종 취합 파일 등록',preview:'과부족 요약 미리보기',approve:'승인·공유',cancel:'등록 대기 취소',retry:'등록 대기 재시도',refresh:'새로고침',select:'모듈에 최종 취합 파일을 선택하세요.',run:'동일한 파일로 과부족 현황 출력을 실행한 후 미리보기·승인하세요.',pending:'등록이 완료되지 않았습니다. 재시도해 주세요.',busy:'공유 작업 중…',done:'공유 완료',cancelled:'취소했습니다.',error:'작업을 완료하지 못했습니다. 연결·등록 파일을 확인하세요.',period:'기준 연월·버전을 확인해 주세요.',limits:'최종 파일과 과부족 Excel은 각각 50MB 이하입니다. 공유 시 같은 회사의 이전 자료를 교체·삭제합니다.',source:'등록할 원본',needsRegister:'먼저 이 최종 취합 파일을 등록하세요.'},
    en:{localFile:'Last saved file',localGap:'Last saved summary',lastChecked:'Last checked',file:'Latest file',gap:'Shortage / surplus',none:'Not registered',waiting:'Awaiting approval',unknown:'Unavailable',title:'Share final workbook and summary',year:'Year',month:'Month',version:'Version',register:'Register current final workbook',preview:'Preview summary',approve:'Approve and share',cancel:'Cancel pending registration',retry:'Retry pending registration',refresh:'Refresh',select:'Select the final workbook in the module.',run:'Run shortage / surplus for the same workbook, then preview and approve.',pending:'Registration is pending. Please retry.',busy:'Sharing…',done:'Shared',cancelled:'Cancelled.',error:'Could not complete. Check the connection and registered file.',period:'Confirm the reporting year, month and version.',limits:'Each workbook must be 50MB or smaller. Sharing replaces and deletes previous files for this company.',source:'Source to register',needsRegister:'Register this final workbook first.'},
    vi:{localFile:'Tệp đã lưu gần nhất',localGap:'Bảng đã lưu gần nhất',lastChecked:'Kiểm tra lần cuối',file:'Tệp mới nhất',gap:'Thừa / thiếu',none:'Chưa đăng ký',waiting:'Chờ duyệt',unknown:'Không xác định',title:'Chia sẻ tệp tổng hợp và bảng tóm tắt',year:'Năm',month:'Tháng',version:'Phiên bản',register:'Đăng ký tệp tổng hợp đang chọn',preview:'Xem trước bảng tóm tắt',approve:'Duyệt và chia sẻ',cancel:'Hủy đăng ký đang chờ',retry:'Thử lại đăng ký đang chờ',refresh:'Làm mới',select:'Chọn tệp tổng hợp cuối cùng trong mô-đun.',run:'Xuất thừa / thiếu từ cùng tệp, sau đó xem trước và duyệt.',pending:'Đăng ký chưa hoàn tất. Vui lòng thử lại.',busy:'Đang chia sẻ…',done:'Đã chia sẻ',cancelled:'Đã hủy.',error:'Không hoàn tất. Kiểm tra kết nối và tệp đã đăng ký.',period:'Xác nhận năm, tháng và phiên bản.',limits:'Mỗi tệp tối đa 50MB. Chia sẻ sẽ thay thế và xóa dữ liệu trước của công ty này.',source:'Tệp nguồn đăng ký',needsRegister:'Đăng ký tệp tổng hợp này trước.'}
  };
  const t=()=>texts[document.documentElement.lang]||texts.ko;
  const el=(tag,text,cls)=>{const e=document.createElement(tag);if(text!==undefined)e.textContent=text;if(cls)e.className=cls;return e;};
  let rows=[],fetching=false,working=false,source=null,result=null,preview=null,panel=null,notice=null;
  const rpc=async(path,payload)=>{const r=await EcussDesktop.call('/stock/'+path,payload);if(r.status!==200)throw new Error(r.value?.message||t().error);return r.value;};
  const current=()=>rows.find(r=>r.company===company);
  const label=i=>i?(document.documentElement.lang==='ko'?`${i.year}년 ${String(i.month).padStart(2,'0')}월 V${i.version}`:`${i.year}-${String(i.month).padStart(2,'0')} V${i.version}`):'';
  let messageKey=null;
  const message=s=>{messageKey=Object.keys(t()).find(k=>t()[k]===s)||null;if(notice)notice.textContent=s;};
  function sourceNow(){return window.EcussStockSource?.()||null;}
  function available(){return !!source&&sourceNow()===source&&window.EcussStockSourceReady?.()!==false;}
  function clearPreview(){preview=null;panel?.querySelector('.stock-preview')?.replaceChildren();controls();}
  function controls(){if(!panel)return;const availableSource=available(),pending=current()?.pending;panel.querySelector('[data-action=register]').disabled=working||!availableSource||pending;panel.querySelector('[data-action=preview]').disabled=working||!availableSource||!result||result.file!==source||pending;panel.querySelector('[data-action=approve]').disabled=working||!preview||preview.file!==source||pending;panel.querySelector('[data-action=retry]').hidden=!pending;panel.querySelector('[data-action=cancel]').hidden=!pending;panel.querySelectorAll('[data-action=retry],[data-action=cancel],[data-action=refresh]').forEach(b=>b.disabled=working);panel.querySelectorAll('input').forEach(x=>x.disabled=working);}
  function suggest(file,period){
    const date=period?.year&&period?.month?[period.year,period.month]:null;
    const m=(file?.name||'').match(/(20\d{2})\s*(?:[-_.\/]|년)\s*(0?[1-9]|1[0-2])(?:\D|$)/);
    const v=(file?.name||'').match(/(?:^|[^a-z0-9])V\s*(\d+)(?:\D|$)/i);
    if(!panel)return;
    for(const [key,value] of [['year',date?.[0]||m?.[1]||''],['month',date?.[1]||m?.[2]||''],['version',v?.[1]||'']]){const input=panel.querySelector('[name='+key+']');if(!input.value&&value)input.value=value;}
  }
  async function action(fn){if(working)return;working=true;window.EcussStockSharing=true;controls();message(t().busy);try{await fn();}catch(e){message(e.message||t().error);}finally{await refresh(true);working=false;window.EcussStockSharing=false;controls();}}
  async function digest(bytes){return Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',bytes)),b=>b.toString(16).padStart(2,'0')).join('');}
  async function upload(bytes,name,kind){
    if(!bytes.byteLength||bytes.byteLength>50000000)throw new Error(t().limits);
    const hash=await digest(bytes),start=await rpc('upload/start',{company,name,kind,size:bytes.byteLength,hash});const data=new Uint8Array(bytes);
    for(let offset=0;offset<data.length;offset+=1024*1024){const chunk=data.subarray(offset,offset+1024*1024);let raw='';for(let i=0;i<chunk.length;i+=32768)raw+=String.fromCharCode(...chunk.subarray(i,i+32768));await rpc('upload/chunk',{company,id:start.id,offset,data:btoa(raw)});}
    return start.id;
  }
  async function register(){await action(async()=>{
    if(!available())throw new Error(t().select);const file=source;
    const period=Object.fromEntries(['year','month','version'].map(k=>[k,Number(panel.querySelector('[name='+k+']').value)]));
    if(!Number.isInteger(period.year)||period.year<2000||period.year>2199||!Number.isInteger(period.month)||period.month<1||period.month>12||!Number.isInteger(period.version)||period.version<1||period.version>9999)throw new Error(t().period);
    await refresh(true);if(current()?.state!=='connected')throw new Error(t().error);const expectedId=current()?.info?.id||null;
    const uploadId=await upload(await file.arrayBuffer(),file.name,'final');if(file!==sourceNow())throw new Error(t().select);
    const r=await rpc('register',{company,uploadId,expectedId,...period});clearPreview();message(r.cancelled?t().cancelled:t().done);
  });}
  function table(cells){const table=el('table');for(let r=0;r<11;r++){const tr=el('tr');for(const c of cells.filter(c=>c.row===r)){const td=el('td',c.text);td.rowSpan=c.rows;td.colSpan=c.columns;tr.append(td);}table.append(tr);}return table;}

  function workbookPreview(html){
    if(typeof html!=='string'||!html.startsWith('<!doctype html>'))throw new Error(t().error);
    const frame=el('iframe');frame.title=t().preview;frame.setAttribute('sandbox','');frame.referrerPolicy='no-referrer';frame.srcdoc=html;
    frame.style.cssText='display:block;width:100%;height:'+(company==='AMO'?490:340)+'px;border:0;background:white';return frame;
  }
  async function prepare(){await action(async()=>{
    clearPreview();if(!available()||!result||result.file!==source)throw new Error(t().run);const captured=result,file=source;
    await refresh(true);const info=current()?.info,sourceHash=await digest(await file.arrayBuffer());if(!info||info.finalHash!==sourceHash)throw new Error(t().needsRegister);
    const uploadId=await upload(captured.bytes,captured.name,'gap'),r=await rpc('preview',{company,uploadId});
    if(file!==sourceNow()||result!==captured)throw new Error(t().run);
    preview={file,company,uploadId,expectedId:info.id,sourceHash};panel.querySelector('.stock-preview').replaceChildren(el('p',label(info)+' · '+info.finalName),workbookPreview(r.html));message(t().run);
  });}
  async function approve(){await action(async()=>{
    if(!preview||preview.file!==sourceNow()||!available())throw new Error(t().run);
    const r=await rpc('approve',{company,uploadId:preview.uploadId,expectedId:preview.expectedId,sourceHash:preview.sourceHash});if(!r.cancelled)clearPreview();message(r.cancelled?t().cancelled:t().done);
  });}
  function renderCards(){for(const c of Object.keys(companies)){
    const card=document.querySelector('[data-module-card="'+modules[c]+'"]');if(!card)continue;let box=card.querySelector('.stock-card');
    if(!box){const open=card.querySelector('button.open'),footer=el('div',undefined,'stock-footer');box=el('div',undefined,'stock-card');box.dataset.ecussDesktop='';if(open){open.before(footer);footer.append(open,box);}else card.append(box);}box.replaceChildren();
    const r=rows.find(x=>x.company===c),connected=r?.state==='connected',local=r?.local;
    const i=connected?r?.info:local?.info;
    const canFile=connected?!!i:!!local?.hasFinal,canGap=connected?!!i?.gapHash:!!local?.hasGap;
    const file=el('button',(connected?t().file:canFile?t().localFile:t().file)+' · '+(i&&canFile?label(i):connected?t().none:t().unknown));
    const gap=el('button',(connected?t().gap:canGap?t().localGap:t().gap)+(canGap?'':' · '+(connected?(i?t().waiting:t().none):t().unknown)));
    file.type=gap.type='button';file.disabled=!canFile;gap.disabled=!canGap;
    const savedAt=!connected&&local?.checkedAt?t().lastChecked+' '+new Date(local.checkedAt).toLocaleString(document.documentElement.lang):'';
    file.title=[i?.finalName,savedAt].filter(Boolean).join(' · ');gap.title=[i?.gapName,savedAt].filter(Boolean).join(' · ');
    file.onclick=()=>cardAction(file,'download',c);gap.onclick=()=>cardAction(gap,'open',c);box.append(file,gap);
  }}
  async function cardAction(button,path,c){button.disabled=true;try{await rpc(path,c);}catch(e){window.alert(e.message);}finally{await refresh(true);}}
  function buildPanel(){
    if(!company||!master||panel)return;
    panel=el('section',undefined,'stock-management');panel.dataset.ecussDesktop='';panel.append(el('h2',t().title));
    const name=el('p',t().select,'stock-source');panel.append(name);const fields=el('div',undefined,'stock-fields');
    for(const [key,min,max]of [['year',2000,2199],['month',1,12],['version',1,9999]]){const lab=el('label',t()[key]);lab.dataset.label=key;const input=el('input');input.type='number';input.name=key;input.min=min;input.max=max;input.step=1;lab.append(input);fields.append(lab);}panel.append(fields);
    const buttons=el('div',undefined,'stock-actions');for(const[key,fn]of [['register',register],['preview',prepare],['approve',approve],['retry',()=>action(async()=>{await rpc('retry',company);message(t().done);})],['cancel',()=>action(async()=>{await rpc('cancel',company);message(t().cancelled);})],['refresh',()=>refresh()]]){const b=el('button',t()[key]);b.type='button';b.dataset.action=key;b.onclick=fn;buttons.append(b);}panel.append(buttons);
    notice=el('p','');notice.setAttribute('role','status');panel.append(notice,el('p',t().limits,'stock-limits'),el('div',undefined,'stock-preview'));
    (document.querySelector('body>main')||document.body).prepend(panel);controls();
  }
  function language(){renderCards();if(!panel)return;const currentSource=sourceNow();panel.querySelector('.stock-source').textContent=currentSource?t().source+': '+currentSource.name:t().select;if(notice&&messageKey)notice.textContent=t()[messageKey];panel.querySelectorAll('.stock-preview iframe').forEach(frame=>frame.title=t().preview);panel.querySelector('h2').textContent=t().title;panel.querySelector('.stock-limits').textContent=t().limits;panel.querySelectorAll('[data-action]').forEach(b=>b.textContent=t()[b.dataset.action]);panel.querySelectorAll('[data-label]').forEach(l=>l.firstChild.textContent=t()[l.dataset.label]);}
  function refresh(force=false){if(fetching)return fetching;if(working&&force!==true)return Promise.resolve();fetching=(async()=>{try{rows=await rpc('status');}catch{rows=Object.keys(companies).map(company=>({company,state:'unavailable'}));}finally{fetching=null;renderCards();controls();}})();return fetching;}
  window.EcussStock={refresh,refreshLanguage:language,invalidate(){result=null;clearPreview();},capture(file,bytes,name,period){if(!master)return;result={file,bytes:bytes instanceof Uint8Array?bytes.slice().buffer:bytes.slice(0),name};clearPreview();suggest(file,period);controls();}};
  const style=el('style');style.dataset.ecussDesktop='';style.textContent=`.stock-footer{grid-column:2;width:100%;box-sizing:border-box;align-self:stretch;justify-self:stretch;display:flex;justify-content:space-between;align-items:center;gap:12px;flex-wrap:wrap;min-width:0}.stock-footer>.open{margin:0;flex-shrink:0}.stock-card{margin-left:auto;display:flex;flex-direction:column;align-items:stretch;gap:8px;justify-self:end;max-width:100%}.stock-card button{box-sizing:border-box;max-width:100%;min-height:36px;border:1px solid #aebbd0;border-radius:10px;background:#fff;color:#000;font:inherit;font-size:12px;font-weight:700;cursor:pointer;text-align:left;padding:8px 11px;overflow-wrap:anywhere;transition:background .15s,border-color .15s}.stock-card button:hover:not(:disabled){background:#edf2ff;border-color:#5276cf}.stock-card button:active:not(:disabled){background:#e1e9fc}.stock-card button:focus-visible{outline:2px solid #5276cf;outline-offset:3px}.stock-card button:disabled{color:#000;background:#f1f3f6;border-color:#c8cfda;cursor:default}.stock-management{padding:20px;margin:12px 0 20px;border:1px solid #d5deeb;border-radius:14px;background:#fff;color:#26374e}.stock-management h2{font-size:16px}.stock-fields,.stock-actions{display:flex;flex-wrap:wrap;gap:12px;margin:12px 0}.stock-fields label{display:flex;align-items:center;gap:8px}.stock-fields input{width:95px;padding:7px;border:1px solid #ccd5e3;border-radius:6px}.stock-actions button{padding:9px;border:1px solid #cbd7ed;border-radius:8px;background:#f1f5ff;color:#365da3;cursor:pointer}.stock-actions button:disabled{opacity:.45;cursor:default}.stock-management p{font-size:12px;overflow-wrap:anywhere}.stock-preview{overflow:auto}.stock-preview table{width:100%;border-collapse:collapse}.stock-preview td{border:1px solid #ccd5e3;white-space:pre-wrap;padding:10px}@media(max-width:600px){.stock-card{grid-column:1/-1;align-items:stretch;justify-self:end}.stock-card button{text-align:left}}`;
  document.head.append(style);
  window.addEventListener('load',()=>{
    if(window.__ECUSS_DESKTOP_CONTEXT__?.moduleId&&(!company||!master))return;
    buildPanel();renderCards();refresh();
    if(!company){const container=document.getElementById('modules');if(container)new MutationObserver(()=>{if(Object.values(modules).some(id=>{const c=document.querySelector('[data-module-card="'+id+'"]');return c&&!c.querySelector('.stock-card');}))renderCards();}).observe(container,{childList:true,subtree:true});}
    if(master&&company)setInterval(()=>{const next=sourceNow();if(next!==source){source=next;result=null;clearPreview();for(const input of panel.querySelectorAll('input'))input.value='';suggest(source);panel.querySelector('.stock-source').textContent=source?t().source+': '+source.name:t().select;}controls();},400);
    new MutationObserver(language).observe(document.documentElement,{attributes:true,attributeFilter:['lang']});setInterval(refresh,60000);window.addEventListener('focus',refresh);window.addEventListener('online',refresh);window.addEventListener('offline',refresh);
  },{once:true});
})();




/* Shared presentation adapter. Existing module controls and business events are retained. */
(() => {
  'use strict';
  window.addEventListener('load', () => {
    if (!window.EcussDesktop || window.__VALIDATION_VIEWER__) return;
    const id=window.__ECUSS_DESKTOP_CONTEXT__?.moduleId;
    const module=window.__ECUSS_SUITE__?.modules?.find(m=>m.id===id);
    const nav=document.getElementById('ecuss-module-navigation');
    if(!module||!nav)return;
    let header=document.querySelector('body>header');
    if(!header&&id==='vn-kr-customs-translation'){
      const heading=document.querySelector('main>.heading');
      if(heading){header=document.createElement('header');heading.before(header);header.append(heading);nav.after(header);}
    }
    if(!header)return;
    document.body.classList.add('ecuss-module-ui');document.body.dataset.suiteCategory=module.category;document.body.dataset.suiteModule=id;
    header.id='ecuss-page-header';
    if(id==='stock-status-amovina'){
      const top=header.querySelector('.topbar'),left=top?.firstElementChild,date=header.querySelector('.datebox'),rate=header.querySelector('.ratebox:not(.datebox)');
      if(top&&left&&date&&rate){const options=document.createElement('div');options.className='top-options';options.append(date,rate);header.append(left,options);top.remove();}
    }else if(id==='stock-status-amogreen-vina'){
      const title=header.querySelector('.header-title');if(title)header.prepend(title);
    }
    if(id==='stock-status-amovina'||id==='stock-status-amogreen-vina'){
      // Move the existing nodes only; their listeners, enabled state and module rules stay intact.
      document.body.classList.add('ecuss-stock-ui');
      const title=id==='stock-status-amovina'?header.firstElementChild:header.querySelector('.header-title>div');
      const version=header.querySelector('.version,.pilot');
      if(title&&version){title.append(version);version.classList.add('suite-stock-version');
        version.textContent=(id==='stock-status-amovina'?'AMOVINA':'AMOGREEN VINA')+' · '+window.EcussModuleUI.sourceVersion;}
      const options=header.querySelector('.top-options');
      options?.classList.add('suite-stock-options');
      if(id==='stock-status-amovina'){
        const field=header.querySelector('.ratebox:not(.datebox)'),input=field?.querySelector('input'),unit=field?.querySelector('span');
        if(input&&unit){const row=document.createElement('span');row.className='rate-input';input.before(row);row.append(input,unit);}
      }
      const run=document.getElementById('run'),gap=document.getElementById(id==='stock-status-amovina'?'shortage':'gapRun');
      const actions=run?.parentElement;
      if(actions&&gap){actions.classList.add('suite-stock-actions');actions.prepend(run);
        run.classList.add('suite-stock-primary');gap.classList.add('suite-stock-secondary');
        const label=()=>{if(!window.EcussModuleI18n&&run.textContent==='재고자료 업데이트')run.textContent='선택 자료 업데이트';};
        label();new MutationObserver(label).observe(run,{childList:true,subtree:true,characterData:true});}
      document.getElementById(id==='stock-status-amovina'?'shortageResult':'gapResults')?.classList.add('suite-stock-result');
      const download=document.getElementById(id==='stock-status-amovina'?'shortageXlsx':'gapDownload');
      if(download){download.classList.add('suite-stock-primary');if(!window.EcussModuleI18n)download.textContent='과부족 현황 Excel 다운로드';}
    }
    const style=document.createElement('style');style.setAttribute('data-ecuss-desktop','');style.textContent="/* Desktop presentation only. Never included in shared result documents. */\nbody.ecuss-module-ui{--suite-accent:#0866d9;--suite-tint:#edf4ff;background:#f5f6fa;font-family:'Segoe UI Variable','Segoe UI','Malgun Gothic',sans-serif}\nbody.ecuss-module-ui[data-suite-category=translation]{--suite-accent:#7650a2;--suite-tint:#f5effc}\nbody.ecuss-module-ui[data-suite-category=inventory]{--suite-accent:#a65720;--suite-tint:#fff4e9}\nbody.ecuss-module-ui #ecuss-module-navigation{position:sticky;top:0;z-index:101;background:#f9fafded;color:#425c7b;backdrop-filter:blur(20px);border-bottom:1px solid #e1e6ef}\nbody.ecuss-module-ui #ecuss-module-navigation .ecuss-nav-inner{max-width:none;padding:8px 24px;gap:12px;flex-wrap:nowrap}\nbody.ecuss-module-ui #ecuss-home-button{font-size:13px;padding:7px 12px;flex-shrink:0}\n#ecuss-category-label{color:#65768d;font-size:12px;font-weight:600;white-space:nowrap}\nbody.ecuss-module-ui #ecuss-page-header{position:sticky!important;top:var(--suite-nav-height,52px)!important;z-index:100;display:block!important;visibility:visible!important;background:#ffffffed;backdrop-filter:blur(20px);color:#202b3b;padding:22px 24px;margin:0;border-radius:0;border-bottom:1px solid #dfe5ef;box-shadow:0 5px 12px #19354e16;max-height:55vh;overflow:auto}\nbody.ecuss-module-ui #ecuss-page-header h1{font:650 25px/1.35 'Segoe UI Variable','Segoe UI','Malgun Gothic',sans-serif;letter-spacing:-.4px;margin:0 0 6px;overflow-wrap:anywhere;color:#202b3b}\nbody.ecuss-module-ui #ecuss-page-header p{font-size:13px;line-height:1.5;color:#65768d;margin:0}\nbody.ecuss-module-ui #ecuss-page-header .top-inner,body.ecuss-module-ui #ecuss-page-header .heading{max-width:none;margin:0 auto;display:flex;gap:18px;align-items:center;justify-content:space-between}\nbody.ecuss-module-ui #ecuss-page-header .language-picker,body.ecuss-module-ui #ecuss-page-header .lang{margin:0;align-self:center;color:#65768d;flex-shrink:0}\nbody.ecuss-module-ui #ecuss-page-header select{background:#fff;color:#234056;max-width:100%;border-radius:8px;padding:7px 10px}\nbody.ecuss-module-ui #ecuss-page-header .eyebrow,body.ecuss-module-ui #ecuss-page-header .brand{font-size:10px;letter-spacing:1px;margin:0 0 5px;color:#6d7e94}\nbody.ecuss-module-ui #ecuss-page-header .version,body.ecuss-module-ui #ecuss-page-header .pilot{font-size:11px;color:#65768d;margin-top:4px}\nbody.ecuss-module-ui #ecuss-page-header .header-title{display:flex;align-items:center;justify-content:space-between;gap:14px}\nbody.ecuss-module-ui #ecuss-page-header .top-options{display:flex;gap:16px;flex-wrap:wrap;margin:10px 0 0;justify-content:flex-start;align-items:flex-start}\nbody.ecuss-module-ui #ecuss-page-header .top-options .field,body.ecuss-module-ui #ecuss-page-header .ratebox{min-width:0;max-width:100%;color:#405878;background:#eef2f8;padding:8px 12px;border-radius:8px;margin:0;flex:0 1 auto}\nbody.ecuss-module-ui #ecuss-page-header .top-options small,body.ecuss-module-ui #ecuss-page-header .ratebox small{font-size:10px;color:#65768d}\nbody.ecuss-module-ui #ecuss-page-header input{max-width:100%;font-size:13px;padding:5px 8px}\nbody.ecuss-module-ui main,body.ecuss-module-ui .container{max-width:none;margin:0 auto;padding:24px 24px 48px}\nbody.ecuss-module-ui .panel,body.ecuss-module-ui .card,body.ecuss-module-ui .upload-card{border-radius:18px;border-color:#e0e6ee;box-shadow:0 5px 20px #24364b05}\nbody.ecuss-module-ui .upload-card,body.ecuss-module-ui .dropzone,body.ecuss-module-ui [data-card],body.ecuss-module-ui .file-box{border-color:#c9d7e2;transition:background-color .12s,border-color .12s}\nbody.ecuss-module-ui .upload-card.ready,body.ecuss-module-ui .dropzone.selected,body.ecuss-module-ui .dropzone.has-file,body.ecuss-module-ui #dropzone[data-selected=true],body.ecuss-module-ui [data-card].selected,body.ecuss-module-ui .file-box[data-selected=true]{border:2px solid var(--suite-accent);background:var(--suite-tint)}\nbody.ecuss-module-ui .file-box.dragover,body.ecuss-module-ui .upload-card.dragover,body.ecuss-module-ui .upload-card.drag,body.ecuss-module-ui .dropzone.dragover,body.ecuss-module-ui .dropzone.drag-over,body.ecuss-module-ui [data-card].dragover{outline:3px solid var(--suite-accent);outline-offset:2px;background:var(--suite-tint)}\nbody.ecuss-module-ui .result-actions{top:var(--suite-header-bottom,150px);z-index:30}\nbody.ecuss-module-ui :is(#results,#result){scroll-margin-top:calc(var(--suite-header-bottom,150px) + 16px)}\n@media(max-width:700px){body.ecuss-module-ui #ecuss-module-navigation .ecuss-nav-inner{padding:8px 16px}#ecuss-home-notice{max-width:45vw;font-size:11px!important}body.ecuss-module-ui #ecuss-page-header{padding:12px 16px}body.ecuss-module-ui #ecuss-page-header h1{font-size:19px}body.ecuss-module-ui #ecuss-page-header .top-inner,body.ecuss-module-ui #ecuss-page-header .heading{flex-direction:row;flex-wrap:wrap;gap:8px}body.ecuss-module-ui #ecuss-page-header .top-options{gap:8px}body.ecuss-module-ui #ecuss-page-header .header-title{flex-wrap:wrap}body.ecuss-module-ui main,body.ecuss-module-ui .container{padding:18px 16px 36px}}\n@media print{body.ecuss-module-ui #ecuss-module-navigation{display:none}body.ecuss-module-ui #ecuss-page-header{position:static!important;max-height:none;overflow:visible}}\n\nbody.ecuss-module-ui #ecuss-page-header:has(>#lang){display:flex!important;justify-content:space-between;align-items:center;gap:16px;flex-wrap:wrap}\n\nbody.ecuss-module-ui #ecuss-page-header select.lang{color:#234056}\n\nbody.ecuss-module-ui #ecuss-home-button{color:#315374;background:#fff;border:1px solid #dce3ed;border-radius:10px}\nbody.ecuss-module-ui button,body.ecuss-module-ui select{border-radius:10px}body.ecuss-module-ui button{font-family:inherit}body.ecuss-module-ui :is(button,input,select):focus-visible{outline:3px solid #2278e6;outline-offset:3px}\nbody.ecuss-module-ui #ecuss-page-header input{background:#fff;color:#293b54;border:1px solid #dce3ed;border-radius:7px}body.ecuss-module-ui .result-actions{background:#ffffffed;backdrop-filter:blur(16px);border-color:#e0e6ee}\n/* A single vertical scroller leaves the mail sheet header and actions visible. */\nbody.ecuss-module-ui #ecuss-mail-dialog{overflow:hidden;border-radius:22px;border:1px solid #ffffffa0;color:#26354b;background:#f4f6fa;box-shadow:0 25px 90px #172b4650}body.ecuss-module-ui #ecuss-mail-dialog[open]{display:flex;flex-direction:column}body.ecuss-module-ui #ecuss-mail-dialog::backdrop{background:#1c2d4666;backdrop-filter:blur(6px)}body.ecuss-module-ui #ecuss-mail-dialog .em-head,body.ecuss-module-ui #ecuss-mail-dialog .em-foot{position:static;flex:0 0 auto;padding:17px 24px;background:#ffffffef;border-color:#e1e6ef}body.ecuss-module-ui #ecuss-mail-dialog h2{font-size:21px;letter-spacing:-.5px}body.ecuss-module-ui #ecuss-mail-dialog .em-content{flex:1 1 auto;min-height:0;overflow:auto;padding:20px 24px;scrollbar-gutter:stable}body.ecuss-module-ui #ecuss-mail-dialog .em-card{border:1px solid #e0e6ee;border-radius:15px;padding:20px}body.ecuss-module-ui #ecuss-mail-dialog .em-choice{background:#f6f8fb;border:1px solid #e1e6ef;border-radius:9px;color:#566880}body.ecuss-module-ui #ecuss-mail-dialog .em-choice:has(input:checked){color:#285583;border-color:#b9d0ef;background:#eef5ff}body.ecuss-module-ui #ecuss-mail-dialog input[type=checkbox]{accent-color:#0866d9}body.ecuss-module-ui #ecuss-mail-dialog select,body.ecuss-module-ui #ecuss-mail-dialog .em-quiet{border-color:#dce3ed;border-radius:9px;background:#f8fafc;color:#3b577a}body.ecuss-module-ui #ecuss-mail-dialog #em-subject{display:block;width:100%;min-width:0;font:600 14px/1.6 'Segoe UI','Malgun Gothic',sans-serif;padding:11px 13px;border:1px solid #b8c9df;border-radius:10px;color:#233b5b;background:#fff}body.ecuss-module-ui #ecuss-mail-dialog #em-subject:disabled{color:#7d8796;background:#f3f5f8}body.ecuss-module-ui #ecuss-mail-dialog #em-send{background:#0866d9;border-radius:11px;padding:12px 25px}body.ecuss-module-ui #ecuss-mail-dialog #em-send:disabled{background:#9caabe;color:#fff}body.ecuss-module-ui #ecuss-mail-dialog #em-viewport{max-height:none;min-height:0;overflow-x:auto;overflow-y:hidden}body.ecuss-module-ui #ecuss-mail-dialog #em-count{font-size:13px}body.ecuss-module-ui #ecuss-mail-dialog .em-note{font-size:11px;line-height:1.7;color:#687c94}body.ecuss-module-ui #ecuss-mail-dialog .em-preview-title{flex-wrap:wrap;font-size:13px}body.ecuss-module-ui #ecuss-mail-dialog .em-file{border-radius:8px;background:#f0f5fc;border-color:#dbe5f2}\n@media(max-width:700px){body.ecuss-module-ui #ecuss-category-label{font-size:10px;white-space:normal}body.ecuss-module-ui #ecuss-mail-dialog .em-head,body.ecuss-module-ui #ecuss-mail-dialog .em-content,body.ecuss-module-ui #ecuss-mail-dialog .em-foot{padding:12px 14px}body.ecuss-module-ui #ecuss-mail-dialog .em-card{padding:14px}body.ecuss-module-ui #ecuss-mail-dialog .em-foot .em-note{margin:4px 0}body.ecuss-module-ui #ecuss-mail-dialog .em-head .em-note{display:none}}\n@media(prefers-reduced-motion:reduce){body.ecuss-module-ui *{transition:none!important;scroll-behavior:auto!important}}\n\nbody.ecuss-module-ui #ecuss-home-notice{color:#975527}\n\nbody.ecuss-module-ui #ecuss-page-header .version{background:#eef2f8;color:#61738d;border-radius:20px;padding:6px 12px}\n\n/* Glass Workspace: shared navigation materials; document content keeps an opaque reading surface. */\nbody.ecuss-module-ui{--suite-accent:#4260da;--suite-tint:#eff3ff;background:radial-gradient(ellipse at 0 0,#e9edfc 0,transparent 48%),#f4f6fb;color:#253148}\nbody.ecuss-module-ui #ecuss-module-navigation{background:#eef2fbdc;border-bottom-color:#e0e6f2;backdrop-filter:blur(24px)}\nbody.ecuss-module-ui #ecuss-page-header{background:#f9faffea;box-shadow:0 6px 20px #34436808;border-bottom-color:#e0e6f2;backdrop-filter:blur(24px)}\nbody.ecuss-module-ui #ecuss-home-button{border-color:#d8e2f4;background:#ffffffc9;color:#4c649b;border-radius:12px}\nbody.ecuss-module-ui .panel,body.ecuss-module-ui .card,body.ecuss-module-ui .upload-card{border-radius:20px;border-color:#e0e6f1;box-shadow:0 8px 26px #34436806}\nbody.ecuss-module-ui #ecuss-page-header .top-options .field,body.ecuss-module-ui #ecuss-page-header .ratebox{background:#eaf0fa9c;border:1px solid #dfe7f5;border-radius:11px}\nbody.ecuss-module-ui #ecuss-mail-dialog{background:#f3f5fb;border-color:#e1e7f2;box-shadow:0 30px 100px #26344e45}\nbody.ecuss-module-ui #ecuss-mail-dialog .em-head,body.ecuss-module-ui #ecuss-mail-dialog .em-foot{background:#f6f8ffed;backdrop-filter:blur(22px)}\nbody.ecuss-module-ui #ecuss-mail-dialog #em-send{background:#4260da}\nbody.ecuss-module-ui dialog::backdrop{background:#26344e66;backdrop-filter:blur(7px)}\n@media(forced-colors:active){body.ecuss-module-ui,body.ecuss-module-ui #ecuss-page-header,body.ecuss-module-ui #ecuss-module-navigation,body.ecuss-module-ui #ecuss-mail-dialog,body.ecuss-module-ui #ecuss-mail-dialog .em-head,body.ecuss-module-ui #ecuss-mail-dialog .em-foot{background:Canvas;color:CanvasText;backdrop-filter:none}body.ecuss-module-ui #ecuss-page-header h1,body.ecuss-module-ui #ecuss-page-header p{color:CanvasText}body.ecuss-module-ui #ecuss-home-button{border:1px solid ButtonText;color:ButtonText;background:ButtonFace}}\n\nbody.ecuss-module-ui #report-dialog{border:1px solid #e1e7f2;border-radius:22px;background:#f3f5fb;box-shadow:0 30px 100px #26344e45;overflow:hidden}body.ecuss-module-ui #report-dialog .report-toolbar{background:#f6f8ffed;border-bottom:1px solid #dfe5f1;color:#354868;gap:14px}body.ecuss-module-ui #report-dialog #close-report{border:1px solid #d8e2f4;border-radius:10px;background:white;color:#4c649b;padding:8px 13px}\n\n\n/* Shared desktop presentation. No engine, workbook, result data or source payload changes. */\nbody.ecuss-module-ui{min-height:100vh}\nbody:is(.ecuss-module-ui,.ecuss-module-frame)[data-suite-module]{\n --suite-accent:#4260da;--suite-tint:#eff3ff;--suite-ink:#253148;--suite-muted:#626f85;\n --suite-line:#dfe5f1;--suite-surface:#ffffffed;--suite-radius:20px;\n --accent:var(--suite-accent);--blue:var(--suite-accent);\n --navy:var(--suite-ink);--ink:var(--suite-ink);--muted:var(--suite-muted);--line:var(--suite-line);\n font:14px/1.65 'Segoe UI Variable','Segoe UI','Malgun Gothic',sans-serif;\n color:var(--suite-ink);background:radial-gradient(ellipse at 0 0,#e5eaff 0,transparent 50%),radial-gradient(ellipse at 100% 65%,#f0ecfb 0,transparent 45%),#f4f6fb;\n}\nbody:is(.ecuss-module-ui,.ecuss-module-frame) :is(h1,h2,h3,h4){color:var(--suite-ink);line-height:1.4;letter-spacing:-.35px}\nbody:is(.ecuss-module-ui,.ecuss-module-frame) h2{font-size:18px;font-weight:650}\nbody:is(.ecuss-module-ui,.ecuss-module-frame) h3{font-size:15px;font-weight:650}\nbody:is(.ecuss-module-ui,.ecuss-module-frame) :is(.muted,.desc,.hint,.help,.note,.intro,.file-size,.drop-hint){color:var(--suite-muted)}\nbody.ecuss-module-ui #ecuss-module-navigation{background:#f2f5ffde;border-bottom:1px solid #ffffffc9;backdrop-filter:blur(24px)}\nbody.ecuss-module-ui #ecuss-page-header{background:#f8faffdb;border-bottom:1px solid #dfe5f1;backdrop-filter:blur(24px);box-shadow:0 8px 28px #2a395505}\nbody.ecuss-module-ui #ecuss-page-header h1{font-size:25px;font-weight:650;color:var(--suite-ink)}\nbody.ecuss-module-ui #ecuss-page-header :is(.version,.pilot){display:inline-block;background:#edf1fc;border:1px solid #dfe6f5;border-radius:20px;color:#68799a;font-size:11px;padding:4px 10px}\nbody.ecuss-module-ui main{min-width:0}\nbody:is(.ecuss-module-ui,.ecuss-module-frame) :is(.panel,.card,.upload-card,.upload,section.method,details.method){\n background:var(--suite-surface);border:1px solid var(--suite-line);border-radius:var(--suite-radius);\n box-shadow:inset 0 1px 0 #fff,0 10px 32px #2a395508;min-width:0;\n}\nbody:is(.ecuss-module-ui,.ecuss-module-frame) :is(.card,.upload-card,.panel){padding:22px}\nbody:is(.ecuss-module-ui,.ecuss-module-frame) :is(button,select,input,textarea){font-family:inherit;font-size:13px}\nbody:is(.ecuss-module-ui,.ecuss-module-frame) button,\nbody:is(.ecuss-module-ui,.ecuss-module-frame) :is(.pick,.filelabel,.file-label,a.secondary,a.primary){\n min-height:38px;padding:9px 14px;border:1px solid #d8e1f3;border-radius:11px;background:#f0f3fd;\n color:#4261a1;font-weight:600;line-height:1.4;box-shadow:none;transition:background-color .15s,border-color .15s;\n}\nbody:is(.ecuss-module-ui,.ecuss-module-frame) button:hover:not(:disabled),\nbody:is(.ecuss-module-ui,.ecuss-module-frame) :is(.pick,.filelabel,.file-label,a.secondary):hover{background:#e7edfc;border-color:#bdcbed}\nbody:is(.ecuss-module-ui,.ecuss-module-frame) :is(button.primary,a.primary,#calculate){background:#4260da;color:#fff;border-color:#4260da;box-shadow:0 4px 12px #4260da18}\nbody:is(.ecuss-module-ui,.ecuss-module-frame) :is(button.primary,a.primary,#calculate):hover:not(:disabled){background:#354ec0;border-color:#354ec0;color:#fff}\nbody:is(.ecuss-module-ui,.ecuss-module-frame) button:disabled{opacity:.48;cursor:not-allowed;box-shadow:none}\nbody:is(.ecuss-module-ui,.ecuss-module-frame) button[aria-pressed=true]{background:#e8eeff;border-color:#b8c8f2;color:#354eb8}\nbody:is(.ecuss-module-ui,.ecuss-module-frame) :is(input:not([type=file]):not([type=checkbox]):not([type=radio]):not([type=range]),select,textarea){\n min-height:36px;max-width:100%;padding:8px 10px;border:1px solid #d7dfed;border-radius:10px;background:#fff;color:var(--suite-ink);box-shadow:inset 0 1px 2px #25314803;\n}\nbody:is(.ecuss-module-ui,.ecuss-module-frame) :is(input[type=checkbox],input[type=radio]){accent-color:var(--suite-accent)}\nbody:is(.ecuss-module-ui,.ecuss-module-frame) :is(button,input,select,textarea,summary,a):focus-visible{outline:3px solid #4260da;outline-offset:3px}\nbody:is(.ecuss-module-ui,.ecuss-module-frame) :is(.file-box,.file-row,.drop,.dropzone){border-color:#cbd7ed;background:#f8faff;border-radius:16px}\nbody:is(.ecuss-module-ui,.ecuss-module-frame) :is(.file-prompt,.step,.tag,.number,.selection-state){color:#5b6f9e}\nbody:is(.ecuss-module-ui,.ecuss-module-frame) :is(.tag,.number,.selection-state){background:#edf2fc;border-color:#dce5f6;border-radius:9px}\nbody:is(.ecuss-module-ui,.ecuss-module-frame) :is(.file-box[data-selected=true],.card.selected,.drop.selected,.drop.has-file,.dropzone.selected,.dropzone.has-file,.upload-card.ready,#dropzone[data-selected=true]){border-color:#4260da;background:#eff3ff;box-shadow:0 0 0 1px #4260da26}\nbody:is(.ecuss-module-ui,.ecuss-module-frame) :is(.dragover,.drag-over,.drag){outline:3px solid #4260da;outline-offset:2px;background:#eaf0ff}\nbody:is(.ecuss-module-ui,.ecuss-module-frame) :is(.clear,.clear-file){min-height:28px;padding:5px 9px;font-size:12px;border-radius:8px}\nbody:is(.ecuss-module-ui,.ecuss-module-frame) details{background:#ffffffad;border:1px solid #dfe5f1;border-radius:15px;padding:14px 17px;margin-top:14px;color:var(--suite-ink)}\nbody:is(.ecuss-module-ui,.ecuss-module-frame) summary{cursor:pointer;color:#4c608c;font-size:13px;font-weight:600;line-height:1.6}\nbody:is(.ecuss-module-ui,.ecuss-module-frame) summary::marker{color:#7c8fbc}\nbody:is(.ecuss-module-ui,.ecuss-module-frame) details[open]>summary{margin-bottom:12px}\nbody:is(.ecuss-module-ui,.ecuss-module-frame) :is(th,.table-head){background:#edf2fc;color:#40567c;border-color:#dce4f2;font-weight:600}\n/* The mismatch grid keeps its original sticky navy header; pair it with light text.\n   Compact filter controls must not inherit full-size workspace button padding. */\nbody.ecuss-module-ui[data-suite-module=balance-ecuss] .mismatch-table thead th{background:#17365d;color:#fff}\nbody.ecuss-module-ui[data-suite-module=balance-ecuss] #mismatch-head .filter-trigger{\n min-height:22px;width:19px;height:22px;padding:0;border:1px solid #88a4c4;border-radius:4px;\n background:#244b77;color:#fff;font-size:11px;line-height:1;box-shadow:none;\n}\nbody.ecuss-module-ui[data-suite-module=balance-ecuss] #mismatch-head .filter-trigger:is(:hover,:focus-visible){background:#315e8f;color:#fff;border-color:#b9d0eb}\nbody.ecuss-module-ui[data-suite-module=balance-ecuss] #mismatch-head .filter-trigger.active{background:#67e8f9;color:#17365d;border-color:#67e8f9}\nbody:is(.ecuss-module-ui,.ecuss-module-frame) :is(table,.tablewrap,.scroll){border-color:#dfe5f1}\nbody:is(.ecuss-module-ui,.ecuss-module-frame) :is(.actions,.toolbar,.resulthead,.result-head){gap:12px}\nbody:is(.ecuss-module-ui,.ecuss-module-frame) :is(dialog,.dialog){border:1px solid #dfe5f1;border-radius:20px;background:#f8faff;box-shadow:0 28px 90px #25314835;color:var(--suite-ink)}\nbody:is(.ecuss-module-ui,.ecuss-module-frame) :is(.dialoghead,.dialog-head){background:#f0f4ff;border-color:#dfe5f1}\nbody.ecuss-module-ui[data-suite-module=stock-status-amovina]>section:not(#ecuss-work-access){max-width:none;margin:24px 24px 0;padding:22px;border:1px solid #dfe5f1;border-radius:20px;background:#ffffffed;box-shadow:0 10px 32px #2a395508}\nbody.ecuss-module-ui[data-suite-module=stock-status-amovina] .notice{background:#edf2fc;border-color:#b8c8ed;border-radius:14px;color:#40567c;padding:16px 18px}\nbody.ecuss-module-ui[data-suite-module=stock-status-amogreen-vina] :is(.local,.tag.required){background:#edf2fc;color:#4c6497;border-color:#dce5f6}\nbody.ecuss-module-ui[data-suite-module=stock-status-amogreen-vina] .inactive{background:#edf0f6;border-style:dashed;box-shadow:none}\nbody.ecuss-module-ui[data-suite-module=monthly-report-consolidation] .shell{max-width:none;margin:auto;grid-template-columns:220px minmax(0,1fr)}\nbody.ecuss-module-ui[data-suite-module=monthly-report-consolidation] .sidebar{background:linear-gradient(150deg,#e9edfcc9,#eef2fbc4 60%,#eeebf8c0);border-color:#dce3f0;padding:28px 18px;backdrop-filter:blur(24px)}\nbody.ecuss-module-ui[data-suite-module=monthly-report-consolidation] .navlink{color:#647497;border:1px solid transparent;border-radius:12px;font-size:13px}\nbody.ecuss-module-ui[data-suite-module=monthly-report-consolidation] .navlink.active{background:#ffffffeb;color:#36539d;border-color:#fff;box-shadow:0 5px 18px #334c7808}\nbody.ecuss-module-ui[data-suite-module=monthly-report-consolidation] .main{margin:0;max-width:none;padding:28px 30px 48px}\nbody.ecuss-module-ui[data-suite-module=monthly-report-consolidation] .side-note{color:#72819c;font-size:11px;border-top:1px solid #dce3f0;padding-top:18px}\nbody.ecuss-module-ui[data-suite-module=monthly-report-consolidation] :is(.period,.rule-box,.rate-card){background:#f4f7fd;border-color:#dfe5f1;border-radius:13px}\nbody.ecuss-module-ui[data-suite-module=psr-rvc-lvc-calculator] #frames{max-width:none;padding:0;margin:0 auto}\nbody.ecuss-module-ui[data-suite-module=psr-rvc-lvc-calculator] #frames iframe{background:transparent}\nbody.ecuss-module-frame{max-width:none;margin:0;padding:24px;min-width:0}\nbody.ecuss-module-frame>section:not(.notice){padding:22px;margin-bottom:18px;background:#ffffffed;border:1px solid #dfe5f1;border-radius:20px;box-shadow:0 10px 32px #2a395508}\nbody.ecuss-module-frame>h1{font-size:22px;margin:0 0 12px}\nbody.ecuss-module-frame :is(.notice,#suite-user-psr-scope){background:#edf2fc;border-color:#d9e3f6;border-radius:13px;color:#496187;padding:14px 17px;font-size:13px}\nbody.ecuss-module-frame :is(table input,table select,table button){font-size:12px;min-height:30px;padding:6px 8px;border-radius:8px}\nbody.ecuss-module-frame #excelPanel{background:#f7f9ff;border-color:#cbd7ed;border-radius:14px}\n@media(max-width:900px){body.ecuss-module-ui[data-suite-module=monthly-report-consolidation] .shell{grid-template-columns:180px minmax(0,1fr)}body.ecuss-module-ui[data-suite-module=monthly-report-consolidation] .main{padding:22px 18px 36px}}\n@media(max-width:760px){body.ecuss-module-ui[data-suite-module=monthly-report-consolidation] .shell{display:block}body.ecuss-module-ui[data-suite-module=monthly-report-consolidation] .sidebar{padding:15px 18px}body.ecuss-module-ui[data-suite-module=monthly-report-consolidation] .side-note{display:none}body.ecuss-module-frame{padding:16px}body:is(.ecuss-module-ui,.ecuss-module-frame) :is(.card,.upload-card,.panel){padding:17px}body.ecuss-module-ui[data-suite-module=stock-status-amovina]>section:not(#ecuss-work-access){margin:18px 16px 0}body.ecuss-module-ui #ecuss-page-header h1{font-size:20px}}\n@media(prefers-reduced-motion:reduce){body:is(.ecuss-module-ui,.ecuss-module-frame) *{transition:none!important}}\n@media(forced-colors:active){body:is(.ecuss-module-ui,.ecuss-module-frame)[data-suite-module],body:is(.ecuss-module-ui,.ecuss-module-frame) :is(.panel,.card,.upload,.drop,.file-box,details,.notice){background:Canvas;color:CanvasText;border-color:CanvasText;box-shadow:none}body:is(.ecuss-module-ui,.ecuss-module-frame) :is(button,.primary){background:ButtonFace;color:ButtonText;border-color:ButtonText}}\n@media print{body:is(.ecuss-module-ui,.ecuss-module-frame)[data-suite-module]{background:white}body:is(.ecuss-module-ui,.ecuss-module-frame) :is(.panel,.card,.upload,section){box-shadow:none;backdrop-filter:none}}\n\n";document.head.append(style);
    const stockStyle=document.getElementById('ecuss-stock-style');if(stockStyle)document.head.append(stockStyle);
    // PSR uses same-origin srcdoc frames. Style their DOM without changing payloads or engines.
    if(id==='psr-rvc-lvc-calculator'){
      const applyFrameTheme=frame=>{
        const doc=frame.contentDocument;
        if(!doc?.body||doc.getElementById('suite-frame-theme'))return;
        doc.body.classList.add('ecuss-module-frame');doc.body.dataset.suiteModule=id;
        const sheet=doc.createElement('style');sheet.id='suite-frame-theme';sheet.setAttribute('data-ecuss-desktop','');sheet.textContent="/* Shared desktop presentation. No engine, workbook, result data or source payload changes. */\nbody.ecuss-module-ui{min-height:100vh}\nbody:is(.ecuss-module-ui,.ecuss-module-frame)[data-suite-module]{\n --suite-accent:#4260da;--suite-tint:#eff3ff;--suite-ink:#253148;--suite-muted:#626f85;\n --suite-line:#dfe5f1;--suite-surface:#ffffffed;--suite-radius:20px;\n --accent:var(--suite-accent);--blue:var(--suite-accent);\n --navy:var(--suite-ink);--ink:var(--suite-ink);--muted:var(--suite-muted);--line:var(--suite-line);\n font:14px/1.65 'Segoe UI Variable','Segoe UI','Malgun Gothic',sans-serif;\n color:var(--suite-ink);background:radial-gradient(ellipse at 0 0,#e5eaff 0,transparent 50%),radial-gradient(ellipse at 100% 65%,#f0ecfb 0,transparent 45%),#f4f6fb;\n}\nbody:is(.ecuss-module-ui,.ecuss-module-frame) :is(h1,h2,h3,h4){color:var(--suite-ink);line-height:1.4;letter-spacing:-.35px}\nbody:is(.ecuss-module-ui,.ecuss-module-frame) h2{font-size:18px;font-weight:650}\nbody:is(.ecuss-module-ui,.ecuss-module-frame) h3{font-size:15px;font-weight:650}\nbody:is(.ecuss-module-ui,.ecuss-module-frame) :is(.muted,.desc,.hint,.help,.note,.intro,.file-size,.drop-hint){color:var(--suite-muted)}\nbody.ecuss-module-ui #ecuss-module-navigation{background:#f2f5ffde;border-bottom:1px solid #ffffffc9;backdrop-filter:blur(24px)}\nbody.ecuss-module-ui #ecuss-page-header{background:#f8faffdb;border-bottom:1px solid #dfe5f1;backdrop-filter:blur(24px);box-shadow:0 8px 28px #2a395505}\nbody.ecuss-module-ui #ecuss-page-header h1{font-size:25px;font-weight:650;color:var(--suite-ink)}\nbody.ecuss-module-ui #ecuss-page-header :is(.version,.pilot){display:inline-block;background:#edf1fc;border:1px solid #dfe6f5;border-radius:20px;color:#68799a;font-size:11px;padding:4px 10px}\nbody.ecuss-module-ui main{min-width:0}\nbody:is(.ecuss-module-ui,.ecuss-module-frame) :is(.panel,.card,.upload-card,.upload,section.method,details.method){\n background:var(--suite-surface);border:1px solid var(--suite-line);border-radius:var(--suite-radius);\n box-shadow:inset 0 1px 0 #fff,0 10px 32px #2a395508;min-width:0;\n}\nbody:is(.ecuss-module-ui,.ecuss-module-frame) :is(.card,.upload-card,.panel){padding:22px}\nbody:is(.ecuss-module-ui,.ecuss-module-frame) :is(button,select,input,textarea){font-family:inherit;font-size:13px}\nbody:is(.ecuss-module-ui,.ecuss-module-frame) button,\nbody:is(.ecuss-module-ui,.ecuss-module-frame) :is(.pick,.filelabel,.file-label,a.secondary,a.primary){\n min-height:38px;padding:9px 14px;border:1px solid #d8e1f3;border-radius:11px;background:#f0f3fd;\n color:#4261a1;font-weight:600;line-height:1.4;box-shadow:none;transition:background-color .15s,border-color .15s;\n}\nbody:is(.ecuss-module-ui,.ecuss-module-frame) button:hover:not(:disabled),\nbody:is(.ecuss-module-ui,.ecuss-module-frame) :is(.pick,.filelabel,.file-label,a.secondary):hover{background:#e7edfc;border-color:#bdcbed}\nbody:is(.ecuss-module-ui,.ecuss-module-frame) :is(button.primary,a.primary,#calculate){background:#4260da;color:#fff;border-color:#4260da;box-shadow:0 4px 12px #4260da18}\nbody:is(.ecuss-module-ui,.ecuss-module-frame) :is(button.primary,a.primary,#calculate):hover:not(:disabled){background:#354ec0;border-color:#354ec0;color:#fff}\nbody:is(.ecuss-module-ui,.ecuss-module-frame) button:disabled{opacity:.48;cursor:not-allowed;box-shadow:none}\nbody:is(.ecuss-module-ui,.ecuss-module-frame) button[aria-pressed=true]{background:#e8eeff;border-color:#b8c8f2;color:#354eb8}\nbody:is(.ecuss-module-ui,.ecuss-module-frame) :is(input:not([type=file]):not([type=checkbox]):not([type=radio]):not([type=range]),select,textarea){\n min-height:36px;max-width:100%;padding:8px 10px;border:1px solid #d7dfed;border-radius:10px;background:#fff;color:var(--suite-ink);box-shadow:inset 0 1px 2px #25314803;\n}\nbody:is(.ecuss-module-ui,.ecuss-module-frame) :is(input[type=checkbox],input[type=radio]){accent-color:var(--suite-accent)}\nbody:is(.ecuss-module-ui,.ecuss-module-frame) :is(button,input,select,textarea,summary,a):focus-visible{outline:3px solid #4260da;outline-offset:3px}\nbody:is(.ecuss-module-ui,.ecuss-module-frame) :is(.file-box,.file-row,.drop,.dropzone){border-color:#cbd7ed;background:#f8faff;border-radius:16px}\nbody:is(.ecuss-module-ui,.ecuss-module-frame) :is(.file-prompt,.step,.tag,.number,.selection-state){color:#5b6f9e}\nbody:is(.ecuss-module-ui,.ecuss-module-frame) :is(.tag,.number,.selection-state){background:#edf2fc;border-color:#dce5f6;border-radius:9px}\nbody:is(.ecuss-module-ui,.ecuss-module-frame) :is(.file-box[data-selected=true],.card.selected,.drop.selected,.drop.has-file,.dropzone.selected,.dropzone.has-file,.upload-card.ready,#dropzone[data-selected=true]){border-color:#4260da;background:#eff3ff;box-shadow:0 0 0 1px #4260da26}\nbody:is(.ecuss-module-ui,.ecuss-module-frame) :is(.dragover,.drag-over,.drag){outline:3px solid #4260da;outline-offset:2px;background:#eaf0ff}\nbody:is(.ecuss-module-ui,.ecuss-module-frame) :is(.clear,.clear-file){min-height:28px;padding:5px 9px;font-size:12px;border-radius:8px}\nbody:is(.ecuss-module-ui,.ecuss-module-frame) details{background:#ffffffad;border:1px solid #dfe5f1;border-radius:15px;padding:14px 17px;margin-top:14px;color:var(--suite-ink)}\nbody:is(.ecuss-module-ui,.ecuss-module-frame) summary{cursor:pointer;color:#4c608c;font-size:13px;font-weight:600;line-height:1.6}\nbody:is(.ecuss-module-ui,.ecuss-module-frame) summary::marker{color:#7c8fbc}\nbody:is(.ecuss-module-ui,.ecuss-module-frame) details[open]>summary{margin-bottom:12px}\nbody:is(.ecuss-module-ui,.ecuss-module-frame) :is(th,.table-head){background:#edf2fc;color:#40567c;border-color:#dce4f2;font-weight:600}\n/* The mismatch grid keeps its original sticky navy header; pair it with light text.\n   Compact filter controls must not inherit full-size workspace button padding. */\nbody.ecuss-module-ui[data-suite-module=balance-ecuss] .mismatch-table thead th{background:#17365d;color:#fff}\nbody.ecuss-module-ui[data-suite-module=balance-ecuss] #mismatch-head .filter-trigger{\n min-height:22px;width:19px;height:22px;padding:0;border:1px solid #88a4c4;border-radius:4px;\n background:#244b77;color:#fff;font-size:11px;line-height:1;box-shadow:none;\n}\nbody.ecuss-module-ui[data-suite-module=balance-ecuss] #mismatch-head .filter-trigger:is(:hover,:focus-visible){background:#315e8f;color:#fff;border-color:#b9d0eb}\nbody.ecuss-module-ui[data-suite-module=balance-ecuss] #mismatch-head .filter-trigger.active{background:#67e8f9;color:#17365d;border-color:#67e8f9}\nbody:is(.ecuss-module-ui,.ecuss-module-frame) :is(table,.tablewrap,.scroll){border-color:#dfe5f1}\nbody:is(.ecuss-module-ui,.ecuss-module-frame) :is(.actions,.toolbar,.resulthead,.result-head){gap:12px}\nbody:is(.ecuss-module-ui,.ecuss-module-frame) :is(dialog,.dialog){border:1px solid #dfe5f1;border-radius:20px;background:#f8faff;box-shadow:0 28px 90px #25314835;color:var(--suite-ink)}\nbody:is(.ecuss-module-ui,.ecuss-module-frame) :is(.dialoghead,.dialog-head){background:#f0f4ff;border-color:#dfe5f1}\nbody.ecuss-module-ui[data-suite-module=stock-status-amovina]>section:not(#ecuss-work-access){max-width:none;margin:24px 24px 0;padding:22px;border:1px solid #dfe5f1;border-radius:20px;background:#ffffffed;box-shadow:0 10px 32px #2a395508}\nbody.ecuss-module-ui[data-suite-module=stock-status-amovina] .notice{background:#edf2fc;border-color:#b8c8ed;border-radius:14px;color:#40567c;padding:16px 18px}\nbody.ecuss-module-ui[data-suite-module=stock-status-amogreen-vina] :is(.local,.tag.required){background:#edf2fc;color:#4c6497;border-color:#dce5f6}\nbody.ecuss-module-ui[data-suite-module=stock-status-amogreen-vina] .inactive{background:#edf0f6;border-style:dashed;box-shadow:none}\nbody.ecuss-module-ui[data-suite-module=monthly-report-consolidation] .shell{max-width:none;margin:auto;grid-template-columns:220px minmax(0,1fr)}\nbody.ecuss-module-ui[data-suite-module=monthly-report-consolidation] .sidebar{background:linear-gradient(150deg,#e9edfcc9,#eef2fbc4 60%,#eeebf8c0);border-color:#dce3f0;padding:28px 18px;backdrop-filter:blur(24px)}\nbody.ecuss-module-ui[data-suite-module=monthly-report-consolidation] .navlink{color:#647497;border:1px solid transparent;border-radius:12px;font-size:13px}\nbody.ecuss-module-ui[data-suite-module=monthly-report-consolidation] .navlink.active{background:#ffffffeb;color:#36539d;border-color:#fff;box-shadow:0 5px 18px #334c7808}\nbody.ecuss-module-ui[data-suite-module=monthly-report-consolidation] .main{margin:0;max-width:none;padding:28px 30px 48px}\nbody.ecuss-module-ui[data-suite-module=monthly-report-consolidation] .side-note{color:#72819c;font-size:11px;border-top:1px solid #dce3f0;padding-top:18px}\nbody.ecuss-module-ui[data-suite-module=monthly-report-consolidation] :is(.period,.rule-box,.rate-card){background:#f4f7fd;border-color:#dfe5f1;border-radius:13px}\nbody.ecuss-module-ui[data-suite-module=psr-rvc-lvc-calculator] #frames{max-width:none;padding:0;margin:0 auto}\nbody.ecuss-module-ui[data-suite-module=psr-rvc-lvc-calculator] #frames iframe{background:transparent}\nbody.ecuss-module-frame{max-width:none;margin:0;padding:24px;min-width:0}\nbody.ecuss-module-frame>section:not(.notice){padding:22px;margin-bottom:18px;background:#ffffffed;border:1px solid #dfe5f1;border-radius:20px;box-shadow:0 10px 32px #2a395508}\nbody.ecuss-module-frame>h1{font-size:22px;margin:0 0 12px}\nbody.ecuss-module-frame :is(.notice,#suite-user-psr-scope){background:#edf2fc;border-color:#d9e3f6;border-radius:13px;color:#496187;padding:14px 17px;font-size:13px}\nbody.ecuss-module-frame :is(table input,table select,table button){font-size:12px;min-height:30px;padding:6px 8px;border-radius:8px}\nbody.ecuss-module-frame #excelPanel{background:#f7f9ff;border-color:#cbd7ed;border-radius:14px}\n@media(max-width:900px){body.ecuss-module-ui[data-suite-module=monthly-report-consolidation] .shell{grid-template-columns:180px minmax(0,1fr)}body.ecuss-module-ui[data-suite-module=monthly-report-consolidation] .main{padding:22px 18px 36px}}\n@media(max-width:760px){body.ecuss-module-ui[data-suite-module=monthly-report-consolidation] .shell{display:block}body.ecuss-module-ui[data-suite-module=monthly-report-consolidation] .sidebar{padding:15px 18px}body.ecuss-module-ui[data-suite-module=monthly-report-consolidation] .side-note{display:none}body.ecuss-module-frame{padding:16px}body:is(.ecuss-module-ui,.ecuss-module-frame) :is(.card,.upload-card,.panel){padding:17px}body.ecuss-module-ui[data-suite-module=stock-status-amovina]>section:not(#ecuss-work-access){margin:18px 16px 0}body.ecuss-module-ui #ecuss-page-header h1{font-size:20px}}\n@media(prefers-reduced-motion:reduce){body:is(.ecuss-module-ui,.ecuss-module-frame) *{transition:none!important}}\n@media(forced-colors:active){body:is(.ecuss-module-ui,.ecuss-module-frame)[data-suite-module],body:is(.ecuss-module-ui,.ecuss-module-frame) :is(.panel,.card,.upload,.drop,.file-box,details,.notice){background:Canvas;color:CanvasText;border-color:CanvasText;box-shadow:none}body:is(.ecuss-module-ui,.ecuss-module-frame) :is(button,.primary){background:ButtonFace;color:ButtonText;border-color:ButtonText}}\n@media print{body:is(.ecuss-module-ui,.ecuss-module-frame)[data-suite-module]{background:white}body:is(.ecuss-module-ui,.ecuss-module-frame) :is(.panel,.card,.upload,section){box-shadow:none;backdrop-filter:none}}\n\n";doc.head.append(sheet);
      };
      document.querySelectorAll('#frames iframe').forEach(frame=>{applyFrameTheme(frame);frame.addEventListener('load',()=>applyFrameTheme(frame));});
    }
    const category=document.createElement('span');category.id='ecuss-category-label';nav.querySelector('.ecuss-nav-inner').append(category);
    const categories={ko:{reporting:'월간리포트 취합',validation:'Balance Sheet 검증',translation:'문서 번역',inventory:'재고 취합',tools:'업무 도구'},en:{reporting:'Monthly reporting',validation:'Balance Sheet validation',translation:'Document translation',inventory:'Stock consolidation',tools:'Work tools'},vi:{reporting:'Báo cáo tháng',validation:'Kiểm tra Balance Sheet',translation:'Dịch tài liệu',inventory:'Tổng hợp tồn kho',tools:'Công cụ công việc'}};
    function labels(){const lang=document.documentElement.lang||'ko',name=module.name[lang]||module.name.ko;const h=header.querySelector('h1');if(h&&h.textContent!==name)h.textContent=name;document.title=name;category.textContent=(categories[lang]||categories.ko)[module.category]||'';}
    function measure(){const n=nav.getBoundingClientRect().height,h=header.getBoundingClientRect().height;document.body.style.setProperty('--suite-nav-height',n+'px');document.body.style.setProperty('--suite-header-bottom',(n+h)+'px');}
    if(id==='balance-sheet-validation'){const filename=document.getElementById('filename'),zone=document.getElementById('dropzone');const selected=()=>{zone.dataset.selected=String(!!window.EcussModuleState?.hasWork?.());};selected();new MutationObserver(selected).observe(filename,{childList:true,subtree:true,characterData:true});}
    labels();measure();new ResizeObserver(measure).observe(header);new ResizeObserver(measure).observe(nav);
    new MutationObserver(labels).observe(document.documentElement,{attributes:true,attributeFilter:['lang']});
    // Modules can render their own title again when language or result state changes.
    new MutationObserver(labels).observe(header.querySelector('h1'),{childList:true,subtree:true,characterData:true});
  },{once:true});
})();

/* User-only presentation. Pinned business engines, inputs and output rules are untouched. */
(() => {
 'use strict';
 if(window.__ECUSS_SUITE__?.profile!=='user')return;
 const words={
  ko:{vn:'등록된 기준으로 PSR을 검토합니다. 지원하지 않는 조건은 판정을 보류합니다. 최종 원산지 충족 여부는 근거와 증빙을 확인하세요.',kr:'KR 비율 계산을 제공합니다. 품목별 충족·불충족 판정과 증빙 심사는 제공하지 않습니다.'},
  en:{vn:'Review PSR using the registered criteria. Unsupported conditions remain pending. Check the source rules and evidence before confirming origin qualification.',kr:'KR ratio calculation is available. Product-specific pass/fail decisions and evidence verification are not provided.'},
  vi:{vn:'Kiểm tra PSR theo tiêu chí đã đăng ký. Điều kiện chưa được hỗ trợ vẫn chưa kết luận. Kiểm tra quy tắc gốc và chứng từ trước khi xác nhận xuất xứ.',kr:'Cung cấp tính tỷ lệ KR. Không kết luận đạt/không đạt theo sản phẩm và không thẩm định chứng từ.'}
 };
 const hide=el=>{if(el){el.dataset.suiteManagement='';el.style.setProperty('display','none','important');}};
 function psr(doc,region,lang){
  if(!doc?.body||!doc.querySelector('section.notice'))return;
  hide(doc.querySelector('body>h1'));hide(doc.querySelector('section.notice'));
  if(region==='VN'){
   doc.querySelectorAll('body>p').forEach(hide);
   hide(doc.querySelector('body>section:last-of-type > p:not([id])'));
  }
  let notice=doc.getElementById('suite-user-psr-scope');
  if(!notice){notice=doc.createElement('section');notice.id='suite-user-psr-scope';notice.className='notice';doc.querySelector('section.notice').after(notice);}
  const text=(words[lang]||words.ko)[region.toLowerCase()];if(notice.textContent!==text)notice.textContent=text;
 }
 window.EcussUserPresentation={psr};
 window.addEventListener('DOMContentLoaded',()=>{
  const id=window.__ECUSS_DESKTOP_CONTEXT__?.moduleId;
  const sections=[...document.querySelectorAll('section')];
  if(id==='stock-status-amovina'){
   for(const section of sections){
    const heading=section.querySelector(':scope>h2,:scope>b')?.textContent||'';
    if(/^검토본 (17|19) 수정 사항$/.test(heading))section.remove();
    if(heading.startsWith('REVIEW18')||heading==='이번 검토본 보완 내용')section.remove();
   }
   // Remove only the duplicate introduction; retain all lower disclosure guidance.
   const intro=document.querySelector('body>main>.notice');
   if(intro?.textContent.trim().startsWith('창고 최초 취합:')&&!intro.querySelector('input,button,select,textarea'))intro.remove();
   for(const summary of document.querySelectorAll('summary')){
    if(summary.textContent==='현재 적용 지침')summary.textContent='담당자별 반영 범위';
    if(summary.textContent==='WIP 적용 지침')summary.textContent='WIP 반영 범위와 주의사항';
    if(summary.textContent==='사용 방법과 테스트 범위'){
     summary.textContent='사용 방법';
     const paragraphs=summary.parentElement.querySelectorAll('p');
     paragraphs[0].textContent='파일은 이 PC에서 처리합니다. 원본을 덮어쓰지 않고 결과 파일을 따로 저장합니다.';
     for(const p of paragraphs)if(p.textContent.startsWith('제공된 양식의 .xlsx'))p.textContent='제공된 양식의 .xlsx, 파일별 최대 80MB. 결과 Excel을 열어 전체 재계산 후 수량과 서식을 확인하세요. JSZip 3.10.1 (MIT).';
    }
   }
   for(const p of document.querySelectorAll('p')){if(p.textContent.includes('현재 담당자별 누적/1:1 교체 규칙은 향후 업무 변경에 맞춰 수정할 수 있습니다.'))p.textContent=p.textContent.replace('현재 담당자별 누적/1:1 교체 규칙은 향후 업무 변경에 맞춰 수정할 수 있습니다.','');}
   document.querySelector('footer')?.remove();
  }
  if(id==='stock-status-amogreen-vina'){
   for(const summary of document.querySelectorAll('summary')){
    if(summary.textContent==='검증 기록 및 확인 범위')summary.parentElement.remove();
    if(summary.textContent==='적용 규칙과 검토 방법'){
     summary.textContent='사용 방법과 확인사항';
     const rules=summary.parentElement.querySelector('.rules');
     rules.innerHTML=rules.innerHTML.replace('외주 입출고 두 시트는 지침 확정 후 활성화합니다.','외주 입출고 두 시트는 처리 대상에서 제외하며 기존 내용을 보존합니다.').replace('아모그린비나 전용 V1.0.5 확정본입니다. ','').replace(' 전체 지침과 변경 이력은 전용 저장소에서 관리합니다.','');
    }
   }
   for(const el of document.querySelectorAll('span,p,small,strong,b'))if(el.childElementCount===0&&el.textContent==='지침 보류')el.textContent='처리 대상 아님';
   for(const p of document.querySelectorAll('p.note'))if(p.textContent.includes('지침 보류 중인'))p.textContent=p.textContent.replace('지침 보류 중인','처리 대상에서 제외된');
   const title=document.querySelector('#results .result-head h2');if(title)title.textContent='결과 파일이 준비되었습니다';
   document.querySelector('footer')?.remove();
  }
  if(id==='monthly-report-consolidation'){
   const guide=document.getElementById('guide');
   if(guide){
    const walker=document.createTreeWalker(guide,NodeFilter.SHOW_TEXT);let node;
    while((node=walker.nextNode()))node.nodeValue=node.nodeValue.replace('이 검토본은 제공된 6개 시트 양식을 대상으로 합니다.','제공된 6개 시트 양식을 사용하세요.').replace('Glass Workspace 참고: TRADE-OPERATIONS-SUITE / docs/MODULE_UI_STANDARD_KO.md · ','');
   }
  }
  if(id==='customs-inspection-cost-comparison')hide(document.querySelector('header>small'));
  if(id==='balance-ecuss')hide(document.getElementById('ecuss-provenance'));
 },{once:true});
})();

/* Common language controls. Business translations remain owned by module sources. */
(() => {
 'use strict';
 const codes=['ko','en','vi'], names={ko:'한국어',en:'English',vi:'Tiếng Việt'};
 const controls={'balance-ecuss':'#language-select','balance-sheet-validation':'#lang','vn-kr-customs-translation':'#language','customs-inspection-cost-comparison':'#suite-tool-language','psr-rvc-lvc-calculator':'#suite-tool-language'};
 const pending=new Set(['shipping-freight-review','machine-information-validation','stock-status-amovina','stock-status-amogreen-vina','monthly-report-consolidation','stock-dashboard']);
 const copy={ko:{label:'언어',busy:'처리가 끝난 뒤 언어를 변경해 주세요.',partial:'이 모듈의 본문과 업무 안내는 현재 한국어로만 제공됩니다. 공통 메뉴의 언어만 변경됩니다.',error:'모듈의 언어를 변경하지 못했습니다.'},en:{label:'Language',busy:'Change the language after the current task finishes.',partial:'This module’s content and business messages are currently in Korean. Only the common menus change language.',error:'Could not change the module language.'},vi:{label:'Ngôn ngữ',busy:'Đổi ngôn ngữ sau khi tác vụ hiện tại hoàn tất.',partial:'Nội dung và thông báo nghiệp vụ của mô-đun hiện chỉ có tiếng Hàn. Chỉ menu chung được đổi ngôn ngữ.',error:'Không đổi được ngôn ngữ mô-đun.'}};
 const moduleId=()=>window.__ECUSS_DESKTOP_CONTEXT__?.moduleId;
 const current=()=>codes.includes(document.documentElement.lang)?document.documentElement.lang:'ko';
 const sourceAPI=()=>window.EcussModuleI18n;
 const completeAPI=()=>codes.every(c=>sourceAPI()?.languages?.includes(c))&&typeof sourceAPI()?.setLanguage==='function';
 function availability(lang){
  const partial=pending.has(moduleId())&&!completeAPI();
  let notice=document.getElementById('ecuss-language-availability');
  if(!partial||lang==='ko'){notice?.remove();return;}
  if(!notice){notice=document.createElement('p');notice.id='ecuss-language-availability';notice.dataset.ecussDesktop='';notice.setAttribute('role','status');notice.style.cssText='margin:0;padding:12px 24px;background:#fff5e8;color:#743b0b;font:14px/1.5 Segoe UI,sans-serif';document.body.prepend(notice);}
  notice.lang=lang;notice.textContent=copy[lang].partial;
 }
 function setLanguage(lang,{initial=false}={}){
  if(!codes.includes(lang))return false;
  const id=moduleId(),control=document.querySelector(id?(controls[id]||'#ecuss-no-language-control'):'#language');
  if(!initial&&(window.EcussDesktopState?.().busy||control?.disabled)){message(copy[current()].busy);return false;}
  if(completeAPI()){
   sourceAPI().setLanguage(lang);
  }else if(control){
   if(control.value!==lang||current()!==lang){control.value=lang;control.dispatchEvent(new Event('change',{bubbles:true}));}
  }else if(['materials-info','materials-shipping'].includes(id)){
   if(window.ShippingI18n?.lang!==lang)document.querySelector('.languages [data-lang="'+lang+'"]')?.click();
  }else if(pending.has(id)){
   document.querySelectorAll('body>main,body>header,.shell>main').forEach(el=>el.lang='ko');
   document.documentElement.lang=lang;
  }else return false;
  if(current()!==lang){message(copy[current()].error);return false;}
  if(window.__ECUSS_SUITE__)window.__ECUSS_SUITE__.lang=lang;
  window.EcussStock?.refreshLanguage?.();availability(lang);refresh();return true;
 }
 function message(text){const el=document.getElementById('ecuss-language-status');if(el)el.textContent=text;}
 function refresh(){
  const bar=document.getElementById('ecuss-language-toolbar');if(!bar)return;
  const lang=current();bar.lang=lang;bar.setAttribute('aria-label',copy[lang].label);bar.querySelector('.ecuss-language-label').textContent=copy[lang].label;
  bar.querySelectorAll('[data-suite-lang]').forEach(b=>b.setAttribute('aria-pressed',String(b.dataset.suiteLang===lang)));
  message('');availability(lang);
 }
 function hideControl(el){
  if(!el)return;const group=el.closest('label,.language-picker,.languages');(group||el).classList.add('ecuss-source-language');
 }
 function install(){
  if(!window.EcussDesktop||window.__VALIDATION_VIEWER__||document.getElementById('ecuss-language-toolbar'))return;
  const id=moduleId(),header=document.querySelector(id?(id==='stock-dashboard'?'.shell>main':'body>header'):'.top-inner');if(!header)return;
  const bar=document.createElement('div');bar.id='ecuss-language-toolbar';bar.dataset.ecussDesktop='';bar.setAttribute('role','group');
  const label=document.createElement('span');label.className='ecuss-language-label';bar.append(label);
  for(const [code,short]of [['ko','KR'],['en','EN'],['vi','VN']]){const b=document.createElement('button');b.type='button';b.dataset.suiteLang=code;b.textContent=short;b.title=names[code];b.setAttribute('aria-label',names[code]);b.addEventListener('click',()=>{try{setLanguage(code);}catch{message(copy[current()].error);}});bar.append(b);}
  const status=document.createElement('span');status.id='ecuss-language-status';status.setAttribute('role','status');status.setAttribute('aria-live','polite');bar.append(status);
  const style=document.createElement('style');style.dataset.ecussDesktop='';style.textContent='.ecuss-source-language{display:none!important}#ecuss-language-toolbar{display:flex;align-items:center;justify-content:flex-end;flex-wrap:wrap;gap:5px;margin:0 0 10px;flex-basis:100%;font:13px/1.4 Segoe UI,Malgun Gothic,sans-serif;color:#52637d}#ecuss-language-toolbar .ecuss-language-label{margin-right:5px}#ecuss-language-toolbar button{appearance:none;min-width:42px;min-height:32px;padding:5px 10px;margin:0;border:1px solid #d8e2f4;border-radius:8px;background:#fff;color:#425773;font:600 12px/1.4 Segoe UI,sans-serif;cursor:pointer}#ecuss-language-toolbar button[aria-pressed=true]{background:#4260da;border-color:#4260da;color:#fff}#ecuss-language-toolbar button:focus-visible{outline:3px solid #2278e6;outline-offset:3px}#ecuss-language-status:empty{display:none}#ecuss-language-status{flex-basis:100%;font-size:12px;color:#975527}.top-inner>#ecuss-language-toolbar{flex-basis:auto;margin:0}@media print{#ecuss-language-toolbar{display:none}}@media(forced-colors:active){#ecuss-language-toolbar button{background:ButtonFace;color:ButtonText;border:1px solid ButtonText}#ecuss-language-toolbar button[aria-pressed=true]{background:Highlight;color:HighlightText;border-color:Highlight}}';document.head.append(style);
  if(id){header.prepend(bar);hideControl(document.querySelector(controls[id]||'#ecuss-no-language-control'));if(id==='customs-inspection-cost-comparison')hideControl(document.getElementById('language'));if(['materials-info','materials-shipping'].includes(id))hideControl(document.querySelector('.languages'));}
  else{hideControl(document.getElementById('language'));header.append(bar);}
  refresh();new MutationObserver(refresh).observe(document.documentElement,{attributes:true,attributeFilter:['lang']});
 }
 window.EcussLanguage={setLanguage,getLanguage:current,install};
 window.addEventListener('load',install,{once:true});
})();
