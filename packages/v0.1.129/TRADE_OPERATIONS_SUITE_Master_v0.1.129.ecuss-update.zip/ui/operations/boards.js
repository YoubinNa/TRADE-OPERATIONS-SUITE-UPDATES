function workL(ko,en,vi){return inLanguage(ko,en,vi);}
function reviewPanel(id,body){
  const target=widgets[id].target;
  return `<article class="panel widget-${id}${id==='imex'?' export-panel':''}" aria-labelledby="title-${id}" data-widget="${id}"${target?' data-panel-target="'+target+'"':''}>${body}</article>`;
}

function stockItemName(group){
  if(group.other)return workL('그 외','Other','Còn lại');
  return group.item||workL('ITEM 미기재','Unspecified item','Chưa ghi ITEM');
}

function inventoryCompanyRow(co,summary){
  const {excess,short,items}=summary,total=excess+short;
  const top=items.slice(0,3),segments=[...top];
  if(items.length>3){
    const rest=items.slice(3).reduce((sum,g)=>({excess:sum.excess+g.excess,short:sum.short+g.short,value:sum.value+g.value}),{excess:0,short:0,value:0});
    segments.push({...rest,other:true});
  }
  const amount=value=>fmt(value,{maximumFractionDigits:0});
  const breakdown=group=>`${stockItemName(group)} · ${fmt(group.value)} USD (${fmt(group.value/total,{style:'percent',maximumFractionDigits:1})}) · ${tr('과잉')} ${fmt(group.excess)} / ${tr('부족')} ${fmt(group.short)} USD`;
  const band=segments.map((group,i)=>{
    const width=100*group.value/total,excessWidth=100*group.excess/group.value;
    const percent=width<1?'&lt;1%':fmt(width,{maximumFractionDigits:0})+'%';
    const rank=group.other?'':`<i class="stock-rank-num">${i+1}</i>`;
    return `<span class="stock-piece" style="width:${width}%" title="${escapeText(breakdown(group))}"><span class="stock-split"><i class="excess" style="width:${excessWidth}%"></i><i class="shortage" style="width:${100-excessWidth}%"></i></span><span class="stock-piece-note">${rank}<span class="stock-piece-name">${escapeText(stockItemName(group))}</span><b>${percent}</b></span></span>`;
  }).join('');
  const ranks=top.map((g,i)=>`<span class="stock-rank-item" title="${escapeText(breakdown(g))}"><i class="stock-rank-num">${i+1}</i><b>${escapeText(stockItemName(g))}</b><small>${amount(g.value)}</small></span>`).join('');
  const company=companies[co],description=`${company} · ${tr('과잉')} ${fmt(excess)} USD · ${tr('부족')} ${fmt(short)} USD`;
  const accessible=[description,...segments.map(breakdown)].join('. ');
  return `<button type="button" class="stock-line" data-stock-company="${co}" data-open="stock-dashboard" aria-label="${escapeText(accessible)}"><span class="stock-line-heading"><b>${company}</b><span><i class="dot excess"></i>${tr('과잉')} ${amount(excess)}</span><span><i class="dot shortage"></i>${tr('부족')} ${amount(short)}</span></span><span class="stock-track" aria-hidden="true">${band}</span>${ranks?`<span class="stock-rank">${ranks}</span>`:''}</button>`;
}

function workInventoryPanel(){
  const entries=Object.entries(live.stock).filter(([,v])=>v.data).map(([co,v])=>[co,v.data]);
  const total=entries.reduce((sum,[,v])=>sum+v.excess+v.short,0);
  const title=panelHead('inventory',workL('법인별 재고 금액','Inventory by company','Giá trị tồn kho theo công ty'),infoButton('inventory','과부족 금액 기준과 표'));
  const complete=entries.length===2&&entries.every(([,v])=>!v.missing);
  const totalLabel=complete?tr('전체 과부족 금액'):workL('확인된 과부족 금액','Verified variance amount','Giá trị chênh lệch đã xác nhận');
  const heading=entries.length?`<div class="stock-total"><span>${totalLabel}</span><strong>${fmt(total)} <small>USD</small></strong></div>`:'';
  return reviewPanel('inventory',title+`<div class="stock-viz">${heading}<div class="stock-lines">${Object.entries(live.stock).map(([co,v])=>v.data?inventoryCompanyRow(co,v.data)+staleNote(v):companyMessage(co,v)).join('')}</div></div>`);
}

function logisticsPeriod(year,months){
  if(!months.length)return String(year);
  const a=months[0].month,b=months.at(-1).month;
  if(a===b)return workL(`${year}년 ${a}월`,`${monthShort(a)} ${year}`,`Tháng ${a}/${year}`);
  return workL(`${year}년 ${a}–${b}월`,`${monthShort(a)}–${monthShort(b)} ${year}`,`Tháng ${a}–${b}/${year}`);
}

function workLogisticsPanel(){
  const {year,months}=live.cost.data||{year:'',months:[]},last=months.at(-1);
  const title=panelHead('logistics',[tr('베트남 물류비'),logisticsPeriod(year,months)].filter(Boolean).join(' · '),infoButton('logistics','월별 물류비 내역'));
  if(!last)return reviewPanel('logistics',title+panelMessage(live.cost));
  const previous=months.find(r=>r.month===last.month-1);
  const delta=previous?.cost>0?(last.cost/previous.cost-1)*100:null;
  const deltaText=delta===null?'':(delta>=0?'+':'')+fmt(delta,{minimumFractionDigits:1,maximumFractionDigits:1})+'%';
  const change=delta===null?monthShort(last.month):workL(`${last.month}월 · 전월 대비 ${deltaText}`,`${monthShort(last.month)} · ${deltaText} vs. prior month`,`Tháng ${last.month} · ${deltaText} so với tháng trước`);
  const costName=workL('물류비','Cost','Chi phí'),caseName=workL('처리 건수','Shipments','Số lô');
  const ko=state.lang==='ko',divisor=ko?1e8:1e6,digits=ko?2:1;
  const unit=workL('억 VND','M VND','triệu VND');
  const compactCost=value=>fmt(value/divisor,{minimumFractionDigits:digits,maximumFractionDigits:digits});
  const fullLabel=m=>`${monthShort(m.month)} · ${costName} ${fmt(m.cost)} VND · ${caseName} ${fmt(m.cases)}`;
  const costs=months.map(m=>m.cost);
  const costMin=Math.min(0,Math.floor(Math.min(...costs)/2e8)*2e8);
  const costMax=Math.max(2e8,Math.ceil(Math.max(...costs)/2e8)*2e8);
  const countMax=Math.max(10,Math.ceil(Math.max(...months.map(m=>m.cases))/10)*10);
  const w=480,x=i=>(i+.5)*w/months.length,y=(v,lo,hi)=>96-81*(v-lo)/(hi-lo);
  const barWidth=Math.min(26,w/months.length*.48);
  const bars=months.map((m,i)=>`<rect class="case-bar" data-cases="${m.cases}" x="${x(i)-barWidth/2}" y="${y(m.cases,0,countMax)}" width="${barWidth}" height="${96-y(m.cases,0,countMax)}" rx="2.5"><title>${fullLabel(m)}</title></rect>`).join('');
  const line=months.map((m,i)=>`${i?'L':'M'} ${x(i)} ${y(m.cost,costMin,costMax)}`).join(' ');
  const dots=months.map((m,i)=>`<circle class="cost-dot" cx="${x(i)}" cy="${y(m.cost,costMin,costMax)}" r="2.8"><title>${fullLabel(m)}</title></circle>`).join('');
  const labels=months.map((m,i)=>`<span class="cost-value" style="left:${100*(i+.5)/months.length}%;top:${y(m.cost,costMin,costMax)}%" title="${fullLabel(m)}">${compactCost(m.cost)}</span>`).join('');
  const calendar=months.map(m=>`<span class="combo-month" role="img" aria-label="${fullLabel(m)}" title="${fullLabel(m)}"><span>${monthShort(m.month)}</span><b class="case-value">${fmt(m.cases)}<small>${workL('건','',' lô')}</small></b></span>`).join('');
  const keys=`<div class="combo-keys"><span><i class="line-key"></i>${costName} · ${unit}</span><span><i class="bar-key"></i>${caseName}</span></div>`;
  const ticks=n=>n===0?'0':workL(fmt(n/1e8)+'억',fmt(n/1e6)+'M',fmt(n/1e6)+'tr');
  const axis=(max,mid,min)=>`<div class="combo-axis" aria-hidden="true"><span>${max}</span><span>${mid}</span><span>${min}</span></div>`;
  const grid=[15,55.5,96].map(v=>`<line x1="0" x2="${w}" y1="${v}" y2="${v}"/>`).join('');
  const name=workL('월별 물류비 추이와 처리 건수','Monthly logistics costs and shipment counts','Chi phí logistics và số lô theo tháng');
  const svg=`<svg viewBox="0 0 ${w} 100" preserveAspectRatio="none" role="img" aria-label="${name}"><g class="combo-grid">${grid}</g>${bars}<path class="cost-line" d="${line}" fill="none" stroke-width="2.5" vector-effect="non-scaling-stroke"/>${dots}</svg>`;
  return reviewPanel('logistics',title+staleNote(live.cost)+`<div class="cost-metric"><strong>${compactCost(last.cost)}<small>${unit}</small></strong><span class="cost-change">${change}</span></div>${keys}<div class="combo-scroller"><div class="combo-chart" style="--months:${months.length};--plot-min:${months.length*35}px">${axis(ticks(costMax),ticks((costMin+costMax)/2),ticks(costMin))}<div class="combo-plot">${svg}<div class="cost-labels" aria-hidden="true">${labels}</div></div>${axis(fmt(countMax),fmt(countMax/2),'0')}<div class="combo-months">${calendar}</div></div></div>`);
}
