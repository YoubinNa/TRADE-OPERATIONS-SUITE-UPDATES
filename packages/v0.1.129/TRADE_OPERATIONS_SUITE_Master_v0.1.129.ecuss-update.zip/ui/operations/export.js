const tradeColors=(()=>{
const itemHues = [278, 47, 151, 222, 98, 219, 187, 266, 8, 326, 127, 351,
    311, 202, 63, 243, 18, 84, 291, 170, 32, 12, 194];
const otherColor = '#798694';
  function itemColor(item) {
    // Hash only the ITEM so companies, dates and ranking order share the same color key.
    let hash = 2166136261;
    for (const char of item ?? '') hash = Math.imul(hash ^ char.codePointAt(0), 16777619);
    hash = hash >>> 0;
    const hue = itemHues[hash % itemHues.length] + (hash >>> 8) % 9 - 4;
    const saturation = 60 + (hash >>> 16) % 18;
    const lightness = (hue >= 205 && hue <= 300 ? 46 : 35) + (hash >>> 24) % 10;
    return `hsl(${hue}, ${saturation}%, ${lightness}%)`;
  }
return {item:itemColor,other:otherColor};})();
// The home area keeps its stable layout id so saved positions and visibility carry over.
const tradeModuleId='import-export-performance';
widgets.imex={name:'임가공 수출 실적',type:'법인별 임가공비 · ITEM TOP 3',icon:'globe',target:tradeModuleId};
addTerms('임가공 수출 실적|Contract processing exports|Kết quả xuất khẩu gia công\n임가공 수출 실적 집계 기준|How contract processing exports are calculated|Cách tính kết quả xuất khẩu gia công\n법인별 임가공비 · ITEM TOP 3|Processing fees by company · Top 3 items|Phí gia công theo công ty · Top 3 mặt hàng\n두 법인의 수출·물류비·재고와 검증 현황|Exports, logistics costs, inventory and checks across both companies|Xuất khẩu, chi phí logistics, tồn kho và kiểm tra của hai công ty');
const exportPeriods=new Map();
const exportMode=()=>exportPeriods.get(state.user)||'month';
function exportFees(selected,range){
  const summary=TradeReport.summarize(selected,range),ranked=TradeReport.ranking(summary,'fee');
  if(ranked.sum===null)return {pending:true,buckets:[]};
  const format=units=>TradeReport.money(units,summary.scale).replaceAll(',','').replace(/^−/,'-');
  const top=ranked.display.slice(0,3);
  const rest=summary.total.fee-top.reduce((sum,g)=>sum+g.fee,0n);
  const buckets=top.map(g=>({item:g.item,fee:g.fee})).concat({other:true,fee:rest}).map(g=>({
    item:g.item,other:g.other,usd:format(g.fee),
    share:!ranked.negative&&ranked.sum>0n?Number(g.fee*1000000n/ranked.sum)/10000:0
  }));
  return {total:format(summary.total.fee),buckets,empty:top.length===0};
}
function exportPeriodText(mode){
  const range=TradeReport.bounds(mode,anchorDate()),locale=localeTags[state.lang];
  const date=key=>new Date(key+'T00:00:00Z');
  const formatter=new Intl.DateTimeFormat(locale,{timeZone:'UTC',year:'numeric',month:mode==='month'?'long':'short',...(mode==='week'?{day:'numeric'}:{})});
  return mode==='month'?formatter.format(date(range.from)):formatter.formatRange(date(range.from),date(range.to));
}
function exportComparison(mode){
  const range=TradeReport.bounds(mode,anchorDate());
  return ['amo','agv'].map(co=>{
    const record=live.trade[co];
    const group=record.data?exportFees(record.data,range):null;
    const itemName=b=>b.other?workL('그 외','Other','Còn lại'):b.item||workL('ITEM 미기재','Unspecified item','Chưa ghi ITEM');
    const usd=v=>new Intl.NumberFormat(localeTags[state.lang],{maximumFractionDigits:2}).format(v);
    const color=b=>b.other?tradeColors.other:tradeColors.item(b.item);
    const band=(group?.buckets||[]).map(b=>'<i style="background:'+color(b)+';flex-grow:'+b.share+'" title="'+escapeText(itemName(b)+' · '+usd(b.usd)+' USD')+'"></i>').join('');
    const unit='<small class="currency-unit">USD</small>';
    const lines=(group?.buckets||[]).map(b=>{
      const name=escapeText(itemName(b));
      return '<li><i style="background:'+color(b)+'" aria-hidden="true"></i><span title="'+name+'">'+name+'</span><b>'+usd(b.usd)+'</b>'+unit+'</li>';
    }).join('');
    const label=companies[co]+' · '+tr(widgets.imex.name)+' · '+exportPeriodText(mode);
    const heading='<h3><button type="button" class="export-open" data-open="'+tradeModuleId+'" aria-label="'+escapeText(label)+'">'+companies[co]+'</button></h3>';
    const result=!group?panelMessage(record):group.pending?'<p class="export-empty">'+workL('임가공비 자료 확인 필요','Processing fee data incomplete','Cần kiểm tra phí gia công')+'</p>':'<strong class="export-total" data-total="'+group.total+'">'+usd(group.total)+' '+unit+'</strong>'+(group.empty?'<p class="export-empty">'+workL('기간 내 수출 거래 없음','No exports in this period','Không có giao dịch xuất trong kỳ')+'</p>':'<div class="export-band" aria-hidden="true">'+band+'</div><ol class="export-ranks">'+lines+'</ol>');
    return '<section class="export-company" data-export-company="'+co+'" aria-label="'+companies[co]+'">'+heading+result+staleNote(record)+'</section>';
  }).join('');
}
function exportPanel(){
  const mode=exportMode(),group=workL('두 법인의 조회 기간','Reporting period for both companies','Kỳ báo cáo của hai công ty');
  const labels=workL(['월','주'],['Mo','Wk'],['Tháng','Tuần']);
  const types=workL(['월간','주간'],['Monthly','Weekly'],['Theo tháng','Theo tuần']);
  const buttons=['month','week'].map((key,i)=>'<button type="button" data-export-period="'+key+'" aria-label="'+types[i]+'" title="'+types[i]+'" aria-pressed="'+(key===mode)+'" aria-controls="export-comparison">'+labels[i]+'</button>').join('');
  const fee=workL('임가공비','Processing fees','Phí gia công');
  const info=tr('임가공 수출 실적 집계 기준');
  const controls='<div class="export-tools"><div class="export-switch" role="group" aria-label="'+group+'">'+buttons+'</div>'+infoButton('export-fees',info)+'</div>';
  const head=panelHead('imex',fee+' · USD',controls);
  const caption='<div class="export-line"><span>'+workL('ITEM TOP 3 · 그 외','Top 3 items · Other','Top 3 mặt hàng · Còn lại')+'</span><time class="export-period-date">'+exportPeriodText(mode)+'</time></div>';
  return reviewPanel('imex',head+caption+'<div class="export-comparison" id="export-comparison" aria-live="polite" aria-atomic="true">'+exportComparison(mode)+'</div>');
}
document.addEventListener('click',event=>{
  const button=event.target.closest('button[data-export-period]');
  if(!button)return;
  const mode=button.dataset.exportPeriod;
  if(!['month','week'].includes(mode)||mode===exportMode())return;
  exportPeriods.set(state.user,mode);
  const panel=button.closest('[data-widget="imex"]');
  panel.querySelectorAll('[data-export-period]').forEach(b=>b.setAttribute('aria-pressed',String(b.dataset.exportPeriod===mode)));
  panel.querySelector('.export-period-date').textContent=exportPeriodText(mode);
  panel.querySelector('.export-comparison').innerHTML=exportComparison(mode);
});
