const main = document.querySelector('#main');
const side = document.querySelector('#side');
const dialog = document.querySelector('#dialog');
const prefs=new Map();
const state={user:suite.profile,scene:'home',category:'all',destination:null,modal:null,draft:null,searchIndex:0};
let currentModule=null;
const readPref=(key,fallback)=>prefs.has(key)?prefs.get(key):fallback;
async function writePref(key,value){
  prefs.set(key,value);
  try{await host.savePreference(key,value);return true;}catch{return false;}
}
const userName=()=>suite.profile==='master'?'Master':'User';
const sceneTitle=id=>id==='favorites'?'즐겨찾기':getGroup(id)?.name||'홈';
const layoutKey=()=> 'layout';
function defaults(scene) {
  const config=sceneWidgets[scene];
  const defaultSlots={imex:0,logistics:1,inventory:2,balanceStatus:3,customsStatus:3,reconcile:4,container:5,shipping:6,inspection:7,outputs:8,...DATA.homeSlots};
  return config.eligible.map(id=>({id,slot:defaultSlots[id],visible:config.on.includes(id)}));
}
function savedLayout() {
  const base=defaults(state.scene);
  let stored=readPref(layoutKey(),null);
  if(Array.isArray(stored)&&stored.every(r=>r&&typeof r==='object')&&stored.some(r=>r.id==='checks')){
    const oldOrder=['imex','reconcile','logistics','container','shipping','inspection','outputs','checks'];
    if(oldOrder.every((id,i)=>stored.some(r=>r.id===id&&r.slot===i&&r.visible===(i<4))))return base;
    const check=stored.find(r=>r.id==='checks');
    stored=stored.filter(r=>r.id!=='checks').concat(['balanceStatus','customsStatus'].map(id=>({...check,id})));
    if(!stored.some(r=>r.id==='inventory'))stored.push({id:'inventory',slot:8,visible:false});
  }
  if (!Array.isArray(stored)||stored.length!==base.length) return base;
  const slots=new Map();
  for (const {id} of base) {
    const r=stored.find(x=>x && x.id===id);
    if (!r||typeof r.visible!=='boolean'||!Number.isInteger(r.slot)||r.slot<0||r.slot>=base.length+(base.length%2))return base;
    if(slots.has(r.slot)&&!(isVerification(id)&&isVerification(slots.get(r.slot))))return base;
    slots.set(r.slot,id);
  }
  return base.map(({id})=>{const {slot,visible}=stored.find(r=>r.id===id);return {id,slot,visible}});
}
const favorites=()=>host.favorites();
let messageTimer;
function toast(text) {
  const el=document.querySelector('#toast');
  el.textContent=tr(text);el.classList.add('on');
  clearTimeout(messageTimer);messageTimer=setTimeout(()=>el.classList.remove('on'),2600);
}
const navButton = (id, label, icon, count='') => '<button class="nav-button'+(state.scene===id?' active':'')+'" data-scene="'+id+'"'+(state.scene===id?' aria-current="page"':'')+'>'+glyph(icon)+'<span>'+label+'</span>'+(count!==''?'<small>'+count+'</small>':'')+'</button>';
function applyReadingScale(){document.documentElement.dataset.textSize=state.textSize;host.appearance(state.theme,state.textSize);}
function renderChrome() {
  side.innerHTML='<div class="brand"><button class="brand-home" data-scene="home" aria-label="메인 화면으로"><span class="brand-mark">'+glyph('container')+'</span><span class="brand-type"><strong>Trade Operations</strong><small>무역 업무 통합 프로그램</small></span></button><button class="nav-close icon-button" data-close-nav aria-label="업무 탐색 닫기">'+glyph('x')+'</button></div>'
    +'<div class="side-content"><nav aria-label="메인 메뉴">'+navButton('home',tr('홈 화면'),'house')+'<div class="nav-divider" aria-hidden="true"></div>'+DATA.groups.map(g=>navButton(g.id,g.name,g.icon)).join('')+'</nav></div>'
    +'<div class="side-bottom">'+preferenceControls()+'<button class="settings-link" data-settings>'+glyph('settings-2')+' 업데이트 · 설정</button><div class="profile"><span class="avatar">'+userName()[0]+'</span><div><span>개인 작업 공간</span><strong>'+userName()+'</strong></div></div></div>';
  const trail=state.scene==='home'?'':glyph('chevron-right')+'<b>'+sceneTitle(state.scene)+'</b>';
  document.querySelector('#bar').innerHTML='<button class="icon-button nav-open" data-menu aria-label="업무 탐색 열기" aria-controls="side" aria-expanded="false">'+glyph('menu')+'</button><div class="breadcrumb"><button class="home-link" data-scene="home" aria-label="홈으로 돌아가기">'+glyph('square-stack')+'홈</button>'+trail+'</div>'+''+'<div class="top-actions"><button class="search-trigger" data-search-open>'+glyph('search')+'<span>업무 또는 자료 검색</span><kbd>Ctrl K</kbd></button><button class="icon-button favorite-shortcut" data-scene="favorites" title="즐겨찾기" aria-label="즐겨찾기">'+glyph('star')+'</button><button class="sample-pill" data-refresh><i></i>새로고침</button></div>';
  localizeNode(side);localizeNode(document.querySelector('#bar'));
}
function dependencyGrid(layout) {
  const active=layout.filter(x=>x.visible).sort((a,b)=>a.slot-b.slot);
  if(!active.length) return '<div class="no-panels">'+glyph('panel-top')+'<span>표시할 요약을 선택하세요.</span><button class="text-link" data-edit>현황판 편집 '+glyph('chevron-right')+'</button></div>';
  const rows=Array.from({length:Math.floor(active.at(-1).slot/2)+1},()=>[]);
  for(const widget of active)rows[Math.floor(widget.slot/2)].push(widget);
  const content=rows.map((entries,row)=>{
    if(!entries.length)return '<div class="summary-row reserved-row" data-gridrow="'+row+'" aria-hidden="true"></div>';
    const occupied=[...new Set(entries.map(w=>w.slot))];
    const cells=occupied.map(slot=>{
      const here=entries.filter(w=>w.slot===slot);
      const area=here.length>1?'<div class="verification-stack">'+here.map(w=>widgetHtml(w.id)).join('')+'</div>':widgetHtml(here[0].id);
      return '<div class="cell '+(slot%2?'right':'left')+'" data-slot="'+slot+'">'+area+'</div>';
    });
    return '<div class="summary-row" data-gridrow="'+row+'">'+cells.join('')+'</div>';
  });
  const tracks=rows.map(entries=>entries.length?'1fr':'auto').join(' ');
  return '<section class="summary-area" aria-label="업무 요약" style="--summary-rows:'+tracks+'">'+content.join('')+'</section>';
}
function dataHeading(title, detail, action='') {
  return '<div class="page-heading"><div><h1>'+escapeText(title)+'</h1>'+(detail?'<p>'+detail+'</p>':'')+'</div>'+action+'</div>';
}
function renderPage() {
  drawPage();localizeNode(main);
}
function drawPage() {
  const scene=state.scene;
  if(scene==='favorites') {
    const ids=favorites();
    const count=inLanguage(userName()+'의 업무 '+ids.length+'개',userName()+' · '+ids.length+' saved',userName()+' · '+ids.length+' mục đã lưu');
    const order=ids.length>1?'<button class="button order-trigger" data-order-edit>'+tr('순서 편집')+'</button>':'';
    main.innerHTML=dataHeading(tr('즐겨찾기'),count,order)+(ids.length?directoryList({id:'favorites',name:'즐겨찾기',ids},false):'<div class="empty-large">'+glyph('star')+'<h2>즐겨찾는 업무를 추가하세요</h2><p>목록에서 별표를 누르면 여기에 모입니다.</p><button class="button primary" data-scene="tools">업무 도구로</button></div>');return;
  }
  if(directorySections[scene]){main.innerHTML=renderDirectory();return;}
  const edit='<button class="button primary" data-edit>'+glyph('sliders-horizontal')+'현황판 편집</button>';
  main.innerHTML=dataHeading('업무 현황판','두 법인의 수출·물류비·재고와 검증 현황',edit)+dependencyGrid(savedLayout());
}
function renderShell() {renderChrome();renderPage();if(currentModule)setModuleNavigation(currentModule);}
function hideNav(){
  document.body.classList.remove('nav-visible');document.querySelector('.nav-open')?.setAttribute('aria-expanded','false');document.querySelector('.nav-shade')?.remove();
}
function showNav(){
  if(document.body.classList.contains('nav-visible'))return;
  document.body.classList.add('nav-visible');document.querySelector('.nav-open')?.setAttribute('aria-expanded','true');
  const btn=document.createElement('button');btn.className='nav-shade';btn.dataset.closeNav='';btn.setAttribute('aria-label',tr('업무 탐색 닫기'));document.body.appendChild(btn);
  (side.querySelector('.nav-button.active')||side.querySelector('.nav-button'))?.focus();
}
function navigate(scene) {
  if(scene!=='home'&&scene!=='favorites'&&!getGroup(scene))return;
  if(!host.isHome()){host.backTo(scene).catch(()=>toast(tr('업무를 열 수 없습니다.')));return;}
  closeModal();hideNav();state.scene=scene;state.destination=null;renderShell();window.scrollTo(0,0);
  main.focus({preventScroll:true});if(scene==='home')loadHome();
}
function openModule(id,trigger){
  const co=trigger?.closest('[data-export-company],[data-stock-company]');
  const company=co?.dataset.exportCompany||co?.dataset.stockCompany;
  host.open(id,company?{company,period:exportMode(),anchor:anchorDate()}:null).catch(()=>toast(tr('업무를 열 수 없습니다.')));
}
async function toggleFavorite(id){try{await host.favorite(id);renderPage();}catch{toast(tr('설정을 저장하지 못했습니다.'));}}
function openModal(type, body, className='', remember=true) {
  const open=dialog.open;
  if(!open&&remember)state.opener=document.activeElement;
  state.modal=type;dialog.className=className;dialog.innerHTML=body;localizeNode(dialog);
  if(!open)dialog.showModal();
}
function closeModal() {
  if(dialog.open)dialog.close();
  state.modal=null;state.draft=null;state.orderDraft=null;
  if(state.opener?.isConnected)state.opener.focus({preventScroll:true});
  state.opener=null;
}
function modalHeader(title,subtitle='') {
  return '<div class="dialog-head"><div><h2 id="dialog-heading">'+title+'</h2>'+(subtitle?'<p>'+subtitle+'</p>':'')+'</div><button class="icon-button" data-close aria-label="닫기">'+glyph('x')+'</button></div>';
}
function slotTitle(slot) {
  const n=Math.floor(slot/2)+1, right=slot%2;
  return inLanguage(n+'행 '+(right?'오른쪽':'왼쪽'),'Row '+n+' · '+(right?'right':'left'),'Hàng '+n+' · '+(right?'phải':'trái'));
}
function beginEdit() {if(!sceneWidgets[state.scene])return;state.draft=savedLayout();drawEditor();}
function drawEditor() {
  const layout=state.draft;
  const slots=Array.from({length:layout.length+layout.length%2},(_,n)=>n);
  const list=layout.map(item=>{
    const w=widgets[item.id];
    return '<div class="setting-row"><label class="display-switch"><input type="checkbox" data-visible="'+item.id+'"'+(item.visible?' checked':'')+' aria-label="'+escapeText(inLanguage(w.name+' 표시','Show '+tr(w.name),'Hiển thị '+tr(w.name)))+'"><i></i></label><div class="setting-name"><b>'+w.name+'</b><small>'+w.type+'</small></div>'+selectMenu(inLanguage(w.name+' 위치','Position · '+tr(w.name),'Vị trí · '+tr(w.name)),'data-position="'+item.id+'"',slots.map(n=>[n,slotTitle(n)]),item.slot)+'</div>';
  }).join('');
  const board=slots.map(n=>{
    const items=layout.filter(r=>r.slot===n&&r.visible);
    return '<div class="layout-slot'+(items.length?' enabled':'')+'" data-drop="'+n+'"><small>'+slotTitle(n)+'</small>'+(items.length?items.map(item=>'<b draggable="true" data-drag="'+item.id+'">'+glyph(widgets[item.id].icon)+widgets[item.id].name+'</b>').join(''):'<span>빈 칸</span>')+'</div>';
  }).join('');
  openModal('editor',modalHeader('현황판 편집',userName()+' · '+tr('홈'))+'<div class="editor-body"><section><h3>표시할 항목 <small>'+layout.filter(x=>x.visible).length+' / '+layout.length+'</small></h3>'+list+'</section><section class="board"><h3>배치 미리보기</h3><div class="board-grid">'+board+'</div><p>끌어서 옮기거나 목록에서 위치를 선택하세요. 두 검증 현황을 같은 칸에 놓으면 함께 표시됩니다.</p></section></div><div class="dialog-foot"><button class="text-link" data-default>'+glyph('refresh-cw')+'기본 배치</button><span></span><button class="button secondary" data-close>취소</button><button class="button primary" data-save>'+glyph('check')+'배치 저장</button></div>','editor-modal');
}
function moveItem(id, slot) {
  if(!state.draft)return;
  const item=state.draft.find(x=>x.id===id), occupied=state.draft.filter(x=>x.slot===slot);
  if(!item||!Number.isInteger(slot)||slot<0||slot>=state.draft.length+state.draft.length%2||item.slot===slot)return;
  if(occupied.length&&!occupied.every(x=>isVerification(x.id)&&isVerification(id))){
    const leavingPartner=state.draft.some(x=>x!==item&&x.slot===item.slot);
    let destination=item.slot;
    if(leavingPartner){
      const used=new Set(state.draft.map(x=>x.slot));
      destination=0;while(used.has(destination))destination++;
    }
    occupied.forEach(x=>{x.slot=destination;});
  }
  item.slot=slot;
  drawEditor();
  dialog.querySelector('[data-position="'+id+'"]')?.focus({preventScroll:true});
}
async function saveLayout() {
  const persisted=await writePref(layoutKey(),state.draft.map(r=>({...r})));
  closeModal();renderPage();loadHome();main.querySelector('[data-edit]')?.focus({preventScroll:true});
  toast(persisted?inLanguage(userName()+'의 배치를 저장했습니다.','Layout saved for '+userName()+'.','Đã lưu bố cục cho '+userName()+'.'):tr('브라우저 저장 공간을 사용할 수 없어 이 창에서만 배치를 유지합니다.'));
}
function searchMatches(value) {
  const words=value.toLocaleLowerCase().trim().split(/\s+/).filter(Boolean);
  return DATA.groups.flatMap(g=>g.ids.map(findModule)).filter(m=>{const terms=[m.title,m.aliases,m.id,...Object.values(m.names||{}),...Object.values(m.descriptions||{}),tr(m.title),tr(m.description),m.input,m.output,tr(m.input),tr(m.output),m.keywords,getGroup(m.group).name,tr(getGroup(m.group).name)].join(' ').toLocaleLowerCase();return words.every(w=>terms.includes(w))});
}
function drawSearchList() {
  const input=dialog.querySelector('#query'), matches=searchMatches(input.value);
  state.searchIndex=Math.max(0,Math.min(state.searchIndex,matches.length-1));
  dialog.querySelector('#match-count').textContent=inLanguage(matches.length+'개 업무',matches.length+(matches.length===1?' tool':' tools'),matches.length+' công cụ');
  dialog.querySelector('#search-results').innerHTML=matches.length?matches.map((m,i)=>'<button id="hit-'+i+'" class="search-hit'+(i===state.searchIndex?' chosen':'')+'" data-open="'+m.id+'">'+glyph(m.icon)+'<b>'+escapeText(m.title)+'</b><small>'+getGroup(m.group).name+'</small>'+glyph('arrow-up-right')+'</button>').join(''):'<p class="no-results">찾는 업무가 없습니다. 다른 업무명이나 자료명을 입력하세요.</p>';
  localizeNode(dialog.querySelector('#search-results'));
}
function beginSearch() {
  if(!host.isHome()){host.backTo('home').then(beginSearch).catch(()=>toast(tr('업무를 열 수 없습니다.')));return;}
  if(dialog.open)closeModal();
  state.searchIndex=0;
  openModal('search',modalHeader('업무 검색','업무명, 약어 또는 입력 자료명으로 찾기')+'<div class="search-wrap">'+glyph('search')+'<input id="query" aria-label="업무 검색어" autocomplete="off" placeholder="예: 수책, 인보이스, UTM"><kbd>Esc</kbd></div><div class="search-cap" id="match-count" aria-live="polite"></div><div id="search-results"></div><div class="search-hint">↑ ↓ 이동 <span>Enter 열기</span></div>','search-modal');
  drawSearchList();dialog.querySelector('#query').focus();
}
function countLabel(n) {return state.lang==='ko'?fmt(n)+'건':fmt(n);}
function table(headers,rows) {
  return '<div class="table-scroll"><table><thead><tr>'+headers.map(v=>'<th scope="col">'+v+'</th>').join('')+'</tr></thead><tbody>'+rows.map(row=>'<tr>'+row.map(v=>'<td>'+v+'</td>').join('')+'</tr>').join('')+'</tbody></table></div>';
}
document.addEventListener('click',e=>{
  if(e.target===dialog){const r=dialog.getBoundingClientRect();if(e.clientX<r.left||e.clientX>r.right||e.clientY<r.top||e.clientY>r.bottom)closeModal();return;}
  const el=e.target.closest('button');
  if(!el){
    const panel=e.target.closest('[data-panel-target]');
    if(panel&&!e.target.closest('a,input,select,label,textarea,summary'))openModule(panel.dataset.panelTarget,e.target);
    return;
  }
  const d=el.dataset;
  if('scene' in d)navigate(d.scene);
  else if('lang' in d)chooseAppearance(d.lang,null);
  else if('themeChoice' in d)chooseAppearance(null,d.themeChoice);
  else if('refresh' in d)loadHome(true);
  else if('orderEdit' in d)beginOrder();
  else if('move' in d&&state.modal==='order')stepOrder(el);
  else if('orderReset' in d&&state.modal==='order')resetOrder();
  else if('orderSave' in d&&state.modal==='order')saveOrder();
  else if('category' in d){state.category=d.category;renderPage();main.querySelector('[data-category="'+d.category+'"]')?.focus({preventScroll:true});}
  else if('menu' in d)showNav();
  else if('closeNav' in d)hideNav();
  else if('open' in d)openModule(d.open,el);
  else if('fav' in d)toggleFavorite(d.fav);
  else if('searchOpen' in d)beginSearch();
  else if('edit' in d)beginEdit();
  else if('close' in d)closeModal();
  else if('save' in d)saveLayout();
  else if('default' in d){state.draft=defaults(state.scene);drawEditor();dialog.querySelector('[data-default]').focus();}
  else if('info' in d)info(d.info);
  else if('settings' in d){hideNav();host.settings();}
});
document.addEventListener('change',e=>{
  const el=e.target,d=el.dataset;
  if('visible' in d&&state.draft){state.draft.find(r=>r.id===d.visible).visible=el.checked;drawEditor();dialog.querySelector('[data-visible="'+d.visible+'"]').focus({preventScroll:true});}
  else if('position' in d)moveItem(d.position,Number(el.value));
});
document.addEventListener('input',e=>{if(e.target.id==='query'){state.searchIndex=0;drawSearchList();}});
dialog.addEventListener('cancel',e=>{e.preventDefault();closeModal();});
document.addEventListener('keydown',e=>{
  if(e.isComposing||e.keyCode===229)return;
  if((e.ctrlKey||e.metaKey)&&e.key.toLowerCase()==='k'){e.preventDefault();if(!dialog.open)beginSearch();return;}
  if(state.modal==='search'&&e.target.id==='query'){
    const buttons=[...dialog.querySelectorAll('.search-hit')];
    if(!buttons.length)return;
    if(e.key==='ArrowDown'||e.key==='ArrowUp'){e.preventDefault();state.searchIndex=(state.searchIndex+(e.key==='ArrowDown'?1:-1)+buttons.length)%buttons.length;drawSearchList();dialog.querySelector('.chosen')?.scrollIntoView({block:'nearest'});}
    else if(e.key==='Enter'){e.preventDefault();buttons[state.searchIndex].click();}
  } else if(e.key==='Escape'&&!dialog.open){
    if(document.body.classList.contains('nav-visible'))hideNav();
    
  }
});
dialog.addEventListener('dragstart',e=>{const el=e.target.closest('[data-drag]');if(el){e.dataTransfer.setData('text/plain',el.dataset.drag);e.dataTransfer.effectAllowed='move';}});
dialog.addEventListener('dragover',e=>{if(state.modal==='editor'&&e.target.closest('[data-drop]')){e.preventDefault();e.dataTransfer.dropEffect='move';}});
dialog.addEventListener('drop',e=>{const target=e.target.closest('[data-drop]');if(!target||state.modal!=='editor')return;e.preventDefault();moveItem(e.dataTransfer.getData('text/plain'),Number(target.dataset.drop));});
function syncPreferences(values){
  for(const [key,value] of Object.entries(values))prefs.set(key,value);
  readAppearance();renderShell();
}
function changeHomeLanguage(){readAppearance();renderShell();}
function measureSidebar(){
  const rect=side.getBoundingClientRect();
  host.measureSidebar?.(Math.max(0,Math.round(rect.right)));
}
function setModuleNavigation(id){
  currentModule=id;
  document.documentElement.toggleAttribute('data-module-open',!!id);
  document.querySelector('#shell>.workspace').inert=!!id;
  const group=id?DATA.mods.find(m=>m.id===id)?.group:state.scene;
  for(const item of side.querySelectorAll('.nav-button')){
    const selected=item.dataset.scene===group;
    item.classList.toggle('active',selected);
    if(selected)item.setAttribute('aria-current','page');else item.removeAttribute('aria-current');
  }
  measureSidebar();
}
function refreshFavoriteView(){if(host.isHome()&&state.scene!=='home')renderPage();}
new ResizeObserver(measureSidebar).observe(side);
window.operationsHomeRendered = host.ready.then(values => {
  syncPreferences(values);
  measureSidebar();
  bindOrderDrag();
  host.present?.(window);
  requestAnimationFrame(()=>loadHome());
});
