(function(root){
'use strict';
const finite=n=>typeof n==='number'&&Number.isFinite(n), near=(a,b)=>Math.abs(a-b)<0.01;
function validateData(d){
 if(!d||!Array.isArray(d.rows)||!Array.isArray(d.months)||!d.rows.length||d.rows.length>100000)throw Error('Invalid logistics rows');
 if(d.months.length<9||d.months.length>12||d.months.some((m,i)=>m.month!==i+1))throw Error('2026 January–closing month (at least September) required');
 let cost=0,cases=0,truck=0;
 for(const m of d.months){
  if(!Number.isSafeInteger(m.cases)||m.cases<1||!finite(m.cost)||m.cost<=0||!finite(m.trucking))throw Error('Invalid month totals');
  const rs=d.rows.filter(r=>r.month===m.month);
  if(rs.length!==m.cases||!near(rs.reduce((s,r)=>s+r.total,0),m.cost))throw Error('Rows and month totals differ');
  cost+=m.cost;cases+=m.cases;truck+=m.trucking;
 }
 for(const r of d.rows){
  if(!Number.isInteger(r.month)||r.month<1||r.month>d.months.length||!finite(r.total)||!finite(r.trucking))throw Error('Invalid detail value');
  for(const k of ['item','imex','mode','inv','hbl','truck'])if(typeof r[k]!=='string'||r[k].length>10000)throw Error('Invalid detail text');
 }
 if(d.row_count!==cases||cases!==d.rows.length||!finite(d.total_cost)||!near(cost,d.total_cost)||!finite(d.trucking_total)||!near(truck,d.trucking_total))throw Error('Dataset totals differ');
 const pm=d.processing?.months;
 if(!Array.isArray(pm)||pm.length!==d.months.length||!d.processing.itemByMonth)throw Error('Missing processing months');
 pm.forEach((p,i)=>{
  if(p.month!==i+1||!finite(p.usd)||p.usd<=0||!finite(p.qty))throw Error('Invalid processing totals');
  const byItem=d.processing.itemByMonth[p.month];
  if(!byItem||typeof byItem!=='object'||Array.isArray(byItem)||Object.values(byItem).some(v=>!finite(v))||!near(Object.values(byItem).reduce((s,v)=>s+v,0),p.usd))throw Error('Processing item totals differ');
 });
 return d;
}
function withRates(data,rates){
 validateData(data);
 const d=JSON.parse(JSON.stringify(data)),fx={};
 for(const p of d.processing.months){
  const rate=Number(rates[p.month]);if(!Number.isFinite(rate)||rate<=0||rate>1000000)throw Error('USD/KRW required: '+p.month);
  fx[p.month]=rate;p.usdkrw=rate;p.krw=Math.round(p.usd*rate);
  if(!Number.isSafeInteger(p.krw))throw Error('KRW outside safe range');
 }
 return{schemaVersion:1,reportYear:2026,fx:{vndKrwDivisor:20,usdKrw:fx},data:d};
}
function validate(snapshot){
 if(snapshot?.schemaVersion!==1||snapshot.reportYear!==2026||snapshot.fx?.vndKrwDivisor!==20)throw Error('Unsupported snapshot');
 const normalized=withRates(snapshot.data,snapshot.fx.usdKrw);
 snapshot.data.processing.months.forEach((p,i)=>{const n=normalized.data.processing.months[i];if(p.usdkrw!==n.usdkrw||p.krw!==n.krw)throw Error('Stored KRW / shared FX mismatch');});
 return normalized;
}
root.LogisticsSnapshot={validateData,withRates,validate};if(typeof module!=='undefined')module.exports=root.LogisticsSnapshot;
})(globalThis);
