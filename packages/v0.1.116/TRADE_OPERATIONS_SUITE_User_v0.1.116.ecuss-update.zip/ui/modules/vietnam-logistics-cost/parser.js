/* Parser from verified 2026-11-11 handoff; legacy semantics preserved. */
(function(root){
'use strict';
function parse(wb,rates={},engine){
const XLSX=engine||root.XLSX,usdKrw=m=>Number(rates[Number(m)]||0);
function excelSerialMonth(v){
  if(v instanceof Date)return{year:v.getFullYear(),month:v.getMonth()+1};
  if(typeof v==='number'){
    if(Number.isInteger(v)&&v>=200001&&v<=209912)return{year:Math.floor(v/100),month:v%100};
    let d=XLSX.SSF.parse_date_code(v);return d?{year:d.y,month:d.m}:null;
  }
  let t=String(v??'').trim();
  let m=t.match(/(20\d{2})\s*[-/.년]\s*(0?[1-9]|1[0-2])(?:\s*[-/.월]\s*\d{1,2})?/);
  return m?{year:Number(m[1]),month:Number(m[2])}:null;
}
function normSheetName(v){return String(v??'').trim().replace(/\s+/g,' ').toLowerCase()}
function getSheetByName(wb,name){let target=normSheetName(name),key=Object.keys(wb.Sheets||{}).find(k=>normSheetName(k)===target);return key?wb.Sheets[key]:null}
function parseProcessingSheet(wb,name){
  const sh=getSheetByName(wb,name);
  if(!sh)throw new Error('임가공비 시트 없음: '+name);
  const A=XLSX.utils.sheet_to_json(sh,{header:1,defval:null,raw:true,blankrows:false});
  const head=A[0]||[],cols=[];
  // Locate every 2026 date header independently, not by fixed column positions.
  for(let c=2;c<head.length;c++){
    const dm=excelSerialMonth(head[c]);
    if(dm&&dm.year===2026&&dm.month>=1&&dm.month<=12)cols.push([c,dm.month]);
  }
  if(!cols.length)throw new Error(name+': 2026년 날짜 헤더를 찾지 못했습니다.');
  const months={},items={};
  for(const [c,m] of cols){
    months[m]={qty:0,usd:0};items[m]={};
    for(let r=2;r<A.length;r++){
      const row=A[r]||[],item=String(row[1]??'').trim();
      const customer=String(row[0]??'').trim().toUpperCase();
      if(!item||customer==='TOTAL'||item.toUpperCase()==='TOTAL')continue;
      const parse=v=>{if(typeof v==='number')return Number.isFinite(v)?v:0;let n=Number(String(v??'').replace(/[$,\s]/g,''));return Number.isFinite(n)?n:0};
      const q=parse(row[c]),u=parse(row[c+1]);
      months[m].qty+=q;months[m].usd+=u;
      items[m][item]=(items[m][item]||0)+u;
    }
  }
  return{months,items};
}
function processWorkbook(wb){
  let sr=getSheetByName(wb,'SUMMARY'),paSh=getSheetByName(wb,'amovina processing fee'),pgSh=getSheetByName(wb,'greenvina processing fee');
  let missing=[];if(!sr)missing.push('SUMMARY');if(!paSh)missing.push('amovina processing fee');if(!pgSh)missing.push('greenvina processing fee');
  if(missing.length)throw new Error('missing sheets: '+missing.join(', '));
  let S=XLSX.utils.sheet_to_json(sr,{header:1,defval:null,raw:true}),rows=[],monthMap={};
  // Detect the header row rather than assuming the monthly data always starts on row 3.
  let headerIndex=S.findIndex(r=>Array.isArray(r)&&r.some(v=>String(v??'').trim().toUpperCase()==='MONTH')&&r.some(v=>String(v??'').trim().toUpperCase()==='ITEM'));
  if(headerIndex<0)throw new Error('SUMMARY: MONTH / ITEM headers not found (rows='+S.length+')');
  let header=S[headerIndex].map(v=>String(v??'').trim().toUpperCase().replace(/\s+/g,' '));
  let monthCol=header.indexOf('MONTH');
  const column=(name)=>header.findIndex(h=>h.replace(/[^A-Z0-9]/g,'')===name.replace(/[^A-Z0-9]/g,''));
  const col={item:column('ITEM'),imex:column('IMEX'),forwarder:column('FORWARDER'),mode:column('SHIPPINGMODE'),inv:column('INVNO'),hbl:column('HBL'),qty:header.findIndex(h=>h.includes('CARTON')||h.includes('PALLET')),truck:column('TRUCKTYPE'),trucking:column('TRUCKINGFEE'),total:column('GRANDTOTAL')};
  if(col.total<0||col.trucking<0)throw new Error('SUMMARY: Grand Total / TRUCKING FEE columns not found');
  const numeric=v=>{if(typeof v==='number')return Number.isFinite(v)?v:NaN;if(v===null||v===undefined||String(v).trim()==='')return NaN;let t=String(v).replace(/[\s,₫₩]/g,'').trim();return /^-?\d+(?:\.\d+)?$/.test(t)?Number(t):NaN;};
  function monthNumber(v){
    if(typeof v==='number')return Number.isInteger(v)&&v>=1&&v<=12?v:null;
    let t=String(v??'').trim();if(!t)return null;
    let m=t.match(/^(?:2026[.\/-])?0?([1-9]|1[0-2])(?:월)?$/);
    return m?Number(m[1]):null;
  }
  for(let i=headerIndex+1;i<S.length;i++){
    let r=S[i]||[],month=monthNumber(r[monthCol]);if(month===null)continue;
    let total=numeric(r[col.total]),hasTotal=Number.isFinite(total),truckFee=numeric(r[col.trucking]),item=String(r[col.item]||'UNKNOWN').trim()||'UNKNOWN',imex=String(r[col.imex]||'N/A').trim()||'N/A',forwarder=String(r[col.forwarder]||'').trim(),mode=String(r[col.mode]||'UNKNOWN').trim()||'UNKNOWN',truck=String(r[col.truck]||'').trim();
    if(!monthMap[month])monthMap[month]={month,cases:0,cost:0,trucking:0};
    monthMap[month].cases++;
    if(hasTotal){
      monthMap[month].cost+=total;
      let tt=truck.toUpperCase(),fw=forwarder.toUpperCase();
      if(tt!=='NONE'&&tt!=='FORK LIFT'&&fw!=='FORKLIFT')monthMap[month].trucking+=total;
      rows.push({item,imex,month,mode,inv:String(r[col.inv]||''),hbl:String(r[col.hbl]||''),qty:r[col.qty]??null,truck,trucking:Number.isFinite(truckFee)?truckFee:0,total});
    }else{
      rows.push({item,imex,month,mode,inv:String(r[col.inv]||''),hbl:String(r[col.hbl]||''),qty:r[col.qty]??null,truck,trucking:Number.isFinite(truckFee)?truckFee:0,total:0});
    }
  }
  let months=Object.values(monthMap).sort((a,b)=>a.month-b.month);
  if(!months.length)throw new Error('SUMMARY has no valid monthly rows. Rows='+S.length+', header row='+(headerIndex+1)+', MONTH column='+(monthCol+1)+', examples='+JSON.stringify(S.slice(headerIndex+1,headerIndex+5).map(r=>r?.[monthCol])));
  const invalidMonths=months.filter(m=>!(m.cost>0));
  if(invalidMonths.length)throw new Error('월별 물류비가 0인 달: '+invalidMonths.map(m=>m.month+'월').join(', '));
  const earliestClosingMonth = 9;
  if (months.length < earliestClosingMonth || months.some((entry, index) => entry.month !== index + 1)) {
    throw new Error('월 마감 데이터는 1월부터 마감월까지 연속되어야 하며 최소 9월까지 필요합니다. 읽은 월: '+months.map(m=>m.month).join(', '));
  }
  const validCosts=rows.filter(r=>Number.isFinite(r.total)&&r.total>0).length;
  if(!validCosts||months.reduce((a,x)=>a+x.cost,0)<=0)throw new Error('SUMMARY: 물류비 합계가 0입니다. 기존 공용 데이터를 덮어쓰지 않았습니다. Grand Total 원본/계산값을 확인하세요.');
  months.forEach((x,i)=>{x.avg=x.cases?Math.round(x.cost/x.cases):0;x.mom=i&&months[i-1].cost?(x.cost/months[i-1].cost-1)*100:null;x.caseMom=i&&months[i-1].cases?(x.cases/months[i-1].cases-1)*100:null;x.avgMom=i&&months[i-1].avg?(x.avg/months[i-1].avg-1)*100:null});
  let pa=parseProcessingSheet(wb,'amovina processing fee'),pg=parseProcessingSheet(wb,'greenvina processing fee'),procMonths=[],itemByMonth={};
  for(const x of months){let m=x.month,a=pa.months[m]||{qty:0,usd:0},g=pg.months[m]||{qty:0,usd:0},usd=a.usd+g.usd,qty=a.qty+g.qty;let im={...(pa.items[m]||{})};for(const [k,v] of Object.entries(pg.items[m]||{}))im[k]=(im[k]||0)+v;itemByMonth[m]=im;procMonths.push({month:m,qty,usd,krw:Math.round(usd*usdKrw(m)),usdkrw:usdKrw(m)})}
  // Prevent overwriting good shared data with missing processing-fee months.
  const missingProcessing=procMonths.filter(x=>!Number.isFinite(x.usd)||x.usd<=0);
  if(missingProcessing.length)throw new Error('임가공비 검증 실패: '+missingProcessing.map(x=>x.month+'월').join(', ')+' USD 금액이 0입니다. 공용 데이터는 변경되지 않았습니다.');
  return{row_count:months.reduce((a,x)=>a+x.cases,0),total_cost:months.reduce((a,x)=>a+x.cost,0),trucking_total:months.reduce((a,x)=>a+x.trucking,0),months,rows,processing:{months:procMonths,itemByMonth}};
}

return processWorkbook(wb);
}
root.LogisticsParser={parse};if(typeof module!=='undefined')module.exports=root.LogisticsParser;
})(globalThis);
