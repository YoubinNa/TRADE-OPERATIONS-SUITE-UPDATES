(function(){
'use strict';
let forceScreen=false;
function clean(){
 document.querySelectorAll('.screen-print-canvas').forEach(n=>n.remove());
 document.body.classList.remove('print-screen');
 forceScreen=false;
 window.requestAnimationFrame(()=>window.dispatchEvent(new Event('resize')));
}
function prepare(){
 const modal=document.getElementById('pdfModal');
 const screen=forceScreen||!modal?.classList.contains('open');
 if(!screen){document.body.classList.remove('print-screen');return;}
 // The button and beforeprint can both run. Keep the first stable snapshot.
 if(!document.querySelectorAll('.screen-print-canvas').length){
  document.querySelectorAll('main .page.active canvas').forEach(canvas=>{
   try{
    if(!canvas.width||!canvas.height)return;
    const copy=document.createElement('canvas');copy.width=canvas.width;copy.height=canvas.height;
    const ctx=copy.getContext('2d');if(!ctx)return;
    // Synchronous bitmap copy: no data URL decoding or image-load race at print time.
    ctx.drawImage(canvas,0,0);copy.className='screen-print-canvas';
    copy.setAttribute('aria-hidden','true');canvas.insertAdjacentElement('afterend',copy);
   }catch(e){/* Original canvas stays visible when copying fails. */}
  });
 }
 document.body.classList.add('print-screen');
}
const button=document.getElementById('screenPrintBtn');
button.onclick=()=>{forceScreen=true;try{prepare();window.print();}catch(e){clean();throw e;}};
window.addEventListener('beforeprint',prepare);
window.addEventListener('afterprint',clean);
})();
