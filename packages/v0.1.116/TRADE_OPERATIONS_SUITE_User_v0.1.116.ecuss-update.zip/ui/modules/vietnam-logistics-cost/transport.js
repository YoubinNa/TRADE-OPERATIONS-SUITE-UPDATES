(function(root){
'use strict';
function supabase({url,publishableKey,getAccessToken,fetchImpl=root.fetch}){
 if(!/^https:\/\/[a-z0-9]+\.supabase\.co$/.test(url)||!publishableKey||typeof getAccessToken!=='function')throw Error('Supabase session configuration required');
 async function rpc(name,body){
  const token=await getAccessToken();if(!token)throw Error('Suite session required');
  const abort=new AbortController(),timer=setTimeout(()=>abort.abort(),30000);
  try{
   const r=await fetchImpl(url+'/rest/v1/rpc/'+name,{method:'POST',headers:{apikey:publishableKey,Authorization:'Bearer '+token,'Content-Type':'application/json'},body:JSON.stringify(body),signal:abort.signal});
   if(!r.ok){const err=await r.json().catch(()=>({}));throw Error(err.code==='40001'?'Shared data changed. Reload before uploading.':'Shared request failed ('+r.status+')');}
   return await r.json();
  }finally{clearTimeout(timer);}
 }
 return{mode:'shared',load:()=>rpc('suite_logistics_read',{}),save:(snapshot,sourceFile,version)=>rpc('suite_logistics_save',{p_snapshot:snapshot,p_source_file:sourceFile,p_expected_version:version})};
}
function native(bridge){
 async function rpc(action,payload){const r=await bridge.call('/logistics/'+action,payload);if(r.status!==200)throw Error(r.value?.message||'Shared logistics request failed');return r.value;}
 return{mode:'shared',load:()=>rpc('read',null),save:(snapshot,sourceFile,version)=>rpc('save',{snapshot,sourceFile,expectedVersion:version}),print:()=>rpc('print',null)};
}
// Explicit standalone review only. Never described as a successful cloud upload.
function local(storage){const key='suiteLogisticsPreviewV1';return{mode:'local',async load(){const text=storage.getItem(key);return text?JSON.parse(text):null;},async save(snapshot,sourceFile,expected){const current=await this.load();if((current?.version||0)!==expected)throw Error('Local data changed. Reload.');const record={snapshot,source_file:sourceFile,version:expected+1,updated_at:new Date().toISOString()};storage.setItem(key,JSON.stringify(record));return record;}};}
root.LogisticsTransport={supabase,native,local};if(typeof module!=='undefined')module.exports=root.LogisticsTransport;
})(globalThis);
