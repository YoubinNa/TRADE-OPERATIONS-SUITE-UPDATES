'use strict';
function escapeHtml(value){return String(value??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}
const LogisticsModule=(()=>{
 let provider=window.LogisticsHost?.provider||LogisticsTransport.local(localStorage),version=0,busy=false,record=null;
 const msg=(ko,en,vi)=>L(ko,en,vi);
 function status(error){
  const printButton=$('screenPrintBtn');if(printButton)printButton.textContent=msg('화면 인쇄','Print screen','In màn hình');
  const el=$('connectionStatus');if(!el)return;
  el.textContent=(provider.mode==='local'?msg('로컬 검토 · 공용 저장 안 됨','Local review · not shared','Xem thử cục bộ · chưa chia sẻ'):msg('Supabase 공유 자료','Shared Supabase data','Dữ liệu Supabase dùng chung'))+(record?' · '+record.source_file+' · '+record.updated_at:'')+(error?' · '+error:'');
  $('reloadShared').textContent=provider.mode==='local'?msg('저장 자료 다시 불러오기','Reload saved data','Tải lại dữ liệu đã lưu'):msg('공유 자료 새로고침','Reload shared data','Tải lại dữ liệu chung');
  const note=$('storageNote');if(note)note.textContent=provider.mode==='local'?msg('업로드 자료와 환율은 이 브라우저에 저장됩니다. 같은 브라우저에서 다시 열면 불러옵니다. 다른 PC와 공유되지 않습니다. 절감과제도 이 브라우저에 저장됩니다.','Uploaded data, rates and savings actions are saved in this browser and restored when reopened here. They are not shared with other PCs.','Dữ liệu, tỷ giá và hạng mục tiết giảm được lưu trong trình duyệt này và tải lại khi mở lại. Không chia sẻ với PC khác.'):msg('업로드 자료와 환율은 Supabase에 공유 저장됩니다. 절감과제는 이 브라우저에 저장됩니다.','Uploaded data and rates are shared in Supabase. Savings actions are saved in this browser.','Dữ liệu và tỷ giá được lưu dùng chung trên Supabase. Hạng mục tiết giảm được lưu trong trình duyệt này.');
 }
 function setBusy(value){busy=value;$('excelFile').disabled=value||window.LogisticsHost?.readOnly===true;$('reloadShared').disabled=value;$('pdfReportBtn').disabled=!DATA.months.length||value;$('copyReport').disabled=!DATA.months.length||value;}
 function accept(r){
  if(!r||!Number.isSafeInteger(r.version)||r.version<1||typeof r.source_file!=='string'||typeof r.updated_at!=='string'||!Number.isFinite(Date.parse(r.updated_at)))throw Error('Invalid shared snapshot metadata');
  const checked=LogisticsSnapshot.validate(r.snapshot);
  DATA=checked.data;USD_KRW={...checked.fx.usdKrw};version=r.version;record=r;
 }
 function ratesDialog(months){
  const dialog=$('fxDialog');$('fxTitle').textContent=msg('월별 USD/KRW 확인','Confirm monthly USD/KRW','Xác nhận USD/KRW hàng tháng');
  $('fxHelp').textContent=msg('확정한 환율을 자료와 함께 저장해 모든 PC에 동일하게 적용합니다. VND→KRW는 ÷20입니다.','Rates are saved with the dataset for every PC. VND→KRW remains ÷20.','Tỷ giá được lưu cùng dữ liệu cho mọi PC. VND→KRW giữ nguyên ÷20.');
  $('fxCancel').textContent=msg('취소','Cancel','Hủy');$('fxConfirm').textContent=msg('확인 후 저장','Confirm and save','Xác nhận và lưu');$('fxError').textContent='';
  $('fxRows').replaceChildren();
  for(const m of months){const label=document.createElement('label');label.textContent=monthLabel(m.month);const input=document.createElement('input');input.type='number';input.step='any';input.min='0.000001';input.max='1000000';input.required=true;input.dataset.month=m.month;input.value=USD_KRW[m.month]||DEFAULT_USD_KRW[m.month]||'';label.append(input);$('fxRows').append(label);}
  return new Promise(resolve=>{
   function done(v){dialog.close();$('fxForm').onsubmit=null;dialog.oncancel=null;resolve(v);}
   $('fxCancel').onclick=()=>done(null);dialog.oncancel=e=>{e.preventDefault();done(null);};
   $('fxForm').onsubmit=e=>{e.preventDefault();const rates={};for(const input of $('fxRows').querySelectorAll('input')){const v=Number(input.value);if(!Number.isFinite(v)||v<=0||v>1000000){$('fxError').textContent=msg('모든 월의 양수 환율을 입력해 주세요.','Enter a positive rate for every month.','Nhập tỷ giá dương cho mọi tháng.');return;}rates[input.dataset.month]=v;}done(rates);};
   dialog.showModal();
  });
 }
 async function upload(file){
  if(busy||!file)return;setBusy(true);
  try{
   if(file.size>50000000)throw Error('Excel file exceeds 50 MB');
   const wb=XLSX.read(await file.arrayBuffer(),{type:'array'}),data=LogisticsParser.parse(wb,{});
   LogisticsSnapshot.validateData(data);
   const rates=await ratesDialog(data.months);if(!rates)return;
   const snapshot=LogisticsSnapshot.withRates(data,rates);
   const saved=await provider.save(snapshot,file.name,version);
   accept(saved);state={month:'all',imex:'all',mode:'all',item:'ALL'};buildFilters();render();status();
   $('uploadMsg').className='uploadMsg ok';$('uploadMsg').textContent=T('uploadOk')+' '+file.name+(provider.mode==='local'?msg(' · 로컬 검토용',' · local review',' · xem thử cục bộ'):msg(' · 공용 저장 완료',' · shared',' · đã chia sẻ'));
  }catch(e){$('uploadMsg').className='uploadMsg err';$('uploadMsg').textContent=T('uploadErr')+' ['+e.message+']';status(e.message);}
  finally{setBusy(false);$('excelFile').value='';}
 }
 async function reload(){
  if(busy)return;setBusy(true);
  try{const loaded=await provider.load();if(loaded){accept(loaded);if(state.month!=='all'&&!DATA.months.some(m=>String(m.month)===state.month))state.month='all';}applyLang();status();}
  catch(e){applyLang();status(msg('조회 실패 · 기존 표시 유지: ','Load failed · retained displayed data: ','Tải thất bại · giữ dữ liệu đang xem: ')+e.message);}
  finally{setBusy(false);}
 }
 async function printReport(){
  try{if(window.LogisticsHost?.printReport){await window.LogisticsHost.printReport();}else if(provider.print){await provider.print();}else window.print();}
  catch(e){$('uploadMsg').textContent=msg('인쇄 실패: ','Print failed: ','In thất bại: ')+e.message;}
 }
 function setLanguage(next){if(!['ko','en','vi'].includes(next))return;lang=next;localStorage.setItem('logisticsLang',lang);applyLang();status();}
 $('excelFile').addEventListener('change',e=>upload(e.target.files?.[0]));$('reloadShared').onclick=reload;
 $('lang').addEventListener('change',()=>status());
 const hostLang=window.LogisticsHost?.language;if(['ko','en','vi'].includes(hostLang))lang=hostLang;
 if(window.LogisticsHost?.hideLanguageSelector)$('lang').hidden=true;
 window.EcussModuleI18n={setLanguage,getLanguage:()=>lang};
 // Start after app's lexical bindings and this API have initialized.
 queueMicrotask(reload);
 return{reload,upload,printReport,setLanguage,getSnapshot:()=>record,setProvider(p){if(busy)throw Error('Upload in progress');provider=p;version=0;record=null;return reload();}};
})();
