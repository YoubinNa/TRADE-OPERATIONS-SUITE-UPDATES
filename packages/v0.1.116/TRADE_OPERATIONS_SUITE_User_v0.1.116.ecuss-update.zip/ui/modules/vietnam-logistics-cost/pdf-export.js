(function(root){
'use strict';
const PAGE_W=841.889764,PAGE_H=595.275591,W=1600,H=1131;
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&apos;'}[c]));
function extract(page){
 const chart=page.querySelector('.report-main-chart,.month-pie-box');
 return {title:page.querySelector('.print-title').textContent,subtitle:page.querySelector('.print-sub').textContent,
  chartTitle:chart.querySelector('h4').textContent,chart:chart.querySelector('svg').outerHTML,
  kpis:Array.from(page.querySelectorAll('.print-kpi'),n=>({label:n.querySelector('.l').textContent,values:n.querySelector('.v').innerHTML.split(/<br\s*\/?\s*>/i).map(v=>{const t=document.createElement('span');t.innerHTML=v;return t.textContent;})})),
  tableTitle:page.querySelector('.item-table-box h4').textContent,
  rows:Array.from(page.querySelectorAll('.print-table tr'),tr=>Array.from(tr.children,c=>c.textContent)),
  share:page.querySelector('.share-check').textContent,footer:page.querySelector('.print-footer').textContent};
}
function pageSvg(m){
 const text=(s,x,y,size=16,extra='')=>`<text x="${x}" y="${y}" font-size="${size}" ${extra}>${esc(s)}</text>`;
 const box=(x,y,w,h)=>`<rect x="${x}" y="${y}" width="${w}" height="${h}" rx="10" fill="white" stroke="#ccd5df" stroke-width="1.5"/>`;
 const view=m.chart.match(/viewBox="([^"]+)"/i);if(!view)throw Error('Chart viewBox missing');
 const [vx,vy,vw,vh]=view[1].trim().split(/[\s,]+/).map(Number);
 if(![vx,vy,vw,vh].every(Number.isFinite)||vw<=0||vh<=0)throw Error('Invalid chart dimensions');
 const scale=Math.min(1480/vw,476/vh),tx=60+(1480-vw*scale)/2-vx*scale,ty=148+(476-vh*scale)/2-vy*scale;
 const svg=`<g transform="translate(${tx} ${ty}) scale(${scale})">${m.chart.replace(/^<svg\b[^>]*>/,'').replace(/<\/svg>\s*$/,'')}</g>`;
 const cols=[60,250,730,1050,1330];
 let out=`<svg xmlns="http://www.w3.org/2000/svg" width="${W}" height="${H}" viewBox="0 0 ${W} ${H}"><rect width="1600" height="1131" fill="white"/><g fill="#172b4d" font-family="Noto Sans KR,Malgun Gothic,Arial,sans-serif">`;
 out+=text(m.title,45,62,25,'font-weight="800"')+text(m.subtitle,45,88,13,'fill="#667085"');
 out+=box(45,105,1510,530)+text(m.chartTitle,60,134,17,'font-weight="700"')+svg;
 m.kpis.forEach((k,i)=>{const x=45+i*765;out+=box(x,650,745,102)+text(k.label,x+15,676,14,'fill="#667085"');k.values.forEach((v,j)=>out+=text(v,x+15,704+j*26,22,'font-weight="800"'));});
 out+=box(45,767,1510,285)+text(m.tableTitle,60,796,17,'font-weight="700"');
 m.rows.forEach((row,r)=>{const y=828+r*37;row.forEach((v,c)=>out+=text(v,cols[c],y,r===0?15:14,r===0||c===0?'font-weight="700"':''));out+=`<path d="M60 ${y+12} H1540" stroke="#dfe7ef"/>`;});
 out+=text(m.share,1540,1032,13,'font-weight="700" text-anchor="end"');
 out+=text(m.footer,1555,1082,11,'fill="#667085" text-anchor="end"')+'</g></svg>';
 return out;
}
// Binary-safe PDF writer: fixed landscape MediaBox, two JPEG page images, no print-driver dependency.
function encodePdf(pages){
 if(pages.length!==2)throw Error('Expected two report pages');
 const enc=new TextEncoder(),chunks=[],offsets=[0];let length=0;
 function put(v){const b=typeof v==='string'?enc.encode(v):v;chunks.push(b);length+=b.length;}
 function obj(n,parts){offsets[n]=length;put(`${n} 0 obj\n`);for(const p of parts)put(p);put('\nendobj\n');}
 put('%PDF-1.4\n');put(new Uint8Array([37,226,227,207,211,10]));
 obj(1,['<< /Type /Catalog /Pages 2 0 R >>']);
 obj(2,['<< /Type /Pages /Count 2 /Kids [3 0 R 6 0 R] >>']);
 pages.forEach((p,i)=>{const n=3+i*3;
  obj(n,[`<< /Type /Page /Parent 2 0 R /MediaBox [0 0 ${PAGE_W} ${PAGE_H}] /Rotate 0 /Resources << /XObject << /Img ${n+1} 0 R >> >> /Contents ${n+2} 0 R >>`]);
  obj(n+1,[`<< /Type /XObject /Subtype /Image /Width ${p.width} /Height ${p.height} /ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /DCTDecode /Length ${p.bytes.length} >>\nstream\n`,p.bytes,'\nendstream']);
  const cmd=`q\n${PAGE_W} 0 0 ${PAGE_H} 0 0 cm\n/Img Do\nQ\n`;
  obj(n+2,[`<< /Length ${enc.encode(cmd).length} >>\nstream\n${cmd}endstream`]);
 });
 const start=length;put('xref\n0 9\n0000000000 65535 f \n');
 for(let i=1;i<=8;i++)put(String(offsets[i]).padStart(10,'0')+' 00000 n \n');
 put(`trailer\n<< /Size 9 /Root 1 0 R >>\nstartxref\n${start}\n%%EOF\n`);
 const bytes=new Uint8Array(length);let pos=0;for(const b of chunks){bytes.set(b,pos);pos+=b.length;}return bytes;
}
async function raster(svg){
 const url=URL.createObjectURL(new Blob([svg],{type:'image/svg+xml;charset=utf-8'}));
 try{const img=new Image();await new Promise((resolve,reject)=>{img.onload=resolve;img.onerror=()=>reject(Error('Report image rendering failed'));img.src=url;});
  const canvas=document.createElement('canvas');canvas.width=W*2;canvas.height=H*2;
  const ctx=canvas.getContext('2d');if(!ctx)throw Error('Canvas unavailable');
  ctx.fillStyle='#fff';ctx.fillRect(0,0,canvas.width,canvas.height);ctx.drawImage(img,0,0,canvas.width,canvas.height);
  const data=atob(canvas.toDataURL('image/jpeg',0.97).split(',')[1]);
  return{width:canvas.width,height:canvas.height,bytes:Uint8Array.from(data,c=>c.charCodeAt(0))};
 }finally{URL.revokeObjectURL(url);}
}
async function save(container,filename){
 if(document.fonts?.ready)await document.fonts.ready;
 const pages=Array.from(container.querySelectorAll('.report-page'));
 if(pages.length!==2)throw Error('Expected two report pages');
 const images=[];for(const page of pages)images.push(await raster(pageSvg(extract(page))));
 const url=URL.createObjectURL(new Blob([encodePdf(images)],{type:'application/pdf'}));
 const a=document.createElement('a');a.href=url;a.download=filename;document.body.append(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),60000);
}
root.LogisticsPdf={save,encodePdf,pageSvg,extract};
if(typeof module!=='undefined')module.exports=root.LogisticsPdf;
})(globalThis);
