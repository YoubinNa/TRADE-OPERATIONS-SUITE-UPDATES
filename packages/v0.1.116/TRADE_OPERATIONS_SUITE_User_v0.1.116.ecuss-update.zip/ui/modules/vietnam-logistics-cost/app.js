
const BASE_DATA={row_count:0,total_cost:0,trucking_total:0,months:[],rows:[],processing:{months:[],itemByMonth:{}}};
const I18N={
ko:{title:'베트남 물류비 관리 시스템',subtitle:'월별 물류비 · 처리 건수 · 건당비용 · 절감과제 통합 관리',upload:'월 마감 엑셀 업로드',tabExec:'회장 보고',tabAnalysis:'비용 분석',tabSaving:'절감과제',tabDetail:'상세 내역',period:'기간',imex:'수출입',mode:'운송수단',item:'ITEM',reset:'필터 초기화',monthlyCaseCost:'월별 물류비 vs 처리 건수',cost:'물류비',cases:'처리 건수',messages:'핵심 메시지',itemTop:'ITEM 비용 구성 TOP 3 + 기타',modeMix:'운송수단 비용 구성',caseDrivers:'월별 건수 · TOP3 ITEM 구성',reportDraft:'회장님 보고 문안 자동 초안',copy:'보고문안 복사',monthlyTable:'월별 비용 / 건수 / 건당비용',month:'월',caseMom:'건수 전월비',costMom:'비용 전월비',avgCase:'건당비용',trucking:'TRUCKING FEE',concentration:'비용 집중도',imexCost:'수출입별 비용',modeTrend:'월별 운송수단 추이',savingArea:'절감 잠재영역',simulation:'절감 목표 시뮬레이션',simulationHelp:'누계 물류비에 대한 절감률을 입력하면 예상 절감액을 계산합니다.',expectedSaving:'예상 절감액',actionMgmt:'절감과제 실행관리',addAction:'+ 과제 추가',actionHelp:'과제·담당자·목표절감액·기한·상태를 브라우저에 저장합니다.',localNote:'※ 업로드 데이터는 Supabase 공용 DB에 저장되어 모든 PC에서 동일한 최신 데이터를 표시합니다. 절감과제는 현재 브라우저에 저장됩니다.',rawDetail:'원천 집계 상세',searchPH:'ITEM / INV / HBL 검색',truckType:'차량/구분',all:'전체',cum:'누계',data:'데이터',latest:'최신',records:'건',avg:'건당 평균',airShare:'TRUCKING FEE 비중',airSub:'총 물류비 대비 비중',truckFee:'TRUCKING FEE',truckSub:'SUMMARY에서 FORKLIFT 및 TRUCK TYPE=NONE 제외 기준',caseCostMsg:'건수 증가와 비용 증가의 관계',copyDone:'복사 완료',uploadOk:'엑셀 업로드가 완료되어 최신 데이터로 갱신되었습니다.',uploadErr:'엑셀을 읽지 못했습니다. SUMMARY, amovina processing fee, greenvina processing fee 3개 시트를 확인해 주세요.',display:'화면에는 최대 500건 표시',search:'검색',monthlyAvg:'월평균 환산',statusReview:'검토',statusProgress:'진행중',statusDone:'완료',statusHold:'보류',delete:'삭제',newTask:'신규 절감과제',pdfReport:'PDF 2장 보고서',procFee:"임가공비",procTrend:"임가공비 · 처리 건수 연계",procInterpret:"임가공비 기반 물량 해석",procMonthly:"월별 임가공비(USD/KRW) · 물류건수 비교",procMom:"임가공비 전월비",periodSelect:'기간 선택'},
en:{title:'Vietnam Logistics Cost Management',subtitle:'Monthly logistics cost · shipment count · cost per case · savings actions',upload:'Upload monthly closing Excel',tabExec:'Executive report',tabAnalysis:'Cost analysis',tabSaving:'Savings actions',tabDetail:'Details',period:'Period',imex:'Import/Export',mode:'Shipping mode',item:'ITEM',reset:'Reset filters',monthlyCaseCost:'Monthly logistics cost vs shipment count',cost:'Logistics cost',cases:'Shipment count',messages:'Executive key messages',itemTop:'ITEM cost mix: Top 3 + Others',modeMix:'Cost mix by shipping mode',caseDrivers:'Shipment count · TOP3 ITEM mix',reportDraft:'Executive report draft',copy:'Copy report',monthlyTable:'Monthly cost / count / cost per case',month:'Month',caseMom:'Count MoM',costMom:'Cost MoM',avgCase:'Cost per case',trucking:'TRUCKING FEE',concentration:'Cost concentration',imexCost:'Cost by import/export',modeTrend:'Monthly shipping mode trend',savingArea:'Savings opportunities',simulation:'Savings target simulation',simulationHelp:'Enter a savings rate against cumulative logistics cost.',expectedSaving:'Expected savings',actionMgmt:'Savings action management',addAction:'+ Add action',actionHelp:'Tasks, owners, targets, due dates and status are stored in this browser.',localNote:'※ Uploaded data is stored in the shared Supabase database so all PCs see the same latest dataset. Savings actions remain stored in this browser.',rawDetail:'Source detail',searchPH:'Search ITEM / INV / HBL',truckType:'Truck/type',all:'All',cum:'Cumulative',data:'Data',latest:'Latest',records:'cases',avg:'Average per case',airShare:'TRUCKING FEE share',airSub:'Share of total logistics cost',truckFee:'TRUCKING FEE',truckSub:'Calculated from SUMMARY excluding FORKLIFT and TRUCK TYPE=NONE',caseCostMsg:'Relationship between count growth and cost growth',copyDone:'Copied',uploadOk:'Excel upload completed. The dashboard has been updated.',uploadErr:'Could not read the Excel file. Check the SUMMARY, amovina processing fee, and greenvina processing fee sheets.',display:'Up to 500 rows shown',search:'Search',monthlyAvg:'Monthly average',statusReview:'Review',statusProgress:'In progress',statusDone:'Done',statusHold:'On hold',delete:'Delete',newTask:'New savings action',pdfReport:'2-page PDF report',procFee:"Processing fee",procTrend:"Processing fee · shipment count linkage",procInterpret:"Volume interpretation from processing fee",procMonthly:"Monthly processing fee (USD/KRW) · shipment count",procMom:"Processing fee MoM",periodSelect:'Select period'},
vi:{title:'Hệ thống quản lý chi phí logistics Việt Nam',subtitle:'Chi phí logistics hàng tháng · số lô xử lý · chi phí/lô · quản lý tiết giảm',upload:'Tải Excel chốt tháng',tabExec:'Báo cáo lãnh đạo',tabAnalysis:'Phân tích chi phí',tabSaving:'Hạng mục tiết giảm',tabDetail:'Chi tiết',period:'Kỳ',imex:'Nhập/Xuất',mode:'Phương thức vận chuyển',item:'ITEM',reset:'Đặt lại bộ lọc',monthlyCaseCost:'Chi phí logistics theo tháng vs số lô xử lý',cost:'Chi phí logistics',cases:'Số lô xử lý',messages:'Thông điệp chính',itemTop:'Cơ cấu ITEM: TOP 3 + Khác',modeMix:'Cơ cấu chi phí theo phương thức',caseDrivers:'Số lô · cơ cấu TOP3 ITEM',reportDraft:'Dự thảo báo cáo lãnh đạo',copy:'Sao chép báo cáo',monthlyTable:'Chi phí / số lô / chi phí mỗi lô theo tháng',month:'Tháng',caseMom:'Số lô so với tháng trước',costMom:'Chi phí so với tháng trước',avgCase:'Chi phí mỗi lô',trucking:'TRUCKING FEE',concentration:'Mức độ tập trung chi phí',imexCost:'Chi phí nhập/xuất',modeTrend:'Xu hướng phương thức vận chuyển theo tháng',savingArea:'Khu vực có tiềm năng tiết giảm',simulation:'Mô phỏng mục tiêu tiết giảm',simulationHelp:'Nhập tỷ lệ tiết giảm trên tổng chi phí logistics lũy kế.',expectedSaving:'Tiết giảm dự kiến',actionMgmt:'Quản lý thực hiện tiết giảm',addAction:'+ Thêm hạng mục',actionHelp:'Hạng mục, người phụ trách, mục tiêu, hạn và trạng thái được lưu trên trình duyệt này.',localNote:'※ Dữ liệu tải lên được lưu trong Supabase dùng chung để mọi PC xem cùng dữ liệu mới nhất. Hạng mục tiết giảm vẫn được lưu trên trình duyệt này.',rawDetail:'Chi tiết dữ liệu nguồn',searchPH:'Tìm ITEM / INV / HBL',truckType:'Xe/loại',all:'Tất cả',cum:'Lũy kế',data:'Dữ liệu',latest:'Mới nhất',records:'lô',avg:'Bình quân mỗi lô',airShare:'Tỷ trọng TRUCKING FEE',airSub:'Tỷ trọng trên tổng chi phí logistics',truckFee:'TRUCKING FEE',truckSub:'Tính từ SUMMARY, loại FORKLIFT và TRUCK TYPE=NONE',caseCostMsg:'Mối quan hệ giữa tăng số lô và tăng chi phí',copyDone:'Đã sao chép',uploadOk:'Đã tải Excel và cập nhật dữ liệu mới nhất.',uploadErr:'Không đọc được Excel. Vui lòng kiểm tra 3 sheet: SUMMARY, amovina processing fee và greenvina processing fee.',display:'Hiển thị tối đa 500 dòng',search:'Tìm kiếm',monthlyAvg:'Bình quân tháng',statusReview:'Xem xét',statusProgress:'Đang thực hiện',statusDone:'Hoàn tất',statusHold:'Tạm dừng',delete:'Xóa',newTask:'Hạng mục tiết giảm mới',pdfReport:'Báo cáo PDF 2 trang',procFee:"Phí gia công",procTrend:"Phí gia công · liên hệ số lô",procInterpret:"Diễn giải sản lượng từ phí gia công",procMonthly:"Phí gia công tháng (USD/KRW) · số lô logistics",procMom:"Phí gia công so với tháng trước",periodSelect:'Chọn kỳ'}};
let lang=['ko','en','vi'].includes(localStorage.getItem('logisticsLang'))?localStorage.getItem('logisticsLang'):'ko';
let DATA=BASE_DATA;let state={month:'all',imex:'all',mode:'all',item:'ALL'};
const FIXED_VND_KRW_DIVISOR=20; // Internal standard: KRW = VND ÷ 20
const DEFAULT_FX={};const DEFAULT_USD_KRW={1:1454.42,2:1447.25,3:1489.51,4:1484.34,5:1489.59,6:1530.20,7:1487.39,8:1403.13};
let USD_KRW={};
const usdKrw=m=>Number(USD_KRW[Number(m)]||0),usdFmt=n=>'$'+Number(n||0).toLocaleString('en-US',{maximumFractionDigits:0}),procKrwFmt=n=>(Number(n||0)/1e8).toFixed(2)+(lang==='ko'?'억원 KRW':' KRW 100M');

let FX_RATES={};
function ensureFxForMonths(months){ /* VND→KRW uses fixed internal rule: VND ÷ 20. No monthly FX prompt. */ }
const $=id=>document.getElementById(id),T=k=>I18N[lang][k]||k,L=(ko,en,vi)=>lang==='ko'?ko:lang==='en'?en:vi,fmt=n=>Number(n||0).toLocaleString(lang==='ko'?'ko-KR':lang==='vi'?'vi-VN':'en-US',{maximumFractionDigits:0}),monthLabel=m=>L(`${m}월`,`Month ${m}`,`Tháng ${m}`),allItemLabel=()=>L('전체 ITEM','All items','Tất cả ITEM'),otherLabel=()=>L('기타','Others','Khác'),manageNeededLabel=()=>L('출하횟수 관리 필요','Shipment-frequency management required','Cần quản lý tần suất xuất hàng'),bn=n=>{n=Number(n||0);return lang==='ko'?(n/1e8).toFixed(n>=1e9?2:1)+'억':(n/1e9).toFixed(2)+'B'},pct=n=>(Number(n||0)).toFixed(1)+'%',fx=m=>1/FIXED_VND_KRW_DIVISOR,toKRW=(v,m)=>Math.round(Number(v||0)/FIXED_VND_KRW_DIVISOR),krwFmt=n=>(Number(n||0)/1e8).toFixed(2)+(lang==='ko'?'억원 KRW':' KRW 100M'),monthKRW=x=>toKRW(x.cost,x.month),truckKRW=x=>toKRW(x.trucking,x.month),dualMoney=(v,m)=>`<span class="dual">${fmt(v)} VND<span class="krw">${krwFmt(toKRW(v,m))}</span></span>`;
function rowsKRW(rows){return rows.reduce((a,r)=>a+toKRW(r.total,r.month),0)}
function monthsKRW(months){return months.reduce((a,x)=>a+monthKRW(x),0)}
function monthsTruckKRW(months){return months.reduce((a,x)=>a+truckKRW(x),0)}
function processingMonths(){return DATA.processing?.months||[]}
function processingForPeriod(month='all'){let a=processingMonths();return month==='all'?a:a.filter(x=>String(x.month)===String(month))}
function processingTotals(month='all'){let a=processingForPeriod(month);return{usd:a.reduce((s,x)=>s+Number(x.usd||0),0),krw:a.reduce((s,x)=>s+Number(x.krw||0),0),qty:a.reduce((s,x)=>s+Number(x.qty||0),0)}}
const REP_ITEMS=['MOTOR','ANT','BLE-UWB'];
function normRepItem(s){s=String(s||'').toUpperCase().trim();if(s.includes('MOTOR'))return'MOTOR';if(s.includes('BLE')||s.includes('UWB'))return'BLE-UWB';if(s==='ANT'||s.startsWith('ANT '))return'ANT';return null}
function procItemUsd(month,item){let o=DATA.processing?.itemByMonth?.[String(month)]||DATA.processing?.itemByMonth?.[month]||{};if(item==='ALL')return Object.values(o).reduce((a,v)=>a+(+v||0),0);if(item==='OTHER')return Object.entries(o).reduce((a,[k,v])=>a+(normRepItem(k)==null?(+v||0):0),0);return Object.entries(o).reduce((a,[k,v])=>a+(normRepItem(k)===item?(+v||0):0),0)}
function procItemKrw(month,item){const p=processingMonths().find(x=>+x.month===+month);return item==='ALL'?Number(p?.krw||0):Math.round(procItemUsd(month,item)*usdKrw(month));}
function logisticsItemMonth(month,item){let rs=DATA.rows.filter(r=>+r.month===+month&&(item==='ALL'||(item==='OTHER'?normRepItem(r.item)==null:normRepItem(r.item)===item)));return{cases:rs.length,cost:rs.reduce((a,r)=>a+(+r.total||0),0)}}
function itemAnalysis(item,month){let pu=procItemUsd(month,item),ppu=procItemUsd(month-1,item),lm=logisticsItemMonth(month,item),lp=logisticsItemMonth(month-1,item);let pchg=ppu?(pu/ppu-1)*100:null,cchg=lp.cases?(lm.cases/lp.cases-1)*100:null,kchg=lp.cost?(lm.cost/lp.cost-1)*100:null;return{pchg,cchg,kchg,flag:pchg!=null&&pchg<=0&&!(kchg!=null&&kchg<0)}}

function processingComboSvg(bars,item){
 let cases=bars.map(x=>logisticsItemMonth(x.x,item).cases),W=760,H=195,p={l:42,r:48,t:24,b:48},iw=W-p.l-p.r,ih=H-p.t-p.b,maxV=Math.max(1,...bars.map(x=>x.v))*1.15;
 let cMin=Math.min(0,...cases),cMax=Math.max(1,...cases),cpad=Math.max(3,(cMax-cMin)*0.18);cMin=Math.max(0,cMin-cpad);cMax+=cpad;if(cMax<=cMin)cMax=cMin+10;
 let x=i=>p.l+(i+.5)*iw/bars.length,yv=v=>p.t+ih-(v/maxV)*ih,yc=v=>p.t+ih*(1-(v-cMin)/(cMax-cMin)),bw=Math.min(55,iw/bars.length*.52),pts=[];
 let z=`<div class="proc-combo"><svg viewBox="0 0 ${W} ${H}" xmlns="http://www.w3.org/2000/svg">`;
 for(let i=0;i<=4;i++){let y=p.t+ih*i/4;z+=`<line x1="${p.l}" y1="${y}" x2="${W-p.r}" y2="${y}" stroke="#e2e8f0"/><text x="${p.l-6}" y="${y+4}" text-anchor="end" font-size="10" fill="#718096">${(maxV*(1-i/4)).toFixed(1)}</text><text x="${W-p.r+6}" y="${y+4}" font-size="10" fill="#718096">${Math.round(cMax-(cMax-cMin)*i/4)}</text>`}
 bars.forEach((d,i)=>{let cx=x(i),yy=yv(d.v),bh=p.t+ih-yy;z+=`<rect x="${cx-bw/2}" y="${yy}" width="${bw}" height="${bh}" rx="5" fill="#8b5cf6"/><text x="${cx}" y="${Math.max(13,yy-6)}" text-anchor="middle" font-size="10" font-weight="700" fill="#102a56">${d.v.toFixed(2)}</text><text x="${cx}" y="${H-23}" text-anchor="middle" font-size="10" fill="#718096">${monthLabel(d.x)}</text><text x="${cx}" y="${H-7}" text-anchor="middle" font-size="10" font-weight="700" fill="#159a68">${fmt(cases[i])}${lang==='ko'?'건':lang==='vi'?' lô':' cases'}</text>`;pts.push([cx,yc(cases[i]),cases[i]])});
 if(pts.length){z+=`<polyline points="${pts.map(q=>q[0]+','+q[1]).join(' ')}" fill="none" stroke="#159a68" stroke-width="2.5"/>`;pts.forEach(q=>{z+=`<circle cx="${q[0]}" cy="${q[1]}" r="4" fill="#159a68"/>`})}
 z+=`<circle cx="${p.l}" cy="14" r="4" fill="#8b5cf6"/><text x="${p.l+9}" y="18" font-size="10" fill="#66758a">${T('procFee')}</text><circle cx="${p.l+100}" cy="14" r="4" fill="#159a68"/><text x="${p.l+109}" y="18" font-size="10" fill="#66758a">${T('cases')}</text></svg></div>`;return z
}
function renderProcessing(){let pm=processingMonths();if(!pm.length)return;let latest=pm.at(-1).month;if($('procPeriod')&&!$('procPeriod').options.length){$('procPeriod').innerHTML=`<option value="all">${L(`1~${latest}월 누계`,`Jan–Month ${latest} cumulative`,`Lũy kế tháng 1-${latest}`)}</option>`+pm.map(x=>`<option value="${x.month}">${monthLabel(x.month)}</option>`).join('');$('procPeriod').onchange=renderProcessing}if($('procItem')&&!$('procItem').options.length){$('procItem').innerHTML=`<option value="ALL">${allItemLabel()}</option>`+REP_ITEMS.map(x=>`<option value="${x}">${x}</option>`).join('')+`<option value="OTHER">${otherLabel()}</option>`;$('procItem').onchange=renderProcessing}let period=$('procPeriod')?.value||'all',item=$('procItem')?.value||'ALL',sel=period==='all'?pm:pm.filter(x=>String(x.month)===String(period)),usd=sel.reduce((a,x)=>a+procItemUsd(x.month,item),0),krw=sel.reduce((a,x)=>a+procItemKrw(x.month,item),0),endM=period==='all'?latest:+period,cur=procItemUsd(endM,item),pre=procItemUsd(endM-1,item),mom=pre?(cur/pre-1)*100:null,bars=pm.map(x=>({x:x.month,v:procItemKrw(x.month,item)/1e8})),max=Math.max(...bars.map(x=>x.v),1);$('processingSummary').innerHTML=`<div class="processing-metrics"><div class="pm"><div class="l">${period==='all'?L('선택기간 임가공비','Selected-period processing fee','Phí gia công kỳ chọn'):L(`${endM}월 임가공비`,`Month ${endM} processing fee`,`Phí gia công tháng ${endM}`)}</div><div class="v">${usdFmt(usd)}<br><span class="small">${procKrwFmt(krw)}</span></div></div><div class="pm"><div class="l">${L("선택 ITEM","Selected ITEM","ITEM đã chọn")}</div><div class="v">${item==='ALL'?(lang==='ko'?'전체':lang==='vi'?'Tất cả':'All'):item==='OTHER'?(otherLabel()):item}</div></div><div class="pm"><div class="l">${L(`${endM}월 전월 대비`,`Month ${endM} MoM`,`Tháng ${endM} so với tháng trước`)}</div><div class="v ${mom==null?'':mom>=0?'proc-up':'proc-down'}">${mom==null?'–':(mom>=0?'+':'')+mom.toFixed(1)+'%'}</div></div></div><div class="small">${L("월별 임가공비 (억원 KRW) · 처리 건수","Monthly processing fee (KRW 100M) · shipment count","Phí gia công theo tháng (100 triệu KRW) · số lô")}</div>${processingComboSvg(bars,item)}`;let cards=REP_ITEMS.map(it=>{let z=itemAnalysis(it,latest),f=v=>v==null?'–':(v>=0?'+':'')+v.toFixed(1)+'%',desc=it==='ANT'?L('임가공비 급증 시 생산물량 증가와 선적횟수·물류비 증가를 함께 비교합니다. 물량 증가율보다 건수 증가율이 높으면 분할출하·재고부족을 우선 점검합니다.','When processing fee rises sharply, compare production-volume growth with shipment count and logistics cost. If shipment-count growth exceeds volume growth, review split shipments and stock shortages first.','Khi phí gia công tăng mạnh, so sánh mức tăng sản lượng với số lô và chi phí logistics. Nếu số lô tăng nhanh hơn sản lượng, ưu tiên kiểm tra chia lô và thiếu tồn kho.'):it==='MOTOR'?L('대표 고비용 ITEM으로 물량 대비 출하횟수 적정성을 관리합니다. 물량이 감소하는데 건수가 유지·증가하면 개선 대상으로 관리합니다.','As a major high-cost ITEM, manage shipment frequency against production volume. If volume falls while shipment count stays flat or rises, flag it for improvement.','Là ITEM có chi phí lớn, quản lý tần suất xuất hàng so với sản lượng. Nếu sản lượng giảm nhưng số lô không giảm hoặc tăng, đưa vào đối tượng cải tiến.'):L('소량 반복출하와 긴급 AIR 발생 여부를 중점 관리하고, 임가공비 대비 선적건수 증가 여부를 확인합니다.','Focus on repeated small shipments and urgent AIR, and check whether shipment count is rising relative to processing fee.','Tập trung quản lý các lô nhỏ lặp lại và AIR khẩn cấp, đồng thời kiểm tra số lô có tăng so với phí gia công hay không.');return `<div class="item-insight"><b>${it} ${z.flag?`<span class="manage-flag">${manageNeededLabel()}</span>`:''}</b><div class="metrics">${L('임가공비','Processing fee','Phí gia công')} ${f(z.pchg)} · ${L('선적건수','Shipment count','Số lô')} ${f(z.cchg)} · ${L('물류비','Logistics cost','Chi phí logistics')} ${f(z.kchg)}</div><div class="proc-note">${desc}</div></div>`}).join('');$('processingInsight').innerHTML=`<div class="item-insights">${cards}</div>`;if($('processingTable'))$('processingTable').innerHTML=pm.map((x,i)=>{let p=pm[i-1],chg=p&&p.usd?(x.usd/p.usd-1)*100:null,mm=DATA.months.find(z=>z.month===x.month);return `<tr><td>${x.month}</td><td class="num">${usdFmt(x.usd)}</td><td class="num">${procKrwFmt(x.krw)}</td><td class="num">${chg==null?'–':(chg>=0?'+':'')+chg.toFixed(1)+'%'}</td><td class="num">${fmt(mm?.cases||0)}</td><td class="num">${krwFmt(monthKRW(mm||{month:x.month,cost:0}))}</td></tr>`}).join('')}
function applyLang(){document.documentElement.lang=lang;document.querySelectorAll('[data-i18n]').forEach(e=>e.textContent=T(e.dataset.i18n));document.querySelectorAll('[data-i18n-ph]').forEach(e=>e.placeholder=T(e.dataset.i18nPh));$('lang').value=lang;buildFilters();renderActions();render()}
function buildFilters(){if(!DATA.months.length){$('dataStatus').textContent=L('월간 엑셀을 업로드해 주세요.','Upload a monthly workbook.','Vui lòng tải Excel hàng tháng.');return;}let months=DATA.months.map(x=>x.month),max=Math.max(...months);$('monthFilter').innerHTML=`<option value="all">${lang==='ko'?`1~${max}월 ${T('cum')}`:lang==='vi'?`Tháng 1~${max} ${T('cum')}`:`Jan–${max} ${T('cum')}`}</option>`+months.map(m=>`<option value="${m}">${m}${lang==='ko'?'월':lang==='vi'?' tháng':''}</option>`).join('');$('monthFilter').value=state.month;$('imexFilter').innerHTML=`<option value="all">${T('all')}</option><option>IMPORT</option><option>EXPORT</option><option>N/A</option>`;$('imexFilter').value=state.imex;let modes=['SEA','AIR'];$('modeFilter').innerHTML=`<option value="all">${T('all')}</option>`+modes.map(m=>`<option>${m}</option>`).join('');$('modeFilter').value=state.mode;$('itemFilter').innerHTML=`<option value="ALL">${allItemLabel()}</option>`+REP_ITEMS.map(x=>`<option value="${x}">${x}</option>`).join('')+`<option value="OTHER">${otherLabel()}</option>`;$('itemFilter').value=state.item;let latest=DATA.months[DATA.months.length-1];$('dataStatus').textContent=`${T('data')}: 2026.01–${String(latest.month).padStart(2,'0')} · ${fmt(DATA.row_count)} ${T('records')} · VND→KRW: ÷20`}
function filtered(){return DATA.rows.filter(r=>(state.month==='all'||String(r.month)===String(state.month))&&(state.imex==='all'||r.imex===state.imex)&&(state.mode==='all'||r.mode===state.mode)&&rowMatchesMainItem(r,state.item))}
function sumRows(rows){let cost=rows.reduce((a,r)=>a+Number(r.total||0),0);return{cost,cases:rows.length,avg:rows.length?cost/rows.length:0}}
function itemGroupName(name){let k=String(name||'UNKNOWN').trim();if(k==='MOTOR'||k==='ANT'||k==='BLE-UWB')return k;return otherLabel()}
function itemFixedCostMix(rows){let groups={'MOTOR':0,'ANT':0,'BLE-UWB':0};groups[otherLabel()]=0;for(const r of rows){groups[itemGroupName(r.item)]=(groups[itemGroupName(r.item)]||0)+Number(r.total||0)}return ['MOTOR','ANT','BLE-UWB',otherLabel()].map(k=>[k,groups[k]||0])}
function itemFixedCaseMix(rows){let groups={'MOTOR':0,'ANT':0,'BLE-UWB':0};groups[otherLabel()]=0;for(const r of rows){groups[itemGroupName(r.item)]=(groups[itemGroupName(r.item)]||0)+1}return ['MOTOR','ANT','BLE-UWB',otherLabel()].map(k=>[k,groups[k]||0])}
function agg(rows,key){let m={};rows.forEach(r=>{let k=key==='item'?itemGroupName(r.item):(r[key]||'UNKNOWN');m[k]=(m[k]||0)+Number(r.total||0)});return Object.entries(m).sort((a,b)=>b[1]-a[1])}
function rankHTML(a,total){let mx=a[0]?.[1]||1;return a.slice(0,7).map(([n,v])=>`<div class="barrow"><span class="rankname" title="${escapeHtml(n)}">${escapeHtml(n)}</span><span class="track"><span class="fill" style="width:${v/mx*100}%"></span></span><span class="rankval">${bn(v)} (${Math.floor(total?v/total*100:0)}%)</span></div>`).join('')}
function rankDualHTML(rows,key,allowed){let src=allowed?rows.filter(r=>allowed.includes(r[key])):rows,m=new Map();for(const r of src){let n=r[key]||'UNKNOWN',o=m.get(n)||{v:0,k:0};o.v+=Number(r.total||0);o.k+=toKRW(r.total,r.month);m.set(n,o)}let a=[...m.entries()].sort((a,b)=>b[1].v-a[1].v),total=a.reduce((z,x)=>z+x[1].v,0),mx=a[0]?.[1].v||1;return a.slice(0,7).map(([n,o])=>`<div class="barrow"><span class="rankname" title="${escapeHtml(n)}">${escapeHtml(n)}</span><span class="track"><span class="fill" style="width:${o.v/mx*100}%"></span></span><span class="rankval">${bn(o.v)} VND (${Math.floor(total?o.v/total*100:0)}%)<br><span class="small">${krwFmt(o.k)}</span></span></div>`).join('')}
function mainItemValue(){return $('mainItem')?.value||'ALL'}
function rowMatchesMainItem(r,item){return item==='ALL'||(item==='OTHER'?normRepItem(r.item)==null:normRepItem(r.item)===item)}
function monthlyByFilter(){let item=state.item||'ALL';if(item==='ALL'&&state.month==='all'&&state.imex==='all'&&state.mode==='all')return DATA.months;return DATA.months.map(m=>{let r=DATA.rows.filter(x=>x.month===m.month&&(state.imex==='all'||x.imex===state.imex)&&(state.mode==='all'||x.mode===state.mode)&&rowMatchesMainItem(x,item));let s=sumRows(r);return{...m,cost:s.cost,cases:r.length,avg:s.avg,trucking:r.reduce((a,x)=>a+Number(x.trucking||0),0)}})}
function kpis(){let rows=filtered(),s=sumRows(rows),months=monthlyByFilter(),mrows=state.month==='all'?months:months.filter(x=>String(x.month)===String(state.month));let cost=mrows.reduce((a,x)=>a+x.cost,0),cases=mrows.reduce((a,x)=>a+x.cases,0),truck=mrows.reduce((a,x)=>a+Number(x.trucking||0),0),costKRW=monthsKRW(mrows),truckK=monthsTruckKRW(mrows);if(state.imex!=='all'||state.mode!=='all'||state.item!=='ALL'){cost=s.cost;cases=s.cases;truck=rows.reduce((a,r)=>a+Number(r.trucking||0),0);costKRW=rowsKRW(rows);truckK=rows.reduce((a,r)=>a+toKRW(r.trucking||0,r.month),0)}let truckShare=cost?Math.floor(truck/cost*100):0,avgV=cases?cost/cases:0,avgK=cases?costKRW/cases:0;let pms=processingForPeriod(state.month),procUsd=state.item==='ALL'?pms.reduce((a,x)=>a+Number(x.usd||0),0):pms.reduce((a,x)=>a+procItemUsd(x.month,state.item),0),procKrw=state.item==='ALL'?pms.reduce((a,x)=>a+Number(x.krw||0),0):pms.reduce((a,x)=>a+procItemKrw(x.month,state.item),0);return `<div class="card kpi"><div class="label">${T('cost')}</div><div class="value">${bn(cost)} VND</div><div class="sub"><span class="krw">${krwFmt(costKRW)}</span></div></div><div class="card kpi"><div class="label">${T('cases')}</div><div class="value">${fmt(cases)}${lang==='ko'?'건':''}</div></div><div class="card kpi"><div class="label">${T('avgCase')}</div><div class="value">${fmt(avgV)} VND</div><div class="sub"><span class="krw">${lang==='ko'?fmt(avgK)+'원':lang==='en'?'KRW '+fmt(avgK):fmt(avgK)+' KRW'}</span></div></div><div class="card kpi"><div class="label">${T('truckFee')}</div><div class="value">${bn(truck)} VND</div><div class="sub"><span class="krw">${krwFmt(truckK)}</span></div></div><div class="card kpi"><div class="label">${T('airShare')}</div><div class="value">${truckShare}%</div><div class="sub">${T('airSub')}</div></div><div class="card kpi"><div class="label">${T('procFee')}</div><div class="value">${usdFmt(procUsd)}</div><div class="sub"><span class="krw">${procKrwFmt(procKrw)}</span></div></div>`}
// Keep cost labels clear of the nearby line segments and point markers.
function costLabelPosition(top,bottom,lineYs){
 const low=Math.min(...lineYs)-6,high=Math.max(...lineYs)+6;
 let y=top+16;
 if(y+3>=low&&y-11<=high)y=high+13;
 if(y>bottom-4)return{y:Math.min(top-7,low-5),inside:false};
 return{y,inside:true};
}
function drawCombo(canvas,series){let rect=canvas.getBoundingClientRect(),dpr=devicePixelRatio||1,w=Math.max(320,rect.width),h=Math.max(240,rect.height);canvas.width=w*dpr;canvas.height=h*dpr;let c=canvas.getContext('2d');c.scale(dpr,dpr);c.clearRect(0,0,w,h);let p={l:55,r:52,t:30,b:56},cw=w-p.l-p.r,ch=h-p.t-p.b,vals=series.map(x=>monthKRW(x)/1e8),maxV=Math.max(...vals,1)*1.15,caseVals=series.map(x=>Number(x.cases||0)),caseMin=Math.min(0,...caseVals),caseMax=Math.max(1,...caseVals),pad=Math.max(5,(caseMax-caseMin)*0.18);caseMin=Math.max(0,caseMin-pad);caseMax+=pad;if(caseMax<=caseMin)caseMax=caseMin+10;c.font='11px Arial';c.strokeStyle='#e2e8f0';c.fillStyle='#718096';for(let i=0;i<=4;i++){let y=p.t+ch*i/4;c.beginPath();c.moveTo(p.l,y);c.lineTo(w-p.r,y);c.stroke();c.textAlign='right';c.fillText((maxV*(1-i/4)).toFixed(2),p.l-7,y+4);c.textAlign='left';c.fillText(Math.round(caseMax-(caseMax-caseMin)*i/4),w-p.r+7,y+4)}let slot=cw/series.length,bw=Math.min(62,slot*.52),pts=[],lineYs=caseVals.map(v=>p.t+ch*(1-Math.max(0,Math.min(1,(v-caseMin)/(caseMax-caseMin)))));series.forEach((x,i)=>{let cx=p.l+slot*i+slot/2,v=vals[i],bh=ch*v/maxV,y=p.t+ch-bh;c.fillStyle=(state.month!=='all'&&String(x.month)===String(state.month))?'#d94841':'#2f6fed';c.fillRect(cx-bw/2,y,bw,bh);let label=costLabelPosition(y,p.t+ch,lineYs.slice(Math.max(0,i-1),i+2));c.fillStyle=label.inside?'#fff':'#172b4d';c.textAlign='center';c.font='bold 11px Arial';c.fillText(v.toFixed(2),cx,label.y);let yy=p.t+ch*(1-Math.max(0,Math.min(1,(Number(x.cases||0)-caseMin)/(caseMax-caseMin))));pts.push([cx,yy,Number(x.cases||0)]);c.fillStyle='#718096';c.font='11px Arial';c.fillText(x.month+(lang==='ko'?'월':''),cx,h-29);c.fillStyle='#159a68';c.font='bold 11px Arial';c.fillText(fmt(Number(x.cases||0))+(lang==='ko'?'건':lang==='vi'?' lô':' cases'),cx,h-11)});c.strokeStyle='#159a68';c.lineWidth=2.5;c.beginPath();pts.forEach((q,i)=>i?c.lineTo(q[0],q[1]):c.moveTo(q[0],q[1]));c.stroke();pts.forEach(q=>{c.fillStyle='#159a68';c.beginPath();c.arc(q[0],q[1],4,0,Math.PI*2);c.fill()});c.fillStyle='#718096';c.font='11px Arial';c.textAlign='left';c.fillText(lang==='ko'?'좌: 억원 KRW':'KRW 100M',p.l,11);c.textAlign='right';c.fillText(T('cases'),w-p.r,11)}
function drawMode(canvas){let months=DATA.months.map(x=>x.month),modes=['SEA','AIR'];let colors=['#2f6fed','#e68a2e'];let rect=canvas.getBoundingClientRect(),dpr=devicePixelRatio||1,w=Math.max(320,rect.width),h=Math.max(240,rect.height);canvas.width=w*dpr;canvas.height=h*dpr;let c=canvas.getContext('2d');c.scale(dpr,dpr);c.clearRect(0,0,w,h);let p={l:45,r:12,t:12,b:35},cw=w-p.l-p.r,ch=h-p.t-p.b;let totals=months.map(m=>DATA.rows.filter(r=>r.month===m&&(r.mode==='SEA'||r.mode==='AIR')).reduce((a,r)=>a+Number(r.total||0),0)),mx=Math.max(...totals,1);months.forEach((m,i)=>{let rs=DATA.rows.filter(r=>r.month===m&&(r.mode==='SEA'||r.mode==='AIR')),x=p.l+i*cw/months.length+8,bw=cw/months.length-16,y=p.t+ch;modes.forEach((mo,j)=>{let v=rs.filter(r=>r.mode===mo).reduce((a,r)=>a+Number(r.total||0),0),hh=ch*v/mx;c.fillStyle=colors[j];c.fillRect(x,y-hh,bw,hh);y-=hh});c.fillStyle='#718096';c.font='11px Arial';c.textAlign='center';c.fillText(m+(lang==='ko'?'월':''),x+bw/2,h-12)})}
function pieHTML(rows,key,allowed,top3=false){let src=allowed?rows.filter(r=>allowed.includes(r[key])):rows;let a;if(key==='item'&&top3){a=itemFixedCostMix(src)}else{let m={};src.forEach(r=>{let k=r[key]||'UNKNOWN';m[k]=(m[k]||0)+Number(r.total||0)});a=Object.entries(m).sort((a,b)=>b[1]-a[1])}let total=a.reduce((z,x)=>z+x[1],0),colors=['#2f6fed','#159a68','#e68a2e','#8b5cf6'];let grad=[],cur=0;a.forEach((x,i)=>{let n=total?x[1]/total*100:0;grad.push(`${colors[i%4]} ${cur}% ${cur+n}%`);cur+=n});return `<div style="display:flex;gap:18px;align-items:center;flex-wrap:wrap"><div style="width:180px;height:180px;border-radius:50%;background:conic-gradient(${grad.join(',')});position:relative"><div style="position:absolute;inset:42px;border-radius:50%;background:white"></div></div><div style="flex:1;min-width:180px">${a.map((x,i)=>`<div style="display:flex;justify-content:space-between;gap:12px;margin:10px 0"><span><i style="display:inline-block;width:10px;height:10px;border-radius:50%;background:${colors[i%4]};margin-right:7px"></i>${x[0]}</span><b>${Math.floor(total?x[1]/total*100:0)}% · ${krwFmt(key==='item'&&top3?rowsKRW(src.filter(r=>itemGroupName(r.item)===x[0])):rowsKRW(src.filter(r=>(r[key]||'UNKNOWN')===x[0])))}</b></div>`).join('')}</div></div>`}
const chartPeriods={item:'all',mode:'all',cases:'all'};
function periodOptionsHTML(selected){let latest=DATA.months.at(-1)?.month||1;let cumLabel=lang==='ko'?`1~${latest}월 누계`:lang==='en'?`Jan-${latest} cumulative`:`Tháng 1-${latest} lũy kế`;return `<option value="all" ${selected==='all'?'selected':''}>${cumLabel}</option>`+DATA.months.map(x=>{let lab=lang==='ko'?`${x.month}월`:lang==='en'?`Month ${x.month}`:`Tháng ${x.month}`;return `<option value="${x.month}" ${String(selected)===String(x.month)?'selected':''}>${lab}</option>`}).join('')}
function rowsForChartPeriod(period){return DATA.rows.filter(r=>(period==='all'||String(r.month)===String(period))&&(state.imex==='all'||r.imex===state.imex)&&(state.mode==='all'||r.mode===state.mode)&&rowMatchesMainItem(r,state.item))}
function periodLabel(period){let latest=DATA.months.at(-1)?.month||1;if(period==='all')return lang==='ko'?`1~${latest}월`:lang==='en'?`Jan-${latest}`:`Tháng 1-${latest}`;return lang==='ko'?`${period}월`:lang==='en'?`Month ${period}`:`Tháng ${period}`}
function donutHTML(a,total,centerText,kind,sourceRows){let colors=['#2f6fed','#159a68','#e68a2e','#8b5cf6'];let grad=[],cur=0;a.forEach((x,i)=>{let n=total?x[1]/total*100:0;grad.push(`${colors[i%4]} ${cur}% ${cur+n}%`);cur+=n});let legends=a.map((x,i)=>{let pct=Math.floor(total?x[1]/total*100:0),right;if(kind==='cases')right=`${fmt(x[1])}${lang==='ko'?'건':lang==='en'?' cases':' lô'} (${pct}%)`;else{let kr=kind==='item'?rowsKRW(sourceRows.filter(r=>itemGroupName(r.item)===x[0])):rowsKRW(sourceRows.filter(r=>(r.mode||'UNKNOWN')===x[0]));right=`${pct}% · ${krwFmt(kr)}`}return `<div style="display:flex;justify-content:space-between;gap:12px;margin:10px 0"><span><i style="display:inline-block;width:10px;height:10px;border-radius:50%;background:${colors[i%4]};margin-right:7px"></i>${x[0]}</span><b>${right}</b></div>`}).join('');return `<div style="display:flex;gap:18px;align-items:center;flex-wrap:wrap;width:100%"><div style="width:180px;height:180px;border-radius:50%;background:conic-gradient(${grad.join(',')});position:relative;flex:0 0 180px"><div style="position:absolute;inset:42px;border-radius:50%;background:white;display:flex;align-items:center;justify-content:center;text-align:center;line-height:1.35"><b>${centerText}</b></div></div><div style="flex:1;min-width:180px">${legends}</div></div>`}
function renderPeriodCharts(){['item','mode','cases'].forEach(k=>{let id=k==='item'?'itemPeriod':k==='mode'?'modePeriod':'caseItemPeriod',el=$(id);if(el){el.innerHTML=periodOptionsHTML(chartPeriods[k]);el.value=chartPeriods[k];el.onchange=e=>{chartPeriods[k]=e.target.value;renderPeriodCharts()}}});let itemRows=rowsForChartPeriod(chartPeriods.item),itemA=itemFixedCostMix(itemRows),itemTotal=itemA.reduce((z,x)=>z+x[1],0);$('itemRank').innerHTML=donutHTML(itemA,itemTotal,periodLabel(chartPeriods.item),'item',itemRows);let modeRows=rowsForChartPeriod(chartPeriods.mode).filter(r=>r.mode==='SEA'||r.mode==='AIR'),modeA=['SEA','AIR'].map(k=>[k,modeRows.filter(r=>r.mode===k).reduce((a,r)=>a+Number(r.total||0),0)]),modeTotal=modeA.reduce((z,x)=>z+x[1],0);$('modeRank').innerHTML=donutHTML(modeA,modeTotal,periodLabel(chartPeriods.mode),'mode',modeRows);let caseRows=rowsForChartPeriod(chartPeriods.cases),caseA=itemFixedCaseMix(caseRows),caseTotal=caseA.reduce((z,x)=>z+x[1],0);$('caseSummary').innerHTML=donutHTML(caseA,caseTotal,`${periodLabel(chartPeriods.cases)}<br>${fmt(caseTotal)}${lang==='ko'?'건':lang==='en'?' cases':' lô'}`,'cases',caseRows)}
function insightTexts(){let ms=DATA.months,last=ms.at(-1),first=ms[0],caseYo=(last.cases/first.cases-1)*100,costYo=(last.cost/first.cost-1)*100,flags=REP_ITEMS.filter(x=>itemAnalysis(x,last.month).flag);return [
`<div class="insight"><b>① ${L('비용 증가는 건수 증가 영향이 큼','Shipment count is a major cost driver','Số lần xuất hàng là yếu tố chính làm tăng chi phí')}</b><p>${L(`1월→${last.month}월 처리 건수는 ${caseYo.toFixed(1)}% 증가했고 물류비는 ${costYo.toFixed(1)}% 변동했습니다. 베트남 법인의 물류비는 출하건수에 정비례합니다.`,`From January to Month ${last.month}, shipment count increased ${caseYo.toFixed(1)}% and logistics cost changed ${costYo.toFixed(1)}%. Logistics cost at the Vietnam entity is directly proportional to shipment count.`,`Từ tháng 1 đến tháng ${last.month}, số lô tăng ${caseYo.toFixed(1)}% và chi phí logistics biến động ${costYo.toFixed(1)}%. Chi phí logistics của pháp nhân Việt Nam tỷ lệ thuận với số lần xuất hàng.`)}</p></div>`,
`<div class="insight"><b>② ${L('관리 목표','Management target','Mục tiêu quản lý')}</b><p>${L(`적정재고 확보 → 출하횟수 축소 → 합배송 확대 → 긴급 AIR 최소화 순으로 관리합니다. 임가공비가 증가하지 않은 사업부·ITEM 중 물류비가 감소하지 않은 경우를 출하횟수 관리 대상으로 지정하고 적정재고 확보 여부를 점검합니다.${flags.length?' 현재 '+flags.join(', ')+' 점검이 필요합니다.':''}`,`Manage in this order: secure adequate inventory → reduce shipment frequency → expand consolidation → minimize urgent AIR. Business units/ITEMs whose processing fee does not increase and whose logistics cost does not decrease are designated for shipment-frequency management and inventory adequacy checks.${flags.length?' Current representative items requiring review: '+flags.join(', ')+'.':''}`,`Quản lý theo thứ tự: bảo đảm tồn kho phù hợp → giảm số lần xuất hàng → tăng gộp lô → giảm AIR khẩn cấp. Bộ phận/ITEM có phí gia công không tăng và chi phí logistics không giảm sẽ được đưa vào đối tượng quản lý tần suất xuất hàng và kiểm tra mức tồn kho phù hợp.${flags.length?' Các ITEM đại diện cần kiểm tra hiện tại: '+flags.join(', ')+'.':''}`)}</p></div>`,
`<div class="insight"><b>③ ${L('대표 관리 ITEM: MOTOR · ANT · BLE-UWB','Representative management ITEMs: MOTOR · ANT · BLE-UWB','ITEM quản lý đại diện: MOTOR · ANT · BLE-UWB')}</b><p>${L('임가공비를 물량지표로 활용해 각 ITEM의 선적건수와 물류비를 연계 분석합니다. 물량 증가보다 출하횟수가 빠르게 증가하면 분할출하·재고부족·긴급출하 여부를 점검합니다.','Use processing fee as a volume indicator and analyze shipment count and logistics cost together for each ITEM. If shipment frequency grows faster than volume, review split shipments, stock shortages and urgent shipments.','Sử dụng phí gia công làm chỉ báo sản lượng và phân tích đồng thời số lô cùng chi phí logistics của từng ITEM. Nếu tần suất xuất hàng tăng nhanh hơn sản lượng, kiểm tra chia lô, thiếu tồn kho và xuất hàng khẩn cấp.')}</p></div>`] }function reportDraft(){let ms=DATA.months,rm=state.month==='all'?ms.at(-1).month:Number(state.month),cur=ms.find(x=>Number(x.month)===rm)||ms.at(-1),prev=ms.find(x=>Number(x.month)===rm-1)||null,pms=processingMonths(),pc=pms.find(x=>Number(x.month)===rm)||null,pp=pms.find(x=>Number(x.month)===rm-1)||null,anal=REP_ITEMS.map(x=>[x,itemAnalysis(x,rm)]),flags=anal.filter(x=>x[1].flag).map(x=>x[0]),f=v=>v==null?'–':(v>=0?'+':'')+v.toFixed(1)+'%',caseMo=prev&&prev.cases?(cur.cases/prev.cases-1)*100:null,costMo=prev&&prev.cost?(cur.cost/prev.cost-1)*100:null,procMo=pp&&pp.usd&&pc?(pc.usd/pp.usd-1)*100:null,curK=monthKRW(cur),avgK=cur.cases?curK/cur.cases:0;if(lang==='ko')return `[2026년 ${rm}월 베트남 물류비 현황 및 절감 관리]

1. ${rm}월 물류비 현황
물류비 ${bn(cur.cost)} VND(${krwFmt(curK)}), 처리 건수 ${fmt(cur.cases)}건, 건당비용 ${fmt(cur.avg)} VND(${fmt(avgK)}원)입니다.${prev?` 전월 대비 처리 건수 ${f(caseMo)}, 물류비 ${f(costMo)} 변동했습니다.`:''}

2. 핵심 관리방향 – 출하 건수 관리
트럭비와 통관비는 출하 건별 최소 고정비가 발생하므로 적정재고 확보를 통한 출하횟수 축소가 핵심입니다. 베트남 법인의 물류비는 출하건수에 정비례합니다.

3. 생산물량과 물류비 연계 관리
${rm}월 임가공비는 ${usdFmt(pc?.usd||0)}(${procKrwFmt(pc?.krw||0)})이며${pp?` 전월 대비 ${f(procMo)} 변동했습니다.`:''} 임가공비가 증가하지 않은 사업부·ITEM은 출하횟수 관리 대상으로 지정합니다.

4. 대표 관리 ITEM – MOTOR / ANT / BLE-UWB
${anal.map(([it,z])=>`${it}: 임가공비 ${f(z.pchg)}, 선적건수 ${f(z.cchg)}, 물류비 ${f(z.kchg)}${z.flag?' → 출하횟수 관리 필요':''}`).join('\n')}

5. 절감 추진 및 사업부 요청
${flags.length?`${flags.join(', ')}은 ${rm}월 출하횟수 관리 대상입니다. `:''}적정재고 확보, 출하계획 사전 조정 및 합배송을 통한 출하횟수 축소를 요청하겠습니다.

6. 관리 목표
생산물량 대비 적정 출하건수를 유지하여 건당 고정비 발생을 최소화합니다.`;if(lang==='en')return `Vietnam logistics report — Month ${rm}, 2026

Logistics cost: ${bn(cur.cost)} VND (${krwFmt(curK)}), shipments: ${fmt(cur.cases)}, cost/shipment: ${fmt(cur.avg)} VND (KRW ${fmt(avgK)}).
Processing fee: ${usdFmt(pc?.usd||0)} (${procKrwFmt(pc?.krw||0)}). Items with no processing-fee increase are shipment-frequency management targets.
MOTOR / ANT / BLE-UWB are representative management items.
${flags.length?'Management required: '+flags.join(', ')+'.':''}`;return `Báo cáo logistics Việt Nam — Tháng ${rm}/2026

Chi phí logistics: ${bn(cur.cost)} VND (${krwFmt(curK)}), số lô: ${fmt(cur.cases)}, chi phí/lô: ${fmt(cur.avg)} VND (${fmt(avgK)} KRW).
Phí gia công: ${usdFmt(pc?.usd||0)} (${procKrwFmt(pc?.krw||0)}). ITEM có phí gia công không tăng là đối tượng quản lý tần suất xuất hàng.
MOTOR / ANT / BLE-UWB là các ITEM quản lý đại diện.
${flags.length?'Cần quản lý: '+flags.join(', ')+'.':''}`}function ensureMainItemSelector(){
 const el=$('mainItem');
 if(!el)return;
 let cur=state.item||el.value||'ALL';
 el.innerHTML=`<option value="ALL">${allItemLabel()}</option><option value="MOTOR">MOTOR</option><option value="ANT">ANT</option><option value="BLE-UWB">BLE-UWB</option><option value="OTHER">${otherLabel()}</option>`;
 el.value=[...el.options].some(o=>o.value===cur)?cur:'ALL';
}
function render(){if(!DATA.months.length){$('kpiWrap').textContent=L('등록된 물류비 자료가 없습니다.','No logistics data loaded.','Chưa có dữ liệu logistics.');return;}try{ensureMainItemSelector();if($('mainItem'))$('mainItem').value=state.item||'ALL';let rows=filtered(),s=sumRows(rows);$('kpiWrap').innerHTML=kpis();$('casePriority').innerHTML=lang==='ko'?'<b>핵심 관리 포인트: 건수 관리</b><p>트럭비와 통관비는 출하 건별로 최소 고정비가 발생합니다. 따라서 물류비 절감의 핵심은 단가 협상보다 적정재고 확보와 출하횟수 관리입니다.</p><p><b>출하 건수 감소 → 건당 고정비 절감 → 총 물류비 절감</b></p>':lang==='en'?'<b>Key management point: Shipment count</b><p>Truck and customs-clearance costs carry a minimum fixed cost per shipment. The key to logistics savings is therefore adequate inventory and shipment-frequency control rather than unit-price negotiation.</p><p><b>Fewer shipments → lower fixed cost per case → lower total logistics cost</b></p>':'<b>Điểm quản lý trọng tâm: Số lô</b><p>Chi phí xe và thông quan phát sinh mức chi phí cố định tối thiểu cho từng lô. Vì vậy trọng tâm tiết giảm là duy trì tồn kho phù hợp và kiểm soát tần suất xuất hàng hơn là đàm phán đơn giá.</p><p><b>Giảm số lô → giảm chi phí cố định/lô → giảm tổng chi phí logistics</b></p>';renderPeriodCharts();renderProcessing();$('imexRank').innerHTML=rankDualHTML(rows,'imex');$('insights').innerHTML=insightTexts().join('');$('reportText').textContent=reportDraft();renderTables();renderDetails();renderSavingIdeas();updateSaving();let ms=monthlyByFilter();setTimeout(()=>{drawCombo($('monthlyChart'),ms);drawMode($('modeChart'))},20)}catch(e){console.error(e);$('uploadMsg').className='uploadMsg err';$('uploadMsg').textContent='화면 표시 오류: '+e.message}}
function renderTables(){let ms=DATA.months;$('monthTable').innerHTML=ms.map(x=>`<tr><td>${x.month}</td><td class="num">${fmt(x.cases)}</td><td class="num ${x.caseMom>0?'up':'down'}">${x.caseMom==null?'–':(x.caseMom>0?'+':'')+x.caseMom.toFixed(1)+'%'}</td><td class="num">${dualMoney(x.cost,x.month)}</td><td class="num ${x.mom>0?'up':'down'}">${x.mom==null?'–':(x.mom>0?'+':'')+x.mom.toFixed(1)+'%'}</td><td class="num">${dualMoney(x.avg,x.month)}</td><td class="num">${dualMoney(x.trucking,x.month)}</td></tr>`).join('');let top3=itemFixedCostMix(DATA.rows).slice(0,3),share=top3.reduce((a,x)=>a+x[1],0)/DATA.total_cost*100,first=ms[0],last=ms.at(-1);$('concentration').innerHTML=`<div class="insight"><b>${lang==='ko'?`관리 ITEM 3종 집중도 ${share.toFixed(1)}%`:lang==='en'?`Managed 3-ITEM concentration ${share.toFixed(1)}%`:`Tỷ trọng 3 ITEM quản lý ${share.toFixed(1)}%`}</b><p>MOTOR, ANT, BLE-UWB</p></div><div class="insight"><b>${T('caseCostMsg')}</b><p>${lang==='ko'?`1월 ${first.cases}건 → ${last.month}월 ${last.cases}건, 건당비용 ${fmt(first.avg)} VND (${krwFmt(toKRW(first.avg,first.month))}) → ${fmt(last.avg)} VND (${krwFmt(toKRW(last.avg,last.month))})`:lang==='en'?`Jan ${first.cases} cases → month ${last.month} ${last.cases} cases; cost/case ${fmt(first.avg)} VND (${krwFmt(toKRW(first.avg,first.month))}) → ${fmt(last.avg)} VND (${krwFmt(toKRW(last.avg,last.month))})`:`Tháng 1 ${first.cases} lô → tháng ${last.month} ${last.cases} lô; chi phí/lô ${fmt(first.avg)} VND (${krwFmt(toKRW(first.avg,first.month))}) → ${fmt(last.avg)} VND (${krwFmt(toKRW(last.avg,last.month))})`}</p></div>`}
function renderDetails(){let rows=filtered(),q=($('searchBox').value||'').toLowerCase();if(q)rows=rows.filter(r=>[r.item,r.inv,r.hbl,r.mode,r.truck].some(x=>String(x||'').toLowerCase().includes(q)));$('detailBody').innerHTML=rows.slice(0,500).map(r=>`<tr><td>${r.month}</td><td>${escapeHtml(r.item)}</td><td>${escapeHtml(r.imex)}</td><td>${r.mode==='SEA'||r.mode==='AIR'?r.mode:'-'}</td><td>${escapeHtml(r.truck||'')}</td><td>${escapeHtml(r.inv||'')}</td><td>${escapeHtml(r.hbl||'')}</td><td class="num">${dualMoney(r.total,r.month)}</td></tr>`).join('');$('detailCount').textContent=`${T('search')} ${fmt(rows.length)} ${T('records')} · ${T('display')}`}


function pdfMainCostCaseChart(){
  let arr=DATA.months,W=1000,H=255,p={l:58,r:58,t:34,b:72},iw=W-p.l-p.r,ih=H-p.t-p.b;
  let vals=arr.map(m=>monthKRW(m)/1e8),maxV=Math.max(...vals,1)*1.15,caseVals=arr.map(m=>Number(m.cases||0)),caseMin=Math.min(0,...caseVals),caseMax=Math.max(1,...caseVals),pad=Math.max(5,(caseMax-caseMin)*0.18);caseMin=Math.max(0,caseMin-pad);caseMax+=pad;if(caseMax<=caseMin)caseMax=caseMin+10;
  let x=i=>p.l+(i+.5)*iw/arr.length,yv=v=>p.t+ih-(v/maxV)*ih,yc=v=>p.t+ih*(1-(v-caseMin)/(caseMax-caseMin));
  let bw=Math.min(62,iw/arr.length*.52),pts=[],lineYs=caseVals.map(yc);
  let s=`<svg viewBox="0 0 ${W} ${H}" xmlns="http://www.w3.org/2000/svg">`;
  s+=`<text x="${p.l}" y="13" font-size="11" fill="#718096">좌: 억원 KRW</text>`;s+=`<text x="${W-p.r}" y="13" text-anchor="end" font-size="11" fill="#718096">처리 건수</text>`;
  for(let i=0;i<=4;i++){let y=p.t+ih*i/4,left=maxV*(1-i/4),right=Math.round(caseMax-(caseMax-caseMin)*i/4);s+=`<line x1="${p.l}" y1="${y}" x2="${W-p.r}" y2="${y}" stroke="#e2e8f0" stroke-width="1"/><text x="${p.l-8}" y="${y+4}" text-anchor="end" font-size="10" fill="#718096">${left.toFixed(2)}</text><text x="${W-p.r+8}" y="${y+4}" text-anchor="start" font-size="10" fill="#718096">${right}</text>`}
  arr.forEach((m,i)=>{let v=vals[i],cx=x(i),yy=yv(v),bh=p.t+ih-yy,fill=(state.month!=='all'&&String(m.month)===String(state.month))?'#d94841':'#2f6fed',label=costLabelPosition(yy,p.t+ih,lineYs.slice(Math.max(0,i-1),i+2));s+=`<rect x="${cx-bw/2}" y="${yy}" width="${bw}" height="${bh}" rx="2" fill="${fill}"/><text x="${cx}" y="${label.y}" text-anchor="middle" font-size="10" font-weight="700" fill="${label.inside?'#fff':'#172b4d'}">${v.toFixed(2)}</text><text x="${cx}" y="${p.t+ih+21}" text-anchor="middle" font-size="10" fill="#718096">${m.month}월</text><text x="${cx}" y="${p.t+ih+39}" text-anchor="middle" font-size="10" font-weight="700" fill="#159a68">${fmt(Number(m.cases||0))}건</text>`;pts.push([cx,yc(Number(m.cases||0)),Number(m.cases||0)])});
  if(pts.length){s+=`<polyline points="${pts.map(q=>q[0]+','+q[1]).join(' ')}" fill="none" stroke="#159a68" stroke-width="2.7"/>`;pts.forEach(q=>s+=`<circle cx="${q[0]}" cy="${q[1]}" r="4" fill="#159a68"/>`) }
  s+=`<circle cx="${p.l}" cy="${H-9}" r="4.5" fill="#2f6fed"/><text x="${p.l+10}" y="${H-5}" font-size="10" fill="#66758a">물류비</text><circle cx="${p.l+74}" cy="${H-9}" r="4.5" fill="#159a68"/><text x="${p.l+84}" y="${H-5}" font-size="10" fill="#66758a">처리 건수</text>`;return s+`</svg>`;
}
function pdfMonthlyItemSeries(item){
  return DATA.months.map(m=>{
    let v;
    if(item==='ALL'){
      v={cases:m.cases,cost:m.cost}
    }else{
      v=logisticsItemMonth(m.month,item)
    }
    let krw=Number(v.cost||0)*Number((DATA.fx&&DATA.fx[m.month])||0);
    return {month:m.month,cases:Number(v.cases||0),cost:Number(v.cost||0),krw,krwEok:krw/1e8}
  })
}
function pdfTrendSvg(item,titleKo,titleVi){
  let arr=pdfMonthlyItemSeries(item),W=520,H=225,p={l:46,r:43,t:22,b:33},iw=W-p.l-p.r,ih=H-p.t-p.b;
  let maxV=Math.max(0.1,...arr.map(x=>x.krwEok))*1.18;
  let moms=arr.map((x,i)=>i&&arr[i-1].krwEok?((x.krwEok/arr[i-1].krwEok)-1)*100:null);
  let maxAbs=Math.max(10,...moms.filter(v=>v!=null).map(v=>Math.abs(v)))*1.25;
  let x=i=>p.l+(i+.5)*iw/arr.length,yv=v=>p.t+ih-(v/maxV)*ih,yp=v=>p.t+ih/2-(v/maxAbs)*(ih/2);
  let bw=Math.min(35,iw/arr.length*.48),s=`<svg viewBox="0 0 ${W} ${H}" xmlns="http://www.w3.org/2000/svg">`;
  for(let i=0;i<=4;i++){let val=maxV*(4-i)/4,y=p.t+ih*i/4;s+=`<line x1="${p.l}" y1="${y}" x2="${W-p.r}" y2="${y}" stroke="#e2e8f0" stroke-width="1"/><text x="${p.l-5}" y="${y+3}" text-anchor="end" font-size="9" fill="#64748b">${val.toFixed(2)}</text>`}
  s+=`<line x1="${p.l}" y1="${yp(0)}" x2="${W-p.r}" y2="${yp(0)}" stroke="#f0b7a8" stroke-dasharray="3 3"/>`;
  [-maxAbs,0,maxAbs].forEach(v=>s+=`<text x="${W-p.r+5}" y="${yp(v)+3}" font-size="9" fill="#9a5b4c">${v.toFixed(0)}%</text>`);
  let pts=[];
  arr.forEach((d,i)=>{
    let cx=x(i),yy=yv(d.krwEok),bh=p.t+ih-yy;
    let fill=(state.month!=='all'&&String(d.month)===String(state.month))?'#d94841':'#2f6fed';s+=`<rect x="${cx-bw/2}" y="${yy}" width="${bw}" height="${bh}" rx="2" fill="${fill}"/>`;
    s+=`<text x="${cx}" y="${Math.min(yy+12,p.t+ih-3)}" text-anchor="middle" font-size="8" font-weight="700" fill="white">${d.krwEok.toFixed(2)}</text>`;
    s+=`<text x="${cx}" y="${H-12}" text-anchor="middle" font-size="9" fill="#64748b">${d.month}월</text>`;
    if(moms[i]!=null)pts.push([cx,yp(moms[i]),moms[i]])
  });
  if(pts.length){
    s+=`<polyline points="${pts.map(q=>q[0]+','+q[1]).join(' ')}" fill="none" stroke="#e56b4a" stroke-width="2"/>`;
    pts.forEach(q=>{s+=`<circle cx="${q[0]}" cy="${q[1]}" r="3" fill="#e56b4a"/><text x="${q[0]}" y="${q[1]-6}" text-anchor="middle" font-size="8" fill="#b64d33">${q[2]>=0?'+':''}${q[2].toFixed(1)}%</text>`})
  }
  s+=`<text x="${p.l}" y="10" font-size="8" fill="#64748b">억원 KRW / 100 triệu KRW</text><text x="${W-p.r}" y="10" text-anchor="end" font-size="8" fill="#9a5b4c">MoM %</text></svg>`;
  let latest=arr.at(-1),prev=arr.at(-2),chg=prev&&prev.krwEok?((latest.krwEok/prev.krwEok)-1)*100:null;
  return `<div class="print-chart-box"><div class="print-chart-title">${titleKo} / ${titleVi}</div><div class="print-chart-sub">${latest.month}월 ${latest.krwEok.toFixed(2)}억원 · ${chg==null?'–':(chg>=0?'+':'')+chg.toFixed(1)+'%'} MoM / Tháng ${latest.month}: ${latest.krwEok.toFixed(2)} x 100 triệu KRW</div>${s}<div class="print-chart-legend">■ 월별 물류비 / Chi phí logistics theo tháng &nbsp;&nbsp; ● 전월 대비 증감 / Biến động so với tháng trước</div></div>`
}

function pdfMonthItemPie(rows,rm){
 const defs=[
   {key:'MOTOR',label:'MOTOR',fill:'#2f6fed'},
   {key:'ANT',label:'ANT',fill:'#159a68'},
   {key:'BLE-UWB',label:'BLE/UWB',fill:'#e68a2e'},
   {key:'OTHER',label:'기타 / Khác',fill:'#8155df'}
 ];
 const grouped=defs.map(d=>{
   let rs=rows.filter(r=>d.key==='OTHER'?normRepItem(r.item)==null:normRepItem(r.item)===d.key);
   let cost=rs.reduce((a,r)=>a+Number(r.total||0),0),krw=rowsKRW(rs);
   return {...d,cost,krw};
 });
 const total=grouped.reduce((a,x)=>a+x.cost,0)||1,W=720,H=235,cx=170,cy=118,R=78,r=44;
 let angle=-Math.PI/2,paths='';
 const point=(rad,ang)=>[cx+rad*Math.cos(ang),cy+rad*Math.sin(ang)];
 grouped.forEach(x=>{
   let frac=x.cost/total,da=frac*Math.PI*2,a0=angle,a1=angle+da;
   if(frac>0){
     let [x0,y0]=point(R,a0),[x1,y1]=point(R,a1),[ix1,iy1]=point(r,a1),[ix0,iy0]=point(r,a0),large=da>Math.PI?1:0;
     paths+=`<path d="M ${x0} ${y0} A ${R} ${R} 0 ${large} 1 ${x1} ${y1} L ${ix1} ${iy1} A ${r} ${r} 0 ${large} 0 ${ix0} ${iy0} Z" fill="${x.fill}"/>`;
   }
   angle=a1;
 });
 let legend=grouped.map((x,i)=>{
   let pct=x.cost/total*100,y=55+i*42;
   return `<rect x="340" y="${y-10}" width="11" height="11" rx="2" fill="${x.fill}"/><text x="360" y="${y}" font-size="13" font-weight="700" fill="#12233f">${x.label}</text><text x="470" y="${y}" font-size="12" fill="#12233f">${pct.toFixed(1)}% · ${bn(x.cost)} VND · ${krwFmt(x.krw)}</text>`;
 }).join('');
 return `<svg viewBox="0 0 ${W} ${H}" xmlns="http://www.w3.org/2000/svg">${paths}<text x="${cx}" y="${cy-3}" text-anchor="middle" font-size="16" font-weight="800" fill="#12233f">${rm}월</text><text x="${cx}" y="${cy+17}" text-anchor="middle" font-size="11" fill="#667085">총 ${bn(total)} VND</text>${legend}</svg>`;
}
function buildOnePageReport(){
 let ms=DATA.months,rm=state.month==='all'?ms.at(-1).month:Number(state.month),
     cur=ms.find(x=>Number(x.month)===rm)||ms.at(-1),
     cumMonths=ms.filter(x=>Number(x.month)<=rm),
     cumRows=DATA.rows.filter(r=>Number(r.month)<=rm),
     monthRows=DATA.rows.filter(r=>Number(r.month)===rm),
     cumCost=cumMonths.reduce((a,x)=>a+Number(x.cost||0),0),
     cumCases=cumMonths.reduce((a,x)=>a+Number(x.cases||0),0),
     cumK=cumMonths.reduce((a,x)=>a+monthKRW(x),0),
     curK=monthKRW(cur),
     defs=[
       {key:'MOTOR',label:'MOTOR'},
       {key:'ANT',label:'ANT'},
       {key:'BLE-UWB',label:'BLE/UWB'},
       {key:'OTHER',label:'기타 / Khác'}
     ];
 function groupStats(rows){
   let arr=defs.map(d=>{
     let rs=rows.filter(r=>d.key==='OTHER'?normRepItem(r.item)==null:normRepItem(r.item)===d.key),
         cost=rs.reduce((a,r)=>a+Number(r.total||0),0),
         cases=rs.length,
         airCases=rs.filter(r=>String(r.mode||'').toUpperCase()==='AIR').length,
         krw=rowsKRW(rs);
     return {...d,cost,cases,airCases,krw}
   });
   let total=arr.reduce((a,x)=>a+x.cost,0)||1;
   arr.forEach(x=>x.share=x.cost/total*100);
   return arr;
 }
 let cumStats=groupStats(cumRows),monthStats=groupStats(monthRows);
 let cumRowsHtml=cumStats.map((x,i)=>`<tr><td><b>${i+1}. ${x.label}</b></td><td>${fmt(x.cases)}건 / lô <span class="air-note">(항공 ${fmt(x.airCases)}건 / AIR ${fmt(x.airCases)} lô)</span></td><td>${bn(x.cost)} VND</td><td>${krwFmt(x.krw)}</td><td><b>${x.share.toFixed(1)}%</b></td></tr>`).join('');
 let monthRowsHtml=monthStats.map((x,i)=>`<tr><td><b>${i+1}. ${x.label}</b></td><td>${fmt(x.cases)}건 / lô <span class="air-note">(항공 ${fmt(x.airCases)}건 / AIR ${fmt(x.airCases)} lô)</span></td><td>${bn(x.cost)} VND</td><td>${krwFmt(x.krw)}</td><td><b>${x.share.toFixed(1)}%</b></td></tr>`).join('');
 let date=new Date().toLocaleDateString('ko-KR');

 $('pdfReport').innerHTML=`
 <div class="print-page report-page page-break">
   <div class="print-title">베트남 물류비 누적 현황 / BÁO CÁO CHI PHÍ LOGISTICS LŨY KẾ</div>
   <div class="print-sub">2026년 1~${rm}월 누계 / Lũy kế tháng 1-${rm}/2026 · 작성일 / Ngày lập: ${date} · 1/2</div>

   <div class="print-box report-main-chart">
     <h4>월별 물류비 vs 처리 건수 / Chi phí logistics & số lô theo tháng</h4>
     ${pdfMainCostCaseChart()}
   </div>

   <div class="print-kpis two-kpis">
     <div class="print-kpi"><div class="l">누적 물류비 / Chi phí logistics lũy kế</div><div class="v">${bn(cumCost)} VND<br>${krwFmt(cumK)}</div></div>
     <div class="print-kpi"><div class="l">누적 처리건수 / Số lô lũy kế</div><div class="v">${fmt(cumCases)}건 / lô</div></div>
   </div>

   <div class="print-box item-table-box">
     <h4>누적 ITEM별 처리건수 및 물류비 / Số lô & chi phí logistics lũy kế theo ITEM</h4>
     <table class="print-table"><tr><th>ITEM</th><th>누적 처리건수 / Số lô lũy kế</th><th>누적 물류비 / Chi phí lũy kế</th><th>KRW</th><th>비중 / Tỷ trọng</th></tr>${cumRowsHtml}</table>
     <div class="share-check">합계 / Tổng: ${cumStats.reduce((a,x)=>a+x.share,0).toFixed(1)}%</div>
   </div>
   <div class="print-footer">Vietnam Logistics Cost Management System · Korean / Tiếng Việt · 1/2</div>
 </div>

 <div class="print-page report-page">
   <div class="print-title">${rm}월 물류비 현황 / BÁO CÁO CHI PHÍ LOGISTICS THÁNG ${rm}</div>
   <div class="print-sub">2026년 ${rm}월 / Tháng ${rm}/2026 · 작성일 / Ngày lập: ${date} · 2/2</div>

   <div class="print-box month-pie-box">
     <h4>${rm}월 ITEM별 물류비 구성 / Cơ cấu chi phí logistics theo ITEM tháng ${rm}</h4>
     ${pdfMonthItemPie(monthRows,rm)}
   </div>

   <div class="print-kpis two-kpis">
     <div class="print-kpi"><div class="l">${rm}월 물류비 / Chi phí logistics tháng ${rm}</div><div class="v">${bn(cur.cost)} VND<br>${krwFmt(curK)}</div></div>
     <div class="print-kpi"><div class="l">${rm}월 처리건수 / Số lô tháng ${rm}</div><div class="v">${fmt(cur.cases)}건 / lô</div></div>
   </div>

   <div class="print-box item-table-box">
     <h4>${rm}월 ITEM별 처리건수 및 물류비 / Số lô & chi phí logistics theo ITEM tháng ${rm}</h4>
     <table class="print-table"><tr><th>ITEM</th><th>당월 처리건수 / Số lô tháng</th><th>당월 물류비 / Chi phí tháng</th><th>KRW</th><th>비중 / Tỷ trọng</th></tr>${monthRowsHtml}</table>
     <div class="share-check">합계 / Tổng: ${monthStats.reduce((a,x)=>a+x.share,0).toFixed(1)}%</div>
   </div>
   <div class="print-footer">Vietnam Logistics Cost Management System · Korean / Tiếng Việt · 2/2</div>
 </div>`}
function printOnePageReport(){
 try{
   buildOnePageReport();
   const src=$('pdfReport'),modal=$('pdfModal'),content=$('pdfModalContent');
   if(!src||!modal||!content)throw new Error('PDF preview elements missing');
   content.innerHTML=src.innerHTML;
   $('pdfModalTitle').textContent=L('PDF 2장 보고서 미리보기','2-page PDF report preview','Xem trước báo cáo PDF 2 trang');
   $('pdfModalSave').textContent=L('PDF 저장','Save PDF','Lưu PDF');
   $('pdfModalPrint').textContent=L('인쇄','Print','In');
   $('pdfModalClose').textContent=L('닫기','Close','Đóng');
   $('pdfPrintHelp').textContent=L('PDF 저장: A4 가로 2쪽으로 자동 저장됩니다.', 'Save PDF: automatically saves 2 A4 landscape pages.', 'Lưu PDF: tự động lưu 2 trang A4 ngang.');
   $('pdfModalSave').onclick=async()=>{
     const button=$('pdfModalSave');if(button.disabled)return;button.disabled=true;
     try{const month=state.month==='all'?DATA.months.at(-1).month:Number(state.month);
       await LogisticsPdf.save(content,`Vietnam_Logistics_2026_${String(month).padStart(2,'0')}.pdf`);
     }catch(e){alert(L('PDF 저장 실패: ','PDF save failed: ','Lưu PDF thất bại: ')+e.message);}
     finally{button.disabled=false;}
   };
   $('pdfModalPrint').onclick=()=>LogisticsModule.printReport();
   $('pdfModalClose').onclick=closePdfModal;
   modal.classList.add('open');
   modal.setAttribute('aria-hidden','false');
   document.body.style.overflow='hidden';
   modal.scrollTop=0;
 }catch(e){
   console.error(e);
   alert(L('PDF 미리보기를 여는 중 오류가 발생했습니다: ','Error opening PDF preview: ','Lỗi khi mở bản xem trước PDF: ')+e.message);
 }
}
function closePdfModal(){const m=$('pdfModal');if(m){m.classList.remove('open');m.setAttribute('aria-hidden','true')}document.body.style.overflow=''}

function renderSavingIdeas(){let air=DATA.rows.filter(r=>r.mode==='AIR').reduce((a,r)=>a+Number(r.total||0),0),truck=DATA.trucking_total,top=['MOTOR','ANT','BLE-UWB'].join(' · ');if(lang==='ko')$('savingIdeas').innerHTML=`<div class="insight"><b>AIR 긴급출하 관리</b><p>AIR 비용의 5%를 관리대상으로 설정하면 약 ${bn(air*.05)} VND 규모입니다. 실제 절감은 SEA 전환 가능 건을 별도로 검증합니다.</p></div><div class="insight"><b>출하 건수 자체를 절감지표로 관리</b><p>월별 건수 증가율과 비용 증가율을 함께 보고, 소량·분할 출하를 통합하는 과제를 우선 관리합니다.</p></div><div class="insight"><b>TRUCKING FEE 최적화</b><p>누계 ${bn(truck)} VND를 기준으로 합배송·차량 톤수 적정화·불필요 이동 감소를 관리합니다.</p></div><div class="insight"><b>고비용 ITEM 집중관리</b><p>${top}의 출하빈도와 운송수단을 우선 분석합니다.</p></div>`;else if(lang==='en')$('savingIdeas').innerHTML=`<div class="insight"><b>Urgent AIR management</b><p>Managing 5% of AIR cost represents about ${bn(air*.05)} VND. Validate SEA conversion case by case.</p></div><div class="insight"><b>Use shipment count as a savings KPI</b><p>Track monthly count growth together with cost growth and consolidate small/split shipments first.</p></div><div class="insight"><b>Optimize TRUCKING FEE</b><p>Manage consolidation, truck sizing and unnecessary moves against cumulative ${bn(truck)} VND.</p></div><div class="insight"><b>Focus on high-cost ITEMs</b><p>Prioritize shipment frequency and mode analysis for ${top}.</p></div>`;else $('savingIdeas').innerHTML=`<div class="insight"><b>Quản lý AIR khẩn cấp</b><p>5% chi phí AIR tương đương khoảng ${bn(air*.05)} VND; cần xác nhận từng lô có thể chuyển sang SEA.</p></div><div class="insight"><b>Dùng số lô làm KPI tiết giảm</b><p>Theo dõi đồng thời mức tăng số lô và chi phí, ưu tiên ghép các lô nhỏ/chia nhỏ.</p></div><div class="insight"><b>Tối ưu TRUCKING FEE</b><p>Quản lý ghép chuyến, tải trọng xe và giảm di chuyển không cần thiết trên tổng ${bn(truck)} VND.</p></div><div class="insight"><b>Tập trung ITEM chi phí cao</b><p>Ưu tiên phân tích tần suất xuất hàng và phương thức vận chuyển của ${top}.</p></div>`}
function updateSaving(){let rate=parseFloat($('saveRate').value)||0,amount=DATA.total_cost*rate/100;let k=DATA.total_cost?monthsKRW(DATA.months)*(rate/100):0;$('saveAmount').innerHTML=bn(amount)+' VND<span class="krw">'+krwFmt(k)+'</span>';$('saveMonthly').innerHTML=T('monthlyAvg')+' '+bn(amount/DATA.months.length)+' VND<span class="krw">'+krwFmt(k/DATA.months.length)+'</span>'}
const defaultActions=[{task:'AIR 긴급출하 사전승인 및 SEA 전환 검토',owner:'SCM',target:120000000,due:'2026-09-30',status:'진행중'},{task:'소량·분할 출하 통합으로 월 처리 건수 절감',owner:'물류',target:90000000,due:'2026-10-31',status:'진행중'},{task:'합배송 및 차량 톤수 최적화',owner:'물류',target:70000000,due:'2026-10-31',status:'검토'}];let actions=(()=>{try{return JSON.parse(localStorage.getItem('logisticsActionsV3'))||defaultActions}catch{return defaultActions}})();function saveActions(){localStorage.setItem('logisticsActionsV3',JSON.stringify(actions))}function renderActions(){$('actions').innerHTML=actions.map((a,i)=>`<div class="action"><input data-i="${i}" data-k="task" value="${escapeHtml(a.task)}"><input data-i="${i}" data-k="owner" value="${escapeHtml(a.owner)}"><input type="number" data-i="${i}" data-k="target" value="${escapeHtml(a.target)}"><input type="date" data-i="${i}" data-k="due" value="${escapeHtml(a.due)}"><select data-i="${i}" data-k="status"><option ${a.status==='검토'?'selected':''}>검토</option><option ${a.status==='진행중'?'selected':''}>진행중</option><option ${a.status==='완료'?'selected':''}>완료</option><option ${a.status==='보류'?'selected':''}>보류</option></select><button data-del="${i}">${T('delete')}</button></div>`).join('');document.querySelectorAll('#actions input,#actions select').forEach(e=>e.addEventListener('change',ev=>{let i=+ev.target.dataset.i,k=ev.target.dataset.k;actions[i][k]=k==='target'?+ev.target.value:ev.target.value;saveActions()}));document.querySelectorAll('[data-del]').forEach(b=>b.addEventListener('click',()=>{actions.splice(+b.dataset.del,1);saveActions();renderActions()}))}
function processWorkbook(wb){return LogisticsParser.parse(wb,USD_KRW)}
$('lang').addEventListener('change',e=>{lang=e.target.value;localStorage.setItem('logisticsLang',lang);applyLang()});$('mainItem').addEventListener('change',e=>{state.item=e.target.value;if($('itemFilter'))$('itemFilter').value=state.item;render()});$('monthFilter').addEventListener('change',e=>{state.month=e.target.value;render()});$('imexFilter').addEventListener('change',e=>{state.imex=e.target.value;render()});$('modeFilter').addEventListener('change',e=>{state.mode=e.target.value;render()});$('itemFilter').addEventListener('change',e=>{state.item=e.target.value;if($('mainItem'))$('mainItem').value=state.item;render()});$('resetBtn').onclick=()=>{state={month:'all',imex:'all',mode:'all',item:'ALL'};buildFilters();if($('mainItem'))$('mainItem').value='ALL';render()};$('searchBox').oninput=renderDetails;$('saveRate').oninput=updateSaving;$('addAction').onclick=()=>{actions.push({task:T('newTask'),owner:'',target:0,due:'2026-10-31',status:'검토'});saveActions();renderActions()};$('copyReport').onclick=async()=>{try{await navigator.clipboard.writeText($('reportText').textContent);let old=$('copyReport').textContent;$('copyReport').textContent=T('copyDone');setTimeout(()=>$('copyReport').textContent=old,1200)}catch{}};$('pdfReportBtn').onclick=printOnePageReport;document.querySelectorAll('.tab').forEach(b=>b.onclick=()=>{document.querySelectorAll('.tab').forEach(x=>x.classList.toggle('active',x===b));document.querySelectorAll('.page').forEach(p=>p.classList.toggle('active',p.id===b.dataset.page));setTimeout(()=>{drawCombo($('monthlyChart'),monthlyByFilter());drawMode($('modeChart'))},20)});window.addEventListener('resize',()=>{drawCombo($('monthlyChart'),monthlyByFilter());drawMode($('modeChart'))});

