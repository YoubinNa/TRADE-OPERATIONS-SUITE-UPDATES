/* Suite-only integration. The approved module engine is not modified. */
(() => {
  'use strict';
  let pending = 0, printing = false;
  async function request(action, payload) {
    pending++;
    try {
      if (!window.EcussDesktop) throw new Error('Suite connection unavailable');
      const reply = await EcussDesktop.call('/logistics/' + action, payload);
      if (reply.status !== 200) throw new Error(reply.value?.message || 'Shared logistics request failed');
      return reply.value;
    } finally { pending--; }
  }
  window.LogisticsHost = {
    language: window.__ECUSS_SUITE__?.lang || document.documentElement.lang || 'ko',
    hideLanguageSelector: true,
    readOnly: false,
    provider: {mode: 'shared', load: () => request('read', null),
      save: (snapshot, sourceFile, expectedVersion) => request('save', {snapshot, sourceFile, expectedVersion})},
    printReport: () => request('print', null)
  };
  window.EcussModuleState = {
    busy: () => pending > 0 || printing || !!document.getElementById('fxDialog')?.open ||
      document.getElementById('excelFile')?.disabled === true,
    hasWork: () => !!document.getElementById('fxDialog')?.open,
    hasResult: () => false
  };
  addEventListener('beforeprint', () => { printing = true; });
  addEventListener('afterprint', () => { printing = false; });
  addEventListener('DOMContentLoaded', () => {
    if (window.EcussModuleI18n) EcussModuleI18n.languages = ['ko', 'en', 'vi'];
    const contrast = document.createElement('style');
    contrast.textContent = '@media screen{body.ecuss-module-ui>header#ecuss-page-header{padding-top:8px;padding-bottom:8px}html[data-suite-weekday] body>header .uploadLabel{background:var(--weekday-soft,#edf4ff)!important;color:var(--weekday-ink,#243654)!important;border:1px solid var(--weekday-line,#cbd5e1)!important}html[data-suite-weekday] body>header .dataStatus{color:var(--weekday-ink,#243654)!important}}';
    document.head.append(contrast);
    // PDF rasterization is asynchronous; protect the tab until the download is handed off.
    if (window.LogisticsPdf?.save) {
      const save = LogisticsPdf.save;
      LogisticsPdf.save = async function (...args) {
        pending++;
        try { return await save.apply(this, args); } finally { pending--; }
      };
    }
  });
})();
