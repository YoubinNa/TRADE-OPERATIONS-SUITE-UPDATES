﻿#requires -Version 5.1
Set-StrictMode -Version Latest
$ErrorActionPreference='Stop'
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
function New-PublisherWindow {
    $paths=Get-PublisherPaths
    $form=New-Object Windows.Forms.Form;$form.Text='TRADE OPERATIONS SUITE · Master 서명 및 전달 1.1.0'
    $form.ClientSize=New-Object Drawing.Size(900,760);$form.MinimumSize=New-Object Drawing.Size(840,720)
    $form.StartPosition='CenterScreen';$form.AutoScaleMode='Dpi';$form.Font=New-Object Drawing.Font('Malgun Gothic',10)
    $form.BackColor=[Drawing.Color]::FromArgb(242,246,253)
    $layout=New-Object Windows.Forms.TableLayoutPanel;$layout.Dock='Fill';$layout.Padding=New-Object Windows.Forms.Padding(26)
    $layout.ColumnCount=1;$layout.RowCount=7
    foreach($height in @(48,44,52,0,64,112,52)){
        $style=New-Object Windows.Forms.RowStyle
        if($height -eq 0){$style.SizeType='Percent';$style.Height=100}else{$style.SizeType='Absolute';$style.Height=$height}
        $null=$layout.RowStyles.Add($style)
    };$form.Controls.Add($layout)
    $heading=New-Object Windows.Forms.Label;$heading.Text='확인 한 번으로, 서명부터 전달까지';$heading.Dock='Fill'
    $heading.Font=New-Object Drawing.Font('Malgun Gothic',19,[Drawing.FontStyle]::Bold);$layout.Controls.Add($heading,0,0)
    $key=New-Object Windows.Forms.Label;$key.Dock='Fill';$layout.Controls.Add($key,0,1)
    $status=New-Object Windows.Forms.Label;$status.Name='RequestStatus';$status.Dock='Fill';$status.Text='공개 요청을 자동으로 불러옵니다…'
    $status.ForeColor=[Drawing.Color]::FromArgb(38,75,126);$layout.Controls.Add($status,0,2)
    $details=New-Object Windows.Forms.TextBox;$details.Name='ReviewDetails';$details.Multiline=$true;$details.ReadOnly=$true
    $details.ScrollBars='Vertical';$details.Dock='Fill';$details.BackColor=[Drawing.Color]::White;$layout.Controls.Add($details,0,3)
    $buttons=New-Object Windows.Forms.FlowLayoutPanel;$buttons.Dock='Fill';$buttons.Padding=New-Object Windows.Forms.Padding(0,12,0,0)
    $buttons.WrapContents=$false;$layout.Controls.Add($buttons,0,4)
    $fetch=New-Object Windows.Forms.Button;$fetch.Text='새로고침';$fetch.Width=120;$fetch.Height=40;$fetch.Name='FetchRequest'
    $approve=New-Object Windows.Forms.Button;$approve.Text='승인 · 서명 · 전달';$approve.Width=220;$approve.Height=40;$approve.Enabled=$false;$approve.Name='ApproveSigning'
    $approve.BackColor=[Drawing.Color]::FromArgb(53,111,224);$approve.ForeColor=[Drawing.Color]::White;$approve.FlatStyle='Flat'
    $retry=New-Object Windows.Forms.Button;$retry.Text='전달 다시 시도';$retry.Width=160;$retry.Height=40;$retry.Enabled=$false;$retry.Name='RetryDelivery'
    $settings=New-Object Windows.Forms.Button;$settings.Text='전달 연결 설정';$settings.Width=160;$settings.Height=40;$settings.Name='ConnectionSettings'
    foreach($b in @($fetch,$approve,$retry,$settings)){$buttons.Controls.Add($b)}
    $connect=New-Object Windows.Forms.Panel;$connect.Dock='Fill';$layout.Controls.Add($connect,0,5)
    $label=New-Object Windows.Forms.Label;$label.Text="최초 1회 · 배포 저장소 전용 게시 토큰을 이 PC에 암호화 저장합니다.`r`nTRADE-OPERATIONS-SUITE-UPDATES만 선택 / Contents: Read and write";$label.Dock='Top';$label.Height=52;$connect.Controls.Add($label)
    $tokenBox=New-Object Windows.Forms.TextBox;$tokenBox.UseSystemPasswordChar=$true;$tokenBox.Name='UploadToken';$tokenBox.SetBounds(0,58,540,32);$tokenBox.Anchor='Top,Left,Right';$connect.Controls.Add($tokenBox)
    $save=New-Object Windows.Forms.Button;$save.Text='연결하고 저장';$save.Name='SaveConnection';$save.SetBounds(550,56,160,36);$save.Anchor='Top,Right';$connect.Controls.Add($save)
    $hint=New-Object Windows.Forms.Label;$hint.Dock='Fill';$hint.Text="공개 서명 결과만 배포 저장소로 전달합니다. 개인키는 이 PC에 유지됩니다.`r`n전달 완료는 배포 활성화와 구분되며 후속 검증은 반복 승인 없이 진행합니다.";$layout.Controls.Add($hint,0,6)
    $state=[pscustomobject]@{Worker=$null;Async=$null;Mode='load';Request=$null;Feed=$null;KeyOk=(Get-PublisherKeyStatus $paths.Signing);Connected=(Test-PublisherUploadConnection $paths.Work)}
    $key.Text=if($state.KeyOk){'기존 Master 키 확인 완료'}else{'기존 Master 키를 확인하지 못했습니다. 기존 키를 보존하고 확인하세요.'}
    $connect.Visible=!$state.Connected;if($state.Connected){$layout.RowStyles[5].Height=0}
    $timer=New-Object Windows.Forms.Timer;$timer.Interval=150;$root=$PSScriptRoot
    $start={
        param([string]$mode,[string]$token='')
        if($null -ne $state.Worker){return}
        foreach($b in @($fetch,$approve,$retry,$settings,$save)){$b.Enabled=$false}
        $state.Mode=$mode;$status.Text=switch($mode){'approve'{'서명하고 자동 전달하고 있습니다…'}'retry'{'보관된 서명을 다시 전달하고 있습니다…'}'connect'{'게시 권한을 확인하고 암호화 저장하고 있습니다…'}default{'공개 요청을 불러오고 있습니다…'}}
        $state.Worker=[PowerShell]::Create()
        $null=$state.Worker.AddScript({
            param($root,$mode,$shown,$paths,$token)
            Import-Module (Join-Path $root 'Publisher.Core.psm1') -Force -DisableNameChecking
            Import-Module (Join-Path $root 'Publisher.Delivery.psm1') -Force -DisableNameChecking
            try{
                $request=Get-PublisherNetworkText request;$feed=Get-PublisherNetworkText feed
                if($mode -eq 'connect'){Connect-PublisherUpload $paths.Work $token $feed}
                $connected=Test-PublisherUploadConnection $paths.Work
                if($mode -eq 'approve'){
                    if(!$connected){throw '먼저 자동 전달 연결을 설정하세요.'}
                    if($request -cne $shown){throw '검토한 요청이 변경됐습니다. 새로고침 후 확인하세요.'}
                    $null=Approve-PublisherRequest $shown $feed $paths.Signing $paths.Work {return $true}
                }
                $delivery=$null
                $pending=Join-Path $paths.Work 'pending-signed.json'
                $decision=Get-PublisherDecision $request $feed $paths.Signing
                # A previously approved result can retry on reopening, without signing again.
                if($connected -and (Test-Path -LiteralPath $pending)){
                    $saved=Read-PublisherEnvelope (Read-PublisherFile $pending)
                    if($mode -eq 'approve' -or $mode -eq 'retry' -or ($decision.State -eq 'ready' -and $saved.Hash -ceq $decision.Request.Payload.Hash)){
                        $delivery=Submit-PublisherPending $paths.Work $request $feed
                    }
                }
                [pscustomobject]@{Ok=$true;Request=$request;Feed=$feed;Connected=$connected;Delivery=$delivery;Error=''}
            }catch{[pscustomobject]@{Ok=$false;Request=$null;Feed=$null;Connected=$false;Delivery=$null;Error=$_.Exception.Message}}
            finally{$token=$null}
        }).AddArgument($root).AddArgument($mode).AddArgument($state.Request).AddArgument($paths).AddArgument($token)
        $state.Async=$state.Worker.BeginInvoke();$timer.Start()
    }.GetNewClosure()
    $timer.Add_Tick({
        if($null -eq $state.Worker -or !$state.Async.IsCompleted){return};$timer.Stop()
        try{
            $rows=@($state.Worker.EndInvoke($state.Async))
            if($state.Worker.HadErrors -or $rows.Count -ne 1){throw '작업을 완료하지 못했습니다. 서명 결과는 보존됩니다.'}
            $r=$rows[0];if(!$r.Ok){throw $r.Error}
            $state.Request=$r.Request;$state.Feed=$r.Feed;$state.Connected=$r.Connected
            $decision=Get-PublisherDecision $r.Request $r.Feed $paths.Signing
            if($state.Mode -eq 'connect'){$connect.Visible=$false;$layout.RowStyles[5].Height=0}
            $key.Text=$(if($state.KeyOk){'기존 Master 키 확인 완료'}else{'기존 Master 키 확인 필요'})+' · '+$(if($state.Connected){'자동 전달 연결 저장됨'}else{'최초 게시 연결 필요'})
            if($decision.State -eq 'ready'){
                $p=$decision.Request.Payload.Document
                $lines=@(('배포 버전: '+$p.catalog.appVersion),('대상: '+($p.catalog.profiles -join ', ')),('순번: '+$p.sequence),'만료: 2099-12-31 23:59:59 UTC','','변경 내용')
                $lines+=@($decision.Request.Notes|ForEach-Object{'• '+$_});$lines+=@('','배포 파일')
                foreach($pkg in $p.catalog.packages){$lines+=@(($pkg.profile+' / '+$pkg.bytes+' bytes'),('SHA-256: '+$pkg.sha256))}
                $details.Text=$lines -join "`r`n"
                $status.Text=if($state.Connected){'내용 확인 후 [승인 · 서명 · 전달] 한 번으로 완료하세요.'}else{'아래에서 자동 전달 연결을 한 번 설정하세요.'}
                $approve.Enabled=$state.KeyOk -and $state.Connected
            }else{
                $status.Text='추가로 서명할 요청이 없습니다. 현재 배포는 완료 상태입니다.'
                $details.Text='현재 공개 버전: '+$decision.Feed.Document.catalog.appVersion+"`r`n순번: "+$decision.Feed.Document.sequence+"`r`n만료: 2099-12-31 23:59:59 UTC"
            }
            if($null -ne $r.Delivery){
                $approve.Enabled=$false
                $status.Text=if($r.Delivery.State -eq 'published'){'이미 게시된 결과입니다. 추가 서명이나 전달이 필요 없습니다.'}else{'자동 전달 완료 · 대화에 붙여넣을 필요가 없습니다.'}
            }
        }catch{
            $status.Text='완료하지 못했습니다. 기존 키와 서명 결과를 보존했습니다.'
            $details.Text=$_.Exception.Message;$approve.Enabled=$false
        }finally{
            $state.Worker.Dispose();$state.Worker=$null;$state.Async=$null
            $fetch.Enabled=$true;$settings.Enabled=$true;$save.Enabled=$true
            $retry.Enabled=(Test-PublisherUploadConnection $paths.Work) -and (Test-Path -LiteralPath (Join-Path $paths.Work 'pending-signed.json'))
        }
    }.GetNewClosure())
    $form.Add_Shown({& $start 'load'}.GetNewClosure())
    $fetch.Add_Click({& $start 'load'}.GetNewClosure())
    $approve.Add_Click({& $start 'approve'}.GetNewClosure())
    $retry.Add_Click({& $start 'retry'}.GetNewClosure())
    $settings.Add_Click({$connect.Visible=!$connect.Visible;$layout.RowStyles[5].Height=if($connect.Visible){112}else{0}}.GetNewClosure())
    $save.Add_Click({$value=$tokenBox.Text.Trim();$tokenBox.Clear();& $start 'connect' $value;$value=$null}.GetNewClosure())
    $form.Add_FormClosed({$timer.Stop();$timer.Dispose();if($null -ne $state.Worker){$state.Worker.Stop();$state.Worker.Dispose()};$tokenBox.Clear()}.GetNewClosure())
    return $form
}
Export-ModuleMember -Function New-PublisherWindow
