﻿#requires -Version 5.1
Set-StrictMode -Version Latest
$ErrorActionPreference='Stop'
Add-Type -AssemblyName System.Windows.Forms
try {
    if([Threading.Thread]::CurrentThread.ApartmentState -ne 'STA'){throw 'Run using the installed Master publisher shortcut.'}
    Import-Module (Join-Path $PSScriptRoot 'Publisher.Core.psm1') -Force -DisableNameChecking
    Import-Module (Join-Path $PSScriptRoot 'Publisher.Delivery.psm1') -Force -DisableNameChecking
Import-Module (Join-Path $PSScriptRoot 'Publisher.UI.psm1') -Force
    [Windows.Forms.Application]::EnableVisualStyles()
    $form=New-PublisherWindow
    try{[Windows.Forms.Application]::Run($form)}finally{$form.Dispose()}
} catch {[Windows.Forms.MessageBox]::Show($_.Exception.Message,'TRADE OPERATIONS SUITE · Master 서명')|Out-Null}
