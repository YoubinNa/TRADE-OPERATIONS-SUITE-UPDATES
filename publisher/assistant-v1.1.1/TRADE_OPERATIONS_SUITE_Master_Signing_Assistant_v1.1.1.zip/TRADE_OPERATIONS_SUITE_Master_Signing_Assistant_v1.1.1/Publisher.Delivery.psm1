﻿#requires -Version 5.1
Set-StrictMode -Version Latest
$ErrorActionPreference='Stop'
Add-Type -AssemblyName System.Security
$script:UploadRepository='YoubinNa/TRADE-OPERATIONS-SUITE-UPDATES'

function ConvertTo-PublisherPublicResult([string]$Text) {
    $verified=Read-PublisherEnvelope $Text
    $e=$Text|ConvertFrom-Json
    $fields=@($e.PSObject.Properties.Name|Sort-Object)
    if(($fields -join ',') -cne 'keyId,payload,schema,signature'){throw '서명 결과에 허용되지 않은 필드가 있습니다.'}
    $canonical=([ordered]@{schema=1;keyId=$e.keyId;payload=$e.payload;signature=$e.signature}|ConvertTo-Json -Compress)+"`n"
    return [pscustomobject]@{Text=$canonical;Payload=$verified;Path=('publisher/inbox/seq-'+$verified.Document.sequence+'-'+$verified.Hash+'.signed.json')}
}
function Get-PublisherUploadToken([string]$Directory) {
    $path=Join-Path $Directory 'github-upload.dat'
    if(!(Test-Path -LiteralPath $path)){throw '먼저 자동 전달 연결을 설정하세요.'}
    $plain=$null
    try{
        $cipher=[IO.File]::ReadAllBytes($path)
        if($cipher.Length -gt 16384){throw 'size'}
        $plain=[Security.Cryptography.ProtectedData]::Unprotect($cipher,[Text.Encoding]::UTF8.GetBytes('TradeOperationsSuite.Publisher.Upload.v1'),[Security.Cryptography.DataProtectionScope]::CurrentUser)
        $token=[Text.Encoding]::UTF8.GetString($plain)
        if($token -cnotmatch '^[A-Za-z0-9._~+/-]{20,8192}={0,2}$'){throw 'format'}
        return $token
    }catch{throw '저장된 게시 연결을 사용할 수 없습니다. 자동 전달 연결을 다시 설정하세요.'}
    finally{if($null -ne $plain){[Array]::Clear($plain,0,$plain.Length)}}
}
function Test-PublisherUploadConnection([string]$Directory) {
    try{$null=Get-PublisherUploadToken $Directory;return $true}catch{return $false}
}
function Save-PublisherUploadToken([string]$Directory,[string]$Token) {
    if($Token -cnotmatch '^[A-Za-z0-9._~+/-]{20,8192}={0,2}$'){throw '게시 토큰 형식을 확인하세요.'}
    $null=[IO.Directory]::CreateDirectory($Directory)
    $plain=[Text.Encoding]::UTF8.GetBytes($Token);$temp=Join-Path $Directory ('upload-'+[Guid]::NewGuid().ToString('N')+'.tmp')
    try{
        $cipher=[Security.Cryptography.ProtectedData]::Protect($plain,[Text.Encoding]::UTF8.GetBytes('TradeOperationsSuite.Publisher.Upload.v1'),[Security.Cryptography.DataProtectionScope]::CurrentUser)
        [IO.File]::WriteAllBytes($temp,$cipher)
        $path=Join-Path $Directory 'github-upload.dat'
        if(Test-Path -LiteralPath $path){[IO.File]::Replace($temp,$path,[NullString]::Value)}else{[IO.File]::Move($temp,$path)}
    }finally{[Array]::Clear($plain,0,$plain.Length);if(Test-Path -LiteralPath $temp){Remove-Item -LiteralPath $temp -Force}}
}
function Invoke-PublisherUploadApi([ValidateSet('GET','PUT')][string]$Method,[string]$Path,[string]$Token,[string]$Body='') {
    if($Path -cne 'publisher/connection-check.signed.json' -and $Path -cnotmatch '^publisher/inbox/seq-[1-9][0-9]*-[a-f0-9]{64}\.signed\.json$'){throw '허용되지 않은 업로드 경로입니다.'}
    if($Token -cnotmatch '^[A-Za-z0-9._~+/-]{20,8192}={0,2}$'){throw '게시 연결을 확인하세요.'}
    Add-Type -AssemblyName System.Net.Http
    $handler=New-Object Net.Http.HttpClientHandler
    $handler.AllowAutoRedirect=$false;$handler.UseCookies=$false;$handler.UseDefaultCredentials=$false
    $client=New-Object Net.Http.HttpClient($handler);$client.Timeout=[TimeSpan]::FromSeconds(25)
    $client.DefaultRequestHeaders.UserAgent.ParseAdd('TradeOperationsSuite-Publisher/1.1.1')
    $client.DefaultRequestHeaders.Authorization=New-Object Net.Http.Headers.AuthenticationHeaderValue('Bearer',$Token)
    $client.DefaultRequestHeaders.Accept.ParseAdd('application/vnd.github+json')
    $client.DefaultRequestHeaders.Add('X-GitHub-Api-Version','2026-03-10')
    $client.DefaultRequestHeaders.CacheControl=New-Object Net.Http.Headers.CacheControlHeaderValue
    $client.DefaultRequestHeaders.CacheControl.NoCache=$true
    $url='https://api.github.com/repos/'+$script:UploadRepository+'/contents/'+$Path
    if($Method -eq 'GET'){$url+='?ref=main'}
    $message=New-Object Net.Http.HttpRequestMessage((New-Object Net.Http.HttpMethod($Method)),$url)
    $response=$null;$stream=$null;$memory=$null
    try{
        if($Method -eq 'PUT'){
            if(!$Body -or $Body.Length -gt 1048576){throw '전달 데이터 크기를 확인하세요.'}
            $message.Content=New-Object Net.Http.StringContent($Body,[Text.Encoding]::UTF8,'application/json')
        }
        $response=$client.SendAsync($message,[Net.Http.HttpCompletionOption]::ResponseHeadersRead).GetAwaiter().GetResult()
        $status=[int]$response.StatusCode
        if($status -eq 401 -or $status -eq 403){throw '게시 권한이 없거나 만료되었습니다. 자동 전달 연결을 다시 설정하세요.'}
        if(@(200,201,404,409,422) -notcontains $status){throw ('GitHub 전달 HTTP '+$status+'. 연결을 확인하고 다시 시도하세요.')}
        if($status -ne 200 -and $status -ne 201){return [pscustomobject]@{Status=$status;Data=$null}}
        if($response.Content.Headers.ContentLength -gt 1048576){throw 'GitHub 응답 크기 초과.'}
        $stream=$response.Content.ReadAsStreamAsync().GetAwaiter().GetResult();$memory=New-Object IO.MemoryStream
        $buffer=New-Object byte[] 8192;$watch=[Diagnostics.Stopwatch]::StartNew()
        while($true){
            $left=25000-[int]$watch.ElapsedMilliseconds;if($left -le 0){throw 'GitHub 응답 시간 초과.'}
            $read=$stream.ReadAsync($buffer,0,$buffer.Length)
            if(!$read.Wait($left)){throw 'GitHub 응답 시간 초과.'}
            $count=$read.GetAwaiter().GetResult();if($count -eq 0){break}
            if($memory.Length+$count -gt 1048576){throw 'GitHub 응답 크기 초과.'}
            $memory.Write($buffer,0,$count)
        }
        $text=([Text.UTF8Encoding]::new($false,$true)).GetString($memory.ToArray())
        return [pscustomobject]@{Status=$status;Data=($text|ConvertFrom-Json)}
    }catch{
        # Never include HTTP body, request, token, or arbitrary exception text in UI/logs.
        $safe=@('게시 권한이 없거나 만료되었습니다. 자동 전달 연결을 다시 설정하세요.','GitHub 응답 크기 초과.','GitHub 응답 시간 초과.')
        if($safe -contains $_.Exception.Message -or $_.Exception.Message -match '^GitHub 전달 HTTP [0-9]{3}\.'){throw $_.Exception.Message}
        throw 'GitHub 전달에 실패했습니다. 네트워크와 게시 연결을 확인하고 다시 시도하세요.'
    }finally{
        if($null -ne $memory){$memory.Dispose()};if($null -ne $stream){$stream.Dispose()};if($null -ne $response){$response.Dispose()}
        $message.Dispose();$client.Dispose();$Token=$null
    }
}
function Read-PublisherUploadContent($Response,[string]$Path) {
    if($Response.Status -ne 200){return $null}
    $d=$Response.Data
    if($d.type -cne 'file' -or $d.path -cne $Path -or $d.encoding -cne 'base64' -or $d.size -gt 1048576 -or $d.sha -cnotmatch '^[a-f0-9]{40}$'){throw 'GitHub 저장 결과를 확인하지 못했습니다.'}
    $bytes=[Convert]::FromBase64String($d.content)
    if($bytes.Length -ne $d.size){throw 'GitHub 저장 크기가 일치하지 않습니다.'}
    return ([Text.UTF8Encoding]::new($false,$true)).GetString($bytes)
}
function Send-PublisherPublicResult([string]$Text,[string]$Token,[switch]$ConnectionProbe) {
    $result=ConvertTo-PublisherPublicResult $Text
    $path=if($ConnectionProbe){'publisher/connection-check.signed.json'}else{$result.Path}
    $existing=Invoke-PublisherUploadApi GET $path $Token
    $prior=Read-PublisherUploadContent $existing $path
    if(!$ConnectionProbe -and $null -ne $prior){
        if($prior -cne $result.Text){throw '동일 요청의 기존 결과가 다릅니다. 덮어쓰지 않고 보존합니다.'}
        return [pscustomobject]@{Path=$path;AlreadyDelivered=$true;PayloadHash=$result.Payload.Hash}
    }
    if(@(200,404) -notcontains $existing.Status){throw '저장소 상태를 확인하고 다시 전달하세요.'}
    $body=[ordered]@{message=('publisher: '+$(if($ConnectionProbe){'verify upload connection'}else{'receive signed sequence '+$result.Payload.Document.sequence}));branch='main';content=[Convert]::ToBase64String([Text.Encoding]::UTF8.GetBytes($result.Text))}
    if($ConnectionProbe -and $null -ne $prior){$body.sha=$existing.Data.sha}
    $sent=Invoke-PublisherUploadApi PUT $path $Token ($body|ConvertTo-Json -Compress)
    if(@(200,201,409,422) -notcontains $sent.Status){throw '게시 저장소 또는 쓰기 권한을 확인하세요.'}
    if($ConnectionProbe -and @(200,201) -notcontains $sent.Status){throw '게시 연결 확인이 완료되지 않았습니다. 다시 시도하세요.'}
    $after=Invoke-PublisherUploadApi GET $path $Token
    if((Read-PublisherUploadContent $after $path) -cne $result.Text){throw '전달 결과를 다시 확인하지 못했습니다. 서명은 보존되며 다시 전달할 수 있습니다.'}
    return [pscustomobject]@{Path=$path;AlreadyDelivered=($sent.Status -eq 409 -or $sent.Status -eq 422);PayloadHash=$result.Payload.Hash}
}
function Connect-PublisherUpload([string]$Directory,[string]$Token,[string]$FeedText) {
    # Existing public signature is the only probe content; never export a private key.
    $null=Send-PublisherPublicResult $FeedText $Token -ConnectionProbe
    Save-PublisherUploadToken $Directory $Token
}
function Submit-PublisherPending([string]$Directory,[string]$RequestText,[string]$FeedText) {
    $path=Join-Path $Directory 'pending-signed.json'
    $result=ConvertTo-PublisherPublicResult (Read-PublisherFile $path)
    $feed=Read-PublisherEnvelope $FeedText
    if($result.Payload.Hash -ceq $feed.Hash){return [pscustomobject]@{State='published';Path=$result.Path}}
    $request=Read-PublisherRequest $RequestText
    if($request.State -cne 'ready' -or $request.Payload.Hash -cne $result.Payload.Hash -or $result.Payload.Document.sequence -le $feed.Document.sequence){throw '현재 요청과 보관된 서명이 다릅니다. 결과를 보존하고 요청을 확인하세요.'}
    $token=Get-PublisherUploadToken $Directory
    try{$sent=Send-PublisherPublicResult $result.Text $token;return [pscustomobject]@{State='delivered';Path=$sent.Path}}finally{$token=$null}
}
Export-ModuleMember -Function ConvertTo-PublisherPublicResult,Test-PublisherUploadConnection,Connect-PublisherUpload,Submit-PublisherPending,Send-PublisherPublicResult
