﻿#requires -Version 5.1
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
$script:KeyId = 'bdbfbeb117243191a5a53327504b6537e7bef131b37fcef7dc7e43dfcfa2945e'
$script:Repository = 'YoubinNa/TRADE-OPERATIONS-SUITE-UPDATES'
$script:RootUrl = 'https://raw.githubusercontent.com/' + $script:Repository + '/main/'
$script:Expiry = '2099-12-31T23:59:59.0000000+00:00'

function Get-PublisherHash([byte[]]$Bytes) {
    $hash = [Security.Cryptography.SHA256]::Create()
    try { return ([BitConverter]::ToString($hash.ComputeHash($Bytes))).Replace('-','').ToLowerInvariant() }
    finally { $hash.Dispose() }
}
function Get-PublisherPaths {
    $root = Join-Path ([Environment]::GetFolderPath('LocalApplicationData')) 'ECUSS-Publisher'
    return @{ Signing = (Join-Path $root 'Signing'); Work = (Join-Path $root 'Assistant') }
}
function Read-PublisherJson([string]$Text) {
    if (!$Text -or $Text.Length -gt 1048576) { throw 'Invalid metadata size.' }
    return ($Text | ConvertFrom-Json)
}
function Read-PublisherFile([string]$Path) {
    if ((Get-Item -LiteralPath $Path).Length -gt 1048576) { throw 'Local metadata exceeds its limit.' }
    return ([Text.UTF8Encoding]::new($false,$true)).GetString([IO.File]::ReadAllBytes($Path))
}
function New-PublisherPublicKey {
    $key = Read-PublisherJson (Read-PublisherFile (Join-Path $PSScriptRoot 'update-signing-public.json'))
    $identity = $key.modulus + '.' + $key.exponent
    if ($key.keyId -cne $script:KeyId -or (Get-PublisherHash ([Text.Encoding]::ASCII.GetBytes($identity))) -cne $script:KeyId) { throw 'Pinned public key does not match.' }
    $rsa = New-Object Security.Cryptography.RSACryptoServiceProvider
    $rsa.PersistKeyInCsp = $false
    try {
        $parameters = New-Object Security.Cryptography.RSAParameters
        $parameters.Modulus = [Convert]::FromBase64String($key.modulus)
        $parameters.Exponent = [Convert]::FromBase64String($key.exponent)
        $rsa.ImportParameters($parameters)
        if ($rsa.KeySize -ne 3072) { throw 'Unexpected key size.' }
        return $rsa
    } catch { $rsa.Dispose(); throw }
}
function Read-PublisherPayload([byte[]]$Bytes, [switch]$RequireLongterm) {
    if ($Bytes.Length -lt 1 -or $Bytes.Length -gt 524288) { throw 'Invalid payload size.' }
    $p = Read-PublisherJson (([Text.UTF8Encoding]::new($false,$true)).GetString($Bytes))
    $now = [DateTimeOffset]::UtcNow
    $issued = [DateTimeOffset]::ParseExact($p.issuedAt,'o',[Globalization.CultureInfo]::InvariantCulture)
    $expires = [DateTimeOffset]::ParseExact($p.expiresAt,'o',[Globalization.CultureInfo]::InvariantCulture)
    if ($p.schema -ne 1 -or $p.product -cne 'ECUSS.ValidationSuite' -or $p.channel -cne 'stable' -or
        $p.sequence -lt 1 -or $p.sequence -gt 9007199254740991 -or [decimal]$p.sequence -ne [Math]::Floor([decimal]$p.sequence) -or
        $issued.Offset -ne [TimeSpan]::Zero -or $expires.Offset -ne [TimeSpan]::Zero -or $issued -gt $now.AddMinutes(5) -or
        $expires -le $now -or $expires -le $issued -or $expires -gt $issued.AddYears(100)) { throw 'Invalid, future or expired metadata.' }
    if ($RequireLongterm -and $p.expiresAt -cne $script:Expiry) { throw 'New distribution requests must expire at the end of 2099 (UTC).' }
    $c = $p.catalog
    $version = [Version]::Parse($c.appVersion)
    if ($c.schema -ne 1 -or $c.product -cne 'ECUSS.ValidationSuite' -or $version.ToString() -cne $c.appVersion -or
        @($c.profiles).Count -lt 1 -or @($c.profiles).Count -gt 2 -or @($c.profiles | Select-Object -Unique).Count -ne @($c.profiles).Count -or
        @($c.packages).Count -ne @($c.profiles).Count) { throw 'Invalid product catalog.' }
    foreach ($profile in $c.profiles) { if ($profile -cne 'master' -and $profile -cne 'user') { throw 'Invalid distribution profile.' } }
    if (@($c.packages.profile | Select-Object -Unique).Count -ne @($c.packages).Count) { throw 'Duplicate package profile.' }
    foreach ($package in $c.packages) {
        $title = if ($package.profile -ceq 'master') { 'Master' } else { 'User' }
        $path = 'packages/v' + $c.appVersion + '/TRADE_OPERATIONS_SUITE_' + $title + '_v' + $c.appVersion + '.ecuss-update.zip'
        if ($package.repository -cne $script:Repository -or $package.appVersion -cne $c.appVersion -or $package.path -cne $path -or
            $c.profiles -cnotcontains $package.profile -or $package.commit -cnotmatch '^[a-f0-9]{40}$' -or
            $package.sha256 -cnotmatch '^[a-f0-9]{64}$' -or $package.bytes -lt 1 -or $package.bytes -gt 1073741824 -or
            [decimal]$package.bytes -ne [Math]::Floor([decimal]$package.bytes) -or $package.launcherApi -ne 4 -or
            $package.releaseId -cnotmatch '^desktop-[0-9.]+-(master|user)-[A-Za-z0-9._-]+$' -or
            !$package.releaseId.StartsWith(('desktop-'+$c.appVersion+'-'+$package.profile+'-'),[StringComparison]::Ordinal)) { throw 'Invalid approved package identity.' }
    }
    return [pscustomobject]@{ Document=$p; Bytes=$Bytes; Hash=(Get-PublisherHash $Bytes) }
}
function Read-PublisherEnvelope([string]$Text) {
    $e = Read-PublisherJson $Text
    if ($e.schema -ne 1 -or $e.keyId -cne $script:KeyId -or $e.signature.Length -ne 512 -or $e.payload.Length -gt 699052) { throw 'Invalid signature envelope.' }
    $bytes = [Convert]::FromBase64String($e.payload); $signature = [Convert]::FromBase64String($e.signature)
    if ([Convert]::ToBase64String($bytes) -cne $e.payload -or [Convert]::ToBase64String($signature) -cne $e.signature -or $signature.Length -ne 384) { throw 'Non-canonical signature envelope.' }
    $rsa = New-PublisherPublicKey
    try { if (!$rsa.VerifyData($bytes,'SHA256',$signature)) { throw 'Production signature verification failed.' } }
    finally { $rsa.Dispose() }
    return Read-PublisherPayload $bytes -RequireLongterm
}
function Read-PublisherRequest([string]$Text) {
    $request = Read-PublisherJson $Text
    if ($request.schema -ne 1 -or $request.product -cne 'TRADE-OPERATIONS-SUITE-PUBLISHER' -or $request.channel -cne 'longterm' -or
        ($request.state -cne 'ready' -and $request.state -cne 'idle')) { throw 'Invalid publisher request.' }
    if ($request.state -ceq 'idle') { return [pscustomobject]@{ State='idle'; RequestText=$Text; Payload=$null; Notes=@() } }
    if (([Version]$request.minimumAssistantVersion -gt [Version]'1.1.1') -or $request.keyId -cne $script:KeyId -or
        $request.payloadSha256 -cnotmatch '^[a-f0-9]{64}$' -or $request.payload.Length -gt 699052 -or
        @($request.notes).Count -lt 1 -or @($request.notes).Count -gt 12) { throw 'Unsupported or invalid signing request.' }
    foreach ($note in $request.notes) { if ($note -isnot [string] -or $note.Length -lt 1 -or $note.Length -gt 400 -or $note -match '[\x00-\x1f]') { throw 'Invalid release summary.' } }
    $bytes = [Convert]::FromBase64String($request.payload)
    if ([Convert]::ToBase64String($bytes) -cne $request.payload -or (Get-PublisherHash $bytes) -cne $request.payloadSha256) { throw 'Reviewed payload hash mismatch.' }
    return [pscustomobject]@{ State='ready'; RequestText=$Text; Payload=(Read-PublisherPayload $bytes -RequireLongterm); Notes=@($request.notes) }
}
function Assert-PublisherHistory($Payload,[string]$SigningDirectory) {
    $path = Join-Path $SigningDirectory 'last-signed-metadata.json'
    if (Test-Path -LiteralPath $path) {
        $last = Read-PublisherJson (Read-PublisherFile $path)
        if ($last.sequence -lt 1 -or $last.sha256 -cnotmatch '^[a-f0-9]{64}$' -or
            $Payload.Document.sequence -lt $last.sequence -or
            ($Payload.Document.sequence -eq $last.sequence -and $Payload.Hash -cne $last.sha256) -or
            [Version]$Payload.Document.catalog.appVersion -lt [Version]$last.appVersion) { throw 'Older or conflicting local signing history.' }
    }
}
function Get-PublisherDecision([string]$RequestText,[string]$FeedText,[string]$SigningDirectory) {
    $request = Read-PublisherRequest $RequestText
    $feed = Read-PublisherEnvelope $FeedText
    if ($request.State -eq 'idle') { return [pscustomobject]@{ State='idle'; Request=$request; Feed=$feed } }
    $p=$request.Payload
    Assert-PublisherHistory $p $SigningDirectory
    if ($p.Document.sequence -lt $feed.Document.sequence -or
        ($p.Document.sequence -eq $feed.Document.sequence -and $p.Hash -cne $feed.Hash) -or
        [Version]$p.Document.catalog.appVersion -lt [Version]$feed.Document.catalog.appVersion) { throw 'Request conflicts with the published release.' }
    $state = if ($p.Hash -ceq $feed.Hash) { 'published' } else { 'ready' }
    return [pscustomobject]@{ State=$state; Request=$request; Feed=$feed }
}
function Get-PublisherNetworkText([ValidateSet('request','feed')][string]$Kind) {
    Add-Type -AssemblyName System.Net.Http
    $path=if($Kind -eq 'request'){'publisher/current-request.json'}else{'updates/stable-longterm.signed.json'}
    $handler=New-Object Net.Http.HttpClientHandler
    $handler.AllowAutoRedirect=$false; $handler.UseCookies=$false; $handler.UseDefaultCredentials=$false
    $client=New-Object Net.Http.HttpClient($handler)
    $client.Timeout=[TimeSpan]::FromSeconds(20)
    $client.DefaultRequestHeaders.UserAgent.ParseAdd('TradeOperationsSuite-Publisher/1.1.1')
    $client.DefaultRequestHeaders.CacheControl=New-Object Net.Http.Headers.CacheControlHeaderValue
    $client.DefaultRequestHeaders.CacheControl.NoCache=$true
    $client.DefaultRequestHeaders.CacheControl.NoStore=$true
    $response=$null; $stream=$null; $memory=$null
    try {
        $response=$client.GetAsync(($script:RootUrl+$path+'?t='+[DateTimeOffset]::UtcNow.Ticks),[Net.Http.HttpCompletionOption]::ResponseHeadersRead).GetAwaiter().GetResult()
        if ([int]$response.StatusCode -ne 200) { throw ('Metadata HTTP '+[int]$response.StatusCode) }
        if ($response.Content.Headers.ContentLength -gt 1048576) { throw 'Metadata response too large.' }
        $stream=$response.Content.ReadAsStreamAsync().GetAwaiter().GetResult(); $memory=New-Object IO.MemoryStream
        $buffer=New-Object byte[] 8192; $timer=[Diagnostics.Stopwatch]::StartNew()
        while ($true) {
            $remaining=20000-[int]$timer.ElapsedMilliseconds
            if ($remaining -le 0) { throw 'Metadata response timed out.' }
            $read=$stream.ReadAsync($buffer,0,$buffer.Length)
            if (!$read.Wait($remaining)) { throw 'Metadata response timed out.' }
            $count=$read.GetAwaiter().GetResult(); if($count -eq 0){break}
            if ($memory.Length+$count -gt 1048576) { throw 'Metadata response exceeded its limit.' }
            $memory.Write($buffer,0,$count)
        }
        return ([Text.UTF8Encoding]::new($false,$true)).GetString($memory.ToArray())
    } finally { if($null -ne $stream){$stream.Dispose()};if($null -ne $memory){$memory.Dispose()};if($null -ne $response){$response.Dispose()};$client.Dispose() }
}
function Write-PublisherAtomic([string]$Path,[string]$Text) {
    $temp=$Path+'.'+[Guid]::NewGuid().ToString('N')+'.tmp'
    try {
        [IO.File]::WriteAllText($temp,$Text,[Text.UTF8Encoding]::new($false))
        if(Test-Path -LiteralPath $Path){[IO.File]::Replace($temp,$Path,[NullString]::Value)}else{[IO.File]::Move($temp,$Path)}
    } finally { if(Test-Path -LiteralPath $temp){Remove-Item -LiteralPath $temp -Force} }
}
function Get-PublisherKeyStatus([string]$SigningDirectory) {
    try {
        $state=Read-PublisherJson (Read-PublisherFile (Join-Path $SigningDirectory 'publisher-local.json'))
        if($state.keyId -cne $script:KeyId -or $state.thumbprint -notmatch '^[a-fA-F0-9]{40}$'){return $false}
        $cert=Get-Item -LiteralPath ('Cert:\CurrentUser\My\'+$state.thumbprint)
        $publicRsa=$null
        try {
            if(!$cert.HasPrivateKey){return $false}
            $publicRsa=[Security.Cryptography.X509Certificates.RSACertificateExtensions]::GetRSAPublicKey($cert)
            $public=$publicRsa.ExportParameters($false)
            $identity=[Convert]::ToBase64String($public.Modulus)+'.'+[Convert]::ToBase64String($public.Exponent)
            return ($publicRsa.KeySize -eq 3072 -and (Get-PublisherHash ([Text.Encoding]::ASCII.GetBytes($identity))) -ceq $script:KeyId)
        }finally{if($null -ne $publicRsa){$publicRsa.Dispose()};$cert.Dispose()}
    } catch {return $false}
}
function Approve-PublisherRequest([string]$RequestText,[string]$FeedText,[string]$SigningDirectory,[string]$WorkDirectory,[scriptblock]$Approve) {
    # Re-parse exact displayed bytes and re-check inside the same lock used by the existing signer.
    $decision=Get-PublisherDecision $RequestText $FeedText $SigningDirectory
    if($decision.State -ne 'ready'){throw 'There is no new request to sign.'}
    $p=$decision.Request.Payload
    if(!(Test-Path -LiteralPath $SigningDirectory)){throw 'Existing Master signing directory is unavailable.'}
    $lock=$null;$rsa=$null;$cert=$null
    try {
        $lock=[IO.File]::Open((Join-Path $SigningDirectory 'signing.lock'),[IO.FileMode]::OpenOrCreate,[IO.FileAccess]::ReadWrite,[IO.FileShare]::None)
        Assert-PublisherHistory $p $SigningDirectory
        $null=[IO.Directory]::CreateDirectory($WorkDirectory)
        $output=Join-Path $WorkDirectory 'pending-signed.json'
        if(Test-Path -LiteralPath $output){
            $existingText=Read-PublisherFile $output;$existing=Read-PublisherEnvelope $existingText
            if($existing.Hash -ceq $p.Hash){return [pscustomobject]@{Text=$existingText;Path=$output;Reused=$true}}
            if($existing.Hash -cne $decision.Feed.Hash){throw 'Previous signed result is not confirmed published. Preserve it before a different request.'}
        }
        if($null -eq $Approve -or !(& $Approve $decision)){throw 'Signing cancelled.'}
        $state=Read-PublisherJson (Read-PublisherFile (Join-Path $SigningDirectory 'publisher-local.json'))
        if($state.keyId -cne $script:KeyId -or $state.thumbprint -notmatch '^[a-fA-F0-9]{40}$'){throw 'Unexpected Master key.'}
        $cert=Get-Item -LiteralPath ('Cert:\CurrentUser\My\'+$state.thumbprint)
        $rsa=[Security.Cryptography.X509Certificates.RSACertificateExtensions]::GetRSAPrivateKey($cert)
        if($null -eq $rsa){throw 'Existing Master private key is unavailable.'}
        $public=$rsa.ExportParameters($false)
        $identity=[Convert]::ToBase64String($public.Modulus)+'.'+[Convert]::ToBase64String($public.Exponent)
        if($rsa.KeySize -ne 3072 -or (Get-PublisherHash ([Text.Encoding]::ASCII.GetBytes($identity))) -cne $script:KeyId){throw 'Unexpected certificate key.'}
        $sig=$rsa.SignData($p.Bytes,[Security.Cryptography.HashAlgorithmName]::SHA256,[Security.Cryptography.RSASignaturePadding]::Pkcs1)
        $envelope=[ordered]@{schema=1;keyId=$script:KeyId;payload=[Convert]::ToBase64String($p.Bytes);signature=[Convert]::ToBase64String($sig)}
        $text=($envelope|ConvertTo-Json -Compress)+"`n"
        $checked=Read-PublisherEnvelope $text
        if($checked.Hash -cne $p.Hash){throw 'Signature self-test failed.'}
        $history=[ordered]@{sequence=$p.Document.sequence;appVersion=$p.Document.catalog.appVersion;sha256=$p.Hash;signedAt=[DateTimeOffset]::UtcNow.ToString('o')}
        Write-PublisherAtomic (Join-Path $SigningDirectory 'last-signed-metadata.json') (($history|ConvertTo-Json)+"`n")
        # History first: after an interrupted result write, an identical request can safely retry.
        Write-PublisherAtomic $output $text
        return [pscustomobject]@{Text=$text;Path=$output;Reused=$false}
    } finally {if($null -ne $lock){$lock.Dispose()};if($null -ne $rsa){$rsa.Dispose()};if($null -ne $cert){$cert.Dispose()}}
}
Export-ModuleMember -Function Get-PublisherHash,Get-PublisherPaths,Read-PublisherRequest,Read-PublisherEnvelope,Get-PublisherDecision,Get-PublisherNetworkText,Get-PublisherKeyStatus,Approve-PublisherRequest,Read-PublisherFile
