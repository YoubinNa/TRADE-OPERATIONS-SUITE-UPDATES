﻿#requires -Version 5.1
[CmdletBinding()]
param([string]$InstallRoot,[string]$ShortcutDirectory)
Set-StrictMode -Version Latest
$ErrorActionPreference='Stop'
Add-Type -AssemblyName System.Windows.Forms
try {
    # Resolve defaults in the body, including paths containing Korean text, spaces and stars.
    if(!$InstallRoot){$InstallRoot=Join-Path ([Environment]::GetFolderPath('LocalApplicationData')) 'ECUSS-Publisher\Tools'}
    if(!$ShortcutDirectory){$ShortcutDirectory=[Environment]::GetFolderPath('DesktopDirectory')}
    $manifest=Get-Content -LiteralPath (Join-Path $PSScriptRoot 'KIT_CONTENTS.json') -Raw -Encoding UTF8|ConvertFrom-Json
    if($manifest.version -cne '1.1.1'){throw 'Unexpected assistant package version.'}
    $expected=@('Open-Publisher.ps1','Publisher.Core.psm1','Publisher.Delivery.psm1','Publisher.UI.psm1','update-signing-public.json','README_KO.txt')
    if(@($manifest.files).Count -ne $expected.Count){throw 'Invalid helper inventory.'}
    foreach($name in $expected){
        $records=@($manifest.files|Where-Object{$_.name -ceq $name})
        if($records.Count -ne 1){throw 'Duplicate or missing helper entry.'}
        $file=Join-Path $PSScriptRoot $name
        if((Get-FileHash -LiteralPath $file -Algorithm SHA256).Hash.ToLowerInvariant() -cne $records[0].sha256 -or (Get-Item -LiteralPath $file).Length -ne $records[0].bytes){throw ('Helper file mismatch: '+$name)}
    }
    $target=Join-Path $InstallRoot '1.1.1'
    $null=[IO.Directory]::CreateDirectory($InstallRoot)
    if(Test-Path -LiteralPath $target){
        foreach($item in $manifest.files){if((Get-FileHash -LiteralPath (Join-Path $target $item.name) -Algorithm SHA256).Hash.ToLowerInvariant() -cne $item.sha256){throw 'Existing helper files differ. Preserve the folder for review.'}}
    }else{
        $stage=Join-Path $InstallRoot ('staging-'+[Guid]::NewGuid().ToString('N'))
        try{
            $null=[IO.Directory]::CreateDirectory($stage)
            foreach($name in $expected){Copy-Item -LiteralPath (Join-Path $PSScriptRoot $name) -Destination (Join-Path $stage $name)}
            [IO.Directory]::Move($stage,$target)
        }finally{if(Test-Path -LiteralPath $stage){Remove-Item -LiteralPath $stage -Recurse -Force}}
    }
    $null=[IO.Directory]::CreateDirectory($ShortcutDirectory)
    # Explicit Unicode IShellLinkW + IPersistFile avoids WScript shortcut path conversion.
    if($null -eq ('TradePublisher.UnicodeLink' -as [type])) {
        Add-Type -TypeDefinition @'
using System;
using System.Text;
using System.Runtime.InteropServices;
using System.Runtime.InteropServices.ComTypes;
namespace TradePublisher {
 [ComImport, Guid("00021401-0000-0000-C000-000000000046")] internal class ShellLink {}
 [ComImport, Guid("000214F9-0000-0000-C000-000000000046"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
 internal interface IShellLinkW {
  void GetPath([Out,MarshalAs(UnmanagedType.LPWStr)] StringBuilder path,int size,IntPtr data,uint flags);
  void GetIDList(out IntPtr list); void SetIDList(IntPtr list);
  void GetDescription([Out,MarshalAs(UnmanagedType.LPWStr)] StringBuilder text,int size);
  void SetDescription([MarshalAs(UnmanagedType.LPWStr)] string text);
  void GetWorkingDirectory([Out,MarshalAs(UnmanagedType.LPWStr)] StringBuilder path,int size);
  void SetWorkingDirectory([MarshalAs(UnmanagedType.LPWStr)] string path);
  void GetArguments([Out,MarshalAs(UnmanagedType.LPWStr)] StringBuilder text,int size);
  void SetArguments([MarshalAs(UnmanagedType.LPWStr)] string text);
  void GetHotkey(out short key); void SetHotkey(short key);
  void GetShowCmd(out int show); void SetShowCmd(int show);
  void GetIconLocation([Out,MarshalAs(UnmanagedType.LPWStr)] StringBuilder path,int size,out int index);
  void SetIconLocation([MarshalAs(UnmanagedType.LPWStr)] string path,int index);
  void SetRelativePath([MarshalAs(UnmanagedType.LPWStr)] string path,uint reserved);
  void Resolve(IntPtr window,uint flags);
  void SetPath([MarshalAs(UnmanagedType.LPWStr)] string path);
 }
 public static class UnicodeLink {
  public static void Save(string file,string target,string arguments,string working) {
   var link=(IShellLinkW)new ShellLink();
   try{link.SetPath(target);link.SetArguments(arguments);link.SetWorkingDirectory(working);link.SetDescription("TRADE OPERATIONS SUITE Master publisher signing");((IPersistFile)link).Save(file,true);}
   finally{Marshal.FinalReleaseComObject(link);}
  }
  public static string Arguments(string file) {
   var link=(IShellLinkW)new ShellLink();
   try{((IPersistFile)link).Load(file,0);var text=new StringBuilder(32768);link.GetArguments(text,text.Capacity);return text.ToString();}
   finally{Marshal.FinalReleaseComObject(link);}
  }
 }
}
'@
    }
    $linkPath=Join-Path $ShortcutDirectory 'TRADE OPERATIONS SUITE - Master Signing.lnk'
    $targetPath=Join-Path $env:WINDIR 'System32\WindowsPowerShell\v1.0\powershell.exe'
    $arguments='-NoProfile -STA -WindowStyle Hidden -ExecutionPolicy Bypass -File "'+(Join-Path $target 'Open-Publisher.ps1')+'"'
    [TradePublisher.UnicodeLink]::Save($linkPath,$targetPath,$arguments,$target)
    Write-Output ('Installed: '+$target)
    Write-Output 'Open the TRADE OPERATIONS SUITE - Master Signing desktop shortcut. No keys were created or changed.'
}catch{Write-Error $_;exit 1}
