﻿TRADE OPERATIONS SUITE — Master Signing Assistant 1.1.1

최초 한 번
1. 압축을 완전히 풀고 Install-Publisher.cmd를 실행합니다. 기존 바로가기가 새 버전으로 연결됩니다.
2. 도우미의 전달 연결 설정에 배포 저장소 전용 GitHub fine-grained 토큰을 입력합니다.
   Repository access: Only select repositories → TRADE-OPERATIONS-SUITE-UPDATES
   Repository permissions: Contents → Read and write (Metadata는 기본 제공)
   Workflows·Administration·다른 저장소 권한은 필요 없습니다.
3. 연결하고 저장을 누릅니다. 공개된 서명 목록으로 쓰기·재조회 검사 후 현재 Windows 사용자용 DPAPI로 암호화 저장합니다.
   토큰은 이 화면에만 입력하며 대화·파일·GitHub에 전달하지 마세요.

이후 새 배포
도우미 실행 → 자동으로 불러온 버전/변경 내용 확인 → 승인·서명·전달 한 번.
공개 서명 결과를 배포 저장소 publisher/inbox에 저장하고 다시 읽어 일치 여부를 확인합니다.
Work 대화에 붙여넣을 필요가 없습니다. 후속 배포 검증은 수신 파일을 직접 읽어 진행합니다.
자동 전달 완료와 온라인 배포 활성화는 구분됩니다. 검증이 끝나기 전에 활성 목록을 바꾸지 않습니다.

실패 시 기존 서명은 유지됩니다. 전달 다시 시도 또는 도우미 재실행으로 같은 결과를 보내며 재서명하지 않습니다.
토큰 만료·회수 또는 Windows 사용자 변경 시에만 연결을 다시 설정합니다.
기존 개인키·PFX·복구 비밀번호를 도구 밖으로 내보내지 않습니다. 일반 User는 도구·게시 토큰을 사용하지 않습니다.

프로그램은 v0.1.24 그대로입니다. 업무 모듈과 실행 중 앱은 변경하지 않습니다.
